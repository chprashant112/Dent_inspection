from __future__ import annotations
import json, queue, threading, time, traceback, copy
from pathlib import Path
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog, filedialog
import cv2
import numpy as np
from PIL import Image, ImageTk

from mobile_inspection_app.config import AppConfig, Recipe, load_config, save_config, safe_name, save_profile, load_profile, ROOT
from mobile_inspection_app.camera.camera_manager import CameraManager
from mobile_inspection_app.camera.simulated_camera import SimulatedCamera
from mobile_inspection_app.camera.basler_camera import BaslerCamera
from mobile_inspection_app.camera.calibration import CalibrationStore
from mobile_inspection_app.lighting.factory import build_engine
from mobile_inspection_app.capture.capture_manager import CaptureManager
from mobile_inspection_app.analysis.illumination import analyze_illumination
from mobile_inspection_app.analysis.correction import correct_illumination
from mobile_inspection_app.analysis.histogram import histogram_image
from mobile_inspection_app.segmentation.registry import create_segmentation_backends
from mobile_inspection_app.detection.discovery import discover_algorithms
from mobile_inspection_app.pipeline.pipeline import InspectionPipeline
from mobile_inspection_app.pipeline.profile import make_profile
from mobile_inspection_app.roi.model import ROI, ROIShape
from mobile_inspection_app.roi.shapes import rasterize_shape
from mobile_inspection_app.ui.theme import apply_theme, COLORS
from mobile_inspection_app.ui.widgets import ScrollableFrame, CollapsibleCard
from mobile_inspection_app.ui.roi_tools import ROIToolController

class MobileInspectionApp:
    def __init__(self, root: tk.Tk | None = None):
        self.root=root or tk.Tk()
        self.root.title("Industrial Defect Inspection & Lighting Control System")
        self.root.geometry("1400x850"); self.root.minsize(1100,700)
        try: self.root.state("zoomed")
        except tk.TclError: pass
        apply_theme(self.root)
        self.config=load_config()
        self.closed=False; self.busy=set(); self.log_queue=queue.Queue(); self.ui_queue=queue.Queue(); self._log_lines=[]
        self._preview_after_id=None; self._log_after_id=None; self._ui_after_id=None
        self.camera_manager=CameraManager(SimulatedCamera(0,self.config.camera1.width,self.config.camera1.height),SimulatedCamera(1,self.config.camera2.width,self.config.camera2.height),self.log)
        self.camera_manager.settings=[self.config.camera1,self.config.camera2]
        self.camera_running=False; self.last_pair=None; self.current_image=None; self.current_source_shape=None
        self._render_scale=1.0; self._zoom=1.0; self._photo=None; self._panel_photos={}; self._canvas_img_id=None
        self.roi_controller=ROIToolController(); self.draw_start=None; self.draw_current=None; self.calibration_points=[]
        self.draw_tool=tk.StringVar(value="Navigate"); self.shape_var=tk.StringVar(value="Rectangle"); self.role_var=tk.StringVar(value="Detection ROI")
        self.model_var=tk.StringVar(value=""); self.mode_var=tk.StringVar(value="TESTING")
        self.camera1_on=tk.BooleanVar(value=True); self.camera2_on=tk.BooleanVar(value=True)
        self.camera_backend_var=tk.StringVar(value="Simulated")
        self.preview_source=tk.StringVar(value=self.config.preview_source); self.stitch_mode=tk.StringVar(value=self.config.stitch_mode)
        self._last_source_signature=(self.preview_source.get(),self.stitch_mode.get())
        self.setting_camera=tk.StringVar(value="Camera 1")
        self.exposure_var=tk.StringVar(value=str(self.config.camera1.exposure_us)); self.gain_var=tk.StringVar(value=str(self.config.camera1.gain)); self.fps_var=tk.StringVar(value=str(self.config.camera1.fps)); self.width_var=tk.StringVar(value=str(self.config.camera1.width)); self.height_var=tk.StringVar(value=str(self.config.camera1.height)); self.full_sensor_var=tk.BooleanVar(value=bool(self.config.camera1.full_sensor))
        self.topology_var=tk.StringVar(value=self.config.topology); self.port_a_var=tk.StringVar(value=self.config.port_a); self.port_b_var=tk.StringVar(value=self.config.port_b); self.settle_var=tk.StringVar(value=str(self.config.settle_ms))
        self.lighting_engine=None; self.recipes_a=[Recipe(**r.__dict__) for r in self.config.recipes_a]; self.recipes_b=[Recipe(**r.__dict__) for r in self.config.recipes_b]
        self.recipe_vars=[]; self.recipe_b_vars=[]; self.recipe_selected=[]
        self.correct_var=tk.BooleanVar(value=self.config.correction_enabled); self.correction_strength=tk.DoubleVar(value=self.config.correction_strength); self.strict_channel_var=tk.BooleanVar(value=self.config.strict_per_channel); self.highlight_var=tk.BooleanVar(value=self.config.highlight_compression)
        self.segmentation_backends=create_segmentation_backends(); self.seg_backend_var=tk.StringVar(value=self.config.segmentation_backend)
        if self.seg_backend_var.get() not in self.segmentation_backends: self.seg_backend_var.set(next(iter(self.segmentation_backends)))
        self.segment_result=None; self.segment_vars={}; self.segmentation_enabled=tk.BooleanVar(value=True)
        self.detection_registry=discover_algorithms(ROOT/"algorithms",self.log)
        if not self.detection_registry.names(): self.log("ERROR","No detector plugins were loaded")
        self.detector_vars={n:tk.BooleanVar(value=(n=="RAW Laplacian V1")) for n in self.detection_registry.names()}
        self.detector_setting_name=tk.StringVar(value="RAW Laplacian V1" if "RAW Laplacian V1" in self.detection_registry.names() else (self.detection_registry.names()[0] if self.detection_registry.names() else ""))
        self.detector_params={n:{**self.detection_registry.get(n).DEFAULTS,**self.config.detector_params.get(n,{})} for n in self.detection_registry.names()}
        self.detector_setting_vars={}; self.inspection_analysis=None; self.last_detection_results=[]; self.last_detection_mask=None; self.last_corrected=None
        raw_params=self.detector_params.get("RAW Laplacian V1",{})
        self.quick_sensitivity=tk.DoubleVar(value=float(raw_params.get("k",2.8)))
        self.quick_min_magnitude=tk.DoubleVar(value=float(raw_params.get("min_magnitude",18.0)))
        self.quick_min_area=tk.DoubleVar(value=float(raw_params.get("min_area_px",20)))
        self.quick_box_padding=tk.DoubleVar(value=float(raw_params.get("box_expand_ratio",0.75))*100.0)
        self.live_detection_var=tk.BooleanVar(value=False)
        self._live_after_id=None; self._live_result_initialized=False
        self.calibration=CalibrationStore(ROOT/"config"/"calibration.json")
        self.regulator_stop=threading.Event(); self.regulator_active=False
        self.loupe_enabled=tk.BooleanVar(value=False); self.loupe_radius=tk.IntVar(value=18); self.loupe_window=None; self.loupe_label=None; self.loupe_photo=None
        self._build_ui()
        self.root.protocol("WM_DELETE_WINDOW",self.close)
        self.root.bind("<Escape>",self._escape); self.root.bind("<Return>",self._enter)
        self._preview_after_id=self.root.after(30,self._tick)
        self._log_after_id=self.root.after(100,self._drain_logs)
        self._ui_after_id=self.root.after(15,self._drain_ui_queue)
        self.log("INFO","Application ready. Simulated cameras are available without hardware.")
        self.log("WARN","Detection boxes are proposals for human review, not certified PASS/FAIL results.")
        self.log("WARN","8-channel lighting frame is UNCONFIRMED; simulator is safe, real hardware transmission is not validated.")

    def log(self, level: str, message: str):
        stamp=time.strftime("%H:%M:%S")
        self.log_queue.put((stamp,level,str(message)))

    def _post_ui(self, callback):
        """Queue a UI callback from workers without calling Tk from a worker thread."""
        if not self.closed: self.ui_queue.put(callback)

    def _drain_ui_queue(self):
        if self.closed: return
        try:
            while True:
                callback=self.ui_queue.get_nowait()
                try: callback()
                except Exception as exc: self.log("ERROR",f"UI callback failed: {exc}")
        except queue.Empty: pass
        self._ui_after_id=self.root.after(15,self._drain_ui_queue)

    def _drain_logs(self):
        if self.closed: return
        try:
            while True:
                stamp,level,msg=self.log_queue.get_nowait()
                self._log_lines.append(f"{stamp} [{level}] {msg}")
                self._log_lines=self._log_lines[-1000:]
                if hasattr(self,"log_text"):
                    self.log_text.configure(state="normal"); self.log_text.insert("end",self._log_lines[-1]+"\n"); self.log_text.see("end"); self.log_text.configure(state="disabled")
        except queue.Empty: pass
        self._log_after_id=self.root.after(100,self._drain_logs)

    def _build_ui(self):
        header=ttk.Frame(self.root,padding=(12,8)); header.pack(fill="x")
        ttk.Label(header,text="INDUSTRIAL DEFECT INSPECTION",font=("Segoe UI",14,"bold")).pack(side="left",padx=(0,16))
        ttk.Label(header,text="Model").pack(side="left")
        self.model_entry=ttk.Entry(header,textvariable=self.model_var,width=18); self.model_entry.pack(side="left",padx=5)
        ttk.Button(header,text="SET",style="Accent.TButton",command=self.set_model).pack(side="left",padx=(0,12))
        ttk.Label(header,text="Mode").pack(side="left")
        mode_combo=ttk.Combobox(header,textvariable=self.mode_var,values=["TESTING","DETECTION"],state="readonly",width=12)
        mode_combo.pack(side="left",padx=5); mode_combo.bind("<<ComboboxSelected>>",self._mode_changed)
        ttk.Button(header,text="SAVE PROFILE",command=self.save_current_profile).pack(side="left",padx=7)
        ttk.Button(header,text="LOAD PROFILE",command=self.load_current_profile).pack(side="left",padx=2)
        self.status_var=tk.StringVar(value="SIMULATOR READY")
        ttk.Label(header,textvariable=self.status_var,foreground=COLORS["success"]).pack(side="right")

        body=ttk.Frame(self.root,padding=(10,0,10,10)); body.pack(fill="both",expand=True)
        body.grid_columnconfigure(0,weight=7,uniform="main"); body.grid_columnconfigure(1,weight=3,uniform="main"); body.grid_rowconfigure(0,weight=1)
        left=ttk.Frame(body); left.grid(row=0,column=0,sticky="nsew",padx=(0,8)); left.grid_columnconfigure(0,weight=1)
        # Give the camera viewer most of the vertical space; the result tabs remain resizable below it.
        left.grid_rowconfigure(0,weight=0); left.grid_rowconfigure(1,weight=0); left.grid_rowconfigure(2,weight=7); left.grid_rowconfigure(3,weight=3); left.grid_rowconfigure(4,weight=0)
        toolbar=ttk.Frame(left); toolbar.grid(row=0,column=0,sticky="ew",pady=(0,2))
        toolrow=ttk.Frame(toolbar); toolrow.pack(fill="x",pady=(0,2))
        ttk.Label(toolrow,text="Tool").pack(side="left")
        tools=["Navigate","Inspection ROI","Camera ROI","Detection ROI","Mask ROI","Free Shape","Calibrate Scale"]
        tool_combo=ttk.Combobox(toolrow,textvariable=self.draw_tool,values=tools,state="readonly",width=14); tool_combo.pack(side="left",padx=4)
        ttk.Label(toolrow,text="Shape").pack(side="left",padx=(6,2))
        ttk.Combobox(toolrow,textvariable=self.shape_var,values=["Rectangle","Circle / Ellipse","Rounded Rectangle","Free Shape"],state="readonly",width=13).pack(side="left")
        ttk.Label(toolrow,text="Role").pack(side="left",padx=(6,2))
        ttk.Combobox(toolrow,textvariable=self.role_var,values=["Detection ROI","Mask ROI"],state="readonly",width=11).pack(side="left")
        ttk.Button(toolrow,text="LOUPE",command=self.toggle_loupe,style="Mini.TButton").pack(side="left",padx=(8,2))
        ttk.Label(toolrow,text="Radius").pack(side="left")
        ttk.Spinbox(toolrow,from_=8,to=40,textvariable=self.loupe_radius,width=3).pack(side="left",padx=2)
        viewrow=ttk.Frame(toolbar); viewrow.pack(fill="x")
        ttk.Label(viewrow,text="VIEW").pack(side="left",padx=(0,5))
        ttk.Button(viewrow,text="FIT",command=self.fit_view,style="Mini.TButton").pack(side="left",padx=2)
        ttk.Button(viewrow,text="−",command=lambda:self.zoom_by(.8),style="Mini.TButton").pack(side="left")
        self.zoom_label=ttk.Label(viewrow,text="FIT"); self.zoom_label.pack(side="left",padx=4)
        ttk.Button(viewrow,text="+",command=lambda:self.zoom_by(1.25),style="Mini.TButton").pack(side="left")
        ttk.Button(viewrow,text="100%",command=self.zoom_100,style="Mini.TButton").pack(side="left",padx=2)
        ttk.Separator(viewrow,orient="vertical").pack(side="left",fill="y",padx=7)
        ttk.Button(viewrow,text="UNDO POINT",command=self.undo_free_point,style="Mini.TButton").pack(side="left",padx=2)
        ttk.Button(viewrow,text="FINISH",command=self.finish_free_shape,style="Mini.TButton").pack(side="left",padx=2)
        ttk.Button(viewrow,text="CANCEL",command=self.cancel_tool,style="Mini.TButton").pack(side="left",padx=2)
        self.viewer_frame=ttk.Frame(left); self.viewer_frame.grid(row=2,column=0,sticky="nsew"); self.viewer_frame.grid_columnconfigure(0,weight=1); self.viewer_frame.grid_rowconfigure(0,weight=1)
        self.viewer_canvas=tk.Canvas(self.viewer_frame,bg=COLORS["viewer"],highlightthickness=0,cursor="crosshair")
        self.hscroll=ttk.Scrollbar(self.viewer_frame,orient="horizontal",command=self.viewer_canvas.xview); self.vscroll=ttk.Scrollbar(self.viewer_frame,orient="vertical",command=self.viewer_canvas.yview)
        self.viewer_canvas.configure(xscrollcommand=self.hscroll.set,yscrollcommand=self.vscroll.set)
        self.viewer_canvas.grid(row=0,column=0,sticky="nsew"); self.vscroll.grid(row=0,column=1,sticky="ns"); self.hscroll.grid(row=1,column=0,sticky="ew")
        self.viewer_canvas.bind("<Configure>",lambda e:self._render_preview())
        self.viewer_canvas.bind("<ButtonPress-1>",self._mouse_down); self.viewer_canvas.bind("<B1-Motion>",self._mouse_drag); self.viewer_canvas.bind("<ButtonRelease-1>",self._mouse_up); self.viewer_canvas.bind("<Motion>",self._mouse_motion)
        self.viewer_canvas.bind("<MouseWheel>",self._viewer_wheel)
        detbar=ttk.Frame(left); detbar.grid(row=3,column=0,sticky="nsew",pady=(5,0)); detbar.grid_columnconfigure(0,weight=1); detbar.grid_rowconfigure(0,weight=1)
        self.results_notebook=ttk.Notebook(detbar); self.results_notebook.grid(row=0,column=0,sticky="nsew")
        self.result_tab=self._make_image_tab("Result"); self.heatmap_tab=self._make_image_tab("Heatmap"); self.histogram_tab=self._make_image_tab("Histogram"); self.segments_tab=self._make_image_tab("Segments"); self.mask_tab=self._make_image_tab("Inspection Mask")
        self.defects_tab=ttk.Frame(self.results_notebook); self.results_notebook.add(self.defects_tab,text="Defects")
        cols=("algorithm","label","x","y","w","h","area","size")
        self.defects_tree=ttk.Treeview(self.defects_tab,columns=cols,show="headings",height=6)
        for c in cols: self.defects_tree.heading(c,text=c.title()); self.defects_tree.column(c,width=76,anchor="center")
        self.defects_tree.pack(fill="both",expand=True)
        actionbar=ttk.Frame(left); actionbar.grid(row=4,column=0,sticky="ew",pady=(5,0)); actionbar.grid_columnconfigure(0,weight=4); actionbar.grid_columnconfigure(1,weight=1)
        self.perform_btn=ttk.Button(actionbar,text="PERFORM DETECTION",style="Accent.TButton",command=self.perform_detection); self.perform_btn.grid(row=0,column=0,sticky="ew",padx=(0,4))
        ttk.Button(actionbar,text="SAVE RESULT",command=self.save_detection_result).grid(row=0,column=1,sticky="ew")

        self.right_scroll=ScrollableFrame(body); self.right_scroll.grid(row=0,column=1,sticky="nsew")
        self.cards={}
        for name,opened in [("CAMERA",True),("IMAGE PROCESSING",False),("LIGHTING",False),("CAPTURE SET",False),("ROIs",False),("SEGMENTATION AND DETECTION",False),("DETECTION MODE",False),("SYSTEM LOG",False)]:
            card=CollapsibleCard(self.right_scroll.inner,name,opened); card.pack(fill="x",pady=(0,7)); self.cards[name]=card
        self._build_camera_card(self.cards["CAMERA"].body)
        self._build_processing_card(self.cards["IMAGE PROCESSING"].body)
        self._build_lighting_card(self.cards["LIGHTING"].body)
        self._build_capture_card(self.cards["CAPTURE SET"].body)
        self._build_roi_card(self.cards["ROIs"].body)
        self._build_detection_card(self.cards["SEGMENTATION AND DETECTION"].body)
        self._build_detection_mode_card(self.cards["DETECTION MODE"].body)
        self._build_log_card(self.cards["SYSTEM LOG"].body)

    def _make_image_tab(self,title):
        frame=ttk.Frame(self.results_notebook); self.results_notebook.add(frame,text=title)
        label=ttk.Label(frame,text="No result yet",anchor="center"); label.pack(fill="both",expand=True)
        return frame,label

    def _build_camera_card(self,p):
        row=ttk.Frame(p,style="Card.TFrame"); row.pack(fill="x")
        ttk.Checkbutton(row,text="Camera 1",variable=self.camera1_on).pack(side="left")
        ttk.Checkbutton(row,text="Camera 2",variable=self.camera2_on).pack(side="left",padx=6)
        ttk.Button(row,text="START",style="Success.TButton",command=self.start_cameras).pack(side="left",padx=2)
        ttk.Button(row,text="STOP",style="Danger.TButton",command=self.stop_cameras).pack(side="left",padx=2)
        ttk.Label(p,text="Camera backend",style="Card.TLabel").pack(anchor="w",pady=(7,1))
        ttk.Combobox(p,textvariable=self.camera_backend_var,values=["Simulated","Basler"],state="readonly").pack(fill="x")
        ttk.Label(p,text="Preview source",style="Card.TLabel").pack(anchor="w",pady=(7,1))
        combo=ttk.Combobox(p,textvariable=self.preview_source,values=["Camera 1","Camera 2","Stitched"],state="readonly"); combo.pack(fill="x")
        combo.bind("<<ComboboxSelected>>",self._source_changed)
        ttk.Label(p,text="Stitching mode",style="Card.TLabel").pack(anchor="w",pady=(5,1))
        sm=ttk.Combobox(p,textvariable=self.stitch_mode,values=["Auto feature stitch","Aligned side-by-side","Vertical aligned join"],state="readonly"); sm.pack(fill="x"); sm.bind("<<ComboboxSelected>>",self._source_changed)
        ttk.Label(p,text="Per-camera settings (apply separately)",style="Card.TLabel").pack(anchor="w",pady=(8,3))
        setting_combo=ttk.Combobox(p,textvariable=self.setting_camera,values=["Camera 1","Camera 2"],state="readonly")
        setting_combo.pack(fill="x"); setting_combo.bind("<<ComboboxSelected>>",self._load_camera_settings_ui)
        ttk.Checkbutton(p,text="Basler: use full sensor / full field of view (recommended)",variable=self.full_sensor_var).pack(anchor="w",pady=(4,2))
        ttk.Label(p,text="When enabled, Width and Height are ignored for Basler and the camera uses its maximum sensor ROI. Uncheck only when you intentionally want a cropped sensor region.",style="Sub.TLabel",wraplength=265).pack(anchor="w",pady=(0,3))
        grid=ttk.Frame(p,style="Card.TFrame"); grid.pack(fill="x",pady=3)
        entries=[("Exposure µs",self.exposure_var),("Gain",self.gain_var),("FPS",self.fps_var),("Width",self.width_var),("Height",self.height_var)]
        for i,(label,var) in enumerate(entries):
            ttk.Label(grid,text=label,style="Card.TLabel").grid(row=i//2,column=(i%2)*2,sticky="w",padx=(0,4),pady=2)
            ttk.Entry(grid,textvariable=var,width=8).grid(row=i//2,column=(i%2)*2+1,sticky="ew",padx=(0,6),pady=2)
        grid.columnconfigure(1,weight=1); grid.columnconfigure(3,weight=1)
        ttk.Button(p,text="APPLY CAMERA SETTINGS",command=self.apply_camera_settings).pack(fill="x",pady=3)
        ttk.Button(p,text="CALIBRATE SCALE (mm / px)",command=self.start_calibration).pack(fill="x",pady=2)
        ttk.Button(p,text="LOCK STITCH STATE",command=self.lock_stitch).pack(fill="x",pady=2)
        ttk.Label(p,text="Basler support requires pypylon. Simulator is active by default.",style="Sub.TLabel",wraplength=260).pack(anchor="w",pady=(5,0))

    def _build_processing_card(self,p):
        ttk.Button(p,text="ANALYZE ILLUMINATION",style="Accent.TButton",command=self.analyze_current).pack(fill="x",pady=2)
        ttk.Checkbutton(p,text="Enable illumination correction",variable=self.correct_var).pack(anchor="w",pady=2)
        ttk.Label(p,text="Correction strength",style="Card.TLabel").pack(anchor="w")
        ttk.Scale(p,from_=0,to=1,variable=self.correction_strength,orient="horizontal").pack(fill="x")
        ttk.Checkbutton(p,text="Highlight compression",variable=self.highlight_var).pack(anchor="w")
        ttk.Checkbutton(p,text="Strict per-channel B/G/R verdict",variable=self.strict_channel_var).pack(anchor="w")
        regrow=ttk.Frame(p,style="Card.TFrame"); regrow.pack(fill="x",pady=3)
        ttk.Button(regrow,text="AUTO REGULATE (ONCE)",command=self.start_auto_regulator,style="Mini.TButton").pack(side="left",fill="x",expand=True)
        self.cont_regulator_btn=ttk.Button(regrow,text="START CONTINUOUS",command=self.toggle_continuous_regulator,style="Mini.TButton"); self.cont_regulator_btn.pack(side="left",fill="x",expand=True,padx=(3,0))
        self.illumination_status=tk.StringVar(value="No analysis yet")
        ttk.Label(p,textvariable=self.illumination_status,style="Card.TLabel",wraplength=260).pack(anchor="w",pady=5)
        ttk.Label(p,text="Illumination correction preserves fine details but cannot recover clipped highlights. Severe glare needs optical changes.",style="Sub.TLabel",wraplength=260).pack(anchor="w")

    def _build_lighting_card(self,p):
        ttk.Label(p,text="Controller topology",style="Card.TLabel").pack(anchor="w")
        topo=ttk.Combobox(p,textvariable=self.topology_var,values=["LIGHT_SINGLE_4","LIGHT_DUAL_4","LIGHT_SINGLE_8 (UNVERIFIED)"],state="readonly"); topo.pack(fill="x"); topo.bind("<<ComboboxSelected>>",self._topology_changed)
        ttk.Label(p,text="Port A",style="Card.TLabel").pack(anchor="w",pady=(4,0)); ttk.Entry(p,textvariable=self.port_a_var).pack(fill="x")
        ttk.Label(p,text="Port B (Dual 4 only)",style="Card.TLabel").pack(anchor="w",pady=(4,0)); ttk.Entry(p,textvariable=self.port_b_var).pack(fill="x")
        ttk.Label(p,text="Settle time ms",style="Card.TLabel").pack(anchor="w",pady=(4,0)); ttk.Spinbox(p,from_=0,to=5000,textvariable=self.settle_var).pack(fill="x")
        row=ttk.Frame(p,style="Card.TFrame"); row.pack(fill="x",pady=5)
        ttk.Button(row,text="CONNECT",style="Success.TButton",command=self.connect_lights).pack(side="left",expand=True,fill="x")
        ttk.Button(row,text="READY / WHITE",command=self.lights_ready).pack(side="left",expand=True,fill="x",padx=3)
        ttk.Button(row,text="ALL OFF",style="Danger.TButton",command=self.lights_off).pack(side="left",expand=True,fill="x")
        self.light_status=tk.StringVar(value="Disconnected")
        ttk.Label(p,textvariable=self.light_status,style="Card.TLabel",wraplength=260).pack(anchor="w")
        ttk.Separator(p).pack(fill="x",pady=5)
        ttk.Label(p,text="Light A / Left recipes (1–8)",style="Card.TLabel").pack(anchor="w")
        self.recipe_frame=ttk.Frame(p,style="Card.TFrame"); self.recipe_frame.pack(fill="x")
        ttk.Button(p,text="ADD RECIPE",command=self.add_recipe,style="Mini.TButton").pack(side="left",pady=3)
        ttk.Button(p,text="REMOVE LAST",command=self.remove_recipe,style="Mini.TButton").pack(side="left",padx=4,pady=3)
        ttk.Label(p,text="Dual 4 uses port A/B separately; Single 8 writes an UNCONFIRMED 8-channel frame.",style="Sub.TLabel",wraplength=260).pack(anchor="w",pady=(4,0))
        self._rebuild_recipe_rows()

    def _build_capture_card(self,p):
        self.capture_folder_var=tk.StringVar(value="Captures save under captures/{model}/setN/")
        ttk.Label(p,textvariable=self.capture_folder_var,style="Card.TLabel",wraplength=260).pack(anchor="w")
        ttk.Button(p,text="CAPTURE SELECTED SET",style="Accent.TButton",command=self.capture_selected).pack(fill="x",pady=4)
        ttk.Button(p,text="CAPTURE ONE TEST IMAGE",command=self.capture_one_testing).pack(fill="x",pady=2)
        self.capture_status=tk.StringVar(value="No capture yet")
        ttk.Label(p,textvariable=self.capture_status,style="Card.TLabel",wraplength=260).pack(anchor="w",pady=3)

    def _build_roi_card(self,p):
        self.roi_summary_var=tk.StringVar(value="0 drawn · 0 active")
        ttk.Label(p,textvariable=self.roi_summary_var,style="Card.TLabel").pack(anchor="w")
        ttk.Label(p,text="Inspection ROI: green • Camera ROI: blue",style="Card.TLabel",wraplength=260).pack(anchor="w")
        ttk.Label(p,text="DETECT includes area; MASK excludes area. Draw several of either. Free Shape: click vertices, press Enter to finish. Drag and click coordinates are source pixels.",style="Sub.TLabel",wraplength=260).pack(anchor="w",pady=3)
        row=ttk.Frame(p,style="Card.TFrame"); row.pack(fill="x",pady=2)
        ttk.Button(row,text="ALL",command=lambda:self.set_all_rois(True),style="Mini.TButton").pack(side="left")
        ttk.Button(row,text="NONE",command=lambda:self.set_all_rois(False),style="Mini.TButton").pack(side="left",padx=3)
        ttk.Button(row,text="CLEAR ALL",command=self.clear_rois,style="Mini.TButton").pack(side="left")
        self.roi_list_frame=ttk.Frame(p,style="Card.TFrame"); self.roi_list_frame.pack(fill="x",pady=4)
        self._refresh_roi_list()

    def _build_detection_card(self,p):
        ttk.Label(p,text="Segmentation backend",style="Card.TLabel").pack(anchor="w")
        ttk.Combobox(p,textvariable=self.seg_backend_var,values=list(self.segmentation_backends),state="readonly").pack(fill="x")
        row=ttk.Frame(p,style="Card.TFrame"); row.pack(fill="x",pady=4)
        ttk.Button(row,text="SEGMENT",command=self.run_segmentation,style="Accent.TButton").pack(side="left",expand=True,fill="x")
        ttk.Checkbutton(row,text="Re-segment on detection",variable=self.segmentation_enabled).pack(side="left",padx=4)
        self.segment_list_frame=ttk.Frame(p,style="Card.TFrame"); self.segment_list_frame.pack(fill="x")
        self.segment_status=tk.StringVar(value="No segmentation yet")
        ttk.Label(p,textvariable=self.segment_status,style="Card.TLabel",wraplength=260).pack(anchor="w",pady=3)
        ttk.Separator(p).pack(fill="x",pady=5)
        ttk.Label(p,text="Detector plugins (multi-select)",style="Card.TLabel").pack(anchor="w")
        ttk.Button(p,text="REFRESH ALGORITHMS",command=self.refresh_algorithms,style="Mini.TButton").pack(anchor="w",pady=2)
        self.detector_list_frame=ttk.Frame(p,style="Card.TFrame"); self.detector_list_frame.pack(fill="x")
        self._refresh_detector_list()

        # Operator-facing controls: tune the common Laplacian parameters without typing numbers.
        quick=ttk.Frame(p,style="Card.TFrame",padding=(7,7)); quick.pack(fill="x",pady=(5,3))
        ttk.Label(quick,text="LIVE DETECTION · QUICK TUNING",style="Card.TLabel",font=("Segoe UI",10,"bold")).pack(anchor="w")
        ttk.Label(quick,text="Lower k = more sensitive. These sliders update RAW Laplacian V1 immediately.",style="Sub.TLabel",wraplength=255).pack(anchor="w",pady=(1,4))
        self._make_tuning_slider(quick,"Sensitivity (k)",self.quick_sensitivity,0.5,6.0,lambda v:f"{float(v):.1f}","quick_sensitivity_value")
        self._make_tuning_slider(quick,"Minimum edge strength",self.quick_min_magnitude,0,100,lambda v:f"{float(v):.0f}","quick_min_magnitude_value")
        self._make_tuning_slider(quick,"Minimum defect area (px)",self.quick_min_area,1,1500,lambda v:f"{int(float(v))}","quick_min_area_value")
        self._make_tuning_slider(quick,"Box padding (%)",self.quick_box_padding,0,150,lambda v:f"{float(v):.0f}%","quick_box_padding_value",display_transform=lambda v:float(v)/100.0)
        row=ttk.Frame(quick,style="Card.TFrame"); row.pack(fill="x",pady=(5,1))
        ttk.Checkbutton(row,text="Run continuously on live frames",variable=self.live_detection_var,command=self._live_detection_toggle).pack(anchor="w")
        ttk.Label(quick,text="Requires at least one active Detection ROI or selected segmentation region. Results remain candidate proposals for review.",style="Sub.TLabel",wraplength=255).pack(anchor="w",pady=(3,0))

        self.advanced_settings_card=CollapsibleCard(p,"ADVANCED PLUGIN SETTINGS",False); self.advanced_settings_card.pack(fill="x",pady=(4,0))
        advanced=self.advanced_settings_card.body
        ttk.Label(advanced,text="Settings for selected plug-in",style="Card.TLabel").pack(anchor="w")
        self.setting_selector=ttk.Combobox(advanced,textvariable=self.detector_setting_name,values=self.detection_registry.names(),state="readonly"); self.setting_selector.pack(fill="x"); self.setting_selector.bind("<<ComboboxSelected>>",lambda e:self._build_detector_settings())
        self.detector_settings_frame=ttk.Frame(advanced,style="Card.TFrame"); self.detector_settings_frame.pack(fill="x",pady=3)
        self._build_detector_settings()
        ttk.Label(advanced,text="RAW Laplacian and Canny are heuristic candidates. YOLO requires compatible .pt weights and optional ultralytics/PyTorch.",style="Sub.TLabel",wraplength=255).pack(anchor="w",pady=4)

    def _make_tuning_slider(self,parent,title,var,from_,to,formatter,value_attr,display_transform=None):
        row=ttk.Frame(parent,style="Card.TFrame"); row.pack(fill="x",pady=(3,1))
        ttk.Label(row,text=title,style="Card.TLabel").pack(side="left",anchor="w")
        value_label=ttk.Label(row,text=formatter(var.get()),style="Card.TLabel",width=6,anchor="e"); value_label.pack(side="right")
        setattr(self,value_attr,value_label)
        scale=ttk.Scale(parent,from_=from_,to=to,orient="horizontal",variable=var,
                        command=lambda value:self._quick_tuning_changed())
        scale.pack(fill="x",padx=(2,4),pady=(0,2))
        return scale

    def _quick_tuning_changed(self):
        name="RAW Laplacian V1"
        if name not in self.detector_params: return
        # The padding slider is in percent to be intuitive for operators.
        values={"k":float(self.quick_sensitivity.get()),
                "min_magnitude":float(self.quick_min_magnitude.get()),
                "min_area_px":int(round(self.quick_min_area.get())),
                "box_expand_ratio":float(self.quick_box_padding.get())/100.0}
        self.detector_params[name].update(values)
        labels=(("quick_sensitivity_value",f"{values['k']:.1f}"),
                ("quick_min_magnitude_value",f"{values['min_magnitude']:.0f}"),
                ("quick_min_area_value",f"{values['min_area_px']}"),
                ("quick_box_padding_value",f"{values['box_expand_ratio']*100:.0f}%"))
        for attr,label in labels:
            widget=getattr(self,attr,None)
            if widget is not None:
                try: widget.configure(text=label)
                except tk.TclError: pass
        # Keep the advanced numeric fields in sync so a later profile/detection read cannot undo slider edits.
        for key,value in values.items():
            field=self.detector_setting_vars.get(name,{}).get(key)
            if field:
                var,kind,spec=field
                try: var.set(str(value))
                except tk.TclError: pass

    def _sync_quick_tuning_from_params(self):
        params=self.detector_params.get("RAW Laplacian V1",{})
        try:
            self.quick_sensitivity.set(float(params.get("k",2.8)))
            self.quick_min_magnitude.set(float(params.get("min_magnitude",18.0)))
            self.quick_min_area.set(float(params.get("min_area_px",20)))
            self.quick_box_padding.set(float(params.get("box_expand_ratio",.75))*100.0)
            self._quick_tuning_changed()
        except (ValueError,tk.TclError):
            pass

    def _live_detection_toggle(self):
        if not self.live_detection_var.get():
            if self._live_after_id is not None:
                try: self.root.after_cancel(self._live_after_id)
                except tk.TclError: pass
                self._live_after_id=None
            self.status_var.set("LIVE DETECTION STOPPED")
            self._render_preview()
            return
        if self.current_image is None:
            self.live_detection_var.set(False)
            messagebox.showwarning("Live detection","Start the camera before enabling live detection.",parent=self.root)
            return
        if not any(var.get() for var in self.detector_vars.values()):
            self.live_detection_var.set(False)
            messagebox.showwarning("Live detection","Select at least one detector plug-in first.",parent=self.root)
            return
        self._live_result_initialized=False
        self.status_var.set("LIVE DETECTION STARTING…")
        self.log("INFO","Live detection enabled; frames are processed on a worker thread.")
        self._live_after_id=self.root.after(100,self._live_detection_tick)

    def _live_detection_tick(self):
        self._live_after_id=None
        if self.closed or not self.live_detection_var.get(): return
        # Schedule the next pass first. If a pass is still running, this tick simply skips it.
        self._live_after_id=self.root.after(350,self._live_detection_tick)
        if self.current_image is None or ("detection" in self.busy) or ("capture" in self.busy) or ("segmentation" in self.busy): return
        selected_detectors=[n for n,v in self.detector_vars.items() if v.get()]
        if not selected_detectors:
            self.live_detection_var.set(False); self.status_var.set("LIVE DETECTION STOPPED — no detector selected")
            return
        active_detection_roi=any(r.role=="detect" and r.enabled for r in self.roi_controller.rois)
        active_segments=any(var.get() for var in self.segment_vars.values())
        if not active_detection_roi and not active_segments:
            if self.segmentation_enabled.get() and self.segment_result is None and "segmentation" not in self.busy:
                self.status_var.set("LIVE DETECTION — preparing segmentation…")
                self.run_segmentation()
                return
            self.live_detection_var.set(False)
            self.status_var.set("LIVE DETECTION STOPPED — activate a Detection ROI or segment")
            self.log("WARN","Live detection stopped because no Detection ROI or segmentation region is active.")
            messagebox.showinfo("Live detection","Draw and enable a Detection ROI, or run SEGMENT and tick one or more regions, then enable live detection.",parent=self.root)
            return
        try:
            settings=self._snapshot_detection_settings()
            if not settings["detectors"]: raise ValueError("Select at least one detector plug-in")
            image=self.current_image.copy()
        except Exception as exc:
            self.live_detection_var.set(False); self.status_var.set("LIVE DETECTION STOPPED")
            self.log("ERROR",f"Live detection setup failed: {exc}")
            return
        self.busy.add("detection")
        def worker():
            try:
                working,mask,results,segresult=self._process_image_for_detection(image,settings)
                combined=self._combine_result_images(working,results)
                self._post_ui(lambda:self._detection_done(combined,working,mask,results,segresult,settings["source_view"],live=True))
            except Exception as exc:
                self._post_ui(lambda exc=exc:self._live_detection_error(exc))
            finally:
                self.busy.discard("detection")
        threading.Thread(target=worker,daemon=True,name="live-detection").start()

    def _live_detection_error(self,exc):
        self.log("ERROR",f"Live detection stopped: {exc}")
        self.live_detection_var.set(False)
        if self._live_after_id is not None:
            try: self.root.after_cancel(self._live_after_id)
            except tk.TclError: pass
            self._live_after_id=None
        self.status_var.set("LIVE DETECTION STOPPED — review active ROIs")
        messagebox.showwarning("Live detection",str(exc),parent=self.root)

    def _build_detection_mode_card(self,p):
        ttk.Label(p,text="DETECTION mode uses the saved/current profile settings to capture selected recipes, then inspect each image. Capture + inspect is performed in the worker thread.",style="Card.TLabel",wraplength=260).pack(anchor="w")
        ttk.Button(p,text="CAPTURE + INSPECT SELECTED LIGHTS",command=self.capture_and_inspect,style="Accent.TButton").pack(fill="x",pady=4)
        ttk.Label(p,text="A detected box is a proposal for human review, not an automated certified verdict.",style="Sub.TLabel",wraplength=260).pack(anchor="w")

    def _build_log_card(self,p):
        self.log_text=tk.Text(p,height=10,wrap="word",bg="#10131a",fg="#e5e7eb",font=("Consolas",8),relief="flat")
        self.log_text.pack(fill="both",expand=True); self.log_text.configure(state="disabled")
        ttk.Button(p,text="CLEAR LOG",command=self.clear_log,style="Mini.TButton").pack(anchor="e",pady=(3,0))

    def _refresh_detector_list(self):
        for w in self.detector_list_frame.winfo_children(): w.destroy()
        for name in self.detection_registry.names():
            if name not in self.detector_vars: self.detector_vars[name]=tk.BooleanVar(value=(name=="RAW Laplacian V1")); self.detector_params[name]=self.detection_registry.get(name).create_default()
            ttk.Checkbutton(self.detector_list_frame,text=name,variable=self.detector_vars[name]).pack(anchor="w")
        if hasattr(self,"setting_selector"):
            self.setting_selector.configure(values=self.detection_registry.names())

    def _build_detector_settings(self):
        if not hasattr(self,"detector_settings_frame"): return
        for w in self.detector_settings_frame.winfo_children(): w.destroy()
        name=self.detector_setting_name.get()
        if not name or name not in self.detection_registry.items(): return
        algo=self.detection_registry.get(name); params=self.detector_params.setdefault(name,algo.create_default()); self.detector_setting_vars[name]={}
        for spec in algo.settings():
            key=spec.get("key"); kind=spec.get("kind"); val=params.get(key,"")
            row=ttk.Frame(self.detector_settings_frame,style="Card.TFrame"); row.pack(fill="x",pady=1)
            ttk.Label(row,text=spec.get("label",key),style="Card.TLabel",wraplength=130).pack(side="left",fill="x",expand=True)
            if kind=="bool":
                var=tk.BooleanVar(value=bool(val)); ttk.Checkbutton(row,variable=var).pack(side="right"); self.detector_setting_vars[name][key]=(var,kind,spec)
            elif kind=="choice":
                var=tk.StringVar(value=str(val)); widget=ttk.Combobox(row,textvariable=var,values=[str(x) for x in spec.get("values",[])],state="readonly",width=9); widget.pack(side="right"); self.detector_setting_vars[name][key]=(var,kind,spec)
            elif kind=="file":
                var=tk.StringVar(value=str(val)); entry=ttk.Entry(row,textvariable=var,width=10); entry.pack(side="left",fill="x",expand=True)
                ttk.Button(row,text="…",command=lambda v=var:self._choose_file(v),style="Mini.TButton").pack(side="right"); self.detector_setting_vars[name][key]=(var,kind,spec)
            else:
                var=tk.StringVar(value=str(val)); ttk.Entry(row,textvariable=var,width=10).pack(side="right"); self.detector_setting_vars[name][key]=(var,kind,spec)
        ttk.Button(self.detector_settings_frame,text="APPLY SETTINGS",command=self._read_detector_settings,style="Mini.TButton").pack(anchor="e",pady=2)

    def _choose_file(self,var):
        name=filedialog.askopenfilename(title="Select detector weights",filetypes=[("PyTorch weights","*.pt"),("All files","*.*")])
        if name: var.set(name)

    def _read_detector_settings(self):
        name=self.detector_setting_name.get()
        for key,(var,kind,spec) in self.detector_setting_vars.get(name,{}).items():
            try:
                value=var.get()
                if kind=="bool": value=bool(value)
                elif kind=="int": value=int(float(value))
                elif kind=="float": value=float(value)
                elif kind=="choice":
                    old=self.detector_params[name].get(key)
                    value=type(old)(value) if old is not None and not isinstance(old,str) else value
                self.detector_params[name][key]=value
            except Exception as exc: messagebox.showerror("Invalid setting",f"{key}: {exc}",parent=self.root); return
        if name=="RAW Laplacian V1": self._sync_quick_tuning_from_params()
        self.log("INFO",f"Updated {name} parameters")

    def _rebuild_recipe_rows(self):
        if not hasattr(self,"recipe_frame"): return
        for w in self.recipe_frame.winfo_children(): w.destroy()
        self.recipe_vars=[]; self.recipe_b_vars=[]; self.recipe_selected=[]
        dual=self.topology_var.get().startswith("LIGHT_DUAL_4") or self.topology_var.get().startswith("LIGHT_SINGLE_8")
        head=ttk.Frame(self.recipe_frame,style="Card.TFrame"); head.pack(fill="x")
        for txt,width in [("✓",2),("Name",9),("R",4),("G",4),("B",4)]: ttk.Label(head,text=txt,width=width,style="Sub.TLabel").pack(side="left")
        if dual:
            ttk.Label(head,text="B name",style="Sub.TLabel").pack(side="left",padx=(3,0))
            ttk.Label(head,text="R2 G2 B2",style="Sub.TLabel").pack(side="left",padx=(3,0))
        for i,recipe in enumerate(self.recipes_a[:8]):
            row=ttk.Frame(self.recipe_frame,style="Card.TFrame"); row.pack(fill="x",pady=1)
            ev=tk.BooleanVar(value=recipe.enabled); ttk.Checkbutton(row,variable=ev).pack(side="left"); namev=tk.StringVar(value=recipe.name); ttk.Entry(row,textvariable=namev,width=9).pack(side="left",padx=2)
            av=[]
            for val in recipe.rgb():
                v=tk.StringVar(value=str(val)); ttk.Spinbox(row,from_=0,to=255,textvariable=v,width=4).pack(side="left",padx=1); av.append(v)
            bv=[]; namebv=None
            rb=self.recipes_b[i] if i<len(self.recipes_b) else recipe
            if dual:
                namebv=tk.StringVar(value=rb.name); ttk.Entry(row,textvariable=namebv,width=7).pack(side="left",padx=(3,1))
                for val in rb.rgb():
                    v=tk.StringVar(value=str(val)); ttk.Spinbox(row,from_=0,to=255,textvariable=v,width=3).pack(side="left",padx=1); bv.append(v)
            ttk.Button(row,text="T",command=lambda j=i:self.test_recipe(j),style="Mini.TButton").pack(side="right",padx=(2,0))
            selected=tk.BooleanVar(value=recipe.enabled and rb.enabled); self.recipe_selected.append(selected)
            self.recipe_vars.append({"enabled":ev,"name":namev,"name_b":namebv,"rgb":av,"rgb_b":bv})
        # Explicit capture selector is kept separate from recipe's enabled flag.
        caprow=ttk.Frame(self.recipe_frame,style="Card.TFrame"); caprow.pack(fill="x",pady=(4,0))
        ttk.Label(caprow,text="Capture selected:",style="Card.TLabel").pack(side="left")
        for i,v in enumerate(self.recipe_selected): ttk.Checkbutton(caprow,text=str(i+1),variable=v).pack(side="left")
        self._topology_changed(None, rebuild=False)

    def _topology_changed(self,event=None,rebuild=True):
        val=self.topology_var.get()
        if rebuild and hasattr(self,"recipe_frame") and getattr(self,"recipe_vars",None):
            try: self._refresh_recipe_model()
            except Exception as exc: self.log("WARN",f"Recipe values could not be saved during topology switch: {exc}")
        if val.startswith("LIGHT_SINGLE_8"):
            self.topology_var.set("LIGHT_SINGLE_8")
            self.light_status.set("UNVERIFIED 8-channel framing — simulator recommended")
        if rebuild and hasattr(self,"recipe_frame"): self._rebuild_recipe_rows()

    def _build_dummy(self): pass

    def _refresh_roi_list(self):
        if not hasattr(self,"roi_list_frame"): return
        for w in self.roi_list_frame.winfo_children(): w.destroy()
        rows=[]
        for roi in [self.roi_controller.inspection,self.roi_controller.camera,*self.roi_controller.rois]:
            if roi is not None: rows.append(roi)
        self.roi_summary_var.set(f"{len(rows)} drawn · {sum(1 for r in rows if r.enabled)} active")
        if not rows:
            ttk.Label(self.roi_list_frame,text="No ROIs drawn",style="Sub.TLabel").pack(anchor="w"); return
        for roi in rows:
            row=ttk.Frame(self.roi_list_frame,style="Card.TFrame"); row.pack(fill="x",pady=1)
            var=tk.BooleanVar(value=roi.enabled)
            def toggle(r=roi,v=var): r.enabled=bool(v.get()); self._render_preview()
            ttk.Checkbutton(row,variable=var,command=toggle).pack(side="left")
            name_var=tk.StringVar(value=roi.name)
            name_entry=ttk.Entry(row,textvariable=name_var,width=11)
            name_entry.pack(side="left",fill="x",expand=True,padx=(0,2))
            name_entry.bind("<FocusOut>",lambda e,r=roi,v=name_var:setattr(r,"name",v.get().strip() or r.name))
            ttk.Label(row,text=roi.role.upper(),style="Sub.TLabel").pack(side="left",padx=2)
            if roi.shape.kind.lower() in ("rounded_rectangle","rounded rectangle","rounded"):
                radius_var=tk.StringVar(value=str(int(roi.shape.radius)))
                spin=ttk.Spinbox(row,from_=1,to=100,textvariable=radius_var,width=3)
                spin.pack(side="right")
                def update_radius(e=None,r=roi,v=radius_var):
                    try: r.shape.radius=max(1,int(float(v.get())))
                    except Exception: pass
                    self._render_preview()
                spin.bind("<FocusOut>",update_radius); spin.bind("<Return>",update_radius)
            if roi.role not in ("inspection","camera"):
                ttk.Button(row,text="×",style="Mini.TButton",command=lambda rid=roi.id:self.delete_roi(rid)).pack(side="right")

    def _refresh_segment_list(self):
        for w in self.segment_list_frame.winfo_children(): w.destroy()
        if not self.segment_result:
            ttk.Label(self.segment_list_frame,text="Run segmentation to create region masks",style="Sub.TLabel",wraplength=260).pack(anchor="w"); return
        for seg in self.segment_result.segments:
            var=self.segment_vars.setdefault(seg.id,tk.BooleanVar(value=(seg.id in (1,3,4))))
            ttk.Checkbutton(self.segment_list_frame,text=f"{seg.id}. {seg.name} ({seg.area_px:,} px)",variable=var).pack(anchor="w")

    def _refresh_recipe_model(self):
        # Copy live controls into recipe dataclasses before any operation.
        for i,row in enumerate(self.recipe_vars):
            if i>=len(self.recipes_a): continue
            try:
                self.recipes_a[i]=Recipe(bool(row["enabled"].get()),row["name"].get().strip() or f"Light{i+1}",*[max(0,min(255,int(float(v.get())))) for v in row["rgb"]])
                if row["rgb_b"]:
                    while len(self.recipes_b)<=i: self.recipes_b.append(Recipe(**self.recipes_a[i].__dict__))
                    bname=(row["name_b"].get().strip() if row.get("name_b") is not None else self.recipes_a[i].name) or f"Light{i+1}"
                    self.recipes_b[i]=Recipe(self.recipes_a[i].enabled,bname,*[max(0,min(255,int(float(v.get())))) for v in row["rgb_b"]])
                elif i>=len(self.recipes_b): self.recipes_b.append(Recipe(**self.recipes_a[i].__dict__))
                if i<len(self.recipe_selected): self.recipe_selected[i].set(bool(self.recipe_selected[i].get()) and self.recipes_a[i].enabled)
            except Exception as exc: raise ValueError(f"Invalid recipe row {i+1}: {exc}") from exc

    def add_recipe(self):
        if len(self.recipes_a)>=8: return messagebox.showinfo("Recipes","Maximum is 8 recipes",parent=self.root)
        n=len(self.recipes_a)+1; self.recipes_a.append(Recipe(True,f"Light{n}",255,255,255)); self.recipes_b.append(Recipe(True,f"Light{n}",255,255,255)); self._rebuild_recipe_rows()
    def remove_recipe(self):
        if len(self.recipes_a)<=1: return messagebox.showinfo("Recipes","At least one recipe is required",parent=self.root)
        self.recipes_a.pop(); self.recipes_b.pop(); self._rebuild_recipe_rows()

    def _mode_changed(self,event=None):
        mode=self.mode_var.get()
        visible={"CAMERA","LIGHTING","DETECTION MODE","SYSTEM LOG"} if mode=="DETECTION" else set(self.cards)
        for name,card in self.cards.items():
            card.pack_forget()
            if name in visible: card.pack(fill="x",pady=(0,7))
        self.log("INFO",f"Mode switched to {mode}")

    def set_model(self):
        model=self.model_var.get().strip()
        if not model: return messagebox.showwarning("Model required","Enter a model name before capture/profile operations.",parent=self.root)
        self.model_var.set(model); self.capture_folder_var.set(f"captures/{safe_name(model)}/setN/"); self.status_var.set(f"MODEL: {model}"); self.log("INFO",f"Model set to {model}")

    def _source_changed(self,event=None):
        new_signature=(self.preview_source.get(),self.stitch_mode.get())
        if new_signature==self._last_source_signature: return
        has_geometry=bool(self.roi_controller.inspection or self.roi_controller.camera or self.roi_controller.rois or self.segment_result)
        if has_geometry:
            if not messagebox.askyesno("Clear ROIs?","Changing view/stitch coordinates can invalidate ROIs and segment masks. Clear them and continue?",parent=self.root):
                self.preview_source.set(self._last_source_signature[0]); self.stitch_mode.set(self._last_source_signature[1]); return
            self.clear_rois()
        else:
            self.segment_result=None; self.segment_vars.clear(); self._refresh_segment_list()
        self._last_source_signature=new_signature
        # A new camera/view must always begin at the image origin, not at a stale scroll offset.
        try: self.viewer_canvas.xview_moveto(0); self.viewer_canvas.yview_moveto(0)
        except Exception: pass
        # Source dimensions and aspect ratios can change radically (single camera vs stitched).
        # Always return to FIT so the new full frame is visible instead of carrying an old zoom.
        self._zoom=1.0
        self.config.preview_source=self.preview_source.get(); self.config.stitch_mode=self.stitch_mode.get(); self._render_preview()

    def start_cameras(self):
        if "camera_start" in self.busy: return
        self.busy.add("camera_start"); self.status_var.set("STARTING CAMERAS…")
        active=(bool(self.camera1_on.get()),bool(self.camera2_on.get()))
        backend_name=self.camera_backend_var.get()
        settings=[copy.deepcopy(self.config.camera1),copy.deepcopy(self.config.camera2)]
        def worker():
            try:
                self.camera_manager.stop()
                if backend_name=="Basler": self.camera_manager.backends=[BaslerCamera(0,self.log),BaslerCamera(1,self.log)]
                else: self.camera_manager.backends=[SimulatedCamera(0,settings[0].width,settings[0].height),SimulatedCamera(1,settings[1].width,settings[1].height)]
                self.camera_manager.start(active,settings); ok=any(self.camera_manager._active)
                self._post_ui(lambda:self._camera_started(ok))
            except Exception as exc: self._post_ui(lambda exc=exc:self._async_error("Camera start",exc))
            finally: self.busy.discard("camera_start")
        threading.Thread(target=worker,daemon=True).start()

    def _camera_started(self,ok):
        self.camera_running=ok; self.status_var.set("CAMERAS RUNNING" if ok else "CAMERA START FAILED")
        if ok: self.log("INFO","Camera backends started")
        else: messagebox.showerror("Camera","Neither selected camera started. See System Log.",parent=self.root)

    def stop_cameras(self):
        threading.Thread(target=self.camera_manager.stop,daemon=True).start(); self.camera_running=False; self.status_var.set("CAMERAS STOPPED"); self.log("INFO","Camera stop requested")

    def apply_camera_settings(self):
        try:
            idx=0 if self.setting_camera.get()=="Camera 1" else 1
            s= self.config.camera1 if idx==0 else self.config.camera2
            s.exposure_us=float(self.exposure_var.get()); s.gain=float(self.gain_var.get()); s.fps=float(self.fps_var.get()); s.width=int(self.width_var.get()); s.height=int(self.height_var.get()); s.full_sensor=bool(self.full_sensor_var.get())
            if min(s.fps,s.width,s.height)<=0: raise ValueError("FPS and image size must be positive")
            self.camera_manager.apply_settings(idx,s); save_config(self.config); self.log("INFO",f"Applied Camera {idx+1} settings")
        except Exception as exc: messagebox.showerror("Camera settings",str(exc),parent=self.root)

    def _load_camera_settings_ui(self,event=None):
        settings=self.config.camera1 if self.setting_camera.get()=="Camera 1" else self.config.camera2
        self.exposure_var.set(str(settings.exposure_us)); self.gain_var.set(str(settings.gain)); self.fps_var.set(str(settings.fps)); self.width_var.set(str(settings.width)); self.height_var.set(str(settings.height)); self.full_sensor_var.set(bool(getattr(settings,"full_sensor",True)))

    def _display_settings_for_camera(self,event=None): pass

    def connect_lights(self):
        if self.busy.intersection({"light_connect"}): return
        try:
            self._refresh_recipe_model(); settle=max(0,int(self.settle_var.get()))
            topology=self.topology_var.get().replace(" (UNVERIFIED)","")
            port_a=self.port_a_var.get().strip() or "SIMULATOR"; port_b=self.port_b_var.get().strip() or "SIMULATOR"
            if topology=="LIGHT_SINGLE_8" and port_a.upper()!="SIMULATOR":
                if not messagebox.askyesno("Unconfirmed protocol","The real 8-channel frame is unconfirmed. Continue only if you have independently verified your controller protocol.",parent=self.root): return
        except Exception as exc: return messagebox.showerror("Lighting",str(exc),parent=self.root)
        def worker():
            try:
                if self.lighting_engine:
                    self.lighting_engine.all_off(); self.lighting_engine.disconnect()
                engine=build_engine(topology,(port_a,port_b),9600,self.log,settle)
                engine.connect(port_a,port_b,9600)
                self.lighting_engine=engine
                self._post_ui(lambda:self.light_status.set(f"Connected: {topology}"+(" — UNCONFIRMED" if topology=="LIGHT_SINGLE_8" else "")))
                self.log("INFO",f"Lighting engine connected: {topology}")
            except Exception as exc: self._post_ui(lambda exc=exc:self._async_error("Light connect",exc))
        threading.Thread(target=worker,daemon=True).start()

    def _ensure_lights(self):
        if not self.lighting_engine or not self.lighting_engine.controller_a.is_open: raise RuntimeError("Connect the lighting controller first (SIMULATOR is available)")
        return self.lighting_engine

    def lights_ready(self):
        def worker():
            try: self._ensure_lights().apply_pair((255,255,255),(255,255,255)); self._post_ui(lambda:self.light_status.set("READY — white applied"))
            except Exception as exc: self._post_ui(lambda exc=exc:self._async_error("Lighting READY",exc))
        threading.Thread(target=worker,daemon=True).start()
    def lights_off(self):
        try:
            if self.lighting_engine: self.lighting_engine.all_off(); self.light_status.set("All lights OFF"); self.log("INFO","Lights switched off")
        except Exception as exc: self.log("ERROR",f"ALL OFF: {exc}")

    def test_recipe(self,index):
        try:
            self._refresh_recipe_model(); engine=self._ensure_lights(); a=self.recipes_a[index]; b=self.recipes_b[index] if index<len(self.recipes_b) else a
        except Exception as exc: return messagebox.showerror("Recipe",str(exc),parent=self.root)
        def worker():
            try: engine.apply_pair(a.rgb(),b.rgb()); self.log("INFO",f"Tested recipe {a.name}")
            except Exception as exc: self._post_ui(lambda exc=exc:self._async_error("Recipe test",exc))
        threading.Thread(target=worker,daemon=True).start()

    def add_roi_shape(self,role,x1,y1,x2,y2):
        kind=self.shape_var.get().lower()
        if kind=="circle / ellipse": kind="ellipse"
        elif kind=="rounded rectangle": kind="rounded_rectangle"
        elif kind=="free shape": kind="free"
        if kind=="free": return
        radius=max(2,min(24,abs(x2-x1)//5,abs(y2-y1)//5))
        shape=ROIShape(kind,bbox=(x1,y1,x2,y2),radius=radius)
        if role=="inspection": self.roi_controller.inspection=self.roi_controller.make_roi("Inspection ROI","inspection",shape)
        elif role=="camera": self.roi_controller.camera=self.roi_controller.make_roi("Camera ROI","camera",shape)
        else: self.roi_controller.rois.append(self.roi_controller.make_roi(f"{role.title()} ROI {len(self.roi_controller.rois)+1}",role,shape))
        self._refresh_roi_list(); self._render_preview(); self.log("INFO",f"Drew {role} {kind} in source pixels")

    def _canvas_to_image(self,event):
        if self.current_image is None or self._render_scale<=0: return (0,0)
        x=self.viewer_canvas.canvasx(event.x)/self._render_scale; y=self.viewer_canvas.canvasy(event.y)/self._render_scale
        h,w=self.current_image.shape[:2]
        return (int(np.clip(round(x),0,w-1)),int(np.clip(round(y),0,h-1)))

    def _mouse_down(self,event):
        self._mouse_motion(event)
        tool=self.draw_tool.get()
        if tool=="Navigate": return
        point=self._canvas_to_image(event)
        if tool=="Free Shape":
            self.roi_controller.current_role="mask" if self.role_var.get()=="Mask ROI" else "detect"
            self.roi_controller.current_shape="free"; self.roi_controller.free_points.append(point); self._render_preview(); return
        if tool=="Calibrate Scale":
            self.calibration_points.append(point)
            if len(self.calibration_points)>=2: self._finish_calibration()
            return
        self.draw_start=point; self.draw_current=point

    def _mouse_drag(self,event):
        self._mouse_motion(event)
        if self.draw_start is not None: self.draw_current=self._canvas_to_image(event); self._render_preview()

    def _mouse_up(self,event):
        if self.draw_start is None: return
        end=self._canvas_to_image(event); start=self.draw_start; self.draw_start=None; self.draw_current=None
        x1,y1=start; x2,y2=end
        if abs(x2-x1)<2 or abs(y2-y1)<2: self._render_preview(); return
        tool=self.draw_tool.get()
        role={"Inspection ROI":"inspection","Camera ROI":"camera","Detection ROI":"detect","Mask ROI":"mask"}.get(tool)
        if role: self.add_roi_shape(role,x1,y1,x2,y2)

    def _mouse_motion(self,event):
        if self.loupe_enabled.get() and self.current_image is not None: self._update_loupe(event)

    def _viewer_wheel(self,event):
        if event.delta>0: self.zoom_by(1.1)
        elif event.delta<0: self.zoom_by(.9)
        return "break"

    def _escape(self,event=None):
        self.cancel_tool()
    def _enter(self,event=None):
        if self.draw_tool.get()=="Free Shape": self.finish_free_shape()
    def undo_free_point(self):
        if self.roi_controller.free_points: self.roi_controller.free_points.pop(); self._render_preview()
    def finish_free_shape(self):
        if self.roi_controller.finish_free(): self._refresh_roi_list(); self._render_preview(); self.log("INFO","Finished free-shape ROI")
        else: messagebox.showinfo("Free shape","A free ROI needs at least three vertices.",parent=self.root)
    def cancel_tool(self): self.draw_start=None; self.draw_current=None; self.roi_controller.free_points.clear(); self.calibration_points.clear(); self._render_preview()

    def delete_roi(self,rid): self.roi_controller.delete(rid); self._refresh_roi_list(); self._render_preview()
    def clear_rois(self):
        self.roi_controller.clear(); self.segment_result=None; self.segment_vars.clear(); self._refresh_roi_list(); self._refresh_segment_list(); self._render_preview()
    def set_all_rois(self,enabled):
        for r in [self.roi_controller.inspection,self.roi_controller.camera,*self.roi_controller.rois]:
            if r: r.enabled=enabled
        self._refresh_roi_list(); self._render_preview()

    def _active_roi(self,role):
        if role=="inspection": return self.roi_controller.inspection
        if role=="camera": return self.roi_controller.camera
        return None

    def _overlay_image(self,image):
        out=image.copy()
        for roi in [self.roi_controller.inspection,self.roi_controller.camera,*self.roi_controller.rois]:
            if roi is None: continue
            try: mask=rasterize_shape(roi.shape,image.shape)
            except Exception: continue
            contours,_=cv2.findContours(mask,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
            color=tuple(int(roi.color.lstrip("#")[i:i+2],16) for i in (4,2,0)) if roi.color.startswith("#") else (0,255,255)
            if not roi.enabled: color=(135,135,135)
            cv2.drawContours(out,contours,-1,color,2,cv2.LINE_AA)
            if roi.role=="mask" and roi.enabled:
                # Red diagonal hatching communicates excluded regions.
                overlay=out.copy()
                for y in range(0,out.shape[0],12): cv2.line(overlay,(0,y),(out.shape[1],y-30),(0,0,220),1)
                out[mask>0]=cv2.addWeighted(out,0.75,overlay,0.25,0)[mask>0]
        if self.segment_result is not None:
            colors={1:(50,190,90),2:(230,100,50),3:(20,200,235),4:(160,90,180)}
            for seg in self.segment_result.segments:
                if self.segment_vars.get(seg.id) and self.segment_vars[seg.id].get():
                    cnt,_=cv2.findContours(seg.mask,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE); cv2.drawContours(out,cnt,-1,colors.get(seg.id,(100,200,200)),1)
        if self.draw_start and self.draw_current:
            cv2.rectangle(out,self.draw_start,self.draw_current,(0,255,255),2)
        if self.roi_controller.free_points:
            pts=np.array(self.roi_controller.free_points,np.int32).reshape((-1,1,2)); cv2.polylines(out,[pts],False,(0,255,255),2)
            for x,y in self.roi_controller.free_points: cv2.circle(out,(int(x),int(y)),4,(0,255,255),-1)
        if getattr(self,"live_detection_var",None) is not None and self.live_detection_var.get():
            for result in getattr(self,"last_detection_results",[]):
                for defect in result.defects:
                    cv2.rectangle(out,(defect.x,defect.y),(defect.x+defect.w-1,defect.y+defect.h-1),(0,0,255),3)
                    label=defect.label or "DEFECT"
                    cv2.putText(out,label,(defect.x,max(18,defect.y-6)),cv2.FONT_HERSHEY_SIMPLEX,.55,(0,0,255),2,cv2.LINE_AA)
        return out

    def _get_preview_image(self):
        pair=self.camera_manager.latest(self.stitch_mode.get()); self.last_pair=pair
        src=self.preview_source.get()
        if src=="Camera 1": image=pair.camera1.image if pair.camera1 else None
        elif src=="Camera 2": image=pair.camera2.image if pair.camera2 else None
        else: image=pair.stitched(self.stitch_mode.get())
        return image

    def _tick(self):
        if self.closed: return
        try:
            image=self._get_preview_image()
            if image is not None:
                frame_shape=tuple(image.shape[:2])
                if self.current_source_shape is None:
                    self.log("INFO",f"Preview frame received: {frame_shape[1]} x {frame_shape[0]} pixels ({self.preview_source.get()})")
                    self._zoom=1.0
                    try: self.viewer_canvas.xview_moveto(0); self.viewer_canvas.yview_moveto(0)
                    except Exception: pass
                elif frame_shape!=tuple(self.current_source_shape):
                    self.log("WARN",f"Source frame size changed to {frame_shape[1]} x {frame_shape[0]} pixels. Clear/recreate ROIs before using them.")
                    self._zoom=1.0
                    try: self.viewer_canvas.xview_moveto(0); self.viewer_canvas.yview_moveto(0)
                    except Exception: pass
                self.current_image=image.copy(); self.current_source_shape=image.shape[:2]
                self._render_preview()
        except Exception as exc: self.log("WARN",f"Preview update: {exc}")
        self._preview_after_id=self.root.after(30,self._tick)

    def _render_preview(self):
        if not hasattr(self,"viewer_canvas") or self.closed: return
        img=self.current_image
        if img is None:
            self.viewer_canvas.delete("all"); self.viewer_canvas.create_text(180,80,text="Start Camera 1 / Camera 2 to view a live image",fill="#cbd5e1",font=("Segoe UI",12)); return
        try:
            overlay=self._overlay_image(img)
            cw=max(200,self.viewer_canvas.winfo_width()-4); ch=max(150,self.viewer_canvas.winfo_height()-4)
            fit=min(cw/max(1,img.shape[1]),ch/max(1,img.shape[0]))
            scale=max(.02,fit*self._zoom); self._render_scale=scale
            dw=max(1,int(img.shape[1]*scale)); dh=max(1,int(img.shape[0]*scale))
            resized=cv2.resize(overlay,(dw,dh),interpolation=cv2.INTER_NEAREST if scale>1 else cv2.INTER_AREA)
            pil=Image.fromarray(cv2.cvtColor(resized,cv2.COLOR_BGR2RGB)); self._photo=ImageTk.PhotoImage(pil)
            self.viewer_canvas.delete("all"); self.viewer_canvas.create_image(0,0,image=self._photo,anchor="nw")
            self.viewer_canvas.configure(scrollregion=(0,0,dw,dh))
            # Small on-image diagnostics distinguish source sensor size from its fitted display size.
            diag=f"SOURCE {img.shape[1]} x {img.shape[0]} px  |  VIEW {dw} x {dh} px  |  {scale*100:.1f}%"
            self.viewer_canvas.create_rectangle(7,7,7+min(max(250,len(diag)*7),dw-2),29,fill="#111827",outline="#374151")
            self.viewer_canvas.create_text(12,11,text=diag,anchor="nw",fill="#f9fafb",font=("Segoe UI",8,"bold"))
            self.zoom_label.configure(text=f"{scale*100:.0f}%")
        except Exception as exc: self.log("WARN",f"Viewer render: {exc}")

    def fit_view(self): self._zoom=1.0; self.viewer_canvas.xview_moveto(0); self.viewer_canvas.yview_moveto(0); self._render_preview()
    def zoom_by(self,factor): self._zoom=float(np.clip(self._zoom*factor,.1,8)); self._render_preview()
    def zoom_100(self):
        if self.current_image is not None:
            fit=min(max(200,self.viewer_canvas.winfo_width()-4)/self.current_image.shape[1],max(150,self.viewer_canvas.winfo_height()-4)/self.current_image.shape[0]); self._zoom=1/max(fit,.01); self._render_preview()

    def toggle_loupe(self):
        self.loupe_enabled.set(not self.loupe_enabled.get())
        if self.loupe_enabled.get():
            if self.loupe_window is None or not self.loupe_window.winfo_exists():
                self.loupe_window=tk.Toplevel(self.root); self.loupe_window.overrideredirect(True); self.loupe_window.attributes("-topmost",True)
                self.loupe_label=tk.Label(self.loupe_window,bg="black",bd=1,relief="solid"); self.loupe_label.pack()
            self.loupe_window.deiconify()
        elif self.loupe_window is not None:
            try: self.loupe_window.withdraw()
            except tk.TclError: pass

    def _update_loupe(self,event):
        if not self.loupe_window or not self.loupe_window.winfo_exists(): return
        x,y=self._canvas_to_image(event); h,w=self.current_image.shape[:2]; r=int(np.clip(self.loupe_radius.get(),8,40))
        crop=self.current_image[max(0,y-r):min(h,y+r+1),max(0,x-r):min(w,x+r+1)]
        if crop.size==0: return
        crop=cv2.resize(crop,(288,288),interpolation=cv2.INTER_NEAREST)
        cv2.line(crop,(144,0),(144,287),(255,255,255),1); cv2.line(crop,(0,144),(287,144),(255,255,255),1)
        b,g,rr=map(int,self.current_image[y,x]); mm=self.calibration.get_scale(self.preview_source.get())
        txt=f"x={x} y={y} BGR={b},{g},{rr}"+(f" {2*r*mm:.3f} mm width" if mm else "")
        cv2.rectangle(crop,(2,2),(286,26),(0,0,0),-1); cv2.putText(crop,txt[:48],(5,18),cv2.FONT_HERSHEY_SIMPLEX,.35,(255,255,255),1,cv2.LINE_AA)
        self.loupe_photo=ImageTk.PhotoImage(Image.fromarray(cv2.cvtColor(crop,cv2.COLOR_BGR2RGB))); self.loupe_label.configure(image=self.loupe_photo)
        try: self.loupe_window.geometry(f"+{event.x_root+18}+{event.y_root+18}")
        except tk.TclError: pass

    def start_calibration(self):
        self.calibration_points=[]; self.draw_tool.set("Calibrate Scale"); self.status_var.set("CALIBRATE: click two points across a known length")
        messagebox.showinfo("Calibrate scale","Click two points on a reference length in the image, then enter its known length in millimetres.",parent=self.root)
    def _finish_calibration(self):
        a,b=self.calibration_points[:2]; self.calibration_points=[]
        px=float(np.linalg.norm(np.array(a,float)-np.array(b,float)))
        if px<=0: return
        mm=simpledialog.askfloat("Known reference length","Enter the real distance between the two clicked points (mm):",minvalue=.001,parent=self.root)
        if mm:
            scale=self.calibration.set_scale(self.preview_source.get(),px,mm); self.status_var.set(f"Calibrated {scale:.6f} mm/px"); self.log("INFO",f"Scale calibration {self.preview_source.get()}: {scale:.6f} mm/px")
        self.draw_tool.set("Navigate")

    def lock_stitch(self):
        # The aligned-side-by-side transform has no geometric registration to lock; keep the source metadata explicit.
        store=self.calibration.data; store["stitch_locked_source"]={"mode":self.stitch_mode.get(),"source_view":self.preview_source.get(),"note":"Coordinate lock stores source selection only; it does not make stitched pixels metrically accurate."}; self.calibration.save()
        self.log("WARN","Stitch source state saved. Auto-feature homography persistence is not yet implemented; aligned join is not metric calibration.")
        messagebox.showinfo("Stitch lock","Source mode recorded. This does not lock an ORB transform or provide metric calibration.",parent=self.root)

    def _effective_inspection_mask(self,image):
        return rasterize_shape(self.roi_controller.inspection.shape,image.shape) if self.roi_controller.inspection and self.roi_controller.inspection.enabled else np.full(image.shape[:2],255,np.uint8)

    def analyze_current(self):
        if self.current_image is None: return messagebox.showwarning("No image","Start a camera first",parent=self.root)
        image=self.current_image.copy(); mask=self._effective_inspection_mask(image)
        try:
            self.inspection_analysis=analyze_illumination(image,mask,self.config.illumination_grid_rows,self.config.illumination_grid_cols,self.config.illumination_range_limit,self.strict_channel_var.get())
            s=self.inspection_analysis["lab_l"]; self.illumination_status.set(f"{self.inspection_analysis['verdict']} — LAB-L range {s['range_percent']:.1f}%, CV {s['cv_percent']:.1f}%")
            self._set_panel_image(self.heatmap_tab,self.inspection_analysis["heatmap"])
            self._set_panel_image(self.histogram_tab,histogram_image(image,mask))
            self.log("INFO",f"Illumination {self.inspection_analysis['verdict']}; LAB-L mean={s['mean']:.1f} range={s['range_percent']:.1f}%; BGR channel stats available in analysis object")
            channels=self.inspection_analysis["channels"]
            self.log("INFO","Per-channel ranges: "+", ".join(f"{k} {v['range_percent']:.1f}%" for k,v in channels.items()))
            self.results_notebook.select(self.heatmap_tab[0])
        except Exception as exc: messagebox.showerror("Illumination analysis",str(exc),parent=self.root)

    def _set_panel_image(self,tab_tuple,image):
        frame,label=tab_tuple
        try:
            w=max(200,frame.winfo_width()-10); h=max(150,frame.winfo_height()-10)
            if image.ndim==2: rgb=cv2.cvtColor(image,cv2.COLOR_GRAY2RGB)
            else: rgb=cv2.cvtColor(image,cv2.COLOR_BGR2RGB)
            scale=min(w/rgb.shape[1],h/rgb.shape[0]); out=cv2.resize(rgb,(max(1,int(rgb.shape[1]*scale)),max(1,int(rgb.shape[0]*scale))),interpolation=cv2.INTER_AREA)
            photo=ImageTk.PhotoImage(Image.fromarray(out)); self._panel_photos[id(label)]=photo; label.configure(image=photo,text="")
        except Exception as exc: self.log("WARN",f"Could not display result tab: {exc}")

    def run_segmentation(self):
        if self.current_image is None: return messagebox.showwarning("No image","Start cameras first",parent=self.root)
        if "segmentation" in self.busy: return
        self.busy.add("segmentation")
        image=self.current_image.copy(); inspection=copy.deepcopy(self.roi_controller.inspection); camera=copy.deepcopy(self.roi_controller.camera)
        backend_name=self.seg_backend_var.get(); segmentation_params=copy.deepcopy(self.config.segmentation_params)
        correction_enabled=bool(self.correct_var.get()); strength=float(self.correction_strength.get()); highlight=bool(self.highlight_var.get())
        inspection_mask=rasterize_shape(inspection.shape,image.shape) if inspection and inspection.enabled else np.full(image.shape[:2],255,np.uint8)
        def worker():
            try:
                work=correct_illumination(image,inspection_mask,strength,highlight) if correction_enabled else image
                result=self._segment_image(work,inspection,camera,backend_name,segmentation_params)
                self._post_ui(lambda:self._segmentation_done(result))
            except Exception as exc: self._post_ui(lambda exc=exc:self._async_error("Segmentation",exc))
            finally: self.busy.discard("segmentation")
        threading.Thread(target=worker,daemon=True).start()

    def _segment_image(self,image,inspection=None,camera=None,backend_name=None,segmentation_params=None):
        roi_mask=rasterize_shape(inspection.shape,image.shape) if inspection and inspection.enabled else np.full(image.shape[:2],255,np.uint8)
        cam_mask=rasterize_shape(camera.shape,image.shape) if camera and camera.enabled else None
        backend=self.segmentation_backends[backend_name or self.seg_backend_var.get()]
        return backend.segment(image,roi_mask,segmentation_params if segmentation_params is not None else self.config.segmentation_params,cam_mask)

    def _segmentation_done(self,result):
        self.segment_result=result
        for seg in result.segments:
            if seg.id not in self.segment_vars: self.segment_vars[seg.id]=tk.BooleanVar(value=(seg.id in (1,3,4)))
        self.segment_status.set(f"{result.backend}: {len(result.segments)} regions. {result.message}")
        self._refresh_segment_list(); self._set_panel_image(self.segments_tab,result.overlay); self._render_preview(); self.log("INFO",self.segment_status.get())

    def _selected_segments(self,result):
        return [s for s in result.segments if self.segment_vars.get(s.id) and self.segment_vars[s.id].get()]

    def _snapshot_detection_settings(self, detector_names=None):
        # Read Tk variables on the UI thread; workers receive only plain values and copied geometry.
        self._read_detector_settings()
        names=detector_names if detector_names is not None else [n for n,v in self.detector_vars.items() if v.get()]
        detectors=[(n,copy.deepcopy(self.detector_params.get(n,self.detection_registry.get(n).create_default()))) for n in names]
        return {
            "inspection":copy.deepcopy(self.roi_controller.inspection),
            "camera":copy.deepcopy(self.roi_controller.camera),
            "rois":copy.deepcopy(self.roi_controller.rois),
            "backend":self.seg_backend_var.get(),
            "segmentation_params":copy.deepcopy(self.config.segmentation_params),
            "segmentation_enabled":bool(self.segmentation_enabled.get()),
            "ticked_segment_ids":[sid for sid,var in self.segment_vars.items() if bool(var.get())],
            "existing_segment_result":copy.deepcopy(self.segment_result),
            "correction_enabled":bool(self.correct_var.get()),
            "correction_strength":float(self.correction_strength.get()),
            "highlight_compression":bool(self.highlight_var.get()),
            "mode":self.mode_var.get(),
            "source_view":self.preview_source.get(),
            "stitch_mode":self.stitch_mode.get(),
            "calibration":self.calibration.get_scale(self.preview_source.get()),
            "detectors":detectors,
        }

    def _process_image_for_detection(self,image,settings,context_images=None,light=None):
        """CPU-only processing path; no Tk widgets are accessed here."""
        inspection=settings["inspection"]; camera=settings["camera"]; rois=settings["rois"]
        insp=rasterize_shape(inspection.shape,image.shape) if inspection and inspection.enabled else np.full(image.shape[:2],255,np.uint8)
        working=correct_illumination(image,insp,settings["correction_strength"],settings["highlight_compression"]) if settings["correction_enabled"] else image.copy()
        segresult=None
        if settings["segmentation_enabled"]:
            segresult=self._segment_image(working,inspection,camera,settings["backend"],settings["segmentation_params"])
        elif settings.get("existing_segment_result") is not None:
            segresult=settings["existing_segment_result"]
        selected=[s for s in (segresult.segments if segresult else []) if s.id in settings["ticked_segment_ids"]]
        from mobile_inspection_app.roi.masks import compose_detection_mask
        selected_drois=[r for r in rois if r.role=="detect" and r.enabled]
        selected_mrois=[r for r in rois if r.role=="mask" and r.enabled]
        final=compose_detection_mask(image.shape,insp,selected_drois,[s.mask for s in selected],selected_mrois,True)
        results=[]
        for name,params in settings["detectors"]:
            algo=self.detection_registry.get(name)
            ctx={"params":params,"selected_regions":[{"id":s.id,"name":s.name,"mask":s.mask} for s in selected],"roi_shapes":rois,"mode":settings["mode"],"light":light,"calibration":{"mm_per_px":settings["calibration"]} if settings["calibration"] else None}
            if algo.multi_image: ctx["images"]=context_images or {}
            results.append(algo.process(working,final,ctx))
        return working,final,results,segresult

    @staticmethod
    def _combine_result_images(image,results):
        combined=image.copy(); palette=[(0,0,255),(0,180,255),(255,80,0),(200,0,200)]
        for i,res in enumerate(results):
            color=palette[i%len(palette)]
            for b in res.defects:
                cv2.rectangle(combined,(b.x,b.y),(b.x+b.w-1,b.y+b.h-1),color,3)
                # Algorithm names belong in the Defects table; the image overlay should identify the defect.
                label=b.label if getattr(b,"label","") else "DEFECT"
                cv2.putText(combined,label,(b.x,max(18,b.y-6)),cv2.FONT_HERSHEY_SIMPLEX,.55,color,2,cv2.LINE_AA)
        if not any(r.defects for r in results): cv2.putText(combined,"NO DEFECTS FLAGGED",(18,32),cv2.FONT_HERSHEY_SIMPLEX,.7,(40,180,40),2)
        return combined

    def perform_detection(self):
        if self.current_image is None: return messagebox.showwarning("No image","Start cameras first",parent=self.root)
        if "detection" in self.busy: return
        try:
            settings=self._snapshot_detection_settings()
            if not settings["detectors"]: raise ValueError("Select at least one detector plugin")
            image=self.current_image.copy()
        except Exception as exc: return messagebox.showerror("Detection",str(exc),parent=self.root)
        self.busy.add("detection"); self.perform_btn.configure(state="disabled",text="DETECTING…"); self.status_var.set("DETECTION RUNNING…")
        def worker():
            try:
                working,mask,results,segresult=self._process_image_for_detection(image,settings)
                combined=self._combine_result_images(working,results)
                self._post_ui(lambda:self._detection_done(combined,working,mask,results,segresult,settings["source_view"]))
            except Exception as exc: self._post_ui(lambda exc=exc:self._async_error("Detection",exc))
            finally:
                self.busy.discard("detection")
                self._post_ui(lambda:self.perform_btn.configure(state="normal",text="PERFORM DETECTION"))
        threading.Thread(target=worker,daemon=True).start()

    def _detection_done(self,combined,working,mask,results,segresult,source_view=None,live=False):
        had_live_result=self._live_result_initialized
        self.last_detection_results=results; self.last_detection_mask=mask; self.last_corrected=working; self.last_combined_image=combined.copy(); self.segment_result=segresult
        self._set_panel_image(self.result_tab,combined); self._set_panel_image(self.mask_tab,mask)
        if not live or not had_live_result: self.results_notebook.select(self.result_tab[0])
        self._live_result_initialized=True
        self.defects_tree.delete(*self.defects_tree.get_children())
        for result in results:
            for b in result.defects:
                scale=self.calibration.get_scale(source_view or self.preview_source.get()); size=f"{max(b.w,b.h)*scale:.3f} mm" if scale else f"{max(b.w,b.h)} px"
                self.defects_tree.insert("","end",values=(result.algorithm,b.label,b.x,b.y,b.w,b.h,b.area_px,size))
            if not live: self.log("INFO",f"{result.algorithm}: {result.message} score={result.score:.6f}")
        count=sum(len(r.defects) for r in results)
        self.status_var.set(("LIVE DETECTION" if live and self.live_detection_var.get() else "DETECTION COMPLETE")+f" — {count} candidate(s)")
        if not results: self.log("WARN","No detector results returned")
        self._render_preview()

    def _async_error(self,title,exc):
        self.log("ERROR",f"{title}: {exc}")
        try: messagebox.showerror(title,str(exc),parent=self.root)
        except tk.TclError: pass

    def capture_selected(self):
        if not self.model_var.get().strip(): return messagebox.showwarning("Model required","Set a model name first.",parent=self.root)
        try:
            self._refresh_recipe_model(); engine=self._ensure_lights()
            inds=[i for i,v in enumerate(self.recipe_selected) if v.get() and i<len(self.recipes_a) and self.recipes_a[i].enabled]
            if not inds: raise ValueError("Tick at least one capture recipe")
            model=self.model_var.get().strip(); recipes_a=copy.deepcopy(self.recipes_a); recipes_b=copy.deepcopy(self.recipes_b); stitch_mode=self.stitch_mode.get()
        except Exception as exc: return messagebox.showerror("Capture",str(exc),parent=self.root)
        if "capture" in self.busy: return
        self.busy.add("capture"); self.capture_status.set("Capturing selected recipes…")
        manager=CaptureManager(self.camera_manager,lambda:engine,ROOT,self.log)
        camera_settings={"camera1":self.config.camera1.__dict__.copy(),"camera2":self.config.camera2.__dict__.copy()}
        scales={k:self.calibration.get_scale(k) for k in ("Camera 1","Camera 2","Stitched")}
        def worker():
            try:
                folder,manifest=manager.capture_selected(model,recipes_a,recipes_b,inds,stitch_mode,camera_settings,scales)
                self._post_ui(lambda:self.capture_status.set(f"Saved {len(manifest['items'])} image set(s): {folder}"))
            except Exception as exc: self._post_ui(lambda exc=exc:self._async_error("Capture",exc))
            finally: self.busy.discard("capture")
        threading.Thread(target=worker,daemon=True).start()

    def capture_one_testing(self):
        if not self.model_var.get().strip(): return messagebox.showwarning("Model required","Set a model name first.",parent=self.root)
        try:
            self._refresh_recipe_model(); engine=self._ensure_lights(); recipe=copy.deepcopy(self.recipes_a[0]); model=self.model_var.get().strip(); view=self.preview_source.get().lower().replace(" ",""); stitch_mode=self.stitch_mode.get()
        except Exception as exc: return messagebox.showerror("Capture",str(exc),parent=self.root)
        def worker():
            try:
                path=CaptureManager(self.camera_manager,lambda:engine,ROOT,self.log).capture_testing(model,recipe,view,stitch_mode)
                self._post_ui(lambda:self.capture_status.set(f"Testing image saved: {path}"))
            except Exception as exc: self._post_ui(lambda exc=exc:self._async_error("Testing capture",exc))
        threading.Thread(target=worker,daemon=True).start()

    def capture_and_inspect(self):
        if self.mode_var.get()!="DETECTION":
            if not messagebox.askyesno("Mode", "Switch to DETECTION mode and capture + inspect?",parent=self.root): return
            self.mode_var.set("DETECTION"); self._mode_changed()
        if not self.model_var.get().strip(): return messagebox.showwarning("Model required","Set a model name first.",parent=self.root)
        if "capture_inspect" in self.busy: return
        try:
            self._refresh_recipe_model(); engine=self._ensure_lights()
            inds=[i for i,v in enumerate(self.recipe_selected) if v.get() and i<len(self.recipes_a) and self.recipes_a[i].enabled]
            if not inds: raise ValueError("Tick at least one capture recipe")
            settings=self._snapshot_detection_settings()
            if not settings["detectors"]: raise ValueError("Select at least one detector plugin")
            model=self.model_var.get().strip(); recipes_a=copy.deepcopy(self.recipes_a); recipes_b=copy.deepcopy(self.recipes_b); stitch_mode=self.stitch_mode.get(); source_view=self.preview_source.get()
        except Exception as exc: return messagebox.showerror("Capture + inspect",str(exc),parent=self.root)
        self.busy.add("capture_inspect"); self.capture_status.set("Capturing and inspecting selected recipes…"); self.status_var.set("CAPTURE + INSPECT RUNNING…")
        manager=CaptureManager(self.camera_manager,lambda:engine,ROOT,self.log)
        camera_settings={"camera1":self.config.camera1.__dict__.copy(),"camera2":self.config.camera2.__dict__.copy()}
        scales={k:self.calibration.get_scale(k) for k in ("Camera 1","Camera 2","Stitched")}
        def worker():
            try:
                folder,manifest=manager.capture_selected(model,recipes_a,recipes_b,inds,stitch_mode,camera_settings,scales)
                file_key={"Stitched":"stitched","Camera 1":"camera1","Camera 2":"camera2"}.get(source_view,"stitched")
                captured={}
                for item in manifest["items"]:
                    filename=item.get("files",{}).get(file_key)
                    if not filename: continue
                    image=cv2.imread(str(folder/filename),cv2.IMREAD_COLOR)
                    if image is not None: captured[item["name"]]=image
                if not captured: raise RuntimeError(f"No usable images were captured for view {source_view}")
                # Multi-image algorithms receive the whole per-light image dictionary; single-image algorithms run once per light.
                all_results=[]; last_combined=None; last_working=None; last_mask=None; last_seg=None; output_root=ROOT/"results"/safe_name(model)/time.strftime("%Y%m%d_%H%M%S")
                multi_specs=[(n,p) for n,p in settings["detectors"] if self.detection_registry.get(n).multi_image]
                single_specs=[(n,p) for n,p in settings["detectors"] if not self.detection_registry.get(n).multi_image]
                for name,image in captured.items():
                    local_settings=dict(settings); local_settings["detectors"]=single_specs
                    if single_specs:
                        working,mask,results,segresult=self._process_image_for_detection(image,local_settings,light={"name":name})
                    else:
                        # Still form the effective mask to provide the multi-image detector with a correctly sized inspection domain.
                        local_settings["detectors"]=[]
                        try: working,mask,_,segresult=self._process_image_for_detection(image,local_settings,light={"name":name})
                        except Exception as exc:
                            if not multi_specs: raise
                            # Defer mask/region setup below if no single-image detector was selected.
                            working=image.copy(); mask=np.full(image.shape[:2],255,np.uint8); segresult=None
                        results=[]
                    if multi_specs and name==next(iter(captured)):
                        local_settings=dict(settings); local_settings["detectors"]=multi_specs
                        _,_,multi_results,multi_seg=self._process_image_for_detection(image,local_settings,context_images=captured,light={"name":name,"multi_image":True})
                        results.extend(multi_results)
                        if multi_seg is not None: segresult=multi_seg
                    combined=self._combine_result_images(working,results)
                    out=output_root/safe_name(name); out.mkdir(parents=True,exist_ok=True)
                    cv2.imwrite(str(out/"annotated.png"),combined); cv2.imwrite(str(out/"mask.png"),mask)
                    (out/"result.json").write_text(json.dumps({"model":model,"light_name":name,"source_view":source_view,"candidate_only":True,"results":[{"algorithm":r.algorithm,"score":r.score,"message":r.message,"defects":[b.__dict__ for b in r.defects]} for r in results]},indent=2),encoding="utf-8")
                    all_results.extend([(name,r) for r in results]); last_combined=combined; last_working=working; last_mask=mask; last_seg=segresult
                if not all_results: raise RuntimeError("No per-image detector results were produced")
                # Display the final captured recipe and aggregate all candidate boxes in the Defects table.
                results_for_display=[r for _,r in all_results]
                aggregated_combined=self._combine_result_images(last_working,results_for_display)
                self._post_ui(lambda:self._detection_done(aggregated_combined,last_working,last_mask,results_for_display,last_seg,source_view))
                self._post_ui(lambda:self.capture_status.set(f"Captured and inspected {len(captured)} recipe(s); results: {output_root}"))
                self.log("INFO",f"Capture + inspect completed for {len(captured)} images. Saved per-light candidate results to {output_root}")
            except Exception as exc: self._post_ui(lambda exc=exc:self._async_error("Capture + inspect",exc))
            finally: self.busy.discard("capture_inspect")
        threading.Thread(target=worker,daemon=True).start()

    def save_current_profile(self):
        model=self.model_var.get().strip()
        if not model: return messagebox.showwarning("Model required","Set a model name first.",parent=self.root)
        try:
            self._refresh_recipe_model(); image=self.current_image
            if image is None: raise ValueError("No active image source")
            active=[n for n,v in self.detector_vars.items() if v.get()]
            dets=[(n,self.detector_params.get(n,{})) for n in active]
            profile=make_profile(model,image.shape,self.preview_source.get(),self.stitch_mode.get(),self.roi_controller.inspection,self.roi_controller.camera,self.roi_controller.rois,self.seg_backend_var.get(),self.config.segmentation_params,[sid for sid,v in self.segment_vars.items() if v.get()],{"enabled":self.correct_var.get(),"strength":self.correction_strength.get(),"highlight_compression":self.highlight_var.get()},dets,[i for i,v in enumerate(self.recipe_selected) if v.get()])
            path=save_profile(model,profile); self.log("INFO",f"Saved profile {path}"); messagebox.showinfo("Profile saved",str(path),parent=self.root)
        except Exception as exc: messagebox.showerror("Save profile",str(exc),parent=self.root)

    def load_current_profile(self):
        model=self.model_var.get().strip()
        if not model: return messagebox.showwarning("Model required","Set a model name first.",parent=self.root)
        try:
            profile=load_profile(model)
            if self.current_image is not None and profile.get("image_size") and list(profile["image_size"])!=[self.current_image.shape[1],self.current_image.shape[0]]:
                raise ValueError(f"Profile image size {profile['image_size']} differs from current source {[self.current_image.shape[1],self.current_image.shape[0]]}; geometry was not loaded.")
            self.preview_source.set(profile.get("source_view",self.preview_source.get())); self.stitch_mode.set(profile.get("stitch_mode",self.stitch_mode.get()))
            self._last_source_signature=(self.preview_source.get(),self.stitch_mode.get())
            self.roi_controller.clear()
            if profile.get("inspection_roi"): self.roi_controller.inspection=ROI.from_dict(profile["inspection_roi"])
            if profile.get("camera_roi"): self.roi_controller.camera=ROI.from_dict(profile["camera_roi"])
            self.roi_controller.rois=[ROI.from_dict(r) for r in profile.get("rois",[])]
            self.seg_backend_var.set(profile.get("segmentation_backend",self.seg_backend_var.get()))
            self.config.segmentation_params=profile.get("segmentation_params",{})
            self.segment_vars={int(k):tk.BooleanVar(value=(int(k) in profile.get("ticked_segment_ids",[]))) for k in ("1","2","3","4")}
            opts=profile.get("correction_options",{}); self.correct_var.set(opts.get("enabled",False)); self.correction_strength.set(opts.get("strength",.75)); self.highlight_var.set(opts.get("highlight_compression",True))
            for n,v in self.detector_vars.items(): v.set(False)
            for row in profile.get("detectors",[]):
                n=row.get("name")
                if n in self.detector_vars: self.detector_vars[n].set(True); self.detector_params[n].update(row.get("params",{}))
            self.detector_setting_name.set(next((r.get("name") for r in profile.get("detectors",[]) if r.get("name") in self.detector_params),self.detector_setting_name.get())); self._build_detector_settings()
            self._refresh_roi_list(); self._refresh_segment_list(); self._render_preview(); self.log("INFO",f"Loaded profile {model}")
        except Exception as exc: messagebox.showerror("Load profile",str(exc),parent=self.root)

    def refresh_algorithms(self):
        self.detection_registry=discover_algorithms(ROOT/"algorithms",self.log)
        self._refresh_detector_list(); self._build_detector_settings(); self.log("INFO","Refreshed detector plugins")

    def start_auto_regulator(self):
        try:
            engine=self._ensure_lights()
            if not engine.dual:
                messagebox.showinfo("Auto regulator","A single light can only change overall brightness. Independent left/right balancing requires two lights.",parent=self.root); return
            self._refresh_recipe_model(); rgb_a=self.recipes_a[0].rgb(); rgb_b=self.recipes_b[0].rgb(); stitch_mode=self.stitch_mode.get(); inspection=copy.deepcopy(self.roi_controller.inspection)
        except Exception as exc: return messagebox.showerror("Auto regulator",str(exc),parent=self.root)
        threading.Thread(target=self._regulator_worker,args=(12,rgb_a,rgb_b,stitch_mode,inspection,False),daemon=True).start()

    def toggle_continuous_regulator(self):
        if self.regulator_active:
            self.regulator_stop.set(); self.cont_regulator_btn.configure(text="STOPPING…",state="disabled"); return
        try:
            engine=self._ensure_lights()
            if not engine.dual:
                messagebox.showinfo("Auto regulator","A single light can only change overall brightness. Independent left/right balancing requires two lights.",parent=self.root); return
            self._refresh_recipe_model(); rgb_a=self.recipes_a[0].rgb(); rgb_b=self.recipes_b[0].rgb(); stitch_mode=self.stitch_mode.get(); inspection=copy.deepcopy(self.roi_controller.inspection)
        except Exception as exc: return messagebox.showerror("Auto regulator",str(exc),parent=self.root)
        self.regulator_stop.clear(); self.regulator_active=True; self.cont_regulator_btn.configure(text="STOP REGULATOR",state="normal")
        threading.Thread(target=self._regulator_worker,args=(12,rgb_a,rgb_b,stitch_mode,inspection,True),daemon=True).start()

    def _regulator_finished(self):
        self.regulator_active=False
        try: self.cont_regulator_btn.configure(text="START CONTINUOUS",state="normal")
        except tk.TclError: pass

    def _regulator_worker(self,max_steps=12,rgb_a=None,rgb_b=None,stitch_mode="Aligned side-by-side",inspection=None,continuous=False):
        try:
            engine=self._ensure_lights(); rgb_a=list(rgb_a or (255,255,255)); rgb_b=list(rgb_b or (255,255,255))
            if not engine.dual: raise RuntimeError("A single light can change only overall brightness; independent balancing needs two lights.")
            step=0
            while step<max_steps or continuous:
                if self.closed or (continuous and self.regulator_stop.is_set()): break
                pair=self.camera_manager.capture_once(timeout=2); image=pair.stitched(stitch_mode)
                if image is None: raise RuntimeError("No image for illumination regulator")
                h,w=image.shape[:2]; split=w//2; lab=cv2.cvtColor(image,cv2.COLOR_BGR2LAB)[:,:,0].astype(float)
                if inspection is not None and inspection.enabled:
                    try:
                        valid=rasterize_shape(inspection.shape,image.shape)>0
                        ma=float(lab[:,:split][valid[:,:split]].mean()) if valid[:,:split].any() else float(lab[:,:split].mean())
                        mb=float(lab[:,split:][valid[:,split:]].mean()) if valid[:,split:].any() else float(lab[:,split:].mean())
                    except Exception: ma=float(lab[:,:split].mean()); mb=float(lab[:,split:].mean())
                else: ma=float(lab[:,:split].mean()); mb=float(lab[:,split:].mean())
                target=(ma+mb)/2
                if target<=1 or abs(ma-mb)/target<=.02:
                    self.log("INFO",f"Auto regulator {'monitor' if continuous else 'converged'} at step {step}: left={ma:.1f}, right={mb:.1f}")
                    if not continuous: return
                    time.sleep(.5); step+=1; continue
                factor_a=float(np.clip(target/max(ma,1),.92,1.08)); factor_b=float(np.clip(target/max(mb,1),.92,1.08))
                rgb_a=[int(np.clip(v*factor_a,0,255)) for v in rgb_a]; rgb_b=[int(np.clip(v*factor_b,0,255)) for v in rgb_b]
                engine.apply_pair(rgb_a,rgb_b); time.sleep(.18); step+=1
            if continuous: self.log("INFO","Continuous illumination regulation stopped")
            elif step>=max_steps: self.log("WARN","Auto regulator stopped after 12 steps without reaching 2% tolerance")
        except Exception as exc: self._post_ui(lambda exc=exc:self._async_error("Auto regulator",exc))
        finally:
            if continuous: self._post_ui(self._regulator_finished)

    def save_detection_result(self):
        if not self.last_detection_results or self.last_detection_mask is None:
            return messagebox.showinfo("Save result","Run detection first.",parent=self.root)
        model=self.model_var.get().strip()
        if not model: return messagebox.showwarning("Model required","Set a model name first.",parent=self.root)
        out=ROOT/"results"/safe_name(model)/time.strftime("%Y%m%d_%H%M%S")
        try:
            out.mkdir(parents=True,exist_ok=False)
            combined=getattr(self,"last_combined_image",self.last_detection_results[0].output).copy()
            cv2.imwrite(str(out/"annotated.png"),combined); cv2.imwrite(str(out/"mask.png"),self.last_detection_mask)
            payload={"model":model,"timestamp":time.strftime("%Y-%m-%dT%H:%M:%S%z"),"candidate_only":True,"results":[{"algorithm":r.algorithm,"score":r.score,"message":r.message,"params":r.params,"defects":[b.__dict__ for b in r.defects]} for r in self.last_detection_results]}
            (out/"result.json").write_text(json.dumps(payload,indent=2),encoding="utf-8")
            self.log("INFO",f"Saved annotated result to {out}"); messagebox.showinfo("Result saved",str(out),parent=self.root)
        except Exception as exc: messagebox.showerror("Save result",str(exc),parent=self.root)

    def clear_log(self):
        self._log_lines=[]
        if hasattr(self,"log_text"): self.log_text.configure(state="normal"); self.log_text.delete("1.0","end"); self.log_text.configure(state="disabled")

    def close(self):
        if self.closed: return
        self.closed=True
        for attr in ("_live_after_id","_preview_after_id","_log_after_id","_ui_after_id"):
            after_id=getattr(self,attr,None)
            if after_id is not None:
                try: self.root.after_cancel(after_id)
                except tk.TclError: pass
                setattr(self,attr,None)
        self.live_detection_var.set(False)
        self.regulator_stop.set()
        try:
            if self.lighting_engine: self.lighting_engine.all_off(); self.lighting_engine.disconnect()
        except Exception as exc: print(f"WARN shutdown lights: {exc}")
        try: self.camera_manager.stop()
        except Exception as exc: print(f"WARN shutdown camera: {exc}")
        try:
            self.config.preview_source=self.preview_source.get(); self.config.stitch_mode=self.stitch_mode.get(); self.config.topology=self.topology_var.get(); self.config.port_a=self.port_a_var.get(); self.config.port_b=self.port_b_var.get(); self.config.settle_ms=int(float(self.settle_var.get())); self.config.correction_enabled=self.correct_var.get(); self.config.correction_strength=self.correction_strength.get(); self.config.highlight_compression=self.highlight_var.get(); self.config.strict_per_channel=self.strict_channel_var.get(); self.config.recipes_a=self.recipes_a; self.config.recipes_b=self.recipes_b; self.config.detector_params=self.detector_params; self.config.segmentation_backend=self.seg_backend_var.get(); save_config(self.config)
        except Exception as exc: print(f"WARN config save: {exc}")
        try:
            if self.loupe_window and self.loupe_window.winfo_exists(): self.loupe_window.destroy()
        except Exception: pass
        self.root.destroy()

    def run(self): self.root.mainloop()

def main(): MobileInspectionApp().run()
