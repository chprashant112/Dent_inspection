from mobile_inspection_app.ui.app import main
if __name__ == "__main__": main()
