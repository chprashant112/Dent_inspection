@echo off
setlocal
cd /d "%~dp0"
python run.py
if errorlevel 1 (
  echo.
  echo Application exited with an error. Check the console output and README.md.
  pause
)
