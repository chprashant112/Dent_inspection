# Mobile Phone Defect Inspection App

A simulator-first Windows desktop application for mobile-phone surface inspection. It uses Python, Tkinter, OpenCV and Pillow. Optional adapters support Basler cameras (`pypylon`), serial light controllers (`pyserial`) and Ultralytics `.pt` models (`ultralytics` + PyTorch).

> **Hardware status:** the simulator and core software paths can be tested on a PC without cameras or lights. The confirmed 4-channel light frame is implemented as specified. The 8-channel frame is an explicitly marked extrapolated placeholder and **must not be treated as hardware-verified**. Do not connect a real 8-channel controller until its manufacturer-confirmed frame format is available.
>
> **Inspection status:** detector boxes are candidate proposals for human review, not certified pass/fail decisions. Segmentation and illumination routines are heuristic starting points and must be validated against real images from the target camera/light setup. Sub-pixel interpolation refines an estimated boundary; it does not create additional sensor pixels or guarantee micrometre accuracy.

## Run

Python 3.10+ is recommended. From this project directory:

```bash
python -m pip install -r requirements.txt
python run.py
```

The app starts in simulator mode; press **START** in the Camera card. No physical hardware is required for initial exploration. The simulated views include non-uniform illumination, phone geometry, camera bump and synthetic surface marks.

### Optional hardware

- **Basler cameras:** install the matching vendor `pypylon` package/driver and select the Basler backend in the Camera card. The UI defaults to simulated cameras. Full-sensor mode clears sensor offsets and uses the camera-reported maximum Width/Height; uncheck it only for an intentional crop.
- **Serial lights:** install `pyserial`, set the correct COM/serial port and select `LIGHT_SINGLE_4` or `LIGHT_DUAL_4` only after confirming the controller wiring and actual device response. Single4 uses `CH1=R, CH2=G, CH3=B, CH4=0`; Dual4 uses two controllers and ports. The simulator logs frames as hex.
- **YOLO `.pt`:** install a compatible `ultralytics`/PyTorch stack. Select the `.pt` file in the YOLO settings. Model labels and performance depend on the selected trained weights.

## Important camera-view fix (partial top-left image)

The Camera card now has **“Basler: use full sensor / full field of view (recommended)”** enabled by default. Basler's Width/Height nodes set a *sensor crop*, not just the size at which the UI displays an image. Older configurations using `960 x 720` could therefore return only the upper-left sensor region. In full-sensor mode, the app first resets `OffsetX` and `OffsetY` to their minimum (normally zero), then sets Width/Height to the maximum legal values reported by the connected camera. Legacy config files also default to this mode.

After pressing START, check the small banner over the preview: `SOURCE W x H px | VIEW W x H px | scale`. `SOURCE` is the image actually delivered by the camera; `VIEW` is only the fit-to-window display size. The status/system log also reports the sensor frame dimensions. Keep full-sensor mode enabled unless you intentionally want a cropped sensor ROI. Fixed Width/Height values are a crop on Basler, not a full-frame downscale. If full-sensor initialization fails for your camera model, the error is logged instead of silently claiming a full view.

## Main workflow

1. Enter and **SET** a model name.
2. Start either/both simulated cameras, choose Camera 1, Camera 2, or Stitched, then choose a stitching mode.
3. Connect the light engine (use `SIMULATOR` when testing the UI), optionally test recipes, and create a capture set.
4. Draw an Inspection ROI, optionally draw a Camera ROI, analyze illumination, and enable illumination correction when needed.
5. Run segmentation and tick the regions to inspect. Draw one or more Detection ROIs (areas included) and Mask ROIs (areas excluded). A detection is refused if no Detection ROI or segmentation region is active, or if the effective mask is empty.
6. In **SEGMENTATION AND DETECTION**, select one or more detector plugins. For RAW Laplacian V1, use the operator-facing sliders for **Sensitivity (k)**, **Minimum edge strength**, **Minimum defect area**, and **Box padding**—no numeric typing is needed for common tuning. Changes apply immediately.
7. Enable **Run continuously on live frames** for throttled, background-thread detection. If no region has been selected yet, the app prepares the segmentation first; otherwise it asks for an active Detection ROI or selected segment. Live detections are overlaid on the camera preview, and boxes are labelled **DEFECT n** rather than with the algorithm name. The advanced plugin parameter form is available inside the collapsed **ADVANCED PLUGIN SETTINGS** panel.
8. Save/load a model-specific testing profile.

**ROI tools:** rectangle, ellipse/circle, rounded rectangle and Free Shape. Free Shapes are drawn by clicking vertices and pressing Enter/FINISH. Core ROI geometry also supports circular arc edges via per-edge bend handles; the current GUI exposes polygon drawing but not the full vertex/arc-handle editing workflow.

## Project structure

```text
run.py
requirements.txt
algorithms/
  raw_laplacian.py
  canny_blobs.py
  yolo_pt.py
mobile_inspection_app/
  config.py, interfaces.py
  camera/ lighting/ capture/ roi/ analysis/
  segmentation/ detection/ pipeline/ ui/
tests/test_core.py
run_core_tests.py
config/ app_config.json (created on save)
config/calibration.json
captures/{model}/setN/
profiles/{model}.json
```

### Swappable boundaries

- `CameraBackend`: simulated or Basler acquisition.
- `LightEngine` + `ChannelController`: single 4-channel, dual 4-channel and placeholder single 8-channel control.
- `CaptureManager`: recipe-set capture, file output and manifest.
- `SegmentationBackend`: adaptive phone regions, LAB k-means, mean-shift regions.
- `DetectionAlgorithm`: auto-discovered plug-ins under `algorithms/`.

### Data output

Capture sets go into `captures/{sanitised-model}/setN/` and include lossless PNG files and `manifest.json`. Testing captures are placed in `captures/{model}/testing/`. Profiles are saved to `profiles/{model}.json`; app options to `config/app_config.json`; calibration to `config/calibration.json`.

## Tests

Run hardware-free core tests, without pytest or a Tk display:

```bash
python run_core_tests.py
```

Or use pytest:

```bash
python -m pytest -q
```

Tests use simulators and synthetic images. A passing simulator test does not prove the physical cameras, lenses, serial controller, lighting response, calibration or detection quality on a production line.

## Known limitations / implementation notes

- Auto feature stitching uses ORB + RANSAC and falls back to aligned side-by-side when descriptors/overlap are insufficient. Persistent homography locking is not yet implemented; the Lock Stitch action records the selected source state and explicitly says so.
- The adaptive segmentation implementation approximates body geometry and the bulged edge as a narrow distance band. It is not the full Viterbi side-normal Laplacian path estimator from the target build specification and needs real-image tuning.
- Capture writes are lossless and duplicate names are disambiguated. For each selected recipe the engine is settled, a fresh frame is requested, then lights are switched off before saved files are completed.
- The initial UI exposes illumination heat maps and B/G/R metrics, but histogram presentation is a rendered static plot; full interactive profile editing, continuous regulator UI and per-light offline reinspection need further polish.
- The profile-load guard refuses geometry if the image dimensions differ, but source-view/stitch calibration should still be rechecked by the operator.
