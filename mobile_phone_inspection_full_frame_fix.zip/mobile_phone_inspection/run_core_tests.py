"""Run core tests without pytest or a display."""
import inspect
from tests import test_core

def main():
    tests=[(name,fn) for name,fn in inspect.getmembers(test_core,inspect.isfunction) if name.startswith("test_")]
    failed=[]
    for name,fn in tests:
        try: fn(); print(f"PASS {name}")
        except Exception as exc:
            failed.append((name,exc)); print(f"FAIL {name}: {exc}")
    print(f"\n{len(tests)-len(failed)}/{len(tests)} tests passed")
    if failed: raise SystemExit(1)
if __name__=="__main__": main()
