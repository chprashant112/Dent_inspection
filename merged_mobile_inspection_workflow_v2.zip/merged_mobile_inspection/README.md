# Industrial Mobile Phone Inspection App

A modular Tkinter/OpenCV application for dual-camera phone inspection. The main workflow keeps the camera live view separate from manual inspection processing and has **no light-controller controls in the UI**.

## Main workflow

1. Select **Camera 1**, **Camera 2**, or **Stitched**, choose **Simulator** or **Basler**, then start the cameras.
2. Press **Capture Frame** in *Image Processing Workflow*. The image is saved and frozen at full resolution so ROI drawing and tuning do not drift with the live stream. Use **Resume Live** to return to live preview.
3. Click **Calibrate Distance (2 Points)**, click two points on a known reference length, and enter its real distance in millimetres. The measured line, pixel length, and saved scale are shown on the image.
4. Run **Canny · Estimate Phone Mask**. Adjust low/high thresholds, and inspect the **Phone Mask** preview. If the silhouette does not close, adjust thresholds or draw an Inspection ROI to constrain the search.
5. Draw one or more **Mask ROI** exclusions. Available shapes are rectangle, ellipse/circle, rounded rectangle, capsule/stadium, and free shape. Draw **Camera ROI** around the camera module to exclude it from the edge/back-glass split.
6. Generate illumination correction candidates and switch between their outputs in the **Correction** tab: Original, Gaussian Divide, Gaussian Subtract, Flat-field, Homomorphic, single-scale Retinex, CLAHE, and the previous LAB correction. Flat-field requires a suitable reference image.
7. Select the preferred technique and press **Use Selected Output for Detection**. Run **Build Edge + Backglass Segments**. The adaptive distance-transform edge band and back-glass region are shown in **Regions**.
8. Select a detector in **Segmentation and Detection** and press **Perform Detection**. When selected-output mode is enabled, detection runs on the chosen processed image and is restricted to the computed back-glass mask plus your regular ROI exclusions.
9. **Save All Stage Outputs** exports the captured image, correction candidates, Canny edges, phone mask, edge band, back-glass mask, and segmentation overlay. Detection results can still be saved through the normal result controls.

## Image-processing techniques

- **Gaussian Divide**: estimates a smooth illumination field and compensates for multiplicative brightness variation.
- **Gaussian Subtract / Existing LAB correction**: removes a smooth additive brightness field in LAB-L.
- **Flat-field**: compensates using a reference image acquired with a suitable uniform target under the same camera/light geometry.
- **Homomorphic** and **Retinex**: logarithmic-domain illumination/reflectance approximations.
- **CLAHE**: local contrast enhancement; useful for comparison, but it may amplify noise and should not be assumed to be the best correction for defect detection.

Correction cannot recover clipped highlights or details buried in sensor noise. Validate each method on known defects, across phone colors and relevant white/RGB lighting conditions, before production use. The Canny contour and edge-band stages are operator-verifiable heuristics, not certified product pass/fail logic.

## Run on Windows

1. Extract the folder.
2. Run `setup_windows.bat`.
3. Run `run_windows.bat`.
4. Select **Simulator** to test without hardware or **Basler** for connected Basler cameras (`pypylon` is optional and must be installed for the camera/software versions in use).

## Performance and UI

Camera acquisition runs on dedicated grab threads. Canny, illumination correction, and edge/back-glass computation run in worker threads so the Tk main loop remains responsive. The viewer supports fit, zoom, horizontal/vertical scrolling, and ROI interaction. The captured workflow frame remains frozen while processing stages run.
