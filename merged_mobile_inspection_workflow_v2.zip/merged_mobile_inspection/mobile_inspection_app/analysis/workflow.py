"""Image-processing helpers for the staged phone-inspection workflow.

The functions here are deliberately stateless so they can safely run in worker
threads. All images use OpenCV BGR ordering; masks are uint8 with 0/255 values.
"""
from __future__ import annotations

import cv2
import numpy as np

METHODS = (
    "Original",
    "Gaussian Divide",
    "Gaussian Subtract",
    "Flat-field",
    "Homomorphic",
    "Retinex (single scale)",
    "CLAHE",
    "Existing LAB correction",
)


def _mask_or_full(mask: np.ndarray | None, shape: tuple[int, ...]) -> np.ndarray:
    h, w = shape[:2]
    if mask is None:
        return np.full((h, w), 255, np.uint8)
    if mask.shape[:2] != (h, w):
        raise ValueError("Processing mask size does not match image size")
    return np.where(mask > 0, 255, 0).astype(np.uint8)


def _sigma(image: np.ndarray, sigma_fraction: float) -> float:
    return max(3.0, float(np.clip(sigma_fraction, 0.005, 0.30)) * min(image.shape[:2]))


def _illumination_field(channel: np.ndarray, mask: np.ndarray, sigma: float) -> np.ndarray:
    valid = (mask > 0).astype(np.float32)
    values = channel.astype(np.float32)
    numerator = cv2.GaussianBlur(values * valid, (0, 0), sigmaX=sigma, sigmaY=sigma)
    denominator = cv2.GaussianBlur(valid, (0, 0), sigmaX=sigma, sigmaY=sigma)
    fallback = float(np.median(values[valid > 0])) if np.any(valid) else 128.0
    return np.where(denominator > 1e-4, numerator / np.maximum(denominator, 1e-4), fallback)


def _replace_lab_l(image: np.ndarray, lightness: np.ndarray, valid_mask: np.ndarray) -> np.ndarray:
    lab = cv2.cvtColor(image, cv2.COLOR_BGR2LAB)
    original_l = lab[:, :, 0]
    lab[:, :, 0] = np.where(valid_mask > 0, np.clip(lightness, 0, 255), original_l).astype(np.uint8)
    result = cv2.cvtColor(lab, cv2.COLOR_LAB2BGR)
    result[valid_mask == 0] = image[valid_mask == 0]
    return result


def correct_image(
    image: np.ndarray,
    method: str,
    mask: np.ndarray | None = None,
    strength: float = 0.8,
    sigma_fraction: float = 0.06,
    flat_field: np.ndarray | None = None,
) -> np.ndarray:
    """Apply one illumination/contrast method while keeping the BGR image format.

    Correction methods modify LAB-L and keep chroma as stable as possible. The
    original is never modified in-place. This is a candidate preprocessing step,
    not a recovery method for saturated or photon-starved pixels.
    """
    if image is None or image.size == 0:
        raise ValueError("No captured image is available")
    if image.ndim != 3 or image.shape[2] != 3:
        raise ValueError("Expected a 3-channel BGR image")
    if method == "Original":
        return image.copy()

    valid_mask = _mask_or_full(mask, image.shape)
    valid = valid_mask > 0
    if not np.any(valid):
        return image.copy()
    strength = float(np.clip(strength, 0.0, 1.0))
    lab = cv2.cvtColor(image, cv2.COLOR_BGR2LAB)
    light = lab[:, :, 0].astype(np.float32)
    median_l = float(np.median(light[valid]))
    sigma = _sigma(image, sigma_fraction)

    if method == "Gaussian Subtract" or method == "Existing LAB correction":
        field = _illumination_field(light, valid_mask, sigma)
        target = light - strength * (field - median_l)

    elif method == "Gaussian Divide":
        field = _illumination_field(light, valid_mask, sigma)
        floor = max(5.0, float(np.percentile(field[valid], 10)) * 0.25)
        corrected = light * median_l / np.maximum(field, floor)
        target = light + strength * (corrected - light)

    elif method == "Flat-field":
        if flat_field is None:
            raise ValueError("Load a flat-field reference image first")
        reference = flat_field
        if reference.shape[:2] != image.shape[:2]:
            reference = cv2.resize(reference, (image.shape[1], image.shape[0]), interpolation=cv2.INTER_AREA)
        ref_l = cv2.cvtColor(reference, cv2.COLOR_BGR2LAB)[:, :, 0].astype(np.float32)
        ref_valid = ref_l[valid]
        ref_median = float(np.median(ref_valid)) if ref_valid.size else float(np.median(ref_l))
        smooth_ref = _illumination_field(ref_l, valid_mask, sigma)
        floor = max(5.0, ref_median * 0.10)
        corrected = light * ref_median / np.maximum(smooth_ref, floor)
        target = light + strength * (corrected - light)

    elif method in ("Homomorphic", "Retinex (single scale)"):
        log_l = np.log(np.maximum(light, 1.0) / 255.0)
        low = cv2.GaussianBlur(log_l, (0, 0), sigmaX=sigma, sigmaY=sigma)
        residual = log_l - low
        if method == "Homomorphic":
            # Keep a portion of low-frequency content; aggressive high-pass filtering
            # can suppress broad shallow dents, so the correction is intentionally mild.
            log_target = log_l - strength * (low - float(np.median(low[valid])))
            target = np.exp(log_target) * 255.0
        else:
            retinex = residual + float(np.median(log_l[valid]))
            raw = np.exp(retinex) * 255.0
            # Robustly map the result to the source luminance range without allowing
            # a single hot pixel to set the entire contrast range.
            lo, hi = np.percentile(raw[valid], [1.0, 99.0])
            if hi - lo > 1e-5:
                mapped = np.clip((raw - lo) * (255.0 / (hi - lo)), 0, 255)
                mapped_median = float(np.median(mapped[valid]))
                raw = mapped + (median_l - mapped_median)
            target = light + strength * (raw - light)

    elif method == "CLAHE":
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
        enhanced = clahe.apply(np.clip(light, 0, 255).astype(np.uint8)).astype(np.float32)
        target = light + strength * (enhanced - light)
    else:
        raise ValueError(f"Unknown image-processing method: {method}")

    # Protect features outside the selected inspection domain and limit numerical
    # amplification in poorly illuminated areas.
    result = _replace_lab_l(image, target, valid_mask)
    return result


def canny_phone_mask(
    image: np.ndarray,
    search_mask: np.ndarray | None = None,
    low_threshold: int = 35,
    high_threshold: int = 110,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, str]:
    """Use Canny edges and contour closure to estimate the phone silhouette.

    A mask is returned separately from the raw edge map so operators can inspect
    both. This is heuristic and should be checked before using for production.
    """
    if image is None or image.size == 0:
        raise ValueError("Capture a frame before running phone/background separation")
    h, w = image.shape[:2]
    valid = _mask_or_full(search_mask, image.shape)
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    # A light denoise reduces surface texture becoming part of the silhouette.
    gray = cv2.GaussianBlur(gray, (5, 5), 1.0)
    low = max(0, int(low_threshold)); high = max(low + 1, int(high_threshold))
    edges = cv2.Canny(gray, low, high, L2gradient=True)
    edges[valid == 0] = 0

    base = max(5, int(round(min(h, w) * 0.012)))
    if base % 2 == 0:
        base += 1
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (base, base))
    closed = cv2.morphologyEx(edges, cv2.MORPH_CLOSE, kernel, iterations=2)
    closed = cv2.dilate(closed, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3)), iterations=1)
    contours, _ = cv2.findContours(closed, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    best = None
    best_score = -1.0
    image_area = float(h * w)
    for contour in contours:
        area = float(cv2.contourArea(contour))
        x, y, bw, bh = cv2.boundingRect(contour)
        bbox_area = float(bw * bh)
        if area < image_area * 0.015 or bbox_area > image_area * 0.96:
            continue
        aspect = max(bw, bh) / max(1.0, min(bw, bh))
        if aspect < 1.12:
            continue
        # Reward a large, phone-like elongated component near the field centre;
        # do not depend on the phone's actual color.
        cx, cy = x + bw / 2.0, y + bh / 2.0
        centre_penalty = 1.0 / (1.0 + 0.45 * (abs(cx - w / 2) / max(1, w / 2) + abs(cy - h / 2) / max(1, h / 2)))
        elongation_bonus = min(2.0, aspect / 2.0)
        score = area * centre_penalty * elongation_bonus
        if score > best_score:
            best, best_score = contour, score

    phone = np.zeros((h, w), np.uint8)
    if best is not None:
        cv2.drawContours(phone, [best], -1, 255, thickness=cv2.FILLED)
        close_k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (max(3, base), max(3, base)))
        phone = cv2.morphologyEx(phone, cv2.MORPH_CLOSE, close_k, iterations=2)
        phone = cv2.bitwise_and(phone, valid)
        # Retain the larger filled silhouette, not inner camera/lens contours.
        cs, _ = cv2.findContours(phone, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if cs:
            filled = np.zeros_like(phone)
            cv2.drawContours(filled, [max(cs, key=cv2.contourArea)], -1, 255, cv2.FILLED)
            phone = cv2.bitwise_and(filled, valid)
        message = f"Phone contour estimated from Canny; bbox={cv2.boundingRect(best)}"
    else:
        message = "No convincing closed phone contour found. Adjust Canny thresholds, improve contrast, or draw an inspection/search ROI."

    overlay = image.copy()
    overlay[edges > 0] = (0, 220, 255)
    if cv2.countNonZero(phone):
        contours2, _ = cv2.findContours(phone, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        cv2.drawContours(overlay, contours2, -1, (50, 230, 80), max(2, int(round(min(h, w) / 500))))
    return edges, phone, overlay, message


def adaptive_edge_backglass(
    image: np.ndarray,
    phone_mask: np.ndarray,
    edge_width_px: int = 12,
    camera_mask: np.ndarray | None = None,
    exclude_mask: np.ndarray | None = None,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Split a phone silhouette into a distance-transform edge band and back glass."""
    if image is None or phone_mask is None or not np.any(phone_mask):
        raise ValueError("Run Canny phone/background separation successfully first")
    h, w = image.shape[:2]
    phone = _mask_or_full(phone_mask, image.shape)
    contours, _ = cv2.findContours(phone, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        raise ValueError("Phone mask has no external contour")
    cleaned = np.zeros((h, w), np.uint8)
    cv2.drawContours(cleaned, [max(contours, key=cv2.contourArea)], -1, 255, cv2.FILLED)
    # Width is operator controlled but scales up gently for large stitched images.
    nominal = max(2, int(edge_width_px))
    adaptive_min = max(2, int(round(min(h, w) * 0.0025)))
    width = max(nominal, adaptive_min)
    distance = cv2.distanceTransform((cleaned > 0).astype(np.uint8), cv2.DIST_L2, 5)
    edge = np.where((cleaned > 0) & (distance <= width), 255, 0).astype(np.uint8)
    backglass = cv2.bitwise_and(cleaned, cv2.bitwise_not(edge))

    cam = np.zeros((h, w), np.uint8) if camera_mask is None else _mask_or_full(camera_mask, image.shape)
    excludes = np.zeros((h, w), np.uint8) if exclude_mask is None else _mask_or_full(exclude_mask, image.shape)
    edge = cv2.bitwise_and(edge, cv2.bitwise_not(cam))
    backglass = cv2.bitwise_and(backglass, cv2.bitwise_not(cam))
    edge = cv2.bitwise_and(edge, cv2.bitwise_not(excludes))
    backglass = cv2.bitwise_and(backglass, cv2.bitwise_not(excludes))

    overlay = image.copy()
    # Blend the regions only for visualization; source pixels remain unchanged.
    tint = overlay.copy()
    tint[backglass > 0] = (35, 160, 75)
    tint[edge > 0] = (0, 185, 245)
    tint[cam > 0] = (200, 90, 30)
    active = (backglass > 0) | (edge > 0) | (cam > 0)
    overlay[active] = cv2.addWeighted(image, 0.48, tint, 0.52, 0)[active]
    for mask, color in ((backglass, (50, 230, 90)), (edge, (0, 220, 255)), (cam, (255, 100, 40))):
        cs, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        cv2.drawContours(overlay, cs, -1, color, max(2, int(round(min(h, w) / 500))) if color != (50, 230, 90) else 1)
    cv2.putText(overlay, f"Edge band: {width}px", (14, 26), cv2.FONT_HERSHEY_SIMPLEX, 0.65, (0, 220, 255), 2, cv2.LINE_AA)
    return edge, backglass, overlay
