from __future__ import annotations
import tkinter as tk
from tkinter import ttk
from mobile_inspection_app.ui.theme import COLORS

class ScrollableFrame(ttk.Frame):
    def __init__(self, master, **kwargs):
        super().__init__(master,**kwargs)
        self.canvas=tk.Canvas(self,highlightthickness=0,bg=COLORS["background"])
        self.vbar=ttk.Scrollbar(self,orient="vertical",command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=self.vbar.set)
        self.inner=ttk.Frame(self.canvas)
        self.window=self.canvas.create_window((0,0),window=self.inner,anchor="nw")
        self.canvas.pack(side="left",fill="both",expand=True); self.vbar.pack(side="right",fill="y")
        self.inner.bind("<Configure>",self._configure); self.canvas.bind("<Configure>",self._resize)
        for widget in (self.canvas,self.inner):
            widget.bind("<MouseWheel>",self._wheel,add="+")
            widget.bind("<Button-4>",lambda e:self.canvas.yview_scroll(-1,"units"),add="+")
            widget.bind("<Button-5>",lambda e:self.canvas.yview_scroll(1,"units"),add="+")
        self.bind_class("ScrollableInspectionWheel","<MouseWheel>",self._wheel)
    def _configure(self,event=None): self.canvas.configure(scrollregion=self.canvas.bbox("all"))
    def _resize(self,event): self.canvas.itemconfigure(self.window,width=event.width)
    def _wheel(self,event):
        self.canvas.yview_scroll(int(-1*(event.delta/120 if event.delta else 0),"units")); return "break"

class CollapsibleCard(ttk.Frame):
    def __init__(self, master, title: str, open_by_default: bool=False):
        super().__init__(master,style="Card.TFrame",padding=0)
        self.title=title; self.open=tk.BooleanVar(value=open_by_default)
        self.header=ttk.Button(self,text=("▾ " if open_by_default else "▸ ")+title,command=self.toggle,style="Mini.TButton")
        self.header.pack(fill="x",padx=5,pady=(5,2))
        self.body=ttk.Frame(self,style="Card.TFrame",padding=8)
        if open_by_default: self.body.pack(fill="x",expand=True,padx=2,pady=(0,6))
    def toggle(self):
        self.open.set(not self.open.get())
        if self.open.get(): self.body.pack(fill="x",expand=True,padx=2,pady=(0,6)); self.header.configure(text="▾ "+self.title)
        else: self.body.pack_forget(); self.header.configure(text="▸ "+self.title)
