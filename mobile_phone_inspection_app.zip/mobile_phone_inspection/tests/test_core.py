from __future__ import annotations
import tempfile, time
from pathlib import Path
import cv2
import numpy as np

from mobile_inspection_app.lighting.protocol import build_4ch_frame, build_8ch_frame_unconfirmed
from mobile_inspection_app.lighting.factory import build_engine
from mobile_inspection_app.camera.simulated_camera import SimulatedCamera
from mobile_inspection_app.camera.camera_manager import CameraManager
from mobile_inspection_app.capture.capture_manager import CaptureManager
from mobile_inspection_app.roi.model import ROI, ROIShape
from mobile_inspection_app.roi.shapes import rasterize_shape, free_shape_outline
from mobile_inspection_app.roi.masks import compose_detection_mask, MaskCompositionError
from mobile_inspection_app.analysis.illumination import analyze_illumination
from mobile_inspection_app.analysis.correction import correct_illumination
from mobile_inspection_app.camera.frame_pair import FramePair, TimedFrame
from mobile_inspection_app.segmentation.registry import create_segmentation_backends
from mobile_inspection_app.detection.discovery import discover_algorithms
from mobile_inspection_app.detection.base import DetectionAlgorithm, DetectionResult
from mobile_inspection_app.config import Recipe
from algorithms.raw_laplacian import RawLaplacianV1

ROOT=Path(__file__).resolve().parents[1]

def test_confirmed_frame_and_clamp():
    assert build_4ch_frame([10,20,30,0]).hex(" ").upper()=="4C 15 0A 14 1E 00 15 0D 0A"
    assert build_4ch_frame([255,140,60,0]).hex(" ").upper()=="4C 15 FF 8C 3C 00 5A 0D 0A"
    assert build_4ch_frame([0,0,0,0]).hex(" ").upper()=="4C 15 00 00 00 00 15 0D 0A"
    assert len(build_8ch_frame_unconfirmed([0]*8))==13
    assert build_4ch_frame([-1,300,2,0])[2:6]==bytes([0,255,2,0])
    try: build_4ch_frame([1,2,3]); assert False
    except ValueError: pass

def test_light_channel_mapping_and_off():
    a=build_engine("LIGHT_SINGLE_4",("SIMULATOR","SIMULATOR"),0)
    a.connect(); a.apply_pair((255,140,60),(40,90,255)); assert a.controller_a.frames[-1]==build_4ch_frame([255,140,60,0]); a.all_off(); assert a.controller_a.frames[-1]==build_4ch_frame([0,0,0,0]); a.disconnect()
    b=build_engine("LIGHT_DUAL_4",("SIMULATOR","SIMULATOR"),0)
    b.connect(); b.apply_pair((255,140,60),(40,90,255)); assert b.controller_a.frames[-1]==build_4ch_frame([255,140,60,0]); assert b.controller_b.frames[-1]==build_4ch_frame([40,90,255,0]); b.disconnect()
    c=build_engine("LIGHT_SINGLE_8",("SIMULATOR","SIMULATOR"),0)
    c.connect(); c.apply_pair((255,140,60),(40,90,255)); assert c.controller_a.frames[-1]==build_8ch_frame_unconfirmed([255,140,60,40,90,255,0,0]); c.disconnect()

def test_roi_shapes_and_arc_handle():
    shape=(120,140,3)
    rect=rasterize_shape(ROIShape("rectangle",bbox=(10,10,80,80)),shape)
    ellipse=rasterize_shape(ROIShape("ellipse",bbox=(10,10,80,80)),shape)
    roundrect=rasterize_shape(ROIShape("rounded_rectangle",bbox=(10,10,80,80),radius=18),shape)
    straight=ROIShape("free",points=[(20,20),(90,20),(90,90),(20,90)],bends=[None,None,None,None])
    curved=ROIShape("free",points=[(20,20),(90,20),(90,90),(20,90)],bends=[(55,5),None,None,None])
    mstraight=rasterize_shape(straight,shape); mcurve=rasterize_shape(curved,shape)
    assert all(m.shape==(120,140) for m in [rect,ellipse,roundrect,mstraight,mcurve])
    assert mcurve.sum()>mstraight.sum()
    outline=free_shape_outline(curved)
    assert min(np.linalg.norm(np.asarray(p)-np.asarray((55,5))) for p in outline)<1e-6
    collinear=ROIShape("free",points=[(20,20),(90,20),(90,90),(20,90)],bends=[(55,20),None,None,None])
    assert abs(int(rasterize_shape(collinear,shape).sum())-int(mstraight.sum()))<1500

def test_mask_composition_and_refusal():
    shape=(50,60,3); ins=np.zeros(shape[:2],np.uint8); ins[5:45,5:55]=255
    detect=ROI("d","d","detect",ROIShape("rectangle",bbox=(10,10,40,40)),True)
    ex=ROI("m","m","mask",ROIShape("rectangle",bbox=(20,20,30,30)),True)
    seg=np.zeros(shape[:2],np.uint8); seg[15:35,15:35]=255
    m=compose_detection_mask(shape,ins,[detect],[seg],[ex])
    assert m[16,16]>0 and m[25,25]==0 and m[2,2]==0
    try: compose_detection_mask(shape,ins,[],[],[]); assert False
    except MaskCompositionError: pass

def test_illumination_correction_channel_stats_and_outside_mask():
    h,w=160,240; x=np.linspace(60,190,w,dtype=np.float32)[None,:]; base=np.repeat(x,h,axis=0)
    img=np.stack([base*.9,base,base*.8],axis=2).clip(0,255).astype(np.uint8)
    cv2.line(img,(20,80),(210,80),(15,15,15),2)
    mask=np.zeros((h,w),np.uint8); mask[10:150,10:230]=255
    before=analyze_illumination(img,mask,8,10,15)
    corrected=correct_illumination(img,mask,.8,False)
    after=analyze_illumination(corrected,mask,8,10,15)
    assert set(before["channels"])=={"B","G","R"}
    assert after["lab_l"]["range_percent"]<before["lab_l"]["range_percent"]
    assert np.array_equal(corrected[mask==0],img[mask==0])
    before_contrast=abs(float(img[80,100].mean())-float(img[75,100].mean()))
    after_contrast=abs(float(corrected[80,100].mean())-float(corrected[75,100].mean()))
    assert before_contrast>0 and abs(after_contrast-before_contrast)/before_contrast<.10

def test_stitching_fallback_and_overlap():
    a=np.zeros((100,120,3),np.uint8); b=np.zeros_like(a)
    a[:]=(80,80,80); b[:]=(90,90,90)
    pair=FramePair(TimedFrame(a,time.monotonic(),0),TimedFrame(b,time.monotonic(),1))
    stitched=pair.stitched("Aligned side-by-side"); assert stitched.shape==(100,240,3)
    pair2=FramePair(TimedFrame(a,time.monotonic(),0),TimedFrame(b,time.monotonic(),1))
    auto=pair2.stitched("Auto feature stitch"); assert auto is not None and auto.shape[0]==100 and "fallback" in pair2.stitch_message.lower()
    rng=np.random.default_rng(2); base=rng.integers(0,256,(240,360,3),dtype=np.uint8); base=cv2.GaussianBlur(base,(3,3),0)
    overlap=FramePair(TimedFrame(base[:,:250],time.monotonic(),0),TimedFrame(base[:,110:],time.monotonic(),1))
    auto_overlap=overlap.stitched("Auto feature stitch")
    assert auto_overlap is not None and "ORB/RANSAC" in overlap.stitch_message and abs(auto_overlap.shape[1]-360)<20

def test_segmentation_output_disjoint():
    cam=SimulatedCamera(width=480,height=360); cam.open(); cam.start(); img=cam.read(); cam.close()
    roi=np.full(img.shape[:2],255,np.uint8)
    camera_roi=np.zeros(img.shape[:2],np.uint8); camera_roi[30:95,60:150]=255
    result=create_segmentation_backends()["Adaptive Phone Regions (Bulged Edge)"].segment(img,roi,{},camera_roi)
    assert len(result.segments)==4
    assert all(s.mask.shape==img.shape[:2] for s in result.segments)
    occupied=np.zeros(img.shape[:2],np.uint8)
    for s in result.segments:
        assert not np.any((occupied>0)&(s.mask>0)); occupied=cv2.bitwise_or(occupied,s.mask)

def test_plugins_and_raw_laplacian():
    logs=[]; registry=discover_algorithms(ROOT/"algorithms",lambda a,b:logs.append((a,b)))
    assert {"RAW Laplacian V1","Canny Blobs","YOLO .pt"}.issubset(set(registry.names()))
    img=np.full((160,160,3),130,np.uint8); cv2.circle(img,(80,80),9,(10,10,10),-1)
    params=RawLaplacianV1.DEFAULTS.copy(); params.update({"min_magnitude":5,"k":1.5,"min_area_px":5,"min_box_size_px":20,"morph_kernel":1})
    mask=np.full(img.shape[:2],255,np.uint8)
    result=RawLaplacianV1().process(img,mask,{"params":params})
    assert len(result.defects)>=1 and result.output.shape==img.shape and result.binary_mask.shape==img.shape[:2]
    assert any(b.x<=80<=b.x+b.w and b.y<=80<=b.y+b.h for b in result.defects)
    clean=RawLaplacianV1().process(np.full_like(img,130),mask,{"params":params})
    assert clean.output.shape==img.shape and len(clean.defects)==0

def test_capture_sets_and_unique_names():
    cam1=SimulatedCamera(0,320,240); cam2=SimulatedCamera(1,320,240)
    manager=CameraManager(cam1,cam2); manager.start((True,True))
    engine=build_engine("LIGHT_DUAL_4",("SIMULATOR","SIMULATOR"),0); engine.connect()
    recipes_a=[Recipe(True,"WARM",255,140,60),Recipe(True,"WARM",200,100,40),Recipe(True,"WARM",255,255,255)]
    recipes_b=[Recipe(True,"WARM",255,140,60),Recipe(True,"BLUE",40,90,255),Recipe(True,"WARM",255,255,255)]
    with tempfile.TemporaryDirectory() as td:
        cap=CaptureManager(manager,lambda:engine,td)
        folder1,m1=cap.capture_selected("S24",recipes_a,recipes_b,[0,1,2],"Aligned side-by-side")
        folder2,m2=cap.capture_selected("S24",recipes_a,recipes_b,[0],"Aligned side-by-side")
        assert folder1.name=="set1" and folder2.name=="set2"
        assert (folder1/"WARM_stitched.png").exists()
        assert (folder1/"WARM_camera1.png").exists() and (folder1/"WARM_camera2.png").exists()
        assert (folder1/"WARM__BLUE_stitched.png").exists()
        assert (folder1/"WARM_2_stitched.png").exists()
        assert (folder1/"manifest.json").exists() and len(m1["items"])==3
        assert m1["items"][1]["name"]=="WARM__BLUE"
        assert engine.controller_a.frames[-1]==build_4ch_frame([0,0,0,0])
    engine.disconnect(); manager.stop()

def test_plugin_failure_isolated_and_multi_detector_results_separate():
    logs=[]
    with tempfile.TemporaryDirectory() as td:
        plugin_dir=Path(td)
        (plugin_dir/"broken.py").write_text("def this is invalid Python !!!",encoding="utf-8")
        plugin_source = (
            "from mobile_inspection_app.detection.base import DetectionAlgorithm, DetectionResult\n"
            "import numpy as np\n"
            "class SamplePlugin(DetectionAlgorithm):\n"
            "    name = 'Sample plugin'\n"
            "    def process(self, image, inspection_mask=None, context=None):\n"
            "        mask = np.zeros(image.shape[:2], np.uint8)\n"
            "        return DetectionResult(self.name, image.copy(), mask, 0.0, 'test', [], {})\n"
        )
        (plugin_dir/"sample_plugin.py").write_text(plugin_source,encoding="utf-8")
        registry=discover_algorithms(plugin_dir,lambda level,msg:logs.append((level,msg)))
        assert "Sample plugin" in registry.names()
        assert any("broken.py skipped" in msg for _,msg in logs)
    image=np.full((80,80,3),100,np.uint8); mask=np.full((80,80),255,np.uint8)
    detectors=[RawLaplacianV1(),discover_algorithms(ROOT/"algorithms").get("Canny Blobs")]
    results=[detector.process(image,mask,{"params":detector.create_default()}) for detector in detectors]
    assert len(results)==2 and results[0].algorithm!=results[1].algorithm
    assert all(result.output.shape==image.shape for result in results)

def test_image_folder_camera_replay():
    from mobile_inspection_app.camera.image_folder_camera import ImageFolderCamera
    with tempfile.TemporaryDirectory() as td:
        image=np.full((40,60,3),90,np.uint8); cv2.imwrite(str(Path(td)/"one.png"),image)
        replay=ImageFolderCamera(td,loop=True,fps=100); replay.open(); replay.start()
        frame=replay.read(200); replay.close()
        assert frame is not None and frame.shape==image.shape

def test_gui_smoke_if_display():
    """GUI integration smoke: run when a display (or Xvfb) is available; otherwise skip silently."""
    import tkinter as tk
    from tkinter import TclError
    from mobile_inspection_app.ui.app import MobileInspectionApp
    try:
        root=tk.Tk()
    except TclError:
        return
    target=ROOT/"config"/"app_config.json"
    prior=target.read_text(encoding="utf-8") if target.exists() else None
    app=None
    try:
        app=MobileInspectionApp(root)
        app.mode_var.set("DETECTION"); app._mode_changed()
        image=np.full((180,240,3),125,np.uint8); cv2.circle(image,(120,90),12,(15,15,15),-1)
        app.current_image=image.copy()
        app.roi_controller.current_role="detect"
        app.roi_controller.free_points=[(20,20),(220,20),(220,160),(20,160)]
        assert app.roi_controller.finish_free()
        app._refresh_roi_list()
        settings=app._snapshot_detection_settings(["RAW Laplacian V1"])
        settings["segmentation_enabled"]=False; settings["ticked_segment_ids"]=[]; settings["existing_segment_result"]=None
        working,mask,results,segments=app._process_image_for_detection(image,settings)
        combined=app._combine_result_images(working,results)
        app._detection_done(combined,working,mask,results,segments,settings["source_view"])
        assert results and results[0].output.shape==image.shape
    finally:
        if app is not None: app.close()
        else: root.destroy()
        if prior is None:
            try: target.unlink()
            except FileNotFoundError: pass
        else:
            target.parent.mkdir(parents=True,exist_ok=True); target.write_text(prior,encoding="utf-8")
