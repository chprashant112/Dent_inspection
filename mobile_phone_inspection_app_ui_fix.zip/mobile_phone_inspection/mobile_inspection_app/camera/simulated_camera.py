from __future__ import annotations
import time
import cv2
import numpy as np
from mobile_inspection_app.interfaces import CameraBackend

class SimulatedCamera(CameraBackend):
    """Deterministic synthetic phone view with edge, camera module and defects."""
    def __init__(self, camera_index: int = 0, width: int = 960, height: int = 720):
        self.camera_index = camera_index
        self.width, self.height = width, height
        self.exposure_us, self.gain, self.fps = 10000.0, 0.0, 20.0
        self._open = False
        self._running = False
        self._started = time.monotonic()
        self._frame_no = 0

    def open(self) -> None:
        self._open = True

    def apply_settings(self, exposure_us: float, gain: float, fps: float, width: int, height: int) -> None:
        self.exposure_us, self.gain, self.fps = exposure_us, gain, fps
        self.width, self.height = max(160, int(width)), max(120, int(height))

    def start(self) -> None:
        if not self._open: self.open()
        self._running = True
        self._started = time.monotonic()

    def read(self, timeout_ms: int = 1000) -> np.ndarray | None:
        if not self._running: return None
        h, w = self.height, self.width
        y, x = np.mgrid[0:h, 0:w]
        # Slightly uneven illumination, intentionally useful for exercising the correction panel.
        light = 0.78 + 0.20 * (x / max(w - 1, 1)) + 0.04 * np.sin(y / max(h, 1) * np.pi)
        bg = np.zeros((h, w, 3), np.float32)
        bg[:] = (37, 42, 47) if self.camera_index == 0 else (42, 39, 36)
        bg *= light[..., None]
        img = np.clip(bg, 0, 255).astype(np.uint8)
        # Each camera sees half of the same object; geometry varies slightly per side.
        cx, cy = int(w * (0.51 if self.camera_index == 0 else 0.47)), int(h * .52)
        pw, ph = int(w * .38), int(h * .82)
        outer = (cx - pw // 2, cy - ph // 2, cx + pw // 2, cy + ph // 2)
        cv2.rectangle(img, (outer[0]+20, outer[1]), (outer[2]-20, outer[3]), (78, 82, 87), -1)
        cv2.ellipse(img, (cx, outer[1]+20), (pw//2-20, 23), 0, 180, 360, (78,82,87), -1)
        cv2.ellipse(img, (cx, outer[3]-20), (pw//2-20, 23), 0, 0, 180, (78,82,87), -1)
        # Inner back glass and the curved/bulged perimeter.
        margin = max(5, int(w * .012))
        inner = (outer[0]+margin*2, outer[1]+margin*2, outer[2]-margin*2, outer[3]-margin*2)
        cv2.rectangle(img, (inner[0]+16, inner[1]), (inner[2]-16, inner[3]), (111, 116, 120), -1)
        cv2.ellipse(img, (cx, inner[1]+16), (max(1,(inner[2]-inner[0])//2-16), 15), 0, 180, 360, (111,116,120), -1)
        cv2.ellipse(img, (cx, inner[3]-16), (max(1,(inner[2]-inner[0])//2-16), 15), 0, 0, 180, (111,116,120), -1)
        # Directional gradient near edge makes the simulated curved band visible.
        cv2.rectangle(img, (inner[0]+16, inner[1]+20), (inner[2]-16, inner[3]-20), (127, 130, 132), -1)
        cv2.rectangle(img, (inner[0]+16, inner[1]+20), (inner[0]+26, inner[3]-20), (91, 96, 100), -1)
        cv2.rectangle(img, (inner[2]-27, inner[1]+20), (inner[2]-16, inner[3]-20), (151, 154, 155), -1)
        # Camera bump and lenses.
        bump_x, bump_y = outer[0] + int(pw*.27), outer[1] + int(ph*.15)
        cv2.rectangle(img, (bump_x-5,bump_y-5), (bump_x+int(pw*.34),bump_y+int(pw*.30)), (54,58,62), -1, cv2.LINE_AA)
        rr = max(5, int(w * .013))
        for dx, dy in [(0,0),(rr*2,0),(0,rr*2)]:
            cv2.circle(img, (bump_x+dx+rr,bump_y+dy+rr), rr, (24,27,30), -1, cv2.LINE_AA)
            cv2.circle(img, (bump_x+dx+rr-2,bump_y+dy+rr-2), max(2,rr//3), (87,104,119), -1, cv2.LINE_AA)
        cv2.circle(img, (bump_x+rr*4,bump_y+rr*4), max(3,rr//2), (185,175,143), -1)
        # Synthetic surface defects: scratch and a small dark blob.
        phase = self._frame_no % 2
        if self.camera_index == 0:
            cv2.line(img, (cx-int(pw*.28), cy+int(ph*.13)), (cx-int(pw*.20), cy+int(ph*.18)), (48, 49, 50), 2, cv2.LINE_AA)
            if phase == 0: cv2.circle(img, (cx+int(pw*.16), cy-int(ph*.14)), 5, (55, 56, 58), -1)
        else:
            cv2.line(img, (cx+int(pw*.09), cy+int(ph*.22)), (cx+int(pw*.24), cy+int(ph*.25)), (63, 65, 67), 2, cv2.LINE_AA)
        # Frame counter and a very small temporal brightness variation.
        pulse = int(2 * np.sin(time.monotonic() - self._started))
        if pulse: img = np.clip(img.astype(np.int16) + pulse, 0, 255).astype(np.uint8)
        self._frame_no += 1
        return img

    def stop(self) -> None: self._running = False
    def close(self) -> None: self.stop(); self._open = False
