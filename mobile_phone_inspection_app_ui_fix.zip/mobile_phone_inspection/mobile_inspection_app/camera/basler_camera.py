from __future__ import annotations
import numpy as np
from mobile_inspection_app.interfaces import CameraBackend

class BaslerCamera(CameraBackend):
    def __init__(self, device_index: int = 0):
        self.device_index = device_index
        self.camera = None
        self.converter = None

    def open(self) -> None:
        try:
            from pypylon import pylon
        except ImportError as exc:
            raise RuntimeError("Basler support requires optional package 'pypylon'.") from exc
        factory = pylon.TlFactory.GetInstance()
        devices = factory.EnumerateDevices()
        if self.device_index >= len(devices):
            raise RuntimeError(f"Basler camera index {self.device_index} not found; {len(devices)} device(s) discovered.")
        self.camera = pylon.InstantCamera(factory.CreateDevice(devices[self.device_index]))
        self.camera.Open()
        self.converter = pylon.ImageFormatConverter()
        self.converter.OutputPixelFormat = pylon.PixelType_BGR8packed
        self.converter.OutputBitAlignment = pylon.OutputBitAlignment_MsbAligned

    def apply_settings(self, exposure_us: float, gain: float, fps: float, width: int, height: int) -> None:
        if self.camera is None: raise RuntimeError("Camera is not open")
        for node, value in (("ExposureTime", exposure_us), ("Gain", gain), ("AcquisitionFrameRate", fps), ("Width", width), ("Height", height)):
            try:
                param = getattr(self.camera, node)
                if hasattr(param, "IsWritable") and not param.IsWritable(): continue
                param.SetValue(value)
            except Exception as exc:
                print(f"WARN Basler camera {self.device_index}: cannot set {node}={value}: {exc}")

    def start(self) -> None:
        if self.camera is None: self.open()
        from pypylon import pylon
        self.camera.StartGrabbing(pylon.GrabStrategy_LatestImageOnly)

    def read(self, timeout_ms: int = 1000) -> np.ndarray | None:
        if self.camera is None or not self.camera.IsGrabbing(): return None
        from pypylon import pylon
        result = self.camera.RetrieveResult(timeout_ms, pylon.TimeoutHandling_Return)
        if result is None: return None
        try:
            if not result.GrabSucceeded(): return None
            return self.converter.Convert(result).GetArray().copy()
        finally:
            result.Release()

    def stop(self) -> None:
        try:
            if self.camera is not None and self.camera.IsGrabbing(): self.camera.StopGrabbing()
        except Exception: pass
    def close(self) -> None:
        self.stop()
        try:
            if self.camera is not None and self.camera.IsOpen(): self.camera.Close()
        finally: self.camera = None
