from __future__ import annotations
import time
from pathlib import Path
import cv2
import numpy as np
from mobile_inspection_app.interfaces import CameraBackend

class ImageFolderCamera(CameraBackend):
    """Replay images from a folder as if they were live camera frames."""
    def __init__(self, folder: str | Path, loop: bool=True, fps: float=5.0):
        self.folder=Path(folder); self.loop=loop; self.fps=max(.1,float(fps)); self.files=[]; self.index=0; self._open=False; self._running=False; self._last=0.0
        self.exposure_us=10000.0; self.gain=0.0; self.width=960; self.height=720
    def open(self):
        if not self.folder.exists(): raise RuntimeError(f"Image folder does not exist: {self.folder}")
        self.files=sorted([p for p in self.folder.iterdir() if p.suffix.lower() in {".png",".jpg",".jpeg",".bmp",".tif",".tiff"}])
        if not self.files: raise RuntimeError(f"No supported images found in {self.folder}")
        self._open=True; self.index=0
    def apply_settings(self,exposure_us,gain,fps,width,height):
        self.exposure_us=float(exposure_us); self.gain=float(gain); self.fps=max(.1,float(fps)); self.width=int(width); self.height=int(height)
    def start(self):
        if not self._open: self.open()
        self._running=True; self._last=0.0
    def read(self,timeout_ms=1000):
        if not self._running: return None
        delay=1/max(self.fps,.1); now=time.monotonic()
        if now-self._last<delay: time.sleep(min(delay-(now-self._last),max(timeout_ms,0)/1000)); return None
        if self.index>=len(self.files):
            if not self.loop: self._running=False; return None
            self.index=0
        image=cv2.imread(str(self.files[self.index]),cv2.IMREAD_COLOR); self.index+=1; self._last=time.monotonic()
        if image is None: return None
        return image
    def stop(self): self._running=False
    def close(self): self.stop(); self._open=False
