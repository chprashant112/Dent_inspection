from __future__ import annotations
import threading, time
from mobile_inspection_app.camera.frame_pair import TimedFrame, FramePair
from mobile_inspection_app.camera.simulated_camera import SimulatedCamera
from mobile_inspection_app.camera.basler_camera import BaslerCamera
from mobile_inspection_app.config import CameraSettings
from mobile_inspection_app.interfaces import CameraBackend

class CameraManager:
    def __init__(self, backend1: CameraBackend | None = None, backend2: CameraBackend | None = None, on_log=None):
        self.backends = [backend1 or SimulatedCamera(0), backend2 or SimulatedCamera(1)]
        self.settings = [CameraSettings(), CameraSettings()]
        self.on_log = on_log or (lambda level, message: None)
        self._latest: list[TimedFrame | None] = [None,None]
        self._threads: list[threading.Thread] = []
        self._stop = threading.Event()
        self._locks = [threading.Lock(), threading.Lock()]
        self._active = [False,False]
        self._homography = None

    def start(self, active: tuple[bool,bool] = (True,True), settings: list[CameraSettings] | None = None) -> None:
        self.stop()
        self._stop.clear()
        self._homography=None
        self._latest=[None,None]
        if settings: self.settings = settings
        for i, enabled in enumerate(active):
            if not enabled: continue
            backend=self.backends[i]
            try:
                backend.open(); s=self.settings[i]
                backend.apply_settings(s.exposure_us,s.gain,s.fps,s.width,s.height); backend.start()
                self._active[i]=True
                t=threading.Thread(target=self._grab_loop,args=(i,),daemon=True,name=f"camera-grab-{i+1}")
                t.start(); self._threads.append(t)
            except Exception as exc:
                self._active[i]=False; self.on_log("ERROR",f"Camera {i+1} failed to start: {exc}")

    def _grab_loop(self, index: int) -> None:
        while not self._stop.is_set():
            try:
                image=self.backends[index].read(100)
                if image is not None:
                    frame=TimedFrame(image,time.monotonic(),index)
                    with self._locks[index]: self._latest[index]=frame
                else: time.sleep(.005)
            except Exception as exc:
                self.on_log("WARN",f"Camera {index+1} read error: {exc}"); time.sleep(.1)

    def _cache_homography(self, transform):
        self._homography=transform.copy()

    def latest(self, stitch_mode: str = "Aligned side-by-side") -> FramePair:
        frames=[]
        for i in range(2):
            with self._locks[i]: frames.append(self._latest[i])
        return FramePair(frames[0],frames[1],stitch_mode,_homography=self._homography,_on_homography=self._cache_homography)

    def capture_once(self, timeout: float = 2.0, after_timestamp: float | None = None) -> FramePair:
        deadline=time.monotonic()+timeout
        active_indices=[i for i,active in enumerate(self._active) if active]
        if not active_indices: raise RuntimeError("No camera is running")
        while time.monotonic()<deadline:
            pair=self.latest()
            all_frames=(pair.camera1,pair.camera2)
            required=[all_frames[i] for i in active_indices]
            if all(frame is not None for frame in required) and (after_timestamp is None or all(frame.timestamp>after_timestamp for frame in required)):
                return pair
            time.sleep(.01)
        raise TimeoutError("Not all active cameras supplied a fresh frame before timeout")

    def apply_settings(self, index: int, settings: CameraSettings) -> None:
        self.settings[index]=settings
        self._homography=None
        if self._active[index]: self.backends[index].apply_settings(settings.exposure_us,settings.gain,settings.fps,settings.width,settings.height)

    def stop(self) -> None:
        self._stop.set()
        for t in self._threads:
            if t.is_alive(): t.join(timeout=.5)
        self._threads.clear()
        for i,b in enumerate(self.backends):
            try: b.stop(); b.close()
            except Exception as exc: self.on_log("WARN",f"Camera {i+1} close: {exc}")
            self._active[i]=False

    close=stop
