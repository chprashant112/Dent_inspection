# Lightweight test runner that needs no pytest.
from tests.test_core import *


def main():
    tests = [
        test_confirmed_4ch_frame,
        test_dual_simulator_updates_both_lights,
        test_algorithm_is_external_plugin,
        test_effective_mask_and_segmentation,
        test_illumination_returns_heatmap,
    ]
    for fn in tests:
        fn()
        print('PASS', fn.__name__)
    print('All core tests passed.')


if __name__ == '__main__':
    main()
