# Mobile Vision Inspection App V6

This revision adds a real two-mode inspection workflow on top of the modular camera/light stack:

- **Testing Mode**: capture → draw Inspection ROI → draw Mask ROI → illumination + histogram → segmentation → select segments → external detection algorithm → human review → approved defect dataset.
- **Detection Mode**: use the last saved Testing Profile on a fresh live/captured frame for a simplified inspection flow.

## Important architecture rule

Detection algorithms are **not hard-coded into the app**. The app discovers Python plugins from the root `algorithms/` folder. You can add/remove algorithm files without editing the GUI/application layer.

The supplied `algorithms/raw_laplacian.py` is the requested enhanced RAW Laplacian detector. It keeps the local mean/std idea, supports optional temporal frames through context, restricts work to the inspection mask, filters small/noisy contours into blob-like defects, and draws an expanded red bounding box around each accepted defect.

## Testing Mode pipeline

`Capture -> ROI -> Mask ROI -> Effective mask -> Illumination analysis -> Histogram -> Segmentation -> Segment selection -> Detection -> Review -> Dataset`

The effective mask is always represented in original image coordinates. The final inspection mask is:

`ROI AND NOT Mask ROI AND Selected Segments`

## Dataset output

Approved annotations are stored as a small self-contained dataset unit:

```text
dataset/
  S24/
    test_YYYYMMDD_HHMMSS/
      original.png
      annotated.png
      detection_mask.png
      metadata.json
      defects/
        defect_001.png
        defect_002.png
```

`metadata.json` contains ROI/mask, selected segments, algorithm, lighting information, bounding boxes, and human approval status.

## Lighting topologies

The current lighting layer supports:

1. `LIGHT_DUAL_4`: two 4-channel controllers, one RGB light per controller.
2. `LIGHT_SINGLE_8`: one 8-channel controller, RGB1 on CH1-3 and RGB2 on CH4-6.
3. `LIGHT_SINGLE_4`: one RGB light on CH1-3.

The confirmed ALT-E4RS 4-channel protocol remains `4C 15 CH1 CH2 CH3 CH4 XOR CR LF` at 9600 8N1. The 8-channel frame is still explicitly marked **UNVERIFIED** and is not represented as confirmed hardware behavior.

## Run

```bash
pip install -r requirements.txt
python run.py
```

Basler cameras require the Basler pypylon runtime/SDK on the target machine.
