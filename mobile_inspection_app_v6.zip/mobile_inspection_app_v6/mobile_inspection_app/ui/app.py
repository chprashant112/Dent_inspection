from __future__ import annotations
import json, threading
from pathlib import Path
import tkinter as tk
from tkinter import ttk,messagebox
import cv2
from PIL import Image,ImageTk
from ..config import AppConfig,TestingProfile,save_profile,load_profile
from ..camera import CameraManager
from ..capture import CaptureManager
from ..detection import discover_algorithms
from ..pipeline import TestingService
from ..dataset import save_approved_defects
from ..roi.masks import effective_mask
from .theme import BG,configure_style,SUCCESS,DANGER
from .widgets import ScrollableFrame,ImageViewer
from .panels.camera_panel import CameraPanel
from .panels.lighting_panel import LightingPanel
from .panels.capture_panel import CapturePanel
from .panels.testing_panel import TestingPanel
from .panels.detection_mode_panel import DetectionModePanel
from .panels.log_panel import LogPanel

class Application(tk.Tk):
    def __init__(self):
        super().__init__(); self.title("Mobile Vision Inspection · V6"); self.minsize(1180,760); self.configure(bg=BG); self.protocol("WM_DELETE_WINDOW",self._close); configure_style(self)
        self.config_data=AppConfig(); self.camera_manager=CameraManager(); self.registry=discover_algorithms(Path("algorithms"),logger=self._plugin_log); self.testing_service=TestingService(self.config_data.analysis); self._last_frame=None; self._running=False; self._capture_busy=False; self._mode=tk.StringVar(value="Testing Mode")
        self._build_ui(); self.profile=load_profile(); self.profile_path=Path("profiles/last_testing_profile.json") if self.profile else None; self.detection_mode_panel.set_profile(self.profile)
    def _plugin_log(self,line):
        if hasattr(self,'log_panel'): self.after(0,lambda:self.log_panel.log(line))
    def _build_ui(self):
        root=ttk.Frame(self,style="App.TFrame"); root.pack(fill="both",expand=True)
        header=ttk.Frame(root,style="Header.TFrame",padding=(18,12));header.pack(fill="x");header.columnconfigure(1,weight=1)
        ttk.Label(header,text="MOBILE VISION INSPECTION",style="Title.TLabel").grid(row=0,column=0,sticky="w"); ttk.Label(header,text="Camera · Lighting · Capture · Testing / Detection",style="Sub.TLabel").grid(row=1,column=0,sticky="w")
        ttk.Label(header,text="MODEL",style="Mini.TLabel").grid(row=0,column=2,sticky="e"); self.model_var=tk.StringVar(value=self.config_data.model_name); ttk.Entry(header,textvariable=self.model_var,width=15).grid(row=1,column=2,sticky="e"); ttk.Button(header,text="SAVE",style="Neutral.TButton",command=self.save_model).grid(row=1,column=3,padx=7)
        ttk.Label(header,text="MODE",style="Mini.TLabel").grid(row=0,column=4,sticky="e"); ttk.Combobox(header,textvariable=self._mode,values=("Testing Mode","Detection Mode"),state="readonly",width=17).grid(row=1,column=4,sticky="e"); self._mode_widget=header.grid_slaves(row=1,column=4)[0]; self._mode_widget.bind("<<ComboboxSelected>>",lambda e:self.switch_mode())
        body=ttk.Frame(root,style="App.TFrame",padding=10); body.pack(fill="both",expand=True); body.columnconfigure(0,weight=7); body.columnconfigure(1,weight=3); body.rowconfigure(0,weight=1)
        left=ttk.Frame(body,style="App.TFrame"); left.grid(row=0,column=0,sticky="nsew",padx=(0,10)); left.columnconfigure(0,weight=1); left.rowconfigure(0,weight=7); left.rowconfigure(1,weight=3)
        pf=ttk.LabelFrame(left,text="LIVE VIEW");pf.grid(row=0,column=0,sticky="nsew"); self.preview=ImageViewer(pf,text="Start camera(s)");self.preview.pack(fill="both",expand=True,padx=5,pady=5)
        rf=ttk.LabelFrame(left,text="ANALYSIS / INSPECTION");rf.grid(row=1,column=0,sticky="nsew",pady=(10,0)); self.viewer_nb=ttk.Notebook(rf); self.viewer_nb.pack(fill="both",expand=True,padx=4,pady=4); self.viewers={}
        for name in ("Result","Heatmap","Histogram","Segments"):
            frame=ttk.Frame(self.viewer_nb); frame.pack(fill="both",expand=True); lab=ImageViewer(frame,text=name);lab.pack(fill="both",expand=True);self.viewers[name]=lab;self.viewer_nb.add(frame,text=name)
        right=ScrollableFrame(body);right.grid(row=0,column=1,sticky="nsew");right.inner.columnconfigure(0,weight=1)
        self.log_panel=LogPanel(right.inner); self.camera_panel=CameraPanel(right.inner,self.camera_manager,self.config_data.camera1,self.config_data.camera2,self.log_panel.log,self._camera_started,self._camera_stopped); self.camera_panel.pack(fill="x",pady=(0,8));
        self.lighting_panel=LightingPanel(right.inner,self.config_data.lighting_topology,self.config_data.lighting_baudrate,self.config_data.capture.settle_ms,self.log_panel.log,self._light_changed);self.lighting_panel.pack(fill="x",pady=(0,8));self.capture_panel=CapturePanel(right.inner,self.capture_set);self.capture_panel.pack(fill="x",pady=(0,8));self.testing_panel=TestingPanel(right.inner,self,self.log_panel.log);self.testing_panel.pack(fill="x",pady=(0,8));self.testing_panel.set_algorithms(self.registry.names());self.detection_mode_panel=DetectionModePanel(right.inner,self,self.log_panel.log);self.detection_mode_panel.pack_forget()
        self.switch_mode();
    def _light_changed(self,engine):
        if hasattr(self,'capture_manager'): self.capture_manager.light_engine=engine
    def _camera_started(self): self._running=True; self._tick_preview()
    def _camera_stopped(self): self._running=False; self.preview.configure(image="",text="Camera stopped")
    def _tick_preview(self):
        if not self._running:return
        pair=self.camera_manager.latest(); frame=pair.stitched(); view=self.camera_panel.selected_view; frame=pair.camera1 if view=="Camera 1" else pair.camera2 if view=="Camera 2" else frame
        if frame is not None: self._last_frame=frame.copy(); self._show(self.preview,frame,1600,900)
        self.after(40,self._tick_preview)
    def _show(self,label,frame,max_w=1000,max_h=420):
        h,w=frame.shape[:2]; s=min(max_w/w,max_h/h,1.0); img=cv2.resize(frame,(max(1,int(w*s)),max(1,int(h*s))),interpolation=cv2.INTER_AREA) if s<1 else frame; img=Image.fromarray(cv2.cvtColor(img,cv2.COLOR_BGR2RGB)); photo=ImageTk.PhotoImage(img); label.configure(image=photo,text=""); label._photo=photo
    def show_result_image(self,img): self._show(self.viewers['Result'],img)
    def show_heatmap(self,img): self._show(self.viewers['Heatmap'],img)
    def show_histogram(self,img): self._show(self.viewers['Histogram'],img)
    def show_segments(self,img): self._show(self.viewers['Segments'],img)
    def switch_mode(self):
        if self._mode.get()=="Testing Mode": self.detection_mode_panel.pack_forget(); self.testing_panel.pack(fill="x",pady=(0,8));
        else: self.testing_panel.pack_forget(); self.detection_mode_panel.pack(fill="x",pady=(0,8));
    def refresh_algorithms(self):
        self.registry=discover_algorithms(Path("algorithms"),logger=self._plugin_log)
        self.testing_panel.set_algorithms(self.registry.names(), self.testing_panel.alg_name.get() if self.testing_panel.alg_name.get() in self.registry.names() else None)
        self.detection_mode_panel.set_profile(self.profile)
        self.log_panel.log(f"INFO: algorithms refreshed: {self.registry.names()}")

    def save_model(self): self.config_data.model_name=self.model_var.get().strip(); self.log_panel.log(f"INFO: model = {self.config_data.model_name}")
    def capture_set(self):
        if self._capture_busy:return
        if not self._running:messagebox.showwarning("Capture","Start camera(s) first.");return
        self._capture_busy=True; self.capture_panel.status.set("Capturing selected set…")
        def work():
            try:
                a=self.lighting_panel.recipes('a'); b=self.lighting_panel.recipes('b') if self.lighting_panel.is_dual() else a; selected=[i for i,r in enumerate(a) if r.enabled and (not self.lighting_panel.is_dual() or b[i].enabled)]
                self.capture_manager=CaptureManager(self.camera_manager,self.lighting_panel.engine,self.config_data.capture,self.log_panel.log); out,_=self.capture_manager.capture_selected(self.model_var.get(),a,b,selected); self.after(0,lambda:self.capture_panel.status.set(f"Saved set → {out}"))
            except Exception as exc:self.after(0,lambda:messagebox.showerror("Capture",str(exc)))
            finally:self._capture_busy=False
        threading.Thread(target=work,daemon=True).start()
    def capture_test_image(self,idx,source,callback):
        if not self._running:
            messagebox.showwarning("Testing","Start camera(s) first.")
            return
        def work():
            try:
                a=self.lighting_panel.recipes('a'); b=self.lighting_panel.recipes('b') if self.lighting_panel.is_dual() else a
                i=max(1,min(4,int(idx)))-1
                cm=CaptureManager(self.camera_manager,self.lighting_panel.engine,self.config_data.capture,self.log_panel.log)
                path,img=cm.capture_single(self.model_var.get(),a[i],b[i] if self.lighting_panel.is_dual() else None,source)
                self.after(0,lambda p=path,im=img,ln=a[i].name: callback(p,im,ln))
            except Exception as exc:
                self.after(0,lambda:messagebox.showerror("Test capture",str(exc)))
        threading.Thread(target=work,daemon=True).start()

    def analyze_testing(self,panel):
        if panel.image is None or panel.roi is None:
            messagebox.showwarning("Testing","Capture/load an image and draw ROI first.")
            return
        def work():
            try:
                analysis=self.testing_service.analyze(panel.image,panel.roi,panel.mask_roi)
                from ..segmentation import SegmentationRegistry
                backend=SegmentationRegistry().create(panel.seg_name.get(),checkpoint_path=panel.sam_path.get())
                seg_result=backend.segment(panel.image,analysis.effective_mask)
                self.after(0,lambda:self._finish_testing_analysis(panel,analysis,seg_result))
            except Exception as exc:
                self.after(0,lambda:messagebox.showerror("Analysis / segmentation",str(exc)))
        threading.Thread(target=work,daemon=True).start()

    def _finish_testing_analysis(self,panel,analysis,seg_result):
        panel.analysis=analysis; panel.segment_result=seg_result; panel.populate_segments()
        self.show_heatmap(analysis.illumination.heatmap); self.show_histogram(analysis.histogram_image); self.show_segments(seg_result.overlay)
        panel.metrics.set(f"Illumination: {analysis.illumination.message}\nHistogram L*: mean={analysis.histogram_metrics['mean']:.1f}, std={analysis.histogram_metrics['std']:.1f}")
        panel.logger(analysis.illumination.message)
    def run_testing_detection(self,panel,image,effective,seg_result,ids,alg_name):
        if alg_name not in self.registry.names():messagebox.showerror("Detection","No external algorithm selected.");return
        final=effective.copy()
        import numpy as np
        seg=np.zeros_like(final)
        for segobj in seg_result.segments:
            if segobj.id in ids: seg[segobj.mask>0]=255
        final[(seg==0)]=0
        def work():
            try:
                detector=self.registry.create(alg_name); result=detector.process(image,final,context={"mode":"testing"}); self.after(0,lambda:panel.show_detection_result(result))
            except Exception as exc:self.after(0,lambda:messagebox.showerror("Detection",str(exc)))
        threading.Thread(target=work,daemon=True).start()
    def save_testing_dataset(self,panel):
        if not getattr(panel,'_result',None):messagebox.showwarning("Dataset","Run detection first.");return
        approved=[i for i,(label,v) in enumerate(panel.defect_vars.items(),1) if v.get()]
        r=panel._result; meta={"image_path":str(panel.image_path) if panel.image_path else "","roi":list(panel.roi),"mask_roi":None if panel.mask_roi is None else list(panel.mask_roi),"effective_area_px":int((panel.analysis.effective_mask>0).sum()) if panel.analysis else None,"segmentation_backend":panel.seg_name.get(),"selected_segments":[i for i,v in panel.selected_vars.items() if v.get()],"algorithm":r.algorithm,"algorithm_params":r.params,"approved_ids":approved,"model_name":self.model_var.get(),"light_name":panel.image_path.stem if panel.image_path else ""}
        try:base,_=save_approved_defects("dataset",self.model_var.get(),panel.image,r.output,r.binary_mask,r.defects,meta); messagebox.showinfo("Dataset saved",f"Saved approved dataset unit to:\n{base}")
        except Exception as exc:messagebox.showerror("Dataset",str(exc))
    def save_testing_profile(self,panel):
        if panel.image is None or panel.roi is None or panel.segment_result is None:messagebox.showwarning("Profile","Complete image + ROI + segmentation first.");return
        profile=TestingProfile(self.model_var.get(),panel.image.shape[1],panel.image.shape[0],tuple(panel.roi),panel.mask_roi,panel.seg_name.get(),[i for i,v in panel.selected_vars.items() if v.get()],panel.alg_name.get(),panel.source_view.get(),panel.light_name, panel.sam_path.get(), None, None); self.profile=profile; self.profile_path=save_profile(profile); self.detection_mode_panel.set_profile(profile); messagebox.showinfo("Profile saved",f"Saved to:\n{self.profile_path}")
    def capture_and_inspect(self,panel):
        if not self.profile:messagebox.showwarning("Detection Mode","Save a Testing Profile first.");return
        if not self._running:messagebox.showwarning("Detection Mode","Start camera(s) first.");return
        # Capture using the profile's lighting label when it matches one of the current recipes; otherwise use the first recipe.
        try:
            recipes=self.lighting_panel.recipes('a'); idx=0
            for i,r in enumerate(recipes):
                if r.name==self.profile.light_name: idx=i;break
            b=self.lighting_panel.recipes('b') if self.lighting_panel.is_dual() else recipes; cm=CaptureManager(self.camera_manager,self.lighting_panel.engine,self.config_data.capture,self.log_panel.log); _p,img=cm.capture_single(self.model_var.get(),recipes[idx],b[idx] if self.lighting_panel.is_dual() else None,self.profile.source_view); self._inspect_with_profile(panel,img,self.profile)
        except Exception as exc:messagebox.showerror("Detection Mode",str(exc))
    def inspect_live(self,panel):
        if not self.profile:messagebox.showwarning("Detection Mode","Save a Testing Profile first.");return
        if self._last_frame is None:messagebox.showwarning("Detection Mode","No live frame available.");return
        self._inspect_with_profile(panel,self._last_frame.copy(),self.profile)
    def _inspect_with_profile(self,panel,image,profile):
        if (image.shape[1],image.shape[0])!=(profile.image_width,profile.image_height):messagebox.showwarning("Detection Mode","Current image size does not match the Testing Profile.");return
        def work():
            try:
                analysis=self.testing_service.analyze(image,profile.roi,profile.mask_roi)
                from ..segmentation import SegmentationRegistry
                backend=SegmentationRegistry().create(profile.segmentation_backend, checkpoint_path=profile.sam_checkpoint_path)
                seg_res=backend.segment(image,analysis.effective_mask); selected=np.zeros_like(analysis.effective_mask)
                for seg in seg_res.segments:
                    if seg.id in profile.selected_segments:selected[seg.mask>0]=255
                final=analysis.effective_mask.copy(); final[selected==0]=0; detector=self.registry.create(self.detection_mode_panel.alg.get() or profile.algorithm_name); result=detector.process(image,final,context={"mode":"detection"}); self.after(0,lambda:panel.show_result(result))
            except Exception as exc:self.after(0,lambda:messagebox.showerror("Detection Mode",str(exc)))
        threading.Thread(target=work,daemon=True).start()
    def _close(self):
        try:self.lighting_panel.all_off();self.lighting_panel.disconnect()
        except Exception:pass
        self.camera_manager.close(); self.destroy()
