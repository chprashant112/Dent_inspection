# Mobile Vision Inspection App V8

Traditional industrial vision inspection workflow for Basler/OpenCV cameras and ALT-E4RS lighting.

## Pipeline

Camera live feed → Inspection ROI → Mask ROI → optional automatic illumination regulation → illumination heatmap/histogram → live segmentation → region selection → localized RAW Laplacian V1 detection.

The supplied adaptive segmentation follows the phone-geometry / continuous bulged-edge approach: phone boundary is locked first; the internal edge/shadow path is estimated from Lab dark-line evidence, gradients, local Laplacian response and directional continuity; regions are then separated into Back Glass, Camera Module, Bulged Edge/Edge, and Surrounding.

## Detection

Detection algorithms are external plugins under `algorithms/`. There is no built-in detector embedded in the application. RAW Laplacian V1 exposes GUI-editable threshold, morphology, blob-box and region-specific kernel settings.

For selected edge regions, the detector uses long anisotropic local windows by default: vertical edge uses a high row/low column ratio and horizontal edge uses a low row/high column ratio. Back glass and camera module use more balanced local windows.

## Current build intentionally excludes

Deep-learning segmentation/model adapters and human-approval/dataset collection have been removed from this build. They can be added later without changing the camera/lighting/segmentation/detection pipeline contracts.

## Illumination regulator

The Camera panel includes an automatic uniform-illumination regulator. It uses the current Inspection ROI and, for dual-light topologies, iteratively balances the left and right illumination by adjusting the two RGB light outputs. A single-light topology cannot correct a spatial illumination gradient because it has only one spatial actuator.
