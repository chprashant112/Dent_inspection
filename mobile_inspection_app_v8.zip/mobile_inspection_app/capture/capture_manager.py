from __future__ import annotations
import json, re
from datetime import datetime
from pathlib import Path
import cv2
from ..config import CaptureConfig, LightRecipe

def safe_name(text):
    return re.sub(r"[^A-Za-z0-9._-]+","_",text.strip()) or "unnamed"

class CaptureManager:
    def __init__(self, camera_manager, light_engine, config: CaptureConfig, logger=print):
        self.camera_manager, self.light_engine, self.config, self.logger = camera_manager, light_engine, config, logger
    def _next_set_dir(self, model_name):
        root=Path(self.config.output_root)/safe_name(model_name); root.mkdir(parents=True,exist_ok=True)
        nums=[]
        for p in root.glob("set*"):
            m=re.fullmatch(r"set(\d+)",p.name,re.I)
            if m: nums.append(int(m.group(1)))
        path=root/f"set{max(nums,default=0)+1}"; path.mkdir(); return path
    def capture_selected(self, model_name, recipes_a, recipes_b, selected_indices):
        if not selected_indices: raise ValueError("Select at least one lighting state before Capture.")
        if self.light_engine is None: raise RuntimeError("Connect the lighting engine first.")
        dual=getattr(self.light_engine,"dual",False); outdir=self._next_set_dir(model_name); manifest=[]
        for idx in selected_indices:
            a=recipes_a[idx]; a.validate(); b=recipes_b[idx] if dual else None
            if b: b.validate()
            name=safe_name(a.name or (b.name if b else "") or f"Light_{idx+1}")
            self.light_engine.apply_pair(a.rgb,b.rgb if b else a.rgb)
            try: pair=self.camera_manager.capture_once(self.config.camera_timeout_ms/1000)
            finally: self.light_engine.all_off()
            saved=[]
            stitched=pair.stitched()
            if self.config.save_stitched and stitched is not None:
                fn=f"{name}_stitched.png"; cv2.imwrite(str(outdir/fn),stitched); saved.append(fn)
            if self.config.save_individual_cameras:
                for n,img in (("camera1",pair.camera1),("camera2",pair.camera2)):
                    if img is not None:
                        fn=f"{name}_{n}.png"; cv2.imwrite(str(outdir/fn),img); saved.append(fn)
            manifest.append({"light_index":idx+1,"name":name,"rgb_a":a.rgb,"rgb_b":b.rgb if b else None,"files":saved})
        (outdir/"manifest.json").write_text(json.dumps({"capture_time":datetime.now().isoformat(),"items":manifest},indent=2),encoding="utf-8")
        self.logger(f"CAPTURE COMPLETE: {outdir}")
        return outdir, manifest
    def capture_single(self, model_name, recipe_a: LightRecipe, recipe_b=None, source_view="Stitched"):
        if self.light_engine is None: raise RuntimeError("Connect the lighting engine first.")
        recipe_a.validate()
        if recipe_b: recipe_b.validate()
        self.light_engine.apply_pair(recipe_a.rgb, recipe_b.rgb if recipe_b else recipe_a.rgb)
        try: pair=self.camera_manager.capture_once(self.config.camera_timeout_ms/1000)
        finally: self.light_engine.all_off()
        if source_view=="Camera 1": image=pair.camera1
        elif source_view=="Camera 2": image=pair.camera2
        else: image=pair.stitched()
        if image is None: raise RuntimeError(f"No image available for {source_view}")
        stamp=datetime.now().strftime("%Y%m%d_%H%M%S_%f")[:-3]
        folder=Path(self.config.output_root)/safe_name(model_name)/"testing"; folder.mkdir(parents=True,exist_ok=True)
        name=safe_name(recipe_a.name or "test_light")
        path=folder/f"{stamp}_{name}_{source_view.replace(' ','').lower()}.png"; cv2.imwrite(str(path),image)
        return path,image
