from __future__ import annotations

import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pathlib import Path

import cv2

from ..widgets import CollapsibleCard
from ..roi_editor import ROIEditor, SingleRectEditor
from ...segmentation import SegmentationRegistry


class TestingPanel(CollapsibleCard):
    """R&D pipeline: ROI → illumination → live segmentation → region selection → detection."""

    def __init__(self, parent, app, logger, **kwargs):
        super().__init__(parent, "TESTING MODE", open_by_default=True, **kwargs)
        self.app = app
        self.logger = logger
        self.seg_registry = SegmentationRegistry()
        self.image = None
        self.image_path = None
        self.light_name = ""
        self.roi = None
        self.mask_roi = None
        self.camera_rect = None
        self.analysis = None
        self.segment_result = None
        self.selected_vars = {}
        self._segment_widgets = {}
        self._build()

    def _build(self):
        b = self.body
        b.columnconfigure(0, weight=1)
        row = 0

        ttk.Label(b, text="1. Camera / ROI", style="Mini.TLabel").grid(row=row, column=0, sticky="w")
        row += 1
        rr = ttk.Frame(b, style="Card.TFrame")
        rr.grid(row=row, column=0, sticky="ew")
        rr.columnconfigure(1, weight=1)
        self.source_view = tk.StringVar(value="Stitched")
        ttk.Label(rr, text="Source").grid(row=0, column=0, sticky="w")
        ttk.Combobox(rr, textvariable=self.source_view, values=("Stitched", "Camera 1", "Camera 2"), state="readonly", width=13).grid(row=0, column=1, sticky="ew", padx=5)
        ttk.Button(rr, text="USE LIVE FRAME", style="Mini.TButton", command=self.use_live_frame).grid(row=0, column=2, padx=(4, 0))
        row += 1
        self.img_status = tk.StringVar(value="No frame selected")
        ttk.Label(b, textvariable=self.img_status, style="Mini.TLabel", wraplength=340).grid(row=row, column=0, sticky="w", pady=(2, 4))
        row += 1
        ttk.Button(b, text="DRAW INSPECTION ROI + MASK ROI", command=self.edit_roi).grid(row=row, column=0, sticky="ew")
        row += 1
        self.roi_status = tk.StringVar(value="ROI: not set | Mask: none")
        ttk.Label(b, textvariable=self.roi_status, style="Mini.TLabel", wraplength=340).grid(row=row, column=0, sticky="w", pady=(4, 5))
        row += 1

        ttk.Label(b, text="2. Illumination", style="Mini.TLabel").grid(row=row, column=0, sticky="w")
        row += 1
        ir = ttk.Frame(b, style="Card.TFrame")
        ir.grid(row=row, column=0, sticky="ew")
        ir.columnconfigure((0, 1), weight=1)
        ttk.Button(ir, text="ANALYZE ILLUMINATION", command=self.app.analyze_illumination_only).grid(row=0, column=0, sticky="ew", padx=(0, 3))
        ttk.Button(ir, text="REGULATE NOW", style="Accent.TButton", command=self.app.regulate_illumination_now).grid(row=0, column=1, sticky="ew", padx=(3, 0))
        row += 1
        self.illum_status = tk.StringVar(value="Illumination: not measured")
        ttk.Label(b, textvariable=self.illum_status, style="Mini.TLabel", wraplength=340).grid(row=row, column=0, sticky="w", pady=(4, 5))
        row += 1

        ttk.Label(b, text="3. Segmentation", style="Mini.TLabel").grid(row=row, column=0, sticky="w")
        row += 1
        sr = ttk.Frame(b, style="Card.TFrame")
        sr.grid(row=row, column=0, sticky="ew")
        sr.columnconfigure(1, weight=1)
        self.seg_name = tk.StringVar(value="Adaptive Phone Regions (Bulged Edge)")
        ttk.Label(sr, text="Backend").grid(row=0, column=0, sticky="w")
        self.seg_combo = ttk.Combobox(sr, textvariable=self.seg_name, values=self.seg_registry.names(), state="readonly")
        self.seg_combo.grid(row=0, column=1, sticky="ew", padx=5)
        row += 1
        self.camera_roi_button = ttk.Button(b, text="DRAW CAMERA ROI (Adaptive, optional)", command=self.edit_camera_roi)
        self.camera_roi_button.grid(row=row, column=0, sticky="ew")
        row += 1
        self.camera_roi_status = tk.StringVar(value="Camera ROI: not set")
        ttk.Label(b, textvariable=self.camera_roi_status, style="Mini.TLabel", wraplength=340).grid(row=row, column=0, sticky="w", pady=(2, 4))
        row += 1
        self.analysis_button = ttk.Button(b, text="ANALYZE + SEGMENT CURRENT FRAME", style="Accent.TButton", command=self.analyze_segment)
        self.analysis_button.grid(row=row, column=0, sticky="ew", pady=(3, 4))
        row += 1
        live_row = ttk.Frame(b, style="Card.TFrame")
        live_row.grid(row=row, column=0, sticky="ew", pady=(0, 7))
        live_row.columnconfigure((0, 1), weight=1)
        self.live_segmentation_var = tk.BooleanVar(value=False)
        self.live_detection_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(live_row, text="LIVE SEGMENTATION", variable=self.live_segmentation_var, command=self.toggle_live_segmentation).grid(row=0, column=0, sticky="w")
        ttk.Checkbutton(live_row, text="LIVE DETECTION", variable=self.live_detection_var, command=self.toggle_live_detection).grid(row=0, column=1, sticky="w")
        row += 1

        self.segment_frame = ttk.LabelFrame(b, text="Segments — detection is allowed only in checked regions")
        self.segment_frame.grid(row=row, column=0, sticky="ew", pady=(0, 6))
        self.segment_frame.columnconfigure(0, weight=1)
        row += 1
        self.select_info = tk.StringVar(value="Segmentation result will populate region switches")
        ttk.Label(b, textvariable=self.select_info, style="Mini.TLabel", wraplength=340).grid(row=row, column=0, sticky="w")
        row += 1
        ttk.Button(b, text="SHOW SELECTED INSPECTION MASK", command=self.refresh_selected_mask).grid(row=row, column=0, sticky="ew", pady=(4, 7))
        row += 1

        ttk.Label(b, text="4. Detection — RAW Laplacian V1", style="Mini.TLabel").grid(row=row, column=0, sticky="w")
        row += 1
        self.alg_name = tk.StringVar(value="")
        self.alg_combo = ttk.Combobox(b, textvariable=self.alg_name, state="readonly")
        self.alg_combo.grid(row=row, column=0, sticky="ew")
        row += 1

        self.settings_frame = ttk.LabelFrame(b, text="Detection V1 settings")
        self.settings_frame.grid(row=row, column=0, sticky="ew", pady=(6, 6))
        self.settings_frame.columnconfigure(1, weight=1)
        row += 1
        self.settings_vars = {}
        self._settings_widgets = {}
        self._build_settings_placeholder()

        arun = ttk.Frame(b, style="Card.TFrame")
        arun.grid(row=row, column=0, sticky="ew")
        arun.columnconfigure((0, 1), weight=1)
        ttk.Button(arun, text="RUN DETECTION ON SELECTED REGIONS", style="BigAccent.TButton", command=self.run_detection).grid(row=0, column=0, sticky="ew", padx=(0, 3))
        ttk.Button(arun, text="DETECT CURRENT LIVE FRAME", style="Accent.TButton", command=self.run_live_detection_once).grid(row=0, column=1, sticky="ew", padx=(3, 0))
        row += 1
        ttk.Button(b, text="REFRESH ALGORITHMS", style="Mini.TButton", command=self.app.refresh_algorithms).grid(row=row, column=0, sticky="ew")
        row += 1
        self.result_status = tk.StringVar(value="Detection result: not run")
        ttk.Label(b, textvariable=self.result_status, style="Mini.TLabel", wraplength=340).grid(row=row, column=0, sticky="w", pady=(7, 0))

        self.seg_combo.bind("<<ComboboxSelected>>", lambda _e: self.on_segmentation_backend_changed())
        self.alg_combo.bind("<<ComboboxSelected>>", lambda _e: self.rebuild_algorithm_settings())
        self.on_segmentation_backend_changed()

    def _build_settings_placeholder(self):
        for c in self.settings_frame.winfo_children(): c.destroy()
        ttk.Label(self.settings_frame, text="Select an algorithm to load its parameters.", style="Mini.TLabel").grid(row=0, column=0, columnspan=2, sticky="w")

    def rebuild_algorithm_settings(self):
        for c in self.settings_frame.winfo_children():
            c.destroy()
        self.settings_vars = {}
        self._settings_widgets = {}
        name = self.alg_name.get()
        if not name or name not in self.app.registry.names():
            self._build_settings_placeholder()
            return
        try:
            alg = self.app.registry.create(name)
        except Exception as exc:
            ttk.Label(self.settings_frame, text=f"Settings unavailable: {exc}", style="Mini.TLabel").grid(row=0, column=0, sticky="w")
            return
        schema = getattr(alg, "SETTINGS_SCHEMA", None)
        defaults = getattr(alg, "DEFAULTS", {})
        if not schema:
            ttk.Label(self.settings_frame, text="This algorithm exposes no editable settings.", style="Mini.TLabel").grid(row=0, column=0, sticky="w")
            return

        ttk.Label(self.settings_frame, text="Threshold / blob", style="Sub.TLabel").grid(row=0, column=0, columnspan=2, sticky="w", pady=(0, 4))
        row = 1
        for spec in schema:
            key = spec["key"]
            var = tk.BooleanVar(value=bool(defaults.get(key, False))) if spec["kind"] == "bool" else tk.StringVar(value=str(defaults.get(key, "")))
            self.settings_vars[key] = var
            ttk.Label(self.settings_frame, text=spec["label"], style="CardBody.TLabel").grid(row=row, column=0, sticky="w", pady=2)
            kind = spec["kind"]
            if kind == "bool":
                w = ttk.Checkbutton(self.settings_frame, variable=var)
            elif kind == "choice":
                w = ttk.Combobox(self.settings_frame, textvariable=var, values=[str(x) for x in spec["values"]], state="readonly", width=12)
            elif kind == "float":
                w = ttk.Spinbox(self.settings_frame, textvariable=var, from_=spec["from"], to=spec["to"], increment=spec.get("step", 0.1), width=12)
            else:
                w = ttk.Spinbox(self.settings_frame, textvariable=var, from_=spec["from"], to=spec["to"], increment=spec.get("step", 1), width=12)
            w.grid(row=row, column=1, sticky="ew", padx=(8, 0), pady=2)
            self._settings_widgets[key] = w
            row += 1
        ttk.Label(self.settings_frame, text="Edge uses an automatically oriented long kernel: vertical side = rows≫cols, horizontal side = cols≫rows.", style="Mini.TLabel", wraplength=330).grid(row=row, column=0, columnspan=2, sticky="w", pady=(5, 0))

    def on_segmentation_backend_changed(self):
        self.camera_roi_button.configure(state="normal" if "Adaptive Phone Regions" in self.seg_name.get() else "disabled")

    def use_live_frame(self):
        frame = self.app.get_live_frame_for_view(self.source_view.get())
        if frame is None:
            messagebox.showwarning("Live frame", "Start the camera feed first.")
            return
        self.stop_live_modes()
        self.set_image(None, frame, "LIVE")
        self.roi = self.mask_roi = self.camera_rect = None
        self.analysis = self.segment_result = None
        self.roi_status.set("ROI: not set | Mask: none")
        self.camera_roi_status.set("Camera ROI: not set")
        self.app.show_result_image(frame)

    def set_image(self, path, image, light_name=""):
        self.image_path = Path(path) if path else None
        self.light_name = light_name or ""
        self.image = image.copy()
        self.img_status.set(f"Image: {self.image_path.name if self.image_path else self.light_name or 'memory'} | {image.shape[1]}×{image.shape[0]}")

    def capture(self):
        self.app.capture_test_image(1, self.source_view.get(), self._capture_done)

    def _capture_done(self, path, image, light_name=""):
        self.stop_live_modes()
        self.set_image(path, image, light_name)
        self.roi = self.mask_roi = self.camera_rect = None
        self.analysis = self.segment_result = None
        self.roi_status.set("ROI: not set | Mask: none")
        self.camera_roi_status.set("Camera ROI: not set")
        self.app.show_result_image(image)

    def load(self):
        p = filedialog.askopenfilename(filetypes=[("Images", "*.png;*.jpg;*.jpeg;*.bmp;*.tif;*.tiff"), ("All files", "*.*")])
        if not p:
            return
        img = cv2.imread(p)
        if img is None:
            messagebox.showerror("Load image", "Could not read image")
            return
        self.stop_live_modes()
        self.set_image(p, img)
        self.roi = self.mask_roi = self.camera_rect = None
        self.analysis = self.segment_result = None
        self.roi_status.set("ROI: not set | Mask: none")
        self.camera_roi_status.set("Camera ROI: not set")
        self.app.show_result_image(img)

    def edit_roi(self):
        image = self.image if self.image is not None else self.app.get_live_frame_for_view(self.source_view.get())
        if image is None:
            messagebox.showwarning("ROI", "Start the camera or load an image first.")
            return
        self.image = image.copy()
        ROIEditor(self, self.image, self.roi, self.mask_roi, self._roi_applied)

    def _roi_applied(self, roi, mask):
        self.roi, self.mask_roi = roi, mask
        self.roi_status.set(f"ROI: {roi} | Mask: {mask or 'none'}")
        self.analysis = self.segment_result = None

    def edit_camera_roi(self):
        image = self.image if self.image is not None else self.app.get_live_frame_for_view(self.source_view.get())
        if image is None:
            messagebox.showwarning("Camera ROI", "Start the camera or load an image first.")
            return
        SingleRectEditor(self, image, self.camera_rect, "Adaptive Segmentation · Camera ROI", self._camera_roi_applied)

    def _camera_roi_applied(self, rect):
        self.camera_rect = rect
        self.camera_roi_status.set(f"Camera ROI: {rect or 'none'}")
        self.segment_result = None

    def analyze_segment(self):
        self.app.analyze_testing(self)

    def toggle_live_segmentation(self):
        if self.live_segmentation_var.get():
            if self.roi is None:
                self.live_segmentation_var.set(False)
                messagebox.showwarning("Live segmentation", "Draw the Inspection ROI first.")
                return
            if not self.app.is_camera_running:
                self.live_segmentation_var.set(False)
                messagebox.showwarning("Live segmentation", "Start the camera feed first.")
                return
            self.app.start_live_segmentation(self)
        else:
            self.app.stop_live_segmentation(self)

    def toggle_live_detection(self):
        if self.live_detection_var.get():
            if not self.live_segmentation_var.get() or self.segment_result is None:
                self.live_detection_var.set(False)
                messagebox.showwarning("Live detection", "Start live segmentation and wait for a segmentation result.")
                return
            self.app.start_live_detection(self)
        else:
            self.app.stop_live_detection(self)

    def stop_live_modes(self):
        self.live_segmentation_var.set(False)
        self.live_detection_var.set(False)
        self.app.stop_live_segmentation(self)
        self.app.stop_live_detection(self)

    @staticmethod
    def _default_selected(seg):
        return seg.name.lower() in {"back glass", "edge", "bulged edge", "camera module"}

    def populate_segments(self, preserve=True):
        if self.segment_result is None:
            return
        previous = {i: v.get() for i, v in self.selected_vars.items()} if preserve else {}
        desired_ids = [seg.id for seg in self.segment_result.segments]
        if desired_ids != list(self._segment_widgets.keys()):
            for c in self.segment_frame.winfo_children():
                c.destroy()
            self._segment_widgets = {}
            self.selected_vars = {}
            for seg in self.segment_result.segments:
                value = previous.get(seg.id, self._default_selected(seg))
                v = tk.BooleanVar(value=value)
                self.selected_vars[seg.id] = v
                widget = ttk.Checkbutton(self.segment_frame, text=f"{seg.id}. {seg.name} ({seg.area_px:,} px)", variable=v, command=self.refresh_selected_mask)
                widget.pack(anchor="w")
                self._segment_widgets[seg.id] = widget
        else:
            for seg in self.segment_result.segments:
                self._segment_widgets[seg.id].configure(text=f"{seg.id}. {seg.name} ({seg.area_px:,} px)")
        self.select_info.set("Only checked segment pixels are sent to the detector.")

    def selected_ids(self):
        return [i for i, v in self.selected_vars.items() if v.get()]

    def selected_region_defs(self):
        ids = set(self.selected_ids())
        return [{"id": seg.id, "name": seg.name, "mask": seg.mask} for seg in (self.segment_result.segments if self.segment_result else []) if seg.id in ids]

    def get_detection_params(self):
        out = {}
        for key, var in self.settings_vars.items():
            val = var.get()
            try:
                spec = next(s for s in getattr(self.app.registry.create(self.alg_name.get()), "SETTINGS_SCHEMA", []) if s["key"] == key)
                if spec["kind"] == "float": val = float(val)
                elif spec["kind"] == "int": val = int(float(val))
                elif spec["kind"] == "choice":
                    val = int(val) if str(val).isdigit() else val
            except Exception:
                pass
            out[key] = val
        return out

    def run_detection(self):
        if self.image is None or self.segment_result is None or self.analysis is None:
            messagebox.showwarning("Detection", "Run segmentation first.")
            return
        ids = self.selected_ids()
        if not ids:
            messagebox.showwarning("Detection", "Select at least one segment.")
            return
        self.app.run_testing_detection(self, self.image, self.analysis.effective_mask, self.segment_result, ids, self.alg_name.get(), self.get_detection_params())

    def run_live_detection_once(self):
        if self.roi is None or self.segment_result is None:
            messagebox.showwarning("Live detection", "Enable live segmentation first.")
            return
        self.app.run_live_detection_once(self)

    def refresh_selected_mask(self):
        self.app.update_selected_mask(self)

    def set_algorithms(self, names, default=None):
        self.alg_combo["values"] = names
        self.alg_name.set(default or (names[0] if names else ""))
        self.rebuild_algorithm_settings()

    def show_detection_result(self, result, live=False):
        self.app.show_result_image(result.output)
        self.app.select_result_view()
        prefix = "LIVE: " if live else ""
        self.result_status.set(f"{prefix}{result.message} | score={result.score if result.score is not None else 'n/a'} | boxes={len(result.defects)}")
