from tkinter import ttk
import tkinter as tk
from ..widgets import CollapsibleCard
class LogPanel(CollapsibleCard):
    def __init__(self,parent,**kwargs):
        super().__init__(parent,"SYSTEM LOG",open_by_default=False,**kwargs); self.body.columnconfigure(0,weight=1); self.text=tk.Text(self.body,height=8,wrap="word"); self.text.grid(row=0,column=0,sticky="ew")
    def log(self,line): self.text.insert("end",line+"\n"); self.text.see("end")
