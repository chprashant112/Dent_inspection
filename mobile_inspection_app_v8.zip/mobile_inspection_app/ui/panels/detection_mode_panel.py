from __future__ import annotations

import tkinter as tk
from tkinter import ttk
from ..widgets import CollapsibleCard


class DetectionModePanel(CollapsibleCard):
    def __init__(self, parent, app, logger, **kwargs):
        super().__init__(parent, "DETECTION MODE", open_by_default=True, **kwargs)
        self.app = app
        self.logger = logger
        self.profile_status = tk.StringVar(value="No Testing Profile loaded")
        self.alg = tk.StringVar()
        self._build()

    def _build(self):
        b = self.body
        b.columnconfigure(0, weight=1)
        ttk.Label(b, text="Production-style inspection uses the saved Testing Profile.", style="Sub.TLabel", wraplength=300).grid(row=0, column=0, sticky="w")
        ttk.Label(b, textvariable=self.profile_status, style="Mini.TLabel", wraplength=300).grid(row=1, column=0, sticky="w", pady=(4, 8))
        self.alg_combo = ttk.Combobox(b, textvariable=self.alg, state="readonly")
        self.alg_combo.grid(row=2, column=0, sticky="ew")
        ttk.Button(b, text="CAPTURE + INSPECT", style="BigAccent.TButton", command=self.capture_inspect).grid(row=3, column=0, sticky="ew", pady=(8, 4))
        ttk.Button(b, text="INSPECT LIVE FRAME", style="Accent.TButton", command=self.inspect_live).grid(row=4, column=0, sticky="ew")
        self.result = tk.StringVar(value="")
        ttk.Label(b, textvariable=self.result, style="Status.TLabel", wraplength=300).grid(row=5, column=0, sticky="w", pady=(10, 0))

    def set_profile(self, profile):
        names = self.app.registry.names()
        self.alg_combo["values"] = names
        if profile:
            self.profile_status.set(
                f"Profile: {profile.segmentation_backend} → {profile.algorithm_name} | "
                f"ROI={profile.roi} | segments={profile.selected_segments}"
            )
            self.alg.set(profile.algorithm_name if profile.algorithm_name in names else (names[0] if names else ""))
        else:
            self.profile_status.set("No Testing Profile loaded")
            self.alg.set(names[0] if names else "")

    def capture_inspect(self): self.app.capture_and_inspect(self)
    def inspect_live(self): self.app.inspect_live(self)

    def show_result(self, result):
        self.result.set(result.message)
        self.app.show_result_image(result.output)
        self.app.select_result_view()
