from __future__ import annotations
import cv2
import numpy as np

def build_histogram_image(image,effective_mask,width=640,height=360):
    lab=cv2.cvtColor(image,cv2.COLOR_BGR2LAB); values=lab[:,:,0][effective_mask>0]
    if values.size==0: raise ValueError("Effective area is empty")
    hist=cv2.calcHist([values.astype(np.uint8)],[0],None,[256],[0,256]).ravel()
    hist=hist/(max(float(hist.max()),1.0)); canvas=np.ones((height,width,3),np.uint8)*245
    base=height-45; left=45; right=width-15; top=25
    for x in range(256):
        x0=left+(right-left)*x/256; x1=left+(right-left)*(x+1)/256; y=base-int(hist[x]*(base-top)); cv2.rectangle(canvas,(int(x0),y),(max(int(x1),int(x0)+1),base),(70,100,180),-1)
    cv2.line(canvas,(left,base),(right,base),(30,30,30),1); cv2.putText(canvas,"L* intensity",(width//2-55,height-12),cv2.FONT_HERSHEY_SIMPLEX,0.55,(30,30,30),1,cv2.LINE_AA); cv2.putText(canvas,"Histogram of effective ROI",(left,18),cv2.FONT_HERSHEY_SIMPLEX,0.65,(30,30,30),1,cv2.LINE_AA)
    return canvas, {"mean":float(values.mean()),"std":float(values.std()),"p1":float(np.percentile(values,1)),"p50":float(np.percentile(values,50)),"p99":float(np.percentile(values,99))}
