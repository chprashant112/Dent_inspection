from __future__ import annotations
from dataclasses import dataclass
import cv2
import numpy as np
from mobile_inspection_app.config import AnalysisConfig

@dataclass
class IlluminationResult:
    mean: float; std: float; min_value: float; max_value: float
    cv_pct: float; range_pct: float; uniformity_pct: float; evenly_illuminated: bool
    heatmap: np.ndarray; message: str

def analyze_illumination(image,effective_mask,config:AnalysisConfig)->IlluminationResult:
    lab=cv2.cvtColor(image,cv2.COLOR_BGR2LAB); l=lab[:,:,0]
    if int(np.count_nonzero(effective_mask))<100: raise ValueError("Effective area is too small for illumination analysis")
    rows=max(2,int(config.illumination_grid_rows)); cols=max(2,int(config.illumination_grid_cols)); h,w=l.shape
    grid=[]; grid_cells=[]
    for ry in range(rows):
        for cx in range(cols):
            y0,y1=ry*h//rows,(ry+1)*h//rows; x0,x1=cx*w//cols,(cx+1)*w//cols
            vm=effective_mask[y0:y1,x0:x1]>0; vals=l[y0:y1,x0:x1][vm]
            if vals.size:
                grid.append(float(np.mean(vals))); grid_cells.append((ry,cx))
            else: grid.append(np.nan)
    g=np.asarray(grid,dtype=np.float32).reshape(rows,cols); valid=g[np.isfinite(g)]
    mean=float(valid.mean()); std=float(valid.std()); mn=float(valid.min()); mx=float(valid.max())
    cv_pct=100.0*std/max(mean,1e-6); range_pct=100.0*(mx-mn)/max(mean,1e-6); uniformity=max(0.0,100.0-range_pct); ok=range_pct<=float(config.illumination_uniformity_limit_pct)
    finite=np.nan_to_num(g,nan=mean); norm=cv2.normalize(finite,None,0,255,cv2.NORM_MINMAX); hm=cv2.applyColorMap(norm.astype(np.uint8),cv2.COLORMAP_JET); hm=cv2.resize(hm,(w,h),interpolation=cv2.INTER_NEAREST); hm[effective_mask==0]=0
    msg=f"grid mean={mean:.1f}, grid std={std:.1f}, range={range_pct:.1f}%, CV={cv_pct:.1f}% -> {'EVEN' if ok else 'NON-UNIFORM'}"
    return IlluminationResult(mean,std,mn,mx,cv_pct,range_pct,uniformity,ok,hm,msg)
