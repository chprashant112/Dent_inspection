from __future__ import annotations
from typing import Dict, List, Tuple
from ..interfaces import ChannelController, LightEngine
from .controllers import AltErs4Controller, AltErs8Controller, SimulatedController
from .engines import Dual4LightEngine, Single4LightEngine, Single8LightEngine

TOPOLOGIES = ("LIGHT_SINGLE_4", "LIGHT_DUAL_4", "LIGHT_SINGLE_8")
TOPOLOGY_LABELS = {
    "LIGHT_SINGLE_4": "1 controller · 1 RGB light (confirmed)",
    "LIGHT_DUAL_4": "2 controllers · 2 RGB lights",
    "LIGHT_SINGLE_8": "1 × 8-ch controller · 2 RGB lights ⚠ unverified",
}

def make_controller(topology, port, on_log=None):
    n = 8 if topology == "LIGHT_SINGLE_8" else 4
    if port == "SIMULATOR": return SimulatedController(n, logger=(on_log or print), label=topology)
    return AltErs8Controller(on_log) if n == 8 else AltErs4Controller(on_log)

def build_engine(topology, ports: Dict[str,str], baud: int, on_log=None, settle_ms=350) -> Tuple[LightEngine,List[ChannelController]]:
    if topology == "LIGHT_DUAL_4":
        a,b = ports["left"], ports["right"]
        if not a or not b: raise RuntimeError("Select both controller ports.")
        if a == b and a != "SIMULATOR": raise RuntimeError("Left and Right must use different COM ports.")
        ca, cb = make_controller(topology,a,on_log), make_controller(topology,b,on_log)
        ca.connect(a,baud); cb.connect(b,baud)
        return Dual4LightEngine(ca,cb,settle_ms), [ca,cb]
    port = ports.get("single")
    if not port: raise RuntimeError("Select the controller port.")
    c = make_controller(topology,port,on_log); c.connect(port,baud)
    return (Single8LightEngine(c,settle_ms) if topology=="LIGHT_SINGLE_8" else Single4LightEngine(c,settle_ms)), [c]
