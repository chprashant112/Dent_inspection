from __future__ import annotations
import time
from ..interfaces import ChannelController, LightEngine, clip_rgb

class Single4LightEngine(LightEngine):
    dual = False
    topology_name = "1 × 4-channel controller (1 RGB light)"
    def __init__(self, controller, settle_ms=350): self.controller, self.settle_ms = controller, settle_ms
    def apply(self, rgb):
        r,g,b = clip_rgb(rgb); self.controller.set_channels([r,g,b,0]); time.sleep(self.settle_ms/1000.0)
    def apply_pair(self, rgb_a, rgb_b): self.apply(rgb_a)
    def all_off(self): self.controller.all_off()
    def disconnect(self): self.controller.disconnect()

class Dual4LightEngine(LightEngine):
    dual = True
    topology_name = "2 × 4-channel controllers"
    def __init__(self, controller_a, controller_b, settle_ms=350): self.controller_a, self.controller_b, self.settle_ms = controller_a, controller_b, settle_ms
    def apply(self, rgb): self.apply_pair(rgb, rgb)
    def apply_pair(self, rgb_a, rgb_b):
        ar,ag,ab = clip_rgb(rgb_a); br,bg,bb = clip_rgb(rgb_b)
        # Back-to-back writes are intentional; common settle is after both writes.
        self.controller_a.set_channels([ar,ag,ab,0]); self.controller_b.set_channels([br,bg,bb,0])
        time.sleep(self.settle_ms/1000.0)
    def apply_single(self, side, rgb): self.apply_pair(rgb,(0,0,0)) if side=="a" else self.apply_pair((0,0,0),rgb)
    def all_off(self):
        errors=[]
        for c in (self.controller_a,self.controller_b):
            try: c.all_off()
            except Exception as e: errors.append(e)
        if errors: raise errors[0]
    def disconnect(self):
        for c in (self.controller_a,self.controller_b):
            try: c.disconnect()
            except Exception: pass

class Single8LightEngine(LightEngine):
    dual = True
    topology_name = "1 × 8-channel controller (UNVERIFIED protocol)"
    def __init__(self, controller, settle_ms=350): self.controller, self.settle_ms = controller, settle_ms
    def apply(self, rgb): self.apply_pair(rgb,(0,0,0))
    def apply_pair(self, rgb_a, rgb_b):
        a,b = clip_rgb(rgb_a), clip_rgb(rgb_b); levels=[0]*8
        levels[0:3], levels[3:6] = list(a), list(b)
        self.controller.set_channels(levels); time.sleep(self.settle_ms/1000.0)
    def apply_single(self, side, rgb): self.apply_pair(rgb,(0,0,0)) if side=="a" else self.apply_pair((0,0,0),rgb)
    def all_off(self): self.controller.all_off()
    def disconnect(self): self.controller.disconnect()
