from __future__ import annotations

from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Optional, Tuple
import json


@dataclass
class CameraConfig:
    name: str
    device_index: int = 0
    exposure_us: Optional[float] = None
    gain: Optional[float] = None
    fps: Optional[float] = None
    width: Optional[int] = None
    height: Optional[int] = None


@dataclass
class LightRecipe:
    name: str
    rgb: Tuple[int, int, int]
    enabled: bool = True

    def validate(self) -> None:
        if len(self.rgb) != 3:
            raise ValueError("RGB must contain exactly 3 values")
        if any(not 0 <= int(v) <= 255 for v in self.rgb):
            raise ValueError("RGB values must be between 0 and 255")


@dataclass
class CaptureConfig:
    output_root: Path = field(default_factory=lambda: Path("captures"))
    settle_ms: int = 350
    camera_timeout_ms: int = 1500
    save_individual_cameras: bool = True
    save_stitched: bool = True


@dataclass
class DetectionConfig:
    min_area_px: int = 20
    min_box_size_px: int = 50
    box_expand_ratio: float = 0.60
    box_color_bgr: Tuple[int, int, int] = (0, 0, 255)
    box_thickness: int = 3


@dataclass
class AnalysisConfig:
    illumination_grid_cols: int = 10
    illumination_grid_rows: int = 8
    illumination_uniformity_limit_pct: float = 15.0


@dataclass
class AppConfig:
    model_name: str = "S24"
    lighting_topology: str = "LIGHT_SINGLE_4"
    lighting_baudrate: int = 9600
    camera1: CameraConfig = field(default_factory=lambda: CameraConfig("Camera 1", 0))
    camera2: CameraConfig = field(default_factory=lambda: CameraConfig("Camera 2", 1))
    capture: CaptureConfig = field(default_factory=CaptureConfig)
    detection: DetectionConfig = field(default_factory=DetectionConfig)
    analysis: AnalysisConfig = field(default_factory=AnalysisConfig)


@dataclass
class TestingProfile:
    model_name: str
    image_width: int
    image_height: int
    roi: Tuple[int, int, int, int]
    mask_roi: Optional[Tuple[int, int, int, int]]
    segmentation_backend: str
    selected_segments: list[int]
    algorithm_name: str
    source_view: str = "Stitched"
    light_name: str = ""
    light_rgb_a: Optional[Tuple[int, int, int]] = None
    light_rgb_b: Optional[Tuple[int, int, int]] = None
    camera_rect: Optional[Tuple[int, int, int, int]] = None

    def to_dict(self):
        d = asdict(self)
        d["roi"] = list(self.roi)
        d["mask_roi"] = None if self.mask_roi is None else list(self.mask_roi)
        d["camera_rect"] = None if self.camera_rect is None else list(self.camera_rect)
        if self.light_rgb_a is not None:
            d["light_rgb_a"] = list(self.light_rgb_a)
        if self.light_rgb_b is not None:
            d["light_rgb_b"] = list(self.light_rgb_b)
        return d

    @classmethod
    def from_dict(cls, d):
        return cls(
            model_name=d["model_name"],
            image_width=int(d["image_width"]), image_height=int(d["image_height"]),
            roi=tuple(map(int, d["roi"])),
            mask_roi=None if d.get("mask_roi") is None else tuple(map(int, d["mask_roi"])),
            segmentation_backend=d["segmentation_backend"],
            selected_segments=[int(x) for x in d["selected_segments"]],
            algorithm_name=d["algorithm_name"],
            source_view=d.get("source_view", "Stitched"),
            light_name=d.get("light_name", ""),
            light_rgb_a=None if d.get("light_rgb_a") is None else tuple(map(int, d["light_rgb_a"])),
            light_rgb_b=None if d.get("light_rgb_b") is None else tuple(map(int, d["light_rgb_b"])),
            camera_rect=None if d.get("camera_rect") is None else tuple(map(int, d["camera_rect"])),
        )


def save_profile(profile: TestingProfile, path: Path = Path("profiles/last_testing_profile.json")) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(profile.to_dict(), indent=2), encoding="utf-8")
    return path


def load_profile(path: Path = Path("profiles/last_testing_profile.json")) -> Optional[TestingProfile]:
    if not path.exists():
        return None
    try:
        return TestingProfile.from_dict(json.loads(path.read_text(encoding="utf-8")))
    except Exception:
        return None
