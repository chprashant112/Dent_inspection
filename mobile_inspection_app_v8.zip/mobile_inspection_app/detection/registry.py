from __future__ import annotations
from dataclasses import dataclass
from typing import Callable
from .base import DetectionAlgorithm

@dataclass
class AlgorithmInfo:
    name: str
    factory: Callable[[], DetectionAlgorithm]
    source: str
    version: str = "1.0"
    error: str = ""

class DetectionRegistry:
    def __init__(self): self._items: dict[str,AlgorithmInfo] = {}
    def register(self, info: AlgorithmInfo): self._items[info.name] = info
    def names(self): return list(self._items.keys())
    def get_info(self, name): return self._items[name]
    def create(self, name): return self._items[name].factory()
    def diagnostics(self): return [v for v in self._items.values() if v.error]
