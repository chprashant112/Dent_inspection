from .base import DetectionAlgorithm, DetectionResult, DefectBox
from .registry import DetectionRegistry, AlgorithmInfo
from .discovery import discover_algorithms
__all__ = ["DetectionAlgorithm","DetectionResult","DefectBox","DetectionRegistry","AlgorithmInfo","discover_algorithms"]
