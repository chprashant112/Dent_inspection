from __future__ import annotations

"""Adaptive phone-region segmentation derived from the user's V4 detector.

The V4 logic first locks phone geometry, searches for a continuous internal
shadow path along the four sides, and defines the regions as:
    1. Back Glass
    2. Camera Module (optional user-drawn camera ROI)
    3. Bulged Edge
    4. Surrounding / outside phone

This module contains only the image-processing part so it can be used both
for a frozen test image and the live-feed testing pipeline.
"""

from typing import Optional

import cv2
import numpy as np

from .base import SegmentationBackend, Segment, SegmentResult

EDGE_MIN_OFFSET = 3
EDGE_MAX_OFFSET = 32
CORNER_FRAC = 0.14
SMOOTHNESS = 1.8
LINE_HALF = 2


def odd(v: float) -> int:
    v = max(1, int(round(v)))
    return v if v % 2 else v + 1


def norm_percentile(a, p1=2, p2=98):
    a = np.asarray(a, np.float32)
    good = np.isfinite(a)
    if not np.any(good):
        return np.zeros_like(a, np.float32)
    lo, hi = np.percentile(a[good], [p1, p2])
    if hi <= lo + 1e-6:
        return np.zeros_like(a, np.float32)
    return np.clip((a - lo) / (hi - lo), 0, 1)


def rounded_rect_mask(shape, x1, y1, x2, y2, radius):
    h, w = shape[:2]
    out = np.zeros((h, w), np.uint8)
    x1, x2 = int(max(0, x1)), int(min(w - 1, x2))
    y1, y2 = int(max(0, y1)), int(min(h - 1, y2))
    if x2 <= x1 or y2 <= y1:
        return out
    r = int(max(1, radius))
    r = min(r, max(1, (x2 - x1) // 2), max(1, (y2 - y1) // 2))
    cv2.rectangle(out, (x1 + r, y1), (x2 - r, y2), 255, -1)
    cv2.rectangle(out, (x1, y1 + r), (x2, y2 - r), 255, -1)
    for cx, cy in ((x1 + r, y1 + r), (x2 - r, y1 + r), (x1 + r, y2 - r), (x2 - r, y2 - r)):
        cv2.circle(out, (cx, cy), r, 255, -1)
    return out


def _smooth_profile(p, sigma=4):
    p = np.asarray(p, np.float32)
    return cv2.GaussianBlur(p.reshape(1, -1), (odd(max(5, sigma * 5)), 1), sigma).ravel()


def find_phone_geometry(img, search_mask=None):
    h, w = img.shape[:2]
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY).astype(np.float32)
    gray = cv2.GaussianBlur(gray, (0, 0), 1.2)
    gx = np.abs(cv2.Sobel(gray, cv2.CV_32F, 1, 0, ksize=3))
    gy = np.abs(cv2.Sobel(gray, cv2.CV_32F, 0, 1, ksize=3))

    allowed = np.ones((h, w), np.float32) if search_mask is None else (search_mask > 0).astype(np.float32)
    gx *= allowed
    gy *= allowed

    y0, y1 = int(0.15 * h), int(0.85 * h)
    x_profile = _smooth_profile(gx[y0:y1].sum(axis=0), 3)

    left_lo, left_hi = int(0.08 * w), int(0.46 * w)
    right_lo, right_hi = int(0.54 * w), int(0.92 * w)
    if left_hi <= left_lo or right_hi <= right_lo:
        raise RuntimeError("Image is too small for phone geometry search.")
    lx = left_lo + int(np.argmax(x_profile[left_lo:left_hi]))
    rx = right_lo + int(np.argmax(x_profile[right_lo:right_hi]))
    width = rx - lx
    if width <= 0:
        raise RuntimeError("Could not find left/right phone boundaries.")

    x0, x1 = int(0.25 * w), int(0.75 * w)
    y_profile = _smooth_profile(gy[:, x0:x1].sum(axis=1), 3)
    top_lo, top_hi = int(0.01 * h), int(0.30 * h)
    ty = top_lo + int(np.argmax(y_profile[top_lo:top_hi]))
    bot_lo, bot_hi = int(0.58 * h), int(0.97 * h)
    candidates = np.argsort(y_profile[bot_lo:bot_hi])[::-1] + bot_lo
    by = None
    best = 1e12
    target_h = width / 0.48
    for cy in candidates[:100]:
        ph = cy - ty
        aspect = width / max(ph, 1)
        if 0.34 <= aspect <= 0.64:
            score = abs(ph - target_h) - 0.01 * float(y_profile[cy])
            if score < best:
                best = score
                by = int(cy)
    if by is None:
        by = int(round(ty + width / 0.48))

    height = by - ty
    if height <= 0:
        raise RuntimeError("Could not find top/bottom phone boundaries.")
    aspect = width / float(height)
    if not 0.34 <= aspect <= 0.64:
        raise RuntimeError(f"Phone geometry failed aspect check: width={width}, height={height}, aspect={aspect:.3f}")

    pad = max(1, int(round(0.004 * min(width, height))))
    lx += pad
    rx -= pad
    ty += pad
    by -= pad
    radius = max(4, int(round(0.065 * width)))
    mask = rounded_rect_mask(img.shape[:2], lx, ty, rx, by, radius)
    if search_mask is not None:
        mask = cv2.bitwise_and(mask, (search_mask > 0).astype(np.uint8) * 255)
        ys, xs = np.where(mask > 0)
        if len(xs) < 100:
            raise RuntimeError("Phone mask collapsed after applying the inspection ROI.")

    return mask, (lx, ty, rx, by), {"width": rx - lx, "height": by - ty, "aspect": (rx - lx) / float(max(by - ty, 1))}


def local_laplacian_z(L, sigma=5.0):
    smooth = cv2.GaussianBlur(L, (0, 0), 1.0)
    lap = np.abs(cv2.Laplacian(smooth, cv2.CV_32F, 3))
    mu = cv2.GaussianBlur(lap, (0, 0), sigma)
    mu2 = cv2.GaussianBlur(lap * lap, (0, 0), sigma)
    std = np.sqrt(np.maximum(mu2 - mu * mu, 1.0))
    return (lap - mu) / std


def anisotropic_continuity(resp, vertical=True):
    kshape = (15, 2) if vertical else (2, 15)
    kernel = np.ones(kshape, np.float32)
    kernel /= kernel.sum()
    return cv2.filter2D(resp.astype(np.float32), -1, kernel)


def viterbi_path(score, smoothness=SMOOTHNESS):
    score = np.asarray(score, np.float32)
    n, m = score.shape
    dp = np.full((n, m), -1e9, np.float32)
    prev = np.zeros((n, m), np.int16)
    dp[0] = score[0]
    offsets = np.arange(m, dtype=np.float32)
    for i in range(1, n):
        for j in range(m):
            trans = dp[i - 1] - smoothness * np.abs(offsets - offsets[j])
            k = int(np.argmax(trans))
            dp[i, j] = score[i, j] + trans[k]
            prev[i, j] = k
    path = np.zeros(n, np.int16)
    path[-1] = int(np.argmax(dp[-1]))
    for i in range(n - 1, 0, -1):
        path[i] = prev[i, path[i]]
    return path.astype(np.int32)


def side_path(img, phone_mask, side, max_offset=24):
    h, w = phone_mask.shape
    L = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)[:, :, 0].astype(np.float32)
    smooth = cv2.GaussianBlur(L, (0, 0), 1.0)
    sx = np.abs(cv2.Sobel(smooth, cv2.CV_32F, 1, 0, 3))
    sy = np.abs(cv2.Sobel(smooth, cv2.CV_32F, 0, 1, 3))
    lapz = np.maximum(local_laplacian_z(L), 0)
    sxn = norm_percentile(sx)
    syn = norm_percentile(sy)
    vx = anisotropic_continuity(sxn, vertical=True)
    hy = anisotropic_continuity(syn, vertical=False)

    ys, xs = np.where(phone_mask > 0)
    xL, xR, yT, yB = int(xs.min()), int(xs.max()), int(ys.min()), int(ys.max())
    offsets = np.arange(EDGE_MIN_OFFSET, max(EDGE_MIN_OFFSET + 1, min(EDGE_MAX_OFFSET, int(max_offset))) + 1, dtype=np.int32)

    def vertical(base_x, coords, direction):
        out = np.zeros((len(coords), len(offsets)), np.float32)
        for j, d in enumerate(offsets):
            c = base_x + direction * int(d)
            if c - 5 < 0 or c + 6 >= w:
                continue
            center = np.mean(L[coords, c - 1:c + 2], axis=1)
            left = np.mean(L[coords, c - 5:c - 2], axis=1)
            right = np.mean(L[coords, c + 3:c + 6], axis=1)
            out[:, j] = 0.5 * (left + right) - center
        return out

    def horizontal(base_y, coords, direction):
        out = np.zeros((len(coords), len(offsets)), np.float32)
        for j, d in enumerate(offsets):
            c = base_y + direction * int(d)
            if c - 5 < 0 or c + 6 >= h:
                continue
            center = np.mean(L[c - 1:c + 2, coords], axis=0)
            left = np.mean(L[c - 5:c - 2, coords], axis=0)
            right = np.mean(L[c + 3:c + 6, coords], axis=0)
            out[:, j] = 0.5 * (left + right) - center
        return out

    if side in ("left", "right"):
        start = yT + int(CORNER_FRAC * (yB - yT))
        end = yB - int(CORNER_FRAC * (yB - yT))
        coords = np.arange(start, end + 1, dtype=np.int32)
        base = xL if side == "left" else xR
        direction = 1 if side == "left" else -1
        dark = vertical(base, coords, direction)
        grad_img, cont_img = sxn, vx
        grads = np.zeros_like(dark); laps = np.zeros_like(dark); conts = np.zeros_like(dark)
        for j, d in enumerate(offsets):
            c = base + direction * int(d)
            if 0 <= c < w:
                grads[:, j] = grad_img[coords, c]
                laps[:, j] = np.clip(lapz[coords, c] / 6.0, 0, 1)
                conts[:, j] = cont_img[coords, c]
    else:
        start = xL + int(CORNER_FRAC * (xR - xL))
        end = xR - int(CORNER_FRAC * (xR - xL))
        coords = np.arange(start, end + 1, dtype=np.int32)
        base = yT if side == "top" else yB
        direction = 1 if side == "top" else -1
        dark = horizontal(base, coords, direction)
        grad_img, cont_img = syn, hy
        grads = np.zeros_like(dark); laps = np.zeros_like(dark); conts = np.zeros_like(dark)
        for j, d in enumerate(offsets):
            c = base + direction * int(d)
            if 0 <= c < h:
                grads[:, j] = grad_img[c, coords]
                laps[:, j] = np.clip(lapz[c, coords] / 6.0, 0, 1)
                conts[:, j] = cont_img[c, coords]

    score = 1.65 * np.clip(dark / 30.0, -1, 1) + 0.75 * grads + 0.65 * laps + 1.05 * conts
    path = viterbi_path(score)
    return coords, offsets[path], (xL, xR, yT, yB)


def build_bulged_edge(img, phone_mask, camera_mask=None, max_offset=24):
    h, w = phone_mask.shape
    edge = np.zeros((h, w), np.uint8)
    details = {}
    for side in ("left", "right", "top", "bottom"):
        coords, offs, bb = side_path(img, phone_mask, side, max_offset=max_offset)
        xL, xR, yT, yB = bb
        details[side] = {
            "median_offset": float(np.median(offs)),
            "mean_offset": float(np.mean(offs)),
            "min_offset": int(np.min(offs)),
            "max_offset": int(np.max(offs)),
        }
        for coord, d in zip(coords, offs):
            d = int(d)
            if side == "left":
                edge[coord, xL:min(xL + d, w - 1) + 1] = 255
            elif side == "right":
                edge[coord, max(xL, xR - d):xR + 1] = 255
            elif side == "top":
                edge[yT:min(yT + d, h - 1) + 1, coord] = 255
            else:
                edge[max(yT, yB - d):yB + 1, coord] = 255

    corner_d = int(round(np.median([d["median_offset"] for d in details.values()])))
    dist = cv2.distanceTransform(phone_mask, cv2.DIST_L2, 5)
    corner = ((dist > 0) & (dist <= max(EDGE_MIN_OFFSET, corner_d))).astype(np.uint8) * 255
    edge |= corner
    edge = cv2.bitwise_and(edge, phone_mask)
    if camera_mask is not None:
        edge = cv2.bitwise_and(edge, cv2.bitwise_not(camera_mask))
    return edge, details


def regions_from_masks(phone_mask, camera_mask, edge_mask, effective_mask):
    effective = effective_mask > 0
    phone = (phone_mask > 0) & effective
    camera = (camera_mask > 0) & phone
    edge = (edge_mask > 0) & phone & ~camera
    back = phone & ~camera & ~edge
    outside = effective & ~phone
    return {
        "Back Glass": (back.astype(np.uint8) * 255),
        "Camera Module": (camera.astype(np.uint8) * 255),
        "Bulged Edge": (edge.astype(np.uint8) * 255),
        "Surrounding": (outside.astype(np.uint8) * 255),
    }


class AdaptivePhoneRegionSegmenter(SegmentationBackend):
    name = "Adaptive Phone Regions (Bulged Edge)"

    def __init__(self, camera_rect=None, max_offset=24):
        self.camera_rect = camera_rect
        self.max_offset = int(max_offset)

    @staticmethod
    def _rect_mask(shape, rect):
        m = np.zeros(shape[:2], np.uint8)
        if rect is None:
            return m
        x0, y0, x1, y1 = map(int, rect)
        h, w = m.shape
        x0, x1 = sorted((max(0, min(w - 1, x0)), max(0, min(w, x1))))
        y0, y1 = sorted((max(0, min(h - 1, y0)), max(0, min(h, y1))))
        if x1 > x0 and y1 > y0:
            m[y0:y1, x0:x1] = 255
        return m

    def segment(self, image, roi_mask):
        if image is None:
            raise ValueError("No image")
        if roi_mask is None or cv2.countNonZero(roi_mask) < 500:
            raise ValueError("Inspection ROI is too small for adaptive phone segmentation")

        phone, bbox, meta = find_phone_geometry(image, roi_mask)
        camera = self._rect_mask(image.shape, self.camera_rect)
        edge, details = build_bulged_edge(image, phone, camera, max_offset=self.max_offset)
        regions = regions_from_masks(phone, camera, edge, roi_mask)

        ids = []
        for i, (name, mask) in enumerate(regions.items(), 1):
            ids.append(Segment(i, name, mask, int(cv2.countNonZero(mask))))

        overlay = image.copy()
        fills = {
            "Back Glass": (40, 210, 60),
            "Camera Module": (30, 80, 240),
            "Bulged Edge": (0, 220, 255),
            "Surrounding": (180, 50, 190),
        }
        for seg in ids:
            idx = seg.mask > 0
            if np.any(idx):
                color = np.array(fills[seg.name], np.float32)
                overlay[idx] = (overlay[idx].astype(np.float32) * 0.52 + color * 0.48).astype(np.uint8)
                contours, _ = cv2.findContours(seg.mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
                cv2.drawContours(overlay, contours, -1, fills[seg.name], 2)

        cv2.rectangle(overlay, (bbox[0], bbox[1]), (bbox[2], bbox[3]), (255, 255, 255), 2)
        if self.camera_rect is not None:
            x0, y0, x1, y1 = map(int, self.camera_rect)
            cv2.rectangle(overlay, (x0, y0), (x1, y1), (30, 80, 240), 2)

        return SegmentResult(
            self.name,
            ids,
            overlay,
            f"4 regions generated | phone={meta['width']}×{meta['height']} | "
            f"edge median={np.median([d['median_offset'] for d in details.values()]):.1f}px",
        )
