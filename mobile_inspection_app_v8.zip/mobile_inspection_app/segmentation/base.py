from __future__ import annotations
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
import numpy as np

@dataclass
class Segment:
    id: int
    name: str
    mask: np.ndarray
    area_px: int

@dataclass
class SegmentResult:
    backend: str
    segments: list[Segment] = field(default_factory=list)
    overlay: np.ndarray | None = None
    message: str = ""

class SegmentationBackend(ABC):
    name="Unnamed segmentation"
    @abstractmethod
    def segment(self, image, roi_mask): ...
