from .traditional import KMeansSegmenter, MeanShiftSegmenter
from .adaptive_regions import AdaptivePhoneRegionSegmenter


class SegmentationRegistry:
    """Traditional + adaptive segmentation only. No deep-learning segmenter in this build."""

    def names(self):
        return [
            "Adaptive Phone Regions (Bulged Edge)",
            "K-Means",
            "Mean Shift",
        ]

    def create(self, name, **kwargs):
        if name == "Adaptive Phone Regions (Bulged Edge)":
            return AdaptivePhoneRegionSegmenter(
                camera_rect=kwargs.get("camera_rect"),
                max_offset=kwargs.get("max_offset", 24),
            )
        if name == "K-Means":
            return KMeansSegmenter()
        if name == "Mean Shift":
            return MeanShiftSegmenter()
        raise KeyError(name)
