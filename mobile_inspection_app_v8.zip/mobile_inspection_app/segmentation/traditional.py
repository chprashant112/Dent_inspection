from __future__ import annotations
import cv2
import numpy as np
from .base import SegmentationBackend, Segment, SegmentResult

class TraditionalSegmenter(SegmentationBackend):
    name="KMeans / Mean Shift (traditional)"
    def __init__(self, mode="kmeans", clusters=3, max_samples=150000):
        self.mode=mode; self.clusters=max(2,int(clusters)); self.max_samples=int(max_samples)

    def _filtered(self,image):
        if self.mode.lower().startswith("mean"):
            return cv2.pyrMeanShiftFiltering(image,21,30,1)
        return image

    def segment(self,image,roi_mask):
        if image is None: raise ValueError("No image")
        ys,xs=np.where(roi_mask>0)
        if len(xs)<100: raise ValueError("ROI/effective mask is too small for segmentation")
        x0,x1,y0,y1=int(xs.min()),int(xs.max()+1),int(ys.min()),int(ys.max()+1)
        crop=image[y0:y1,x0:x1].copy(); local_mask=roi_mask[y0:y1,x0:x1]>0
        work=self._filtered(crop)
        lab=cv2.cvtColor(work,cv2.COLOR_BGR2LAB).astype(np.float32)
        data=lab[local_mask].reshape(-1,3)
        if data.shape[0]>self.max_samples:
            idx=np.linspace(0,data.shape[0]-1,self.max_samples).astype(np.int32); sample=data[idx]
        else: sample=data
        criteria=(cv2.TERM_CRITERIA_EPS+cv2.TERM_CRITERIA_MAX_ITER,30,0.5)
        _compact,_,centers=cv2.kmeans(sample.astype(np.float32),self.clusters,None,criteria,5,cv2.KMEANS_PP_CENTERS)
        flat=lab.reshape(-1,3); d=((flat[:,None,:]-centers[None,:,:])**2).sum(axis=2); labels=np.argmin(d,axis=1).reshape(crop.shape[:2])
        # Label touching the effective ROI boundary as outside/background.
        border=np.zeros_like(local_mask,np.uint8); border[0,:]=border[-1,:]=border[:,0]=border[:,-1]=1
        scores=[]
        for k in range(self.clusters): scores.append(int(np.count_nonzero((labels==k)&(border>0)&local_mask)))
        bg=int(np.argmax(scores))
        fg=(labels!=bg)&local_mask
        # Keep the largest connected foreground component; this approximates the phone body.
        num, cc, stats, cents=cv2.connectedComponentsWithStats(fg.astype(np.uint8),8)
        if num<=1: raise RuntimeError("Traditional segmentation did not isolate a foreground object")
        areas=stats[1:,cv2.CC_STAT_AREA]; keep=1+int(np.argmax(areas)); foreground=(cc==keep).astype(np.uint8)*255
        ksz=max(3,int(min(crop.shape[:2])*.006)//2*2+1); kernel=cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(ksz,ksz))
        foreground=cv2.morphologyEx(foreground,cv2.MORPH_CLOSE,kernel)
        foreground=cv2.morphologyEx(foreground,cv2.MORPH_OPEN,kernel)
        erode=cv2.erode(foreground,np.ones((max(3,ksz//2*2+1),max(3,ksz//2*2+1)),np.uint8),1)
        edge=(foreground>0)&(erode==0); glass=(erode>0); outside=local_mask&(foreground==0)
        masks=[]
        full=np.zeros(roi_mask.shape,np.uint8)
        for name,m in (("Back Glass",glass),("Edge",edge),("Outside Phone",outside)):
            full[:]=0; full[y0:y1,x0:x1][m]=255; masks.append(Segment(len(masks)+1,name,full.copy(),int(np.count_nonzero(full))))
        overlay=image.copy()
        for seg in masks:
            color=((50*seg.id)%255,(110*seg.id)%255,(170*seg.id)%255)
            overlay[seg.mask>0]=((overlay[seg.mask>0].astype(np.float32)*0.55)+np.array(color)*0.45).astype(np.uint8)
        return SegmentResult(self.name,masks,overlay,"generated 3 semantic regions from foreground + ring decomposition")

class KMeansSegmenter(TraditionalSegmenter):
    name="K-Means"
    def __init__(self): super().__init__(mode="kmeans",clusters=3)

class MeanShiftSegmenter(TraditionalSegmenter):
    name="Mean Shift"
    def __init__(self): super().__init__(mode="meanshift",clusters=3)
