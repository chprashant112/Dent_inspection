from mobile_inspection_app.ui.app import Application


if __name__ == "__main__":
    Application().mainloop()
