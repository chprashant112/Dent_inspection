# External detection algorithms

Drop a Python file into this folder. The file must define a concrete subclass of:

```python
from mobile_inspection_app.detection.base import DetectionAlgorithm, DetectionResult
```

The application discovers subclasses at startup. There is intentionally no built-in detector in the main application.

Expected method:

```python
def process(self, image, inspection_mask=None, context=None) -> DetectionResult:
    ...
```

The application may provide `context["selected_regions"]`, containing region id/name/mask, and `context["params"]`, containing GUI-configured parameters. `DefectBox` coordinates remain in original image coordinates.
