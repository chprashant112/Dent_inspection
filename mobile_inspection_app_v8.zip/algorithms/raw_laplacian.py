from __future__ import annotations

from collections import deque
from typing import Any

import cv2
import numpy as np

from mobile_inspection_app.detection.base import DetectionAlgorithm, DetectionResult, DefectBox


class RawLaplacianDetector(DetectionAlgorithm):
    """RAW Laplacian V1: localized thresholding + region-aware morphology.

    The GUI can provide region-specific filter dimensions through
    ``context['params']``.  For thin edge regions, separate vertical and
    horizontal kernels are used automatically so the local statistics follow
    the long direction of the edge instead of treating a thin strip like the
    broad back-glass region.
    """

    name = "RAW Laplacian V1"
    version = "2.0"

    DEFAULTS = {
        "k": 2.8,
        "min_magnitude": 18.0,
        "lap_ksize": 3,
        "morph_kernel": 3,
        "general_rows": 21,
        "general_cols": 21,
        "min_area_px": 20,
        "max_area_px": 2000000,
        "min_box_size_px": 70,
        "box_expand_ratio": 0.75,
        "blob_max_aspect": 12.0,
        "blob_min_solidity": 0.08,
        "edge_auto_orientation": True,
        "back_rows": 21,
        "back_cols": 21,
        "camera_rows": 15,
        "camera_cols": 15,
        "edge_vertical_rows": 31,
        "edge_vertical_cols": 5,
        "edge_horizontal_rows": 5,
        "edge_horizontal_cols": 31,
        "outside_rows": 21,
        "outside_cols": 21,
        "temporal_buffer": 3,
        "persistence": 2,
        "temporal_enabled": False,
    }

    SETTINGS_SCHEMA = [
        {"key": "k", "label": "K multiplier", "kind": "float", "from": 0.5, "to": 10.0, "step": 0.1},
        {"key": "min_magnitude", "label": "Minimum Laplacian", "kind": "float", "from": 0, "to": 100, "step": 1},
        {"key": "lap_ksize", "label": "Laplacian ksize", "kind": "choice", "values": [1, 3, 5, 7]},
        {"key": "morph_kernel", "label": "Morph kernel", "kind": "choice", "values": [1, 3, 5, 7, 9]},
        {"key": "min_area_px", "label": "Min blob area", "kind": "int", "from": 1, "to": 1000000, "step": 1},
        {"key": "max_area_px", "label": "Max blob area", "kind": "int", "from": 100, "to": 5000000, "step": 100},
        {"key": "min_box_size_px", "label": "Min red box size", "kind": "int", "from": 20, "to": 500, "step": 5},
        {"key": "box_expand_ratio", "label": "Box expansion", "kind": "float", "from": 0.0, "to": 2.0, "step": 0.05},
        {"key": "blob_max_aspect", "label": "Max blob aspect", "kind": "float", "from": 1.0, "to": 50.0, "step": 0.5},
        {"key": "blob_min_solidity", "label": "Min solidity", "kind": "float", "from": 0.0, "to": 1.0, "step": 0.01},
        {"key": "general_rows", "label": "General rows", "kind": "choice", "values": [9, 11, 15, 21, 31, 41, 51]},
        {"key": "general_cols", "label": "General cols", "kind": "choice", "values": [9, 11, 15, 21, 31, 41, 51]},
        {"key": "edge_auto_orientation", "label": "Edge auto orientation", "kind": "bool"},
        {"key": "back_rows", "label": "Back rows", "kind": "choice", "values": [9, 11, 15, 21, 31, 41, 51]},
        {"key": "back_cols", "label": "Back cols", "kind": "choice", "values": [9, 11, 15, 21, 31, 41, 51]},
        {"key": "camera_rows", "label": "Camera rows", "kind": "choice", "values": [9, 11, 15, 21, 31]},
        {"key": "camera_cols", "label": "Camera cols", "kind": "choice", "values": [9, 11, 15, 21, 31]},
        {"key": "edge_vertical_rows", "label": "Edge vertical rows", "kind": "choice", "values": [15, 21, 31, 41, 51]},
        {"key": "edge_vertical_cols", "label": "Edge vertical cols", "kind": "choice", "values": [3, 5, 7, 9]},
        {"key": "edge_horizontal_rows", "label": "Edge horizontal rows", "kind": "choice", "values": [3, 5, 7, 9]},
        {"key": "edge_horizontal_cols", "label": "Edge horizontal cols", "kind": "choice", "values": [15, 21, 31, 41, 51]},
        {"key": "outside_rows", "label": "Outside rows", "kind": "choice", "values": [9, 11, 15, 21, 31]},
        {"key": "outside_cols", "label": "Outside cols", "kind": "choice", "values": [9, 11, 15, 21, 31]},
        {"key": "temporal_enabled", "label": "Temporal filter", "kind": "bool"},
        {"key": "temporal_buffer", "label": "Temporal buffer", "kind": "choice", "values": [1, 2, 3, 5, 7]},
        {"key": "persistence", "label": "Temporal hits", "kind": "choice", "values": [1, 2, 3, 4, 5]},
    ]

    def __init__(self, **overrides):
        p = dict(self.DEFAULTS)
        p.update(overrides)
        for key, value in p.items():
            setattr(self, key, value)
        self.morph_kernel = max(1, int(self.morph_kernel))
        self.temporal_buffer = max(1, int(self.temporal_buffer))
        self.persistence = max(1, int(self.persistence))
        self._frames = deque(maxlen=self.temporal_buffer)

    @classmethod
    def create_default(cls):
        return cls()

    def settings(self) -> dict[str, Any]:
        return {key: getattr(self, key) for key in self.DEFAULTS}

    def _gray(self, image):
        return cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) if image.ndim == 3 else image.copy()

    @staticmethod
    def _odd(v):
        v = max(1, int(v))
        return v if v % 2 else v + 1

    def _masked_local_stats(self, mag, valid, rows, cols):
        rows, cols = self._odd(rows), self._odd(cols)
        vm = (valid > 0).astype(np.float32)
        denom = cv2.boxFilter(vm, -1, (cols, rows), normalize=False, borderType=cv2.BORDER_REFLECT)
        sum1 = cv2.boxFilter(mag * vm, -1, (cols, rows), normalize=False, borderType=cv2.BORDER_REFLECT)
        sum2 = cv2.boxFilter((mag * mag) * vm, -1, (cols, rows), normalize=False, borderType=cv2.BORDER_REFLECT)
        denom = np.maximum(denom, 1.0)
        mean = sum1 / denom
        var = np.maximum(sum2 / denom - mean * mean, 0.0)
        std = np.sqrt(var)
        return mean, std

    def _threshold(self, image, valid_mask, rows, cols, k, min_magnitude, lap_ksize):
        gray = self._gray(image)
        lap_ksize = max(1, self._odd(lap_ksize))
        if lap_ksize not in (1, 3, 5, 7):
            lap_ksize = 3
        lap = cv2.Laplacian(gray, cv2.CV_32F, ksize=lap_ksize)
        mag = np.abs(lap).astype(np.float32)
        mean, std = self._masked_local_stats(mag, valid_mask, rows, cols)
        dyn = mean + float(k) * std
        binary = ((mag >= np.maximum(dyn, float(min_magnitude))) & (valid_mask > 0)).astype(np.uint8) * 255
        return binary

    def _morph(self, binary):
        k = self._odd(self.morph_kernel)
        if k <= 1:
            return binary
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k))
        out = cv2.morphologyEx(binary, cv2.MORPH_CLOSE, kernel, iterations=1)
        out = cv2.dilate(out, kernel, iterations=1)
        out = cv2.morphologyEx(out, cv2.MORPH_OPEN, kernel, iterations=1)
        return out

    def _region_mask(self, inspection_mask, region):
        if region is None:
            return inspection_mask
        m = region.get("mask")
        if m is None:
            return inspection_mask
        return cv2.bitwise_and(inspection_mask, m)

    def _single_region(self, image, region_mask, region_name, p):
        if region_mask is None or cv2.countNonZero(region_mask) == 0:
            return np.zeros(image.shape[:2], np.uint8)

        name = region_name.lower()
        k = float(p["k"])
        min_mag = float(p["min_magnitude"])

        if "edge" in name and bool(p.get("edge_auto_orientation", True)):
            vertical = self._threshold(
                image, region_mask,
                p["edge_vertical_rows"], p["edge_vertical_cols"],
                k, min_mag, p["lap_ksize"],
            )
            horizontal = self._threshold(
                image, region_mask,
                p["edge_horizontal_rows"], p["edge_horizontal_cols"],
                k, min_mag, p["lap_ksize"],
            )
            binary = cv2.bitwise_or(vertical, horizontal)
        elif "camera" in name:
            binary = self._threshold(image, region_mask, p["camera_rows"], p["camera_cols"], k, min_mag, p["lap_ksize"])
        elif "back" in name or "glass" in name:
            binary = self._threshold(image, region_mask, p["back_rows"], p["back_cols"], k, min_mag, p["lap_ksize"])
        else:
            binary = self._threshold(image, region_mask, p["outside_rows"], p["outside_cols"], k, min_mag, p["lap_ksize"])
        return self._morph(binary)

    def _resolve_params(self, context):
        p = dict(self.DEFAULTS)
        if context:
            p.update(context.get("params", {}) or {})
        # Keep numeric values sane and compatible with spinbox output.
        for key in ("general_rows", "general_cols", "back_rows", "back_cols", "camera_rows", "camera_cols", "edge_vertical_rows", "edge_vertical_cols", "edge_horizontal_rows", "edge_horizontal_cols", "outside_rows", "outside_cols"):
            p[key] = self._odd(p[key])
        p["morph_kernel"] = max(1, self._odd(p["morph_kernel"]))
        return p

    def process(self, image, inspection_mask=None, context=None):
        if image is None:
            raise ValueError("No image")
        if inspection_mask is None:
            inspection_mask = np.ones(image.shape[:2], np.uint8) * 255
        else:
            inspection_mask = (inspection_mask > 0).astype(np.uint8) * 255

        p = self._resolve_params(context)
        regions = [] if context is None else context.get("selected_regions", []) or []

        if regions:
            masks = []
            names = []
            for region in regions:
                rm = self._region_mask(inspection_mask, region)
                if cv2.countNonZero(rm) == 0:
                    continue
                rb = self._single_region(image, rm, region.get("name", "Region"), p)
                masks.append(rb)
                names.append(region.get("name", "Region"))
            if masks:
                binary = np.zeros_like(masks[0])
                for m in masks:
                    binary = cv2.bitwise_or(binary, m)
            else:
                binary = np.zeros(image.shape[:2], np.uint8)
        else:
            binary = self._threshold(image, inspection_mask, p.get("general_rows", 21), p.get("general_cols", 21), p["k"], p["min_magnitude"], p["lap_ksize"])
            binary = self._morph(binary)
            names = ["Selected ROI"]

        if bool(p.get("temporal_enabled", False)):
            if self._frames.maxlen != int(p["temporal_buffer"]):
                self._frames = deque(maxlen=max(1, int(p["temporal_buffer"])))
            self._frames.append(binary > 0)
            votes = np.stack(list(self._frames), axis=0)
            needed = min(max(1, int(p["persistence"])), votes.shape[0])
            binary = (np.sum(votes, axis=0) >= needed).astype(np.uint8) * 255

        return self._postprocess(image, binary, inspection_mask, p, names)

    def _postprocess(self, image, binary, inspection_mask, p, region_names):
        contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        h, w = image.shape[:2]
        annotated = image.copy()
        defects = []
        clean = np.zeros((h, w), np.uint8)

        for contour in contours:
            area = cv2.contourArea(contour)
            if area < float(p["min_area_px"]) or area > float(p["max_area_px"]):
                continue
            x, y, bw, bh = cv2.boundingRect(contour)
            aspect = max(bw, bh) / max(1, min(bw, bh))
            hull = cv2.convexHull(contour)
            hull_area = max(cv2.contourArea(hull), 1.0)
            solidity = area / hull_area
            if aspect > float(p["blob_max_aspect"]) or solidity < float(p["blob_min_solidity"]):
                continue

            cv2.drawContours(clean, [contour], -1, 255, -1)
            base_size = max(bw, bh)
            box_size = max(int(p["min_box_size_px"]), int(base_size * (1.0 + float(p["box_expand_ratio"]))))
            cx, cy = x + bw // 2, y + bh // 2
            ex = max(0, cx - box_size // 2)
            ey = max(0, cy - box_size // 2)
            ex2 = min(w, ex + box_size)
            ey2 = min(h, ey + box_size)
            local = inspection_mask[ey:ey2, ex:ex2]
            if local.size and int(np.count_nonzero(local)) == 0:
                continue

            label = f"DEFECT {len(defects)+1}"
            cv2.rectangle(annotated, (ex, ey), (ex2, ey2), (0, 0, 255), 4)
            cv2.drawContours(annotated, [contour], -1, (0, 0, 255), 2)
            ty = ey - 9 if ey > 28 else min(h - 10, ey2 + 23)
            cv2.putText(annotated, label, (ex, ty), cv2.FONT_HERSHEY_SIMPLEX, 0.75, (0, 0, 255), 3, cv2.LINE_AA)
            defects.append(
                DefectBox(
                    x=int(ex), y=int(ey), w=int(ex2-ex), h=int(ey2-ey),
                    label=label, area_px=int(area),
                    raw_x=int(x), raw_y=int(y), raw_w=int(bw), raw_h=int(bh),
                )
            )

        score = float(np.count_nonzero(clean)) / float(clean.size)
        if defects:
            msg = f"{len(defects)} defect(s) flagged in selected region(s)"
        else:
            msg = "No defects above threshold in selected region(s)"
            cv2.putText(annotated, "NO DEFECTS FLAGGED", (18, 38), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 220, 80), 2, cv2.LINE_AA)

        return DetectionResult(
            self.name, annotated, clean, score, msg, defects,
            params={**p, "selected_region_names": list(region_names)},
        )
