from __future__ import annotations
import cv2
import numpy as np
from collections import deque
from threading import Lock
from mobile_inspection_app.detection.base import DetectionAlgorithm, DetectionResult, DefectBox

class RawLaplacianV1(DetectionAlgorithm):
    name="RAW Laplacian V1"
    version="1.0"
    DEFAULTS={"k":3.0,"min_magnitude":8.0,"lap_ksize":3,"morph_kernel":1,"min_area_px":10,"max_area_px":2000000,"min_box_size_px":40,"box_expand_ratio":0.25,"blob_max_aspect":24.0,"blob_min_solidity":0.02,"max_area_fraction":0.03,"max_box_fraction":0.02,"edge_auto_orientation":True,"temporal_enabled":True,"persistence_frames":3,"persistence_hits":2,"window_backglass":51,"window_camera":15,"window_surrounding":51,"window_edge_long":31,"window_edge_short":5}
    SETTINGS_SCHEMA=[
      {"key":"k","label":"Std multiplier k","kind":"float","from":0.1,"to":10,"step":0.1},
      {"key":"min_magnitude","label":"Minimum Laplacian magnitude","kind":"float","from":0,"to":255,"step":1},
      {"key":"lap_ksize","label":"Laplacian kernel","kind":"choice","values":[1,3,5,7]},
      {"key":"morph_kernel","label":"Morphology kernel","kind":"int","from":1,"to":15,"step":2},
      {"key":"min_area_px","label":"Minimum blob area (px)","kind":"int","from":1,"to":100000,"step":1},
      {"key":"max_area_px","label":"Maximum blob area (px)","kind":"int","from":100,"to":5000000,"step":100},
      {"key":"min_box_size_px","label":"Minimum proposal box (px)","kind":"int","from":1,"to":2000,"step":1},
      {"key":"box_expand_ratio","label":"Proposal box expansion","kind":"float","from":0,"to":3,"step":0.05},
      {"key":"blob_max_aspect","label":"Maximum blob aspect ratio","kind":"float","from":1,"to":50,"step":0.5},
      {"key":"blob_min_solidity","label":"Minimum solidity","kind":"float","from":0,"to":1,"step":0.01},
      {"key":"max_area_fraction","label":"Max defect area / ROI","kind":"float","from":0.001,"to":0.5,"step":0.005},
      {"key":"max_box_fraction","label":"Max proposal box / ROI","kind":"float","from":0.001,"to":0.8,"step":0.01},
      {"key":"window_backglass","label":"Backglass local window","kind":"int","from":3,"to":151,"step":2},
      {"key":"window_camera","label":"Camera local window","kind":"int","from":3,"to":101,"step":2},
      {"key":"window_surrounding","label":"Surrounding local window","kind":"int","from":3,"to":151,"step":2},
      {"key":"window_edge_long","label":"Bulged edge long window","kind":"int","from":3,"to":151,"step":2},
      {"key":"window_edge_short","label":"Bulged edge short window","kind":"int","from":3,"to":51,"step":2},
      {"key":"edge_auto_orientation","label":"Directional windows on Bulged Edge","kind":"bool"},
      {"key":"temporal_enabled","label":"Live temporal persistence","kind":"bool"},
      {"key":"persistence_frames","label":"Persistence buffer frames","kind":"int","from":1,"to":15,"step":1},
      {"key":"persistence_hits","label":"Persistence minimum hits","kind":"int","from":1,"to":15,"step":1},
    ]

    def __init__(self):
        self._buffer = deque(maxlen=3)
        self._buffer_len = 3
        self._last_shape = None
        self._lock = Lock()

    @staticmethod
    def _local_stats(lap: np.ndarray, valid: np.ndarray, ksize: tuple[int,int]):
        weight=valid.astype(np.float32); lapf=lap.astype(np.float32)
        count=cv2.boxFilter(weight,-1,ksize,normalize=False,borderType=cv2.BORDER_REFLECT)
        total=cv2.boxFilter(lapf*weight,-1,ksize,normalize=False,borderType=cv2.BORDER_REFLECT)
        total2=cv2.boxFilter(lapf*lapf*weight,-1,ksize,normalize=False,borderType=cv2.BORDER_REFLECT)
        mean=total/np.maximum(count,1.0)
        variance=np.maximum(total2/np.maximum(count,1.0)-mean*mean,0)
        return mean,np.sqrt(variance)

    @staticmethod
    def _components(binary, params, mask):
        kernel=max(1,int(params.get("morph_kernel",1))); kernel += (kernel%2==0)
        ellipse=cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(kernel,kernel))
        m=cv2.morphologyEx(binary,cv2.MORPH_CLOSE,ellipse)
        # Avoid unconditional dilation: it joins distant bright/dark edge responses
        # into phone-sized rectangles, which main6.py did not do.
        m=cv2.morphologyEx(m,cv2.MORPH_OPEN,ellipse)
        m=cv2.bitwise_and(m,mask)
        contours,_=cv2.findContours(m,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
        h,w=m.shape; boxes=[]; clean=np.zeros_like(m)
        mn=max(1,int(params.get("min_area_px",10))); mx=max(mn,int(params.get("max_area_px",2_000_000)))
        max_aspect=float(params.get("blob_max_aspect",50)); min_sol=float(params.get("blob_min_solidity",.02))
        valid_area=max(1,cv2.countNonZero(mask))
        max_area_fraction=float(np.clip(params.get("max_area_fraction",.03),.001,.5))
        max_box_fraction=float(np.clip(params.get("max_box_fraction",.08),.001,.8))
        for cnt in contours:
            area=float(cv2.contourArea(cnt)); x,y,bw,bh=cv2.boundingRect(cnt); bbox_area=bw*bh
            # Large connected illumination borders/phone outlines are not micro-defect
            # proposals. Fractions adapt to resolution and selected backglass ROI size.
            if area<mn or area>mx or area>valid_area*max_area_fraction or bbox_area>valid_area*max_box_fraction: continue
            aspect=max(bw,bh)/max(1,min(bw,bh))
            hull=cv2.convexHull(cnt); hull_area=max(float(cv2.contourArea(hull)),1.0); solidity=area/hull_area
            if aspect>max_aspect or solidity<min_sol: continue
            cv2.drawContours(clean,[cnt],-1,255,-1)
            expand=float(np.clip(params.get("box_expand_ratio",.25),0.0,3.0))
            pad_x=int(round(bw*expand*0.5)); pad_y=int(round(bh*expand*0.5))
            minside=max(1,int(params.get("min_box_size_px",40)))
            # Keep the actual contour's aspect ratio (as in main6.py); padding is
            # per axis, not a square formed from the longest side.
            box_w=max(minside,bw+2*pad_x); box_h=max(minside,bh+2*pad_y)
            cx=x+bw//2; cy=y+bh//2
            bx=max(0,cx-box_w//2); by=max(0,cy-box_h//2)
            ex=min(w,bx+box_w); ey=min(h,by+box_h); bx=max(0,ex-box_w); by=max(0,ey-box_h)
            if not np.any(mask[by:ey,bx:ex]): continue
            boxes.append(DefectBox(bx,by,ex-bx,ey-by,f"DEFECT {len(boxes)+1}",int(area),x,y,bw,bh,True))
        clean[mask==0]=0
        return clean,boxes

    def process(self,image,inspection_mask=None,context=None)->DetectionResult:
        if image is None: raise ValueError("No image supplied to RAW Laplacian")
        context=context or {}; params={**self.DEFAULTS,**context.get("params",{})}
        h,w=image.shape[:2]
        mask=np.full((h,w),255,np.uint8) if inspection_mask is None else np.where(inspection_mask>0,255,0).astype(np.uint8)
        gray=cv2.cvtColor(image,cv2.COLOR_BGR2GRAY)
        ks=int(params.get("lap_ksize",3)); ks=ks if ks in (1,3,5,7) else 3
        # Match main6.py's detector: absolute, floating-point Laplacian response and
        # local mean + k*local-standard-deviation rather than one global threshold.
        lap=np.abs(cv2.Laplacian(gray,cv2.CV_32F,ksize=ks))
        valid=mask>0
        raw_mask=np.zeros((h,w),np.uint8)
        selected_regions=context.get("selected_regions") or []
        regions=[r for r in selected_regions if r.get("mask") is not None] if selected_regions else [{"name":"All","mask":mask}]
        for region in regions:
            region_mask=(region["mask"]>0)&valid
            if not region_mask.any(): continue
            name=str(region.get("name","")).lower()
            if "edge" in name and params.get("edge_auto_orientation",True):
                windows=[(int(params.get("window_edge_short",5)),int(params.get("window_edge_long",31))),
                         (int(params.get("window_edge_long",31)),int(params.get("window_edge_short",5)))]
            elif "camera" in name:
                side=int(params.get("window_camera",15)); windows=[(side,side)]
            elif "back" in name:
                side=int(params.get("window_backglass",51)); windows=[(side,side)]
            elif "surround" in name:
                side=int(params.get("window_surrounding",51)); windows=[(side,side)]
            else:
                windows=[(51,51)]
            candidate=np.zeros((h,w),bool)
            for kw,kh in windows:
                kw=max(3,kw); kh=max(3,kh)
                if kw%2==0: kw+=1
                if kh%2==0: kh+=1
                mean,std=self._local_stats(lap,region_mask,(kw,kh))
                threshold=np.maximum(mean+float(params.get("k",3.0))*std,float(params.get("min_magnitude",8.0)))
                candidate |= (lap>threshold)&region_mask
            raw_mask[candidate]=1

        # main6.py's temporal-persistence filter is active only for live mode. A
        # manual image/test capture should produce a result from that exact image,
        # without stale evidence carried over from a previous frame.
        live=bool(context.get("live",False))
        if bool(params.get("temporal_enabled",True)) and live:
            frames=max(1,min(15,int(params.get("persistence_frames",3))))
            hits=max(1,min(frames,int(params.get("persistence_hits",2))))
            with self._lock:
                if self._buffer_len != frames:
                    self._buffer_len=frames; self._buffer=deque(maxlen=frames)
                if self._last_shape != raw_mask.shape:
                    self._buffer.clear(); self._last_shape=raw_mask.shape
                self._buffer.append(raw_mask.copy())
                if hits<=1 or len(self._buffer)<2:
                    stable=raw_mask.copy()
                else:
                    hit_count=np.sum(np.stack(tuple(self._buffer),axis=0),axis=0)
                    stable=(hit_count>=min(hits,len(self._buffer))).astype(np.uint8)
            final_mask=stable*255
        else:
            # Clear state so switching back to live mode begins with clean evidence.
            with self._lock:
                self._buffer.clear(); self._last_shape=raw_mask.shape
            final_mask=raw_mask*255

        # Never permit morphology or threshold neighbourhoods to reintroduce pixels
        # outside the allowed inspection mask.
        clean,boxes=self._components(final_mask,params,mask)
        clean[mask==0]=0
        annotated=image.copy()
        for i,b in enumerate(boxes,1):
            cv2.rectangle(annotated,(b.x,b.y),(b.x+b.w-1,b.y+b.h-1),(0,0,255),3)
            cv2.rectangle(annotated,(b.raw_x,b.raw_y),(b.raw_x+b.raw_w-1,b.raw_y+b.raw_h-1),(0,70,255),1)
            cv2.putText(annotated,f"DEFECT {i}",(b.x,max(20,b.y-7)),cv2.FONT_HERSHEY_SIMPLEX,.6,(0,0,255),2,cv2.LINE_AA)
        if not boxes: cv2.putText(annotated,"NO DEFECTS FLAGGED",(18,32),cv2.FONT_HERSHEY_SIMPLEX,.75,(40,210,80),2,cv2.LINE_AA)
        score=float(np.count_nonzero(clean)/max(np.count_nonzero(mask),1))
        note="main6-style local Laplacian + persistence" if live and params.get("temporal_enabled",True) else "main6-style local Laplacian (single-frame)"
        return DetectionResult(self.name,annotated,clean,score,f"{len(boxes)} candidate defect(s); {note}; candidates require human review.",boxes,params)

