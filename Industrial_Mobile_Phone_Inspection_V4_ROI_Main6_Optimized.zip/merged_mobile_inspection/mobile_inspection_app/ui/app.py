from __future__ import annotations
import json, queue, threading, time, traceback, copy, os
from pathlib import Path
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog, filedialog
import cv2
# Prevent OpenCV from oversubscribing every CPU core while camera/UI threads are active.
try: cv2.setNumThreads(max(1, min(4, os.cpu_count() or 2)))
except Exception: pass
import numpy as np
from PIL import Image, ImageTk

from mobile_inspection_app.config import AppConfig, Recipe, load_config, save_config, safe_name, save_profile, load_profile, ROOT
from mobile_inspection_app.camera.camera_manager import CameraManager
from mobile_inspection_app.camera.simulated_camera import SimulatedCamera
from mobile_inspection_app.camera.basler_camera import BaslerCamera
from mobile_inspection_app.camera.calibration import CalibrationStore
from mobile_inspection_app.lighting.factory import build_engine
from mobile_inspection_app.capture.capture_manager import CaptureManager
from mobile_inspection_app.analysis.illumination import analyze_illumination
from mobile_inspection_app.analysis.correction import correct_illumination
from mobile_inspection_app.analysis.histogram import histogram_image
from mobile_inspection_app.analysis.workflow import (METHODS as WORKFLOW_METHODS, correct_image, canny_phone_mask,
    detect_phone_region, make_correction_comparison, adaptive_edge_backglass)
from mobile_inspection_app.segmentation.registry import create_segmentation_backends
from mobile_inspection_app.detection.discovery import discover_algorithms
from mobile_inspection_app.pipeline.pipeline import InspectionPipeline
from mobile_inspection_app.pipeline.profile import make_profile
from mobile_inspection_app.roi.model import ROI, ROIShape
from mobile_inspection_app.roi.shapes import rasterize_shape
from mobile_inspection_app.ui.theme import apply_theme, COLORS
from mobile_inspection_app.ui.widgets import ScrollableFrame, CollapsibleCard
from mobile_inspection_app.ui.roi_tools import ROIToolController

class MobileInspectionApp:
    def __init__(self, root: tk.Tk | None = None):
        self.root=root or tk.Tk()
        self.root.title("Industrial Phone Defect Inspection — Image Processing Workflow")
        self.root.geometry("1400x850"); self.root.minsize(1100,700)
        try: self.root.state("zoomed")
        except tk.TclError: pass
        apply_theme(self.root)
        self.config=load_config()
        self.closed=False; self.busy=set(); self.log_queue=queue.Queue(); self.ui_queue=queue.Queue(); self._log_lines=[]
        self._preview_after_id=None; self._log_after_id=None; self._ui_after_id=None
        self.camera_manager=CameraManager(SimulatedCamera(0,self.config.camera1.width,self.config.camera1.height),SimulatedCamera(1,self.config.camera2.width,self.config.camera2.height),self.log)
        self.camera_manager.settings=[self.config.camera1,self.config.camera2]
        self.camera_running=False; self.last_pair=None; self.current_image=None; self.current_source_shape=None
        self._render_scale=1.0; self._zoom=1.0; self._photo=None; self._panel_photos={}; self._canvas_img_id=None
        self.roi_controller=ROIToolController(); self.draw_start=None; self.draw_current=None; self.calibration_points=[]
        self.draw_tool=tk.StringVar(value="Navigate"); self.shape_var=tk.StringVar(value="Rectangle"); self.role_var=tk.StringVar(value="Detection ROI")
        self.model_var=tk.StringVar(value=""); self.mode_var=tk.StringVar(value="TESTING")
        self.camera1_on=tk.BooleanVar(value=True); self.camera2_on=tk.BooleanVar(value=True)
        self.camera_backend_var=tk.StringVar(value="Simulated")
        self.preview_source=tk.StringVar(value=self.config.preview_source); self.stitch_mode=tk.StringVar(value=self.config.stitch_mode)
        self._last_source_signature=(self.preview_source.get(),self.stitch_mode.get())
        self.setting_camera=tk.StringVar(value="Camera 1")
        self.exposure_var=tk.StringVar(value=str(self.config.camera1.exposure_us)); self.gain_var=tk.StringVar(value=str(self.config.camera1.gain)); self.fps_var=tk.StringVar(value=str(self.config.camera1.fps)); self.width_var=tk.StringVar(value=str(self.config.camera1.width)); self.height_var=tk.StringVar(value=str(self.config.camera1.height)); self.full_sensor_var=tk.BooleanVar(value=bool(self.config.camera1.full_sensor))
        self.topology_var=tk.StringVar(value=self.config.topology); self.port_a_var=tk.StringVar(value=self.config.port_a); self.port_b_var=tk.StringVar(value=self.config.port_b); self.settle_var=tk.StringVar(value=str(self.config.settle_ms))
        self.lighting_engine=None; self.recipes_a=[Recipe(**r.__dict__) for r in self.config.recipes_a]; self.recipes_b=[Recipe(**r.__dict__) for r in self.config.recipes_b]
        self.recipe_vars=[]; self.recipe_b_vars=[]; self.recipe_selected=[]
        self.correct_var=tk.BooleanVar(value=self.config.correction_enabled); self.correction_strength=tk.DoubleVar(value=self.config.correction_strength); self.strict_channel_var=tk.BooleanVar(value=self.config.strict_per_channel); self.highlight_var=tk.BooleanVar(value=self.config.highlight_compression)
        self.segmentation_backends=create_segmentation_backends(); self.seg_backend_var=tk.StringVar(value=self.config.segmentation_backend)
        if self.seg_backend_var.get() not in self.segmentation_backends: self.seg_backend_var.set(next(iter(self.segmentation_backends)))
        self.segment_result=None; self.segment_vars={}; self.segmentation_enabled=tk.BooleanVar(value=True)
        self.detection_registry=discover_algorithms(ROOT/"algorithms",self.log)
        if not self.detection_registry.names(): self.log("ERROR","No detector plugins were loaded")
        self.detector_vars={n:tk.BooleanVar(value=(n=="RAW Laplacian V1")) for n in self.detection_registry.names()}
        self.detector_setting_name=tk.StringVar(value="RAW Laplacian V1" if "RAW Laplacian V1" in self.detection_registry.names() else (self.detection_registry.names()[0] if self.detection_registry.names() else ""))
        self.detector_params={n:{**self.detection_registry.get(n).DEFAULTS,**self.config.detector_params.get(n,{})} for n in self.detection_registry.names()}
        self.detector_setting_vars={}; self.inspection_analysis=None; self.last_detection_results=[]; self.last_detection_mask=None; self.last_corrected=None
        raw_params=self.detector_params.get("RAW Laplacian V1",{})
        self.quick_sensitivity=tk.DoubleVar(value=float(raw_params.get("k",2.8)))
        self.quick_min_magnitude=tk.DoubleVar(value=float(raw_params.get("min_magnitude",18.0)))
        self.quick_min_area=tk.DoubleVar(value=float(raw_params.get("min_area_px",20)))
        self.quick_box_padding=tk.DoubleVar(value=float(raw_params.get("box_expand_ratio",0.75))*100.0)
        self.live_detection_var=tk.BooleanVar(value=False)
        self._live_after_id=None; self._live_result_initialized=False
        self.calibration=CalibrationStore(ROOT/"config"/"calibration.json")
        self.regulator_stop=threading.Event(); self.regulator_active=False
        self.loupe_enabled=tk.BooleanVar(value=False); self.loupe_radius=tk.IntVar(value=18); self.loupe_window=None; self.loupe_label=None; self.loupe_photo=None
        # Staged manual-capture / illumination-correction / edge-backglass workflow.
        self.workflow_frame=None; self.workflow_frozen=False; self.workflow_outputs={}; self.workflow_selected_image=None; self.workflow_selected_method=None
        self.workflow_phone_edges=None; self.workflow_phone_mask=None; self.workflow_edge_mask=None; self.workflow_backglass_mask=None
        self.workflow_flat_field=None; self.workflow_flat_field_path=None; self.workflow_segment_overlay=None
        self.workflow_method_var=tk.StringVar(value="Gaussian Divide")
        # Optional correction is deliberately OFF by default; standard detection uses
        # the uncorrected back-glass ROI unless the operator opts in.
        self.workflow_use_selected_var=tk.BooleanVar(value=False)
        self.workflow_strength_var=tk.DoubleVar(value=0.8); self.workflow_sigma_var=tk.DoubleVar(value=0.06)
        self.workflow_canny_low_var=tk.IntVar(value=35); self.workflow_canny_high_var=tk.IntVar(value=110)
        self.phone_width_mm_var=tk.DoubleVar(value=84.0); self.phone_height_mm_var=tk.DoubleVar(value=163.0)
        self.phone_center_x_var=tk.DoubleVar(value=50.0); self.phone_center_y_var=tk.DoubleVar(value=50.0)
        self.phone_frame_width_var=tk.DoubleVar(value=65.0); self.phone_color_tolerance_var=tk.DoubleVar(value=30.0)
        self.workflow_edge_width_mm_var=tk.DoubleVar(value=1.1)
        self.phone_workflow_enabled_var=tk.BooleanVar(value=True)
        self.workflow_status_var=tk.StringVar(value="1. Start cameras, capture a frame, then calibrate if physical dimensions are required.")
        self.calibration_line=None; self.calibration_distance_px=None; self.calibration_distance_mm=None
        self._last_render_time=0.0; self._last_preview_signature=None; self._roi_display_cache={}
        # Low-latency viewer: one renderer, a single replaceable pending frame, and Tk-only display callbacks.
        self._empty_canvas_text_id=None; self._canvas_scrollregion=None
        self._last_preview_frame_signature=None; self._roi_render_cache={}; self._segment_render_cache={}
        self._preview_render_lock=threading.Lock(); self._preview_render_latest=None; self._preview_render_active=False
        self._preview_generation=0; self._preview_displayed_generation=0; self._preview_invalidate_before=0
        # Stitching (especially ORB/RANSAC mode) also runs outside Tk's event loop.
        self._stitch_lock=threading.Lock(); self._stitch_latest=None; self._stitch_active=False
        self._stitch_generation=0; self._stitch_displayed_generation=0
        self._build_ui()
        self.root.protocol("WM_DELETE_WINDOW",self.close)
        self.root.bind("<Escape>",self._escape); self.root.bind("<Return>",self._enter)
        self._preview_after_id=self.root.after(30,self._tick)
        self._log_after_id=self.root.after(100,self._drain_logs)
        self._ui_after_id=self.root.after(15,self._drain_ui_queue)
        self.log("INFO","Application ready. Simulated cameras are available without hardware.")
        self.log("WARN","Detection boxes are proposals for human review, not certified PASS/FAIL results.")
        self.log("WARN","8-channel lighting frame is UNCONFIRMED; simulator is safe, real hardware transmission is not validated.")

    def log(self, level: str, message: str):
        stamp=time.strftime("%H:%M:%S")
        self.log_queue.put((stamp,level,str(message)))

    def _post_ui(self, callback):
        """Queue a UI callback from workers without calling Tk from a worker thread."""
        if not self.closed: self.ui_queue.put(callback)

    def _drain_ui_queue(self):
        if self.closed: return
        try:
            while True:
                callback=self.ui_queue.get_nowait()
                try: callback()
                except Exception as exc: self.log("ERROR",f"UI callback failed: {exc}")
        except queue.Empty: pass
        self._ui_after_id=self.root.after(15,self._drain_ui_queue)

    def _drain_logs(self):
        if self.closed: return
        try:
            while True:
                stamp,level,msg=self.log_queue.get_nowait()
                self._log_lines.append(f"{stamp} [{level}] {msg}")
                self._log_lines=self._log_lines[-1000:]
                if hasattr(self,"log_text"):
                    self.log_text.configure(state="normal"); self.log_text.insert("end",self._log_lines[-1]+"\n"); self.log_text.see("end"); self.log_text.configure(state="disabled")
        except queue.Empty: pass
        self._log_after_id=self.root.after(100,self._drain_logs)

    def _build_ui(self):
        header=ttk.Frame(self.root,padding=(12,8)); header.pack(fill="x")
        ttk.Label(header,text="INDUSTRIAL DEFECT INSPECTION",font=("Segoe UI",14,"bold")).pack(side="left",padx=(0,16))
        ttk.Label(header,text="Model").pack(side="left")
        self.model_entry=ttk.Entry(header,textvariable=self.model_var,width=18); self.model_entry.pack(side="left",padx=5)
        ttk.Button(header,text="SET",style="Accent.TButton",command=self.set_model).pack(side="left",padx=(0,12))
        ttk.Label(header,text="Mode").pack(side="left")
        mode_combo=ttk.Combobox(header,textvariable=self.mode_var,values=["TESTING","DETECTION"],state="readonly",width=12)
        mode_combo.pack(side="left",padx=5); mode_combo.bind("<<ComboboxSelected>>",self._mode_changed)
        ttk.Button(header,text="SAVE PROFILE",command=self.save_current_profile).pack(side="left",padx=7)
        ttk.Button(header,text="LOAD PROFILE",command=self.load_current_profile).pack(side="left",padx=2)
        self.status_var=tk.StringVar(value="SIMULATOR READY")
        ttk.Label(header,textvariable=self.status_var,foreground=COLORS["success"]).pack(side="right")

        body=ttk.Frame(self.root,padding=(10,0,10,10)); body.pack(fill="both",expand=True)
        body.grid_columnconfigure(0,weight=7,uniform="main"); body.grid_columnconfigure(1,weight=3,uniform="main"); body.grid_rowconfigure(0,weight=1)
        left=ttk.Frame(body); left.grid(row=0,column=0,sticky="nsew",padx=(0,8)); left.grid_columnconfigure(0,weight=1)
        # Give the camera viewer most of the vertical space; the result tabs remain resizable below it.
        left.grid_rowconfigure(0,weight=0); left.grid_rowconfigure(1,weight=0); left.grid_rowconfigure(2,weight=7); left.grid_rowconfigure(3,weight=3); left.grid_rowconfigure(4,weight=0)
        toolbar=ttk.Frame(left); toolbar.grid(row=0,column=0,sticky="ew",pady=(0,2))
        toolrow=ttk.Frame(toolbar); toolrow.pack(fill="x",pady=(0,2))
        ttk.Label(toolrow,text="Tool").pack(side="left")
        tools=["Navigate","Inspection ROI","Camera ROI","Detection ROI","Mask ROI","Free Shape","Calibrate Scale"]
        tool_combo=ttk.Combobox(toolrow,textvariable=self.draw_tool,values=tools,state="readonly",width=14); tool_combo.pack(side="left",padx=4)
        ttk.Label(toolrow,text="Shape").pack(side="left",padx=(6,2))
        ttk.Combobox(toolrow,textvariable=self.shape_var,values=["Rectangle","Circle / Ellipse","Rounded Rectangle","Capsule / Stadium","Free Shape"],state="readonly",width=13).pack(side="left")
        ttk.Label(toolrow,text="Role").pack(side="left",padx=(6,2))
        ttk.Combobox(toolrow,textvariable=self.role_var,values=["Detection ROI","Mask ROI"],state="readonly",width=11).pack(side="left")
        ttk.Button(toolrow,text="LOUPE",command=self.toggle_loupe,style="Mini.TButton").pack(side="left",padx=(8,2))
        ttk.Label(toolrow,text="Radius").pack(side="left")
        ttk.Spinbox(toolrow,from_=8,to=40,textvariable=self.loupe_radius,width=3).pack(side="left",padx=2)
        viewrow=ttk.Frame(toolbar); viewrow.pack(fill="x")
        ttk.Label(viewrow,text="VIEW").pack(side="left",padx=(0,5))
        ttk.Button(viewrow,text="FIT",command=self.fit_view,style="Mini.TButton").pack(side="left",padx=2)
        ttk.Button(viewrow,text="−",command=lambda:self.zoom_by(.8),style="Mini.TButton").pack(side="left")
        self.zoom_label=ttk.Label(viewrow,text="FIT"); self.zoom_label.pack(side="left",padx=4)
        ttk.Button(viewrow,text="+",command=lambda:self.zoom_by(1.25),style="Mini.TButton").pack(side="left")
        ttk.Button(viewrow,text="100%",command=self.zoom_100,style="Mini.TButton").pack(side="left",padx=2)
        ttk.Separator(viewrow,orient="vertical").pack(side="left",fill="y",padx=7)
        ttk.Button(viewrow,text="UNDO POINT",command=self.undo_free_point,style="Mini.TButton").pack(side="left",padx=2)
        ttk.Button(viewrow,text="FINISH",command=self.finish_free_shape,style="Mini.TButton").pack(side="left",padx=2)
        ttk.Button(viewrow,text="CANCEL",command=self.cancel_tool,style="Mini.TButton").pack(side="left",padx=2)
        self.viewer_frame=ttk.Frame(left); self.viewer_frame.grid(row=2,column=0,sticky="nsew"); self.viewer_frame.grid_columnconfigure(0,weight=1); self.viewer_frame.grid_rowconfigure(0,weight=1)
        self.viewer_canvas=tk.Canvas(self.viewer_frame,bg=COLORS["viewer"],highlightthickness=0,cursor="crosshair")
        self.hscroll=ttk.Scrollbar(self.viewer_frame,orient="horizontal",command=self.viewer_canvas.xview); self.vscroll=ttk.Scrollbar(self.viewer_frame,orient="vertical",command=self.viewer_canvas.yview)
        self.viewer_canvas.configure(xscrollcommand=self.hscroll.set,yscrollcommand=self.vscroll.set)
        self.viewer_canvas.grid(row=0,column=0,sticky="nsew"); self.vscroll.grid(row=0,column=1,sticky="ns"); self.hscroll.grid(row=1,column=0,sticky="ew")
        self._resize_render_after_id=None
        self.viewer_canvas.bind("<Configure>",self._viewer_resized)
        self.viewer_canvas.bind("<ButtonPress-1>",self._mouse_down); self.viewer_canvas.bind("<B1-Motion>",self._mouse_drag); self.viewer_canvas.bind("<ButtonRelease-1>",self._mouse_up); self.viewer_canvas.bind("<Motion>",self._mouse_motion)
        self.viewer_canvas.bind("<MouseWheel>",self._viewer_wheel)
        detbar=ttk.Frame(left); detbar.grid(row=3,column=0,sticky="nsew",pady=(5,0)); detbar.grid_columnconfigure(0,weight=1); detbar.grid_rowconfigure(0,weight=1)
        self.results_notebook=ttk.Notebook(detbar); self.results_notebook.grid(row=0,column=0,sticky="nsew")
        self.result_tab=self._make_image_tab("Result"); self.heatmap_tab=self._make_image_tab("Heatmap"); self.histogram_tab=self._make_image_tab("Histogram"); self.segments_tab=self._make_image_tab("Segments"); self.mask_tab=self._make_image_tab("Inspection Mask")
        self.defects_tab=ttk.Frame(self.results_notebook); self.results_notebook.add(self.defects_tab,text="Defects")
        self.workflow_original_tab=self._make_image_tab("Captured")
        self.workflow_canny_tab=self._make_image_tab("Phone Mask")
        self.workflow_corrected_tab=self._make_image_tab("Correction Preview")
        self.workflow_compare_tab=self._make_image_tab("Correction Grid")
        self.workflow_segments_tab=self._make_image_tab("Edge + Backglass")
        cols=("algorithm","label","x","y","w","h","area","size")
        self.defects_tree=ttk.Treeview(self.defects_tab,columns=cols,show="headings",height=6)
        for c in cols: self.defects_tree.heading(c,text=c.title()); self.defects_tree.column(c,width=76,anchor="center")
        self.defects_tree.pack(fill="both",expand=True)
        actionbar=ttk.Frame(left); actionbar.grid(row=4,column=0,sticky="ew",pady=(5,0)); actionbar.grid_columnconfigure(0,weight=4); actionbar.grid_columnconfigure(1,weight=1)
        self.perform_btn=ttk.Button(actionbar,text="PERFORM DETECTION",style="Accent.TButton",command=self.perform_detection); self.perform_btn.grid(row=0,column=0,sticky="ew",padx=(0,4))
        ttk.Button(actionbar,text="SAVE RESULT",command=self.save_detection_result).grid(row=0,column=1,sticky="ew")

        self.right_scroll=ScrollableFrame(body); self.right_scroll.grid(row=0,column=1,sticky="nsew")
        self.cards={}
        for name,opened in [("CAMERA",True),("IMAGE PROCESSING WORKFLOW",True),("ROIs",False),("DETECTION ALGORITHMS",False),("SYSTEM LOG",False)]:
            card=CollapsibleCard(self.right_scroll.inner,name,opened); card.pack(fill="x",pady=(0,7)); self.cards[name]=card
        self._build_camera_card(self.cards["CAMERA"].body)
        self._build_processing_card(self.cards["IMAGE PROCESSING WORKFLOW"].body)
        self._build_roi_card(self.cards["ROIs"].body)
        self._build_detection_card(self.cards["DETECTION ALGORITHMS"].body)
        self._build_log_card(self.cards["SYSTEM LOG"].body)

    def _make_image_tab(self,title):
        frame=ttk.Frame(self.results_notebook); self.results_notebook.add(frame,text=title)
        label=ttk.Label(frame,text="No result yet",anchor="center"); label.pack(fill="both",expand=True)
        return frame,label

    def _build_camera_card(self,p):
        row=ttk.Frame(p,style="Card.TFrame"); row.pack(fill="x")
        ttk.Checkbutton(row,text="Camera 1",variable=self.camera1_on).pack(side="left")
        ttk.Checkbutton(row,text="Camera 2",variable=self.camera2_on).pack(side="left",padx=6)
        ttk.Button(row,text="START",style="Success.TButton",command=self.start_cameras).pack(side="left",padx=2)
        ttk.Button(row,text="STOP",style="Danger.TButton",command=self.stop_cameras).pack(side="left",padx=2)
        ttk.Label(p,text="Camera backend",style="Card.TLabel").pack(anchor="w",pady=(7,1))
        ttk.Combobox(p,textvariable=self.camera_backend_var,values=["Simulated","Basler"],state="readonly").pack(fill="x")
        ttk.Label(p,text="Preview source",style="Card.TLabel").pack(anchor="w",pady=(7,1))
        combo=ttk.Combobox(p,textvariable=self.preview_source,values=["Camera 1","Camera 2","Stitched"],state="readonly"); combo.pack(fill="x")
        combo.bind("<<ComboboxSelected>>",self._source_changed)
        ttk.Label(p,text="Stitching mode",style="Card.TLabel").pack(anchor="w",pady=(5,1))
        sm=ttk.Combobox(p,textvariable=self.stitch_mode,values=["Auto feature stitch","Aligned side-by-side","Vertical aligned join"],state="readonly"); sm.pack(fill="x"); sm.bind("<<ComboboxSelected>>",self._source_changed)
        ttk.Label(p,text="For your top/bottom half-phone camera layout, use Vertical aligned join. Choose Aligned side-by-side only when cameras cover left/right halves.",style="Sub.TLabel",wraplength=265).pack(anchor="w",pady=(2,3))
        ttk.Label(p,text="Per-camera settings (apply separately)",style="Card.TLabel").pack(anchor="w",pady=(8,3))
        setting_combo=ttk.Combobox(p,textvariable=self.setting_camera,values=["Camera 1","Camera 2"],state="readonly")
        setting_combo.pack(fill="x"); setting_combo.bind("<<ComboboxSelected>>",self._load_camera_settings_ui)
        ttk.Checkbutton(p,text="Basler: use full sensor / full field of view (recommended)",variable=self.full_sensor_var).pack(anchor="w",pady=(4,2))
        ttk.Label(p,text="When enabled, Width and Height are ignored for Basler and the camera uses its maximum sensor ROI. Uncheck only when you intentionally want a cropped sensor region.",style="Sub.TLabel",wraplength=265).pack(anchor="w",pady=(0,3))
        grid=ttk.Frame(p,style="Card.TFrame"); grid.pack(fill="x",pady=3)
        entries=[("Exposure µs",self.exposure_var),("Gain",self.gain_var),("FPS",self.fps_var),("Width",self.width_var),("Height",self.height_var)]
        for i,(label,var) in enumerate(entries):
            ttk.Label(grid,text=label,style="Card.TLabel").grid(row=i//2,column=(i%2)*2,sticky="w",padx=(0,4),pady=2)
            ttk.Entry(grid,textvariable=var,width=8).grid(row=i//2,column=(i%2)*2+1,sticky="ew",padx=(0,6),pady=2)
        grid.columnconfigure(1,weight=1); grid.columnconfigure(3,weight=1)
        ttk.Button(p,text="APPLY CAMERA SETTINGS",command=self.apply_camera_settings).pack(fill="x",pady=3)
        ttk.Button(p,text="CALIBRATE SCALE (mm / px)",command=self.start_calibration).pack(fill="x",pady=2)
        ttk.Button(p,text="LOCK STITCH STATE",command=self.lock_stitch).pack(fill="x",pady=2)
        ttk.Label(p,text="Basler support requires pypylon. Simulator is active by default.",style="Sub.TLabel",wraplength=260).pack(anchor="w",pady=(5,0))

    def _build_processing_card(self,p):
        ttk.Label(p,text="STAGE 1 · CAPTURE + CALIBRATION",style="Card.TLabel",font=("Segoe UI",10,"bold")).pack(anchor="w")
        row=ttk.Frame(p,style="Card.TFrame"); row.pack(fill="x",pady=3)
        ttk.Button(row,text="CAPTURE FRAME",style="Accent.TButton",command=self.capture_workflow_frame).pack(side="left",fill="x",expand=True)
        ttk.Button(row,text="RESUME LIVE",command=self.resume_workflow_live).pack(side="left",fill="x",expand=True,padx=(4,0))
        ttk.Button(p,text="CALIBRATE · DRAW TWO POINTS",command=self.start_calibration).pack(fill="x",pady=2)
        self.workflow_scale_label=tk.StringVar(value="Scale: not calibrated; dimension estimate will use frame proportions")
        ttk.Label(p,textvariable=self.workflow_scale_label,style="Sub.TLabel",wraplength=270).pack(anchor="w",pady=(0,5))

        ttk.Separator(p).pack(fill="x",pady=4)
        ttk.Label(p,text="STAGE 2 · PHONE REGION + MANUAL MASKS",style="Card.TLabel",font=("Segoe UI",10,"bold")).pack(anchor="w")
        ttk.Checkbutton(p,text="Use phone / backglass ROI workflow for detection",variable=self.phone_workflow_enabled_var).pack(anchor="w",pady=(2,4))
        grid=ttk.Frame(p,style="Card.TFrame"); grid.pack(fill="x")
        entries=[("Phone width (mm)",self.phone_width_mm_var),("Phone height (mm)",self.phone_height_mm_var),
                 ("Centre X (%)",self.phone_center_x_var),("Centre Y (%)",self.phone_center_y_var),
                 ("Uncalibrated width (% frame)",self.phone_frame_width_var),("Colour tolerance",self.phone_color_tolerance_var)]
        for i,(label,var) in enumerate(entries):
            ttk.Label(grid,text=label,style="Card.TLabel").grid(row=i,column=0,sticky="w",padx=(0,4),pady=2)
            ttk.Spinbox(grid,from_=0.1 if "mm" in label else (12 if "width (%" in label else 0),
                          to=500 if "mm" in label else (85 if "width (%" in label else (100 if "Centre" in label else 70)),
                          increment=0.5 if "mm" in label else 1, textvariable=var,width=8).grid(row=i,column=1,sticky="ew",pady=2)
        grid.columnconfigure(1,weight=1)
        row=ttk.Frame(p,style="Card.TFrame"); row.pack(fill="x",pady=(4,2))
        ttk.Label(row,text="Canny support low/high",style="Card.TLabel").pack(side="left")
        ttk.Spinbox(row,from_=0,to=254,textvariable=self.workflow_canny_low_var,width=5).pack(side="left",padx=(5,2))
        ttk.Spinbox(row,from_=1,to=255,textvariable=self.workflow_canny_high_var,width=5).pack(side="left",padx=2)
        ttk.Button(p,text="FIND PHONE REGION · DIMENSIONS + COLOUR",command=self.run_phone_separation,style="Accent.TButton").pack(fill="x",pady=3)
        ttk.Label(p,text="Then draw any number of Mask ROIs on the main viewer. The toolbar supports rectangle, circle/ellipse, rounded rectangle, capsule/stadium and free shape. Inspection ROI limits the phone search; Camera ROI excludes the camera assembly.",style="Sub.TLabel",wraplength=270).pack(anchor="w",pady=(2,4))
        row=ttk.Frame(p,style="Card.TFrame"); row.pack(fill="x",pady=2)
        ttk.Label(row,text="Bulged edge width (mm)",style="Card.TLabel").pack(side="left")
        ttk.Spinbox(row,from_=0.1,to=10.0,increment=0.1,textvariable=self.workflow_edge_width_mm_var,width=7).pack(side="right")
        ttk.Button(p,text="BUILD EDGE + BACKGLASS ROIS",command=self.run_workflow_segmentation,style="Accent.TButton").pack(fill="x",pady=3)

        ttk.Separator(p).pack(fill="x",pady=4)
        ttk.Label(p,text="STAGE 3 · OPTIONAL ILLUMINATION CORRECTION",style="Card.TLabel",font=("Segoe UI",10,"bold")).pack(anchor="w")
        ttk.Label(p,text="The ROI stage above is independent. Generate these outputs only when needed; masks are excluded from illumination statistics. Original input remains the default for detection.",style="Sub.TLabel",wraplength=270).pack(anchor="w",pady=(1,4))
        ttk.Label(p,text="Correction method",style="Card.TLabel").pack(anchor="w")
        self.workflow_method_combo=ttk.Combobox(p,textvariable=self.workflow_method_var,values=list(WORKFLOW_METHODS),state="readonly")
        self.workflow_method_combo.pack(fill="x")
        self.workflow_method_combo.bind("<<ComboboxSelected>>",lambda e:self._preview_selected_workflow_method())
        ttk.Label(p,text="Correction strength",style="Card.TLabel").pack(anchor="w",pady=(4,0))
        ttk.Scale(p,from_=0.0,to=1.0,variable=self.workflow_strength_var,orient="horizontal").pack(fill="x")
        ttk.Label(p,text="Illumination blur scale",style="Card.TLabel").pack(anchor="w",pady=(3,0))
        ttk.Scale(p,from_=0.015,to=0.20,variable=self.workflow_sigma_var,orient="horizontal").pack(fill="x")
        row=ttk.Frame(p,style="Card.TFrame"); row.pack(fill="x",pady=3)
        ttk.Button(row,text="LOAD FLAT-FIELD",command=self.load_flat_field_reference,style="Mini.TButton").pack(side="left",fill="x",expand=True)
        ttk.Button(row,text="GENERATE OUTPUTS",command=self.generate_workflow_outputs,style="Mini.TButton").pack(side="left",fill="x",expand=True,padx=(4,0))
        ttk.Checkbutton(p,text="Use selected correction for detection (otherwise original ROI)",variable=self.workflow_use_selected_var,command=self._workflow_selection_changed).pack(anchor="w",pady=2)
        ttk.Button(p,text="SAVE ALL STAGE OUTPUTS",command=self.save_workflow_outputs,style="Mini.TButton").pack(fill="x",pady=2)
        self.workflow_status_label=ttk.Label(p,textvariable=self.workflow_status_var,style="Card.TLabel",wraplength=270)
        self.workflow_status_label.pack(anchor="w",pady=5)
        ttk.Label(p,text="When a profile is loaded, clicking PERFORM DETECTION automatically re-finds the phone, excludes masks, rebuilds the 1.1 mm edge/backglass regions, optionally applies the selected correction, and runs the existing detector logic. RESUME LIVE returns the viewer to live camera mode.",style="Sub.TLabel",wraplength=270).pack(anchor="w",pady=(2,0))

    # ---------------- Staged image-processing workflow ----------------
    def _workflow_source_image(self):
        """Return the frozen inspection frame, or the newest camera frame in live mode."""
        source = self.workflow_frame if self.workflow_frozen and self.workflow_frame is not None else self.current_image
        return None if source is None else source.copy()

    def _workflow_domain_mask(self, image):
        """Return the phone/inspection pixels used to estimate illumination."""
        if self.workflow_backglass_mask is not None and self.workflow_backglass_mask.shape[:2] == image.shape[:2] and cv2.countNonZero(self.workflow_backglass_mask):
            domain = self.workflow_backglass_mask.copy()
        elif self.workflow_phone_mask is not None and self.workflow_phone_mask.shape[:2] == image.shape[:2] and cv2.countNonZero(self.workflow_phone_mask):
            domain = self.workflow_phone_mask.copy()
        else:
            domain = self._effective_inspection_mask(image).copy()
        inspection = self.roi_controller.inspection
        if inspection is not None and inspection.enabled:
            domain = cv2.bitwise_and(domain, rasterize_shape(inspection.shape, image.shape))
        for roi in self.roi_controller.rois:
            if roi.enabled and roi.role == "mask":
                domain = cv2.bitwise_and(domain, cv2.bitwise_not(rasterize_shape(roi.shape, image.shape)))
        return domain

    def _workflow_exclusions(self, image):
        excluded = np.zeros(image.shape[:2], np.uint8)
        for roi in self.roi_controller.rois:
            if roi.enabled and roi.role == "mask":
                cv2.bitwise_or(excluded, rasterize_shape(roi.shape, image.shape), dst=excluded)
        return excluded

    def capture_workflow_frame(self):
        """Freeze a full-resolution frame so the operator can annotate reproducibly."""
        if any(name in self.busy for name in ("workflow_canny","workflow_correction","workflow_segments")):
            messagebox.showinfo("Workflow busy", "Wait for the current image-processing stage to finish before capturing another frame.", parent=self.root)
            return
        image = self.current_image
        if image is None:
            messagebox.showwarning("Capture frame", "Start a camera and wait until the live image is visible before capturing.", parent=self.root)
            return
        image = image.copy()
        if self.current_source_shape is not None and tuple(image.shape[:2]) != tuple(self.current_source_shape):
            has_rois = bool(self.roi_controller.inspection or self.roi_controller.camera or self.roi_controller.rois)
            if has_rois and not messagebox.askyesno("Image dimensions changed", "The new frame has different dimensions. Clear old ROI coordinates before continuing?", parent=self.root):
                return
            if has_rois:
                self.clear_rois()
        self.workflow_frame = image
        self.workflow_frozen = True
        self.current_image = image.copy()
        self.current_source_shape = image.shape[:2]
        self.workflow_outputs = {"Original": image.copy()}
        self.workflow_selected_image = None
        self.workflow_selected_method = None
        # Keep the correction-in-detection option as profile/configuration state;
        # a newly captured frame will have its selected method recomputed lazily.
        self.workflow_phone_edges = None
        self.workflow_phone_mask = None
        self.workflow_edge_mask = None
        self.workflow_backglass_mask = None
        self.workflow_segment_overlay = None
        self.segment_result = None
        self.calibration_line = None
        self.calibration_distance_px = None
        self.calibration_distance_mm = None
        self._set_panel_image(self.workflow_original_tab, image)
        out_dir = ROOT / "captures" / "workflow_frames"
        filename = f"frame_{time.strftime('%Y%m%d_%H%M%S')}_{self.preview_source.get().lower().replace(' ', '_')}.png"
        self.workflow_status_var.set(f"Frame captured and frozen: {image.shape[1]}×{image.shape[0]}. Saving full-resolution PNG in background…")
        self.status_var.set("WORKFLOW FRAME FROZEN")
        self.log("INFO", f"Manual workflow frame captured: {image.shape[1]}x{image.shape[0]} from {self.preview_source.get()}")
        self._render_preview()
        def save_worker():
            try:
                out_dir.mkdir(parents=True, exist_ok=True)
                saved=cv2.imwrite(str(out_dir / filename), image)
                note=f"Saved {filename}" if saved else "Captured (automatic save failed)"
                self._post_ui(lambda:self.workflow_status_var.set(f"Frame frozen: {image.shape[1]}×{image.shape[0]}. {note}"))
            except Exception as exc:
                self._post_ui(lambda exc=exc:self.log("WARN",f"Capture save failed: {exc}"))
        threading.Thread(target=save_worker,daemon=True,name="workflow-frame-save").start()

    def resume_workflow_live(self):
        self.workflow_frozen = False
        self.status_var.set("LIVE VIEW")
        self.workflow_status_var.set("Live view resumed. Capture a new frame to continue the staged workflow.")
        self.log("INFO", "Resumed live preview; existing workflow outputs remain available until the next capture.")

    def load_flat_field_reference(self):
        path = filedialog.askopenfilename(parent=self.root, title="Select flat-field reference image", filetypes=[("Images", "*.png *.jpg *.jpeg *.bmp *.tif *.tiff"), ("All files", "*.*")])
        if not path:
            return
        image = cv2.imread(path, cv2.IMREAD_COLOR)
        if image is None:
            messagebox.showerror("Flat-field reference", "Could not read this image.", parent=self.root)
            return
        self.workflow_flat_field = image
        self.workflow_flat_field_path = str(Path(path).resolve())
        self.workflow_status_var.set(f"Flat-field reference loaded: {Path(path).name}. It will be resized to match the captured frame if needed.")
        self.log("INFO", f"Flat-field reference loaded: {path}")

    def run_phone_separation(self):
        if self.workflow_frame is None or not self.workflow_frozen:
            return messagebox.showwarning("Phone region", "Capture and freeze a frame before setting up the phone ROI. Resume Live is available after setup.", parent=self.root)
        image = self.workflow_frame.copy()
        if image is None:
            return messagebox.showwarning("Phone region", "Capture a frame first.", parent=self.root)
        if "workflow_canny" in self.busy:
            return
        low = int(self.workflow_canny_low_var.get()); high = int(self.workflow_canny_high_var.get())
        if high <= low:
            return messagebox.showerror("Canny", "Canny high threshold must be greater than low threshold.", parent=self.root)
        try:
            phone_w = float(self.phone_width_mm_var.get()); phone_h = float(self.phone_height_mm_var.get())
            cx = float(self.phone_center_x_var.get()); cy = float(self.phone_center_y_var.get())
            fill = float(self.phone_frame_width_var.get()) / 100.0
            tolerance = float(self.phone_color_tolerance_var.get())
            scale = self.calibration.get_scale(self.preview_source.get())
            inspection = copy.deepcopy(self.roi_controller.inspection)
            search = rasterize_shape(inspection.shape, image.shape) if inspection and inspection.enabled else np.full(image.shape[:2],255,np.uint8)
            excludes = self._workflow_exclusions(image)
            camera_roi = copy.deepcopy(self.roi_controller.camera)
            if camera_roi and camera_roi.enabled:
                cv2.bitwise_or(excludes, rasterize_shape(camera_roi.shape, image.shape), dst=excludes)
        except Exception as exc:
            return messagebox.showerror("Phone region settings", str(exc), parent=self.root)
        self.busy.add("workflow_canny")
        self.workflow_status_var.set("Estimating phone region from dimensions, centre and Lab colour similarity…")
        def worker():
            try:
                edges, phone_mask, overlay, message, bbox = detect_phone_region(
                    image, search, phone_w, phone_h, scale, cx, cy, fill, tolerance, low, high, exclude_mask=excludes)
                self._post_ui(lambda: self._phone_separation_done(image, edges, phone_mask, overlay, message, bbox))
            except Exception as exc:
                self._post_ui(lambda exc=exc: self._async_error("Phone region detection", exc))
            finally:
                self.busy.discard("workflow_canny")
        threading.Thread(target=worker, daemon=True, name="phone-region-worker").start()

    def _phone_separation_done(self, image, edges, phone_mask, overlay, message, bbox=None):
        self.workflow_phone_edges = edges
        self.workflow_phone_mask = phone_mask if phone_mask is not None and cv2.countNonZero(phone_mask) else None
        self.workflow_outputs = {"Original": self.workflow_frame.copy() if self.workflow_frame is not None else image.copy()}
        self.workflow_selected_image = None
        self.workflow_selected_method = None
        self.workflow_edge_mask = None
        self.workflow_backglass_mask = None
        self.workflow_segment_overlay = None
        self._set_panel_image(self.workflow_canny_tab, overlay if overlay is not None else edges)
        if self.workflow_phone_mask is not None:
            count = cv2.countNonZero(self.workflow_phone_mask)
            self.workflow_status_var.set(f"Phone region ready: {count:,} px; bbox={bbox}. {message}")
            self.log("INFO", f"Phone region estimated: {count} px; bbox={bbox}; {message}")
        else:
            self.workflow_status_var.set("Phone region could not be generated. Check dimensions, centre and Inspection ROI.")
            self.log("WARN", self.workflow_status_var.get())
        self.results_notebook.select(self.workflow_canny_tab[0])
        self._render_preview()

    def generate_workflow_outputs(self):
        if self.workflow_frame is None or not self.workflow_frozen:
            return messagebox.showwarning("Illumination correction", "Capture and freeze a frame, then build the edge/backglass ROIs first.", parent=self.root)
        if self.workflow_backglass_mask is None or not cv2.countNonZero(self.workflow_backglass_mask):
            return messagebox.showwarning("Illumination correction", "Build the edge/backglass ROIs first. Correction statistics must use only the valid backglass area.", parent=self.root)
        image = self.workflow_frame.copy()
        if image is None:
            return messagebox.showwarning("Illumination correction", "Capture a frame first.", parent=self.root)
        if "workflow_correction" in self.busy:
            return
        valid = self._workflow_domain_mask(image)
        if not np.any(valid):
            return messagebox.showwarning("Illumination correction", "No valid pixels remain after applying the phone ROI and exclusion masks. Rebuild the phone and edge/backglass ROIs.", parent=self.root)
        strength = float(self.workflow_strength_var.get())
        sigma_fraction = float(self.workflow_sigma_var.get())
        flat_field = None if self.workflow_flat_field is None else self.workflow_flat_field.copy()
        self.busy.add("workflow_correction")
        self.workflow_status_var.set("Generating every available correction candidate in a background worker…")
        def worker():
            outputs = {"Original": image.copy()}
            errors = {}
            try:
                for method in WORKFLOW_METHODS:
                    if method == "Original":
                        continue
                    try:
                        outputs[method] = correct_image(image, method, valid, strength, sigma_fraction, flat_field)
                    except Exception as exc:
                        errors[method] = str(exc)
                grid = make_correction_comparison(outputs)
                self._post_ui(lambda: self._workflow_outputs_done(outputs, errors, grid))
            except Exception as exc:
                self._post_ui(lambda exc=exc: self._async_error("Correction candidates", exc))
            finally:
                self.busy.discard("workflow_correction")
        threading.Thread(target=worker, daemon=True, name="workflow-correction-worker").start()

    def _workflow_outputs_done(self, outputs, errors, grid=None):
        self.workflow_outputs = outputs
        if self.workflow_method_var.get() not in outputs:
            self.workflow_method_var.set("Gaussian Divide" if "Gaussian Divide" in outputs else "Original")
        self._preview_selected_workflow_method()
        if grid is not None:
            self._set_panel_image(self.workflow_compare_tab, grid)
        available = ", ".join(outputs.keys())
        note = f"Image-processing outputs ready: {available}. Preview a method or inspect Correction Grid."
        if errors:
            note += " Unavailable: " + "; ".join(f"{k}: {v}" for k, v in errors.items())
        self.workflow_status_var.set(note)
        self.log("INFO", note)

    def _preview_selected_workflow_method(self):
        method = self.workflow_method_var.get()
        image = self.workflow_outputs.get(method)
        if image is None:
            self.workflow_status_var.set(f"No output for {method}. Flat-field requires a loaded reference image; generate outputs again after loading it.")
            return
        self.workflow_selected_image = image.copy()
        self.workflow_selected_method = method
        self._set_panel_image(self.workflow_corrected_tab, image)
        state = "will be used for detection" if self.workflow_use_selected_var.get() else "preview only; original ROI remains the detection input"
        self.workflow_status_var.set(f"Previewing {method}; {state}.")
        self.results_notebook.select(self.workflow_corrected_tab[0])

    def use_selected_workflow_output(self):
        # Retained as a convenient action for older layouts/profiles.
        image = self.workflow_outputs.get(self.workflow_method_var.get())
        if image is None:
            return messagebox.showwarning("Select output", "Generate outputs first. Flat-field requires a loaded reference image.", parent=self.root)
        self.workflow_selected_image = image.copy()
        self.workflow_selected_method = self.workflow_method_var.get()
        self.workflow_use_selected_var.set(True)
        self._workflow_selection_changed()

    def _workflow_selection_changed(self):
        method = self.workflow_method_var.get()
        if self.workflow_use_selected_var.get():
            self.workflow_status_var.set(f"Detection correction enabled: {method}. The method will be recomputed for every new frame using only valid backglass pixels; masks are excluded.")
            self.log("INFO", f"Selected illumination-correction method for detection: {method}")
        else:
            self.workflow_status_var.set("Correction is optional and disabled for detection; the original backglass ROI will be used.")

    def _edge_width_pixels(self, image, phone_mask=None):
        width_mm = max(0.1, float(self.workflow_edge_width_mm_var.get()))
        scale = self.calibration.get_scale(self.preview_source.get())
        if scale and scale > 0:
            return max(2, int(round(width_mm / scale)))
        bbox = None
        if phone_mask is not None and np.count_nonzero(phone_mask):
            contours, _ = cv2.findContours((phone_mask > 0).astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            if contours:
                bbox = cv2.boundingRect(max(contours, key=cv2.contourArea))
        if bbox is not None:
            phone_w_px = bbox[2]
            phone_w_mm = max(1.0, float(self.phone_width_mm_var.get()))
            return max(2, int(round(phone_w_px * width_mm / phone_w_mm)))
        return 12

    def run_workflow_segmentation(self):
        if self.workflow_frame is None or not self.workflow_frozen:
            return messagebox.showwarning("Edge / backglass ROIs", "Capture and freeze a frame before building regions.", parent=self.root)
        image = self.workflow_frame.copy()
        if image is None:
            return messagebox.showwarning("Edge / backglass ROIs", "Capture a frame first.", parent=self.root)
        if self.workflow_phone_mask is None or self.workflow_phone_mask.shape[:2] != image.shape[:2] or not cv2.countNonZero(self.workflow_phone_mask):
            self.run_phone_separation()
            self.workflow_status_var.set("Phone region requested. When it completes, press BUILD EDGE + BACKGLASS ROIS again.")
            return
        if "workflow_segments" in self.busy:
            return
        phone = self.workflow_phone_mask.copy()
        edge_width = self._edge_width_pixels(image, phone)
        camera_roi = copy.deepcopy(self.roi_controller.camera)
        camera_mask = rasterize_shape(camera_roi.shape, image.shape) if camera_roi and camera_roi.enabled else None
        excludes = self._workflow_exclusions(image)
        self.busy.add("workflow_segments")
        self.workflow_status_var.set(f"Building a consistent {float(self.workflow_edge_width_mm_var.get()):.2f} mm edge band ({edge_width}px estimate) and backglass ROI…")
        def worker():
            try:
                edge, backglass, overlay = adaptive_edge_backglass(image, phone, edge_width, camera_mask, excludes)
                self._post_ui(lambda: self._workflow_segmentation_done(edge, backglass, overlay, edge_width))
            except Exception as exc:
                self._post_ui(lambda exc=exc: self._async_error("Edge / backglass ROI generation", exc))
            finally:
                self.busy.discard("workflow_segments")
        threading.Thread(target=worker, daemon=True, name="edge-backglass-worker").start()

    def _workflow_segmentation_done(self, edge, backglass, overlay, edge_width):
        self.workflow_edge_mask = edge
        self.workflow_backglass_mask = backglass
        self.workflow_segment_overlay = overlay
        self._set_panel_image(self.workflow_segments_tab, overlay)
        self.results_notebook.select(self.workflow_segments_tab[0])
        status=f"ROIs ready: edge={cv2.countNonZero(edge):,} px; backglass={cv2.countNonZero(backglass):,} px; edge width≈{edge_width}px ({float(self.workflow_edge_width_mm_var.get()):.2f} mm). Mask ROIs are excluded."
        self.workflow_status_var.set(status)
        self.log("INFO", status)

    def save_workflow_outputs(self):
        if not self.workflow_outputs and self.workflow_frame is None:
            return messagebox.showwarning("Save outputs", "Capture a frame and generate outputs first.", parent=self.root)
        folder = filedialog.askdirectory(parent=self.root, title="Choose folder for stage outputs")
        if not folder:
            return
        out = Path(folder)
        # Snapshot array references before starting a writer; no Tk operation is done by the worker.
        original=None if self.workflow_frame is None else self.workflow_frame.copy()
        images={k:v.copy() for k,v in self.workflow_outputs.items()}
        masks={name:mask.copy() for name,mask in (("phone_mask",self.workflow_phone_mask),("canny_edges",self.workflow_phone_edges),("edge_band_mask",self.workflow_edge_mask),("backglass_mask",self.workflow_backglass_mask)) if mask is not None}
        overlay=None if self.workflow_segment_overlay is None else self.workflow_segment_overlay.copy()
        phone_overlay = None
        if self.workflow_phone_mask is not None and original is not None:
            phone_overlay = original.copy()
            contours, _ = cv2.findContours(self.workflow_phone_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            if contours: cv2.drawContours(phone_overlay, contours, -1, (40, 230, 80), 2, cv2.LINE_AA)
        self.workflow_status_var.set(f"Saving stage outputs in background to {out}…")
        def save_worker():
            try:
                out.mkdir(parents=True, exist_ok=True); saved=[]
                if original is not None and cv2.imwrite(str(out / "captured_original.png"), original): saved.append("captured_original.png")
                for name, image in images.items():
                    safe=safe_name(name.lower().replace(" ","_"))
                    if cv2.imwrite(str(out / f"{safe}.png"),image): saved.append(f"{safe}.png")
                for name, mask in masks.items():
                    if cv2.imwrite(str(out / f"{name}.png"),mask): saved.append(f"{name}.png")
                if overlay is not None and cv2.imwrite(str(out / "edge_backglass_overlay.png"),overlay): saved.append("edge_backglass_overlay.png")
                if phone_overlay is not None and cv2.imwrite(str(out / "phone_region_overlay.png"),phone_overlay): saved.append("phone_region_overlay.png")
                self._post_ui(lambda:self.workflow_status_var.set(f"Saved {len(saved)} stage outputs to {out}"))
                self.log("INFO", f"Saved {len(saved)} workflow outputs to {out}")
            except Exception as exc:
                self._post_ui(lambda exc=exc:self._async_error("Save stage outputs",exc))
        threading.Thread(target=save_worker,daemon=True,name="workflow-output-save").start()

    def _build_lighting_card(self,p):
        ttk.Label(p,text="Controller topology",style="Card.TLabel").pack(anchor="w")
        topo=ttk.Combobox(p,textvariable=self.topology_var,values=["LIGHT_SINGLE_4","LIGHT_DUAL_4","LIGHT_SINGLE_8 (UNVERIFIED)"],state="readonly"); topo.pack(fill="x"); topo.bind("<<ComboboxSelected>>",self._topology_changed)
        ttk.Label(p,text="Port A",style="Card.TLabel").pack(anchor="w",pady=(4,0)); ttk.Entry(p,textvariable=self.port_a_var).pack(fill="x")
        ttk.Label(p,text="Port B (Dual 4 only)",style="Card.TLabel").pack(anchor="w",pady=(4,0)); ttk.Entry(p,textvariable=self.port_b_var).pack(fill="x")
        ttk.Label(p,text="Settle time ms",style="Card.TLabel").pack(anchor="w",pady=(4,0)); ttk.Spinbox(p,from_=0,to=5000,textvariable=self.settle_var).pack(fill="x")
        row=ttk.Frame(p,style="Card.TFrame"); row.pack(fill="x",pady=5)
        ttk.Button(row,text="CONNECT",style="Success.TButton",command=self.connect_lights).pack(side="left",expand=True,fill="x")
        ttk.Button(row,text="READY / WHITE",command=self.lights_ready).pack(side="left",expand=True,fill="x",padx=3)
        ttk.Button(row,text="ALL OFF",style="Danger.TButton",command=self.lights_off).pack(side="left",expand=True,fill="x")
        self.light_status=tk.StringVar(value="Disconnected")
        ttk.Label(p,textvariable=self.light_status,style="Card.TLabel",wraplength=260).pack(anchor="w")
        ttk.Separator(p).pack(fill="x",pady=5)
        ttk.Label(p,text="Light A / Left recipes (1–8)",style="Card.TLabel").pack(anchor="w")
        self.recipe_frame=ttk.Frame(p,style="Card.TFrame"); self.recipe_frame.pack(fill="x")
        ttk.Button(p,text="ADD RECIPE",command=self.add_recipe,style="Mini.TButton").pack(side="left",pady=3)
        ttk.Button(p,text="REMOVE LAST",command=self.remove_recipe,style="Mini.TButton").pack(side="left",padx=4,pady=3)
        ttk.Label(p,text="Dual 4 uses port A/B separately; Single 8 writes an UNCONFIRMED 8-channel frame.",style="Sub.TLabel",wraplength=260).pack(anchor="w",pady=(4,0))
        self._rebuild_recipe_rows()

    def _build_capture_card(self,p):
        self.capture_folder_var=tk.StringVar(value="Captures save under captures/{model}/setN/")
        ttk.Label(p,textvariable=self.capture_folder_var,style="Card.TLabel",wraplength=260).pack(anchor="w")
        ttk.Button(p,text="CAPTURE SELECTED SET",style="Accent.TButton",command=self.capture_selected).pack(fill="x",pady=4)
        ttk.Button(p,text="CAPTURE ONE TEST IMAGE",command=self.capture_one_testing).pack(fill="x",pady=2)
        self.capture_status=tk.StringVar(value="No capture yet")
        ttk.Label(p,textvariable=self.capture_status,style="Card.TLabel",wraplength=260).pack(anchor="w",pady=3)

    def _build_roi_card(self,p):
        self.roi_summary_var=tk.StringVar(value="0 drawn · 0 active")
        ttk.Label(p,textvariable=self.roi_summary_var,style="Card.TLabel").pack(anchor="w")
        ttk.Label(p,text="Inspection ROI: green • Camera ROI: blue",style="Card.TLabel",wraplength=260).pack(anchor="w")
        ttk.Label(p,text="DETECT includes area; MASK excludes area. Draw several of either. Free Shape: click vertices, press Enter to finish. Drag and click coordinates are source pixels.",style="Sub.TLabel",wraplength=260).pack(anchor="w",pady=3)
        row=ttk.Frame(p,style="Card.TFrame"); row.pack(fill="x",pady=2)
        ttk.Button(row,text="ALL",command=lambda:self.set_all_rois(True),style="Mini.TButton").pack(side="left")
        ttk.Button(row,text="NONE",command=lambda:self.set_all_rois(False),style="Mini.TButton").pack(side="left",padx=3)
        ttk.Button(row,text="CLEAR ALL",command=self.clear_rois,style="Mini.TButton").pack(side="left")
        self.roi_list_frame=ttk.Frame(p,style="Card.TFrame"); self.roi_list_frame.pack(fill="x",pady=4)
        self._refresh_roi_list()

    def _build_detection_card(self,p):
        ttk.Label(p,text="Detector plugins (multi-select)",style="Card.TLabel").pack(anchor="w")
        legacy=CollapsibleCard(p,"LEGACY SEGMENTATION (optional; not used by phone ROI workflow)",False); legacy.pack(fill="x",pady=(2,5))
        lp=legacy.body
        ttk.Label(lp,text="Use only when the phone / backglass ROI workflow is disabled.",style="Sub.TLabel",wraplength=250).pack(anchor="w")
        ttk.Combobox(lp,textvariable=self.seg_backend_var,values=list(self.segmentation_backends),state="readonly").pack(fill="x")
        row=ttk.Frame(lp,style="Card.TFrame"); row.pack(fill="x",pady=4)
        ttk.Button(row,text="SEGMENT",command=self.run_segmentation,style="Mini.TButton").pack(side="left",expand=True,fill="x")
        ttk.Checkbutton(row,text="Re-segment on detection",variable=self.segmentation_enabled).pack(side="left",padx=4)
        self.segment_list_frame=ttk.Frame(lp,style="Card.TFrame"); self.segment_list_frame.pack(fill="x")
        self.segment_status=tk.StringVar(value="No segmentation yet")
        ttk.Label(lp,textvariable=self.segment_status,style="Card.TLabel",wraplength=260).pack(anchor="w",pady=3)
        ttk.Button(p,text="REFRESH ALGORITHMS",command=self.refresh_algorithms,style="Mini.TButton").pack(anchor="w",pady=2)
        self.detector_list_frame=ttk.Frame(p,style="Card.TFrame"); self.detector_list_frame.pack(fill="x")
        self._refresh_detector_list()

        # Operator-facing controls: tune the common Laplacian parameters without typing numbers.
        quick=ttk.Frame(p,style="Card.TFrame",padding=(7,7)); quick.pack(fill="x",pady=(5,3))
        ttk.Label(quick,text="LIVE DETECTION · QUICK TUNING",style="Card.TLabel",font=("Segoe UI",10,"bold")).pack(anchor="w")
        ttk.Label(quick,text="Lower k / minimum magnitude = more sensitive. RAW Laplacian uses main6-style local mean+std thresholding; temporal persistence is applied only in live mode.",style="Sub.TLabel",wraplength=255).pack(anchor="w",pady=(1,4))
        self._make_tuning_slider(quick,"Sensitivity (k)",self.quick_sensitivity,0.5,6.0,lambda v:f"{float(v):.1f}","quick_sensitivity_value")
        self._make_tuning_slider(quick,"Minimum edge strength",self.quick_min_magnitude,0,100,lambda v:f"{float(v):.0f}","quick_min_magnitude_value")
        self._make_tuning_slider(quick,"Minimum defect area (px)",self.quick_min_area,1,1500,lambda v:f"{int(float(v))}","quick_min_area_value")
        self._make_tuning_slider(quick,"Box padding (%)",self.quick_box_padding,0,150,lambda v:f"{float(v):.0f}%","quick_box_padding_value",display_transform=lambda v:float(v)/100.0)
        row=ttk.Frame(quick,style="Card.TFrame"); row.pack(fill="x",pady=(5,1))
        ttk.Checkbutton(row,text="Run continuously on live frames",variable=self.live_detection_var,command=self._live_detection_toggle).pack(anchor="w")
        ttk.Label(quick,text="Runs on live frames in a background worker. The phone ROI workflow needs no separate Detection ROI; candidates still require human review.",style="Sub.TLabel",wraplength=255).pack(anchor="w",pady=(3,0))

        self.advanced_settings_card=CollapsibleCard(p,"ADVANCED PLUGIN SETTINGS",False); self.advanced_settings_card.pack(fill="x",pady=(4,0))
        advanced=self.advanced_settings_card.body
        ttk.Label(advanced,text="Settings for selected plug-in",style="Card.TLabel").pack(anchor="w")
        self.setting_selector=ttk.Combobox(advanced,textvariable=self.detector_setting_name,values=self.detection_registry.names(),state="readonly"); self.setting_selector.pack(fill="x"); self.setting_selector.bind("<<ComboboxSelected>>",lambda e:self._build_detector_settings())
        self.detector_settings_frame=ttk.Frame(advanced,style="Card.TFrame"); self.detector_settings_frame.pack(fill="x",pady=3)
        self._build_detector_settings()
        ttk.Label(advanced,text="RAW Laplacian and Canny are heuristic candidates. YOLO requires compatible .pt weights and optional ultralytics/PyTorch.",style="Sub.TLabel",wraplength=255).pack(anchor="w",pady=4)

    def _make_tuning_slider(self,parent,title,var,from_,to,formatter,value_attr,display_transform=None):
        row=ttk.Frame(parent,style="Card.TFrame"); row.pack(fill="x",pady=(3,1))
        ttk.Label(row,text=title,style="Card.TLabel").pack(side="left",anchor="w")
        value_label=ttk.Label(row,text=formatter(var.get()),style="Card.TLabel",width=6,anchor="e"); value_label.pack(side="right")
        setattr(self,value_attr,value_label)
        scale=ttk.Scale(parent,from_=from_,to=to,orient="horizontal",variable=var,
                        command=lambda value:self._quick_tuning_changed())
        scale.pack(fill="x",padx=(2,4),pady=(0,2))
        return scale

    def _quick_tuning_changed(self):
        name="RAW Laplacian V1"
        if name not in self.detector_params: return
        # The padding slider is in percent to be intuitive for operators.
        values={"k":float(self.quick_sensitivity.get()),
                "min_magnitude":float(self.quick_min_magnitude.get()),
                "min_area_px":int(round(self.quick_min_area.get())),
                "box_expand_ratio":float(self.quick_box_padding.get())/100.0}
        self.detector_params[name].update(values)
        labels=(("quick_sensitivity_value",f"{values['k']:.1f}"),
                ("quick_min_magnitude_value",f"{values['min_magnitude']:.0f}"),
                ("quick_min_area_value",f"{values['min_area_px']}"),
                ("quick_box_padding_value",f"{values['box_expand_ratio']*100:.0f}%"))
        for attr,label in labels:
            widget=getattr(self,attr,None)
            if widget is not None:
                try: widget.configure(text=label)
                except tk.TclError: pass
        # Keep the advanced numeric fields in sync so a later profile/detection read cannot undo slider edits.
        for key,value in values.items():
            field=self.detector_setting_vars.get(name,{}).get(key)
            if field:
                var,kind,spec=field
                try: var.set(str(value))
                except tk.TclError: pass

    def _sync_quick_tuning_from_params(self):
        params=self.detector_params.get("RAW Laplacian V1",{})
        try:
            self.quick_sensitivity.set(float(params.get("k",2.8)))
            self.quick_min_magnitude.set(float(params.get("min_magnitude",18.0)))
            self.quick_min_area.set(float(params.get("min_area_px",20)))
            self.quick_box_padding.set(float(params.get("box_expand_ratio",.75))*100.0)
            self._quick_tuning_changed()
        except (ValueError,tk.TclError):
            pass

    def _live_detection_toggle(self):
        if not self.live_detection_var.get():
            if self._live_after_id is not None:
                try: self.root.after_cancel(self._live_after_id)
                except tk.TclError: pass
                self._live_after_id=None
            self.status_var.set("LIVE DETECTION STOPPED")
            self._render_preview()
            return
        if self.current_image is None:
            self.live_detection_var.set(False)
            messagebox.showwarning("Live detection","Start the camera before enabling live detection.",parent=self.root)
            return
        if not any(var.get() for var in self.detector_vars.values()):
            self.live_detection_var.set(False)
            messagebox.showwarning("Live detection","Select at least one detector plug-in first.",parent=self.root)
            return
        self._live_result_initialized=False
        self.status_var.set("LIVE DETECTION STARTING…")
        self.log("INFO","Live detection enabled; frames are processed on a worker thread.")
        self._live_after_id=self.root.after(100,self._live_detection_tick)

    def _live_detection_tick(self):
        self._live_after_id=None
        if self.closed or not self.live_detection_var.get(): return
        # Schedule the next pass first. If a pass is still running, this tick simply skips it.
        self._live_after_id=self.root.after(350,self._live_detection_tick)
        if self.current_image is None or any(name in self.busy for name in ("detection","capture","segmentation","workflow_canny","workflow_correction","workflow_segments")): return
        selected_detectors=[n for n,v in self.detector_vars.items() if v.get()]
        if not selected_detectors:
            self.live_detection_var.set(False); self.status_var.set("LIVE DETECTION STOPPED — no detector selected")
            return
        active_detection_roi=any(r.role=="detect" and r.enabled for r in self.roi_controller.rois)
        active_segments=any(var.get() for var in self.segment_vars.values())
        workflow_ready=bool(self.phone_workflow_enabled_var.get())
        if not active_detection_roi and not active_segments and not workflow_ready:
            if self.segmentation_enabled.get() and self.segment_result is None and "segmentation" not in self.busy:
                self.status_var.set("LIVE DETECTION — preparing segmentation…")
                self.run_segmentation()
                return
            self.live_detection_var.set(False)
            self.status_var.set("LIVE DETECTION STOPPED — activate a Detection ROI or segment")
            self.log("WARN","Live detection stopped because no Detection ROI or segmentation region is active.")
            messagebox.showinfo("Live detection","Draw and enable a Detection ROI, or run SEGMENT and tick one or more regions, then enable live detection.",parent=self.root)
            return
        try:
            settings=self._snapshot_detection_settings()
            if not settings["detectors"]: raise ValueError("Select at least one detector plug-in")
            image=self.current_image.copy()
        except Exception as exc:
            self.live_detection_var.set(False); self.status_var.set("LIVE DETECTION STOPPED")
            self.log("ERROR",f"Live detection setup failed: {exc}")
            return
        self.busy.add("detection")
        def worker():
            try:
                working,mask,results,segresult=self._process_image_for_detection(image,settings,live=True)
                combined=self._combine_result_images(working,results)
                self._post_ui(lambda:self._detection_done(combined,working,mask,results,segresult,settings["source_view"],live=True,workflow_details=settings.get("_workflow_generated")))
            except Exception as exc:
                self._post_ui(lambda exc=exc:self._live_detection_error(exc))
            finally:
                self.busy.discard("detection")
        threading.Thread(target=worker,daemon=True,name="live-detection").start()

    def _live_detection_error(self,exc):
        self.log("ERROR",f"Live detection stopped: {exc}")
        self.live_detection_var.set(False)
        if self._live_after_id is not None:
            try: self.root.after_cancel(self._live_after_id)
            except tk.TclError: pass
            self._live_after_id=None
        self.status_var.set("LIVE DETECTION STOPPED — review active ROIs")
        messagebox.showwarning("Live detection",str(exc),parent=self.root)

    def _build_detection_mode_card(self,p):
        ttk.Label(p,text="DETECTION mode uses the saved/current profile settings to capture selected recipes, then inspect each image. Capture + inspect is performed in the worker thread.",style="Card.TLabel",wraplength=260).pack(anchor="w")
        ttk.Button(p,text="CAPTURE + INSPECT SELECTED LIGHTS",command=self.capture_and_inspect,style="Accent.TButton").pack(fill="x",pady=4)
        ttk.Label(p,text="A detected box is a proposal for human review, not an automated certified verdict.",style="Sub.TLabel",wraplength=260).pack(anchor="w")

    def _build_log_card(self,p):
        self.log_text=tk.Text(p,height=10,wrap="word",bg="#10131a",fg="#e5e7eb",font=("Consolas",8),relief="flat")
        self.log_text.pack(fill="both",expand=True); self.log_text.configure(state="disabled")
        ttk.Button(p,text="CLEAR LOG",command=self.clear_log,style="Mini.TButton").pack(anchor="e",pady=(3,0))

    def _refresh_detector_list(self):
        for w in self.detector_list_frame.winfo_children(): w.destroy()
        for name in self.detection_registry.names():
            if name not in self.detector_vars: self.detector_vars[name]=tk.BooleanVar(value=(name=="RAW Laplacian V1")); self.detector_params[name]=self.detection_registry.get(name).create_default()
            ttk.Checkbutton(self.detector_list_frame,text=name,variable=self.detector_vars[name]).pack(anchor="w")
        if hasattr(self,"setting_selector"):
            self.setting_selector.configure(values=self.detection_registry.names())

    def _build_detector_settings(self):
        if not hasattr(self,"detector_settings_frame"): return
        for w in self.detector_settings_frame.winfo_children(): w.destroy()
        name=self.detector_setting_name.get()
        if not name or name not in self.detection_registry.items(): return
        algo=self.detection_registry.get(name); params=self.detector_params.setdefault(name,algo.create_default()); self.detector_setting_vars[name]={}
        for spec in algo.settings():
            key=spec.get("key"); kind=spec.get("kind"); val=params.get(key,"")
            row=ttk.Frame(self.detector_settings_frame,style="Card.TFrame"); row.pack(fill="x",pady=1)
            ttk.Label(row,text=spec.get("label",key),style="Card.TLabel",wraplength=130).pack(side="left",fill="x",expand=True)
            if kind=="bool":
                var=tk.BooleanVar(value=bool(val)); ttk.Checkbutton(row,variable=var).pack(side="right"); self.detector_setting_vars[name][key]=(var,kind,spec)
            elif kind=="choice":
                var=tk.StringVar(value=str(val)); widget=ttk.Combobox(row,textvariable=var,values=[str(x) for x in spec.get("values",[])],state="readonly",width=9); widget.pack(side="right"); self.detector_setting_vars[name][key]=(var,kind,spec)
            elif kind=="file":
                var=tk.StringVar(value=str(val)); entry=ttk.Entry(row,textvariable=var,width=10); entry.pack(side="left",fill="x",expand=True)
                ttk.Button(row,text="…",command=lambda v=var:self._choose_file(v),style="Mini.TButton").pack(side="right"); self.detector_setting_vars[name][key]=(var,kind,spec)
            else:
                var=tk.StringVar(value=str(val)); ttk.Entry(row,textvariable=var,width=10).pack(side="right"); self.detector_setting_vars[name][key]=(var,kind,spec)
        ttk.Button(self.detector_settings_frame,text="APPLY SETTINGS",command=self._read_detector_settings,style="Mini.TButton").pack(anchor="e",pady=2)

    def _choose_file(self,var):
        name=filedialog.askopenfilename(title="Select detector weights",filetypes=[("PyTorch weights","*.pt"),("All files","*.*")])
        if name: var.set(name)

    def _read_detector_settings(self):
        name=self.detector_setting_name.get()
        for key,(var,kind,spec) in self.detector_setting_vars.get(name,{}).items():
            try:
                value=var.get()
                if kind=="bool": value=bool(value)
                elif kind=="int": value=int(float(value))
                elif kind=="float": value=float(value)
                elif kind=="choice":
                    old=self.detector_params[name].get(key)
                    value=type(old)(value) if old is not None and not isinstance(old,str) else value
                self.detector_params[name][key]=value
            except Exception as exc: messagebox.showerror("Invalid setting",f"{key}: {exc}",parent=self.root); return
        if name=="RAW Laplacian V1": self._sync_quick_tuning_from_params()
        self.log("INFO",f"Updated {name} parameters")

    def _rebuild_recipe_rows(self):
        if not hasattr(self,"recipe_frame"): return
        for w in self.recipe_frame.winfo_children(): w.destroy()
        self.recipe_vars=[]; self.recipe_b_vars=[]; self.recipe_selected=[]
        dual=self.topology_var.get().startswith("LIGHT_DUAL_4") or self.topology_var.get().startswith("LIGHT_SINGLE_8")
        head=ttk.Frame(self.recipe_frame,style="Card.TFrame"); head.pack(fill="x")
        for txt,width in [("✓",2),("Name",9),("R",4),("G",4),("B",4)]: ttk.Label(head,text=txt,width=width,style="Sub.TLabel").pack(side="left")
        if dual:
            ttk.Label(head,text="B name",style="Sub.TLabel").pack(side="left",padx=(3,0))
            ttk.Label(head,text="R2 G2 B2",style="Sub.TLabel").pack(side="left",padx=(3,0))
        for i,recipe in enumerate(self.recipes_a[:8]):
            row=ttk.Frame(self.recipe_frame,style="Card.TFrame"); row.pack(fill="x",pady=1)
            ev=tk.BooleanVar(value=recipe.enabled); ttk.Checkbutton(row,variable=ev).pack(side="left"); namev=tk.StringVar(value=recipe.name); ttk.Entry(row,textvariable=namev,width=9).pack(side="left",padx=2)
            av=[]
            for val in recipe.rgb():
                v=tk.StringVar(value=str(val)); ttk.Spinbox(row,from_=0,to=255,textvariable=v,width=4).pack(side="left",padx=1); av.append(v)
            bv=[]; namebv=None
            rb=self.recipes_b[i] if i<len(self.recipes_b) else recipe
            if dual:
                namebv=tk.StringVar(value=rb.name); ttk.Entry(row,textvariable=namebv,width=7).pack(side="left",padx=(3,1))
                for val in rb.rgb():
                    v=tk.StringVar(value=str(val)); ttk.Spinbox(row,from_=0,to=255,textvariable=v,width=3).pack(side="left",padx=1); bv.append(v)
            ttk.Button(row,text="T",command=lambda j=i:self.test_recipe(j),style="Mini.TButton").pack(side="right",padx=(2,0))
            selected=tk.BooleanVar(value=recipe.enabled and rb.enabled); self.recipe_selected.append(selected)
            self.recipe_vars.append({"enabled":ev,"name":namev,"name_b":namebv,"rgb":av,"rgb_b":bv})
        # Explicit capture selector is kept separate from recipe's enabled flag.
        caprow=ttk.Frame(self.recipe_frame,style="Card.TFrame"); caprow.pack(fill="x",pady=(4,0))
        ttk.Label(caprow,text="Capture selected:",style="Card.TLabel").pack(side="left")
        for i,v in enumerate(self.recipe_selected): ttk.Checkbutton(caprow,text=str(i+1),variable=v).pack(side="left")
        self._topology_changed(None, rebuild=False)

    def _topology_changed(self,event=None,rebuild=True):
        val=self.topology_var.get()
        if rebuild and hasattr(self,"recipe_frame") and getattr(self,"recipe_vars",None):
            try: self._refresh_recipe_model()
            except Exception as exc: self.log("WARN",f"Recipe values could not be saved during topology switch: {exc}")
        if val.startswith("LIGHT_SINGLE_8"):
            self.topology_var.set("LIGHT_SINGLE_8")
            self.light_status.set("UNVERIFIED 8-channel framing — simulator recommended")
        if rebuild and hasattr(self,"recipe_frame"): self._rebuild_recipe_rows()

    def _build_dummy(self): pass

    def _refresh_roi_list(self):
        if not hasattr(self,"roi_list_frame"): return
        for w in self.roi_list_frame.winfo_children(): w.destroy()
        rows=[]
        for roi in [self.roi_controller.inspection,self.roi_controller.camera,*self.roi_controller.rois]:
            if roi is not None: rows.append(roi)
        self.roi_summary_var.set(f"{len(rows)} drawn · {sum(1 for r in rows if r.enabled)} active")
        if not rows:
            ttk.Label(self.roi_list_frame,text="No ROIs drawn",style="Sub.TLabel").pack(anchor="w"); return
        for roi in rows:
            row=ttk.Frame(self.roi_list_frame,style="Card.TFrame"); row.pack(fill="x",pady=1)
            var=tk.BooleanVar(value=roi.enabled)
            def toggle(r=roi,v=var): r.enabled=bool(v.get()); self._render_preview()
            ttk.Checkbutton(row,variable=var,command=toggle).pack(side="left")
            name_var=tk.StringVar(value=roi.name)
            name_entry=ttk.Entry(row,textvariable=name_var,width=11)
            name_entry.pack(side="left",fill="x",expand=True,padx=(0,2))
            name_entry.bind("<FocusOut>",lambda e,r=roi,v=name_var:setattr(r,"name",v.get().strip() or r.name))
            ttk.Label(row,text=roi.role.upper(),style="Sub.TLabel").pack(side="left",padx=2)
            if roi.shape.kind.lower() in ("rounded_rectangle","rounded rectangle","rounded"):
                radius_var=tk.StringVar(value=str(int(roi.shape.radius)))
                spin=ttk.Spinbox(row,from_=1,to=100,textvariable=radius_var,width=3)
                spin.pack(side="right")
                def update_radius(e=None,r=roi,v=radius_var):
                    try: r.shape.radius=max(1,int(float(v.get())))
                    except Exception: pass
                    self._render_preview()
                spin.bind("<FocusOut>",update_radius); spin.bind("<Return>",update_radius)
            if roi.role not in ("inspection","camera"):
                ttk.Button(row,text="×",style="Mini.TButton",command=lambda rid=roi.id:self.delete_roi(rid)).pack(side="right")

    def _refresh_segment_list(self):
        for w in self.segment_list_frame.winfo_children(): w.destroy()
        if not self.segment_result:
            ttk.Label(self.segment_list_frame,text="Run segmentation to create region masks",style="Sub.TLabel",wraplength=260).pack(anchor="w"); return
        for seg in self.segment_result.segments:
            var=self.segment_vars.setdefault(seg.id,tk.BooleanVar(value=(seg.id in (1,3,4))))
            ttk.Checkbutton(self.segment_list_frame,text=f"{seg.id}. {seg.name} ({seg.area_px:,} px)",variable=var).pack(anchor="w")

    def _refresh_recipe_model(self):
        # Copy live controls into recipe dataclasses before any operation.
        for i,row in enumerate(self.recipe_vars):
            if i>=len(self.recipes_a): continue
            try:
                self.recipes_a[i]=Recipe(bool(row["enabled"].get()),row["name"].get().strip() or f"Light{i+1}",*[max(0,min(255,int(float(v.get())))) for v in row["rgb"]])
                if row["rgb_b"]:
                    while len(self.recipes_b)<=i: self.recipes_b.append(Recipe(**self.recipes_a[i].__dict__))
                    bname=(row["name_b"].get().strip() if row.get("name_b") is not None else self.recipes_a[i].name) or f"Light{i+1}"
                    self.recipes_b[i]=Recipe(self.recipes_a[i].enabled,bname,*[max(0,min(255,int(float(v.get())))) for v in row["rgb_b"]])
                elif i>=len(self.recipes_b): self.recipes_b.append(Recipe(**self.recipes_a[i].__dict__))
                if i<len(self.recipe_selected): self.recipe_selected[i].set(bool(self.recipe_selected[i].get()) and self.recipes_a[i].enabled)
            except Exception as exc: raise ValueError(f"Invalid recipe row {i+1}: {exc}") from exc

    def add_recipe(self):
        if len(self.recipes_a)>=8: return messagebox.showinfo("Recipes","Maximum is 8 recipes",parent=self.root)
        n=len(self.recipes_a)+1; self.recipes_a.append(Recipe(True,f"Light{n}",255,255,255)); self.recipes_b.append(Recipe(True,f"Light{n}",255,255,255)); self._rebuild_recipe_rows()
    def remove_recipe(self):
        if len(self.recipes_a)<=1: return messagebox.showinfo("Recipes","At least one recipe is required",parent=self.root)
        self.recipes_a.pop(); self.recipes_b.pop(); self._rebuild_recipe_rows()

    def _mode_changed(self,event=None):
        # Testing and Detection modes share the same staged inspection workflow.
        # Keep all camera, processing, ROI, and detector options visible in either mode.
        for card in self.cards.values():
            card.pack_forget(); card.pack(fill="x",pady=(0,7))
        self.log("INFO",f"Mode switched to {self.mode_var.get()}")

    def set_model(self):
        model=self.model_var.get().strip()
        if not model: return messagebox.showwarning("Model required","Enter a model name before capture/profile operations.",parent=self.root)
        self.model_var.set(model)
        if hasattr(self,"capture_folder_var"): self.capture_folder_var.set(f"captures/{safe_name(model)}/setN/")
        self.status_var.set(f"MODEL: {model}"); self.log("INFO",f"Model set to {model}")

    def _source_changed(self,event=None):
        new_signature=(self.preview_source.get(),self.stitch_mode.get())
        if new_signature==self._last_source_signature: return
        has_geometry=bool(self.workflow_frame is not None or self.roi_controller.inspection or self.roi_controller.camera or self.roi_controller.rois or self.segment_result)
        if has_geometry:
            if not messagebox.askyesno("Clear ROIs?","Changing view/stitch coordinates can invalidate ROIs and segment masks. Clear them and continue?",parent=self.root):
                self.preview_source.set(self._last_source_signature[0]); self.stitch_mode.set(self._last_source_signature[1]); return
            self.clear_rois()
        else:
            self.segment_result=None; self.segment_vars.clear(); self._refresh_segment_list()
        self._last_source_signature=new_signature
        self.workflow_frozen=False; self.workflow_frame=None; self.workflow_outputs={}; self.workflow_selected_image=None; self.workflow_selected_method=None
        self.workflow_use_selected_var.set(False); self.workflow_phone_edges=None; self.workflow_phone_mask=None
        self.workflow_edge_mask=None; self.workflow_backglass_mask=None; self.workflow_segment_overlay=None
        self.calibration_line=None; self.calibration_distance_px=None; self.calibration_distance_mm=None
        # A new camera/view must always begin at the image origin, not at a stale scroll offset.
        try: self.viewer_canvas.xview_moveto(0); self.viewer_canvas.yview_moveto(0)
        except Exception: pass
        # Source dimensions and aspect ratios can change radically (single camera vs stitched).
        # Always return to FIT so the new full frame is visible instead of carrying an old zoom.
        self._zoom=1.0
        self.config.preview_source=self.preview_source.get(); self.config.stitch_mode=self.stitch_mode.get(); self._render_preview()

    def start_cameras(self):
        if "camera_start" in self.busy: return
        self.busy.add("camera_start"); self.status_var.set("STARTING CAMERAS…")
        active=(bool(self.camera1_on.get()),bool(self.camera2_on.get()))
        backend_name=self.camera_backend_var.get()
        settings=[copy.deepcopy(self.config.camera1),copy.deepcopy(self.config.camera2)]
        def worker():
            try:
                self.camera_manager.stop()
                if backend_name=="Basler": self.camera_manager.backends=[BaslerCamera(0,self.log),BaslerCamera(1,self.log)]
                else: self.camera_manager.backends=[SimulatedCamera(0,settings[0].width,settings[0].height),SimulatedCamera(1,settings[1].width,settings[1].height)]
                self.camera_manager.start(active,settings); ok=any(self.camera_manager._active)
                self._post_ui(lambda:self._camera_started(ok))
            except Exception as exc: self._post_ui(lambda exc=exc:self._async_error("Camera start",exc))
            finally: self.busy.discard("camera_start")
        threading.Thread(target=worker,daemon=True).start()

    def _camera_started(self,ok):
        self.camera_running=ok; self.status_var.set("CAMERAS RUNNING" if ok else "CAMERA START FAILED")
        if ok: self.log("INFO","Camera backends started")
        else: messagebox.showerror("Camera","Neither selected camera started. See System Log.",parent=self.root)

    def stop_cameras(self):
        threading.Thread(target=self.camera_manager.stop,daemon=True).start(); self.camera_running=False; self.status_var.set("CAMERAS STOPPED"); self.log("INFO","Camera stop requested")

    def apply_camera_settings(self):
        try:
            idx=0 if self.setting_camera.get()=="Camera 1" else 1
            s= self.config.camera1 if idx==0 else self.config.camera2
            s.exposure_us=float(self.exposure_var.get()); s.gain=float(self.gain_var.get()); s.fps=float(self.fps_var.get()); s.width=int(self.width_var.get()); s.height=int(self.height_var.get()); s.full_sensor=bool(self.full_sensor_var.get())
            if min(s.fps,s.width,s.height)<=0: raise ValueError("FPS and image size must be positive")
            self.camera_manager.apply_settings(idx,s); save_config(self.config); self.log("INFO",f"Applied Camera {idx+1} settings")
        except Exception as exc: messagebox.showerror("Camera settings",str(exc),parent=self.root)

    def _load_camera_settings_ui(self,event=None):
        settings=self.config.camera1 if self.setting_camera.get()=="Camera 1" else self.config.camera2
        self.exposure_var.set(str(settings.exposure_us)); self.gain_var.set(str(settings.gain)); self.fps_var.set(str(settings.fps)); self.width_var.set(str(settings.width)); self.height_var.set(str(settings.height)); self.full_sensor_var.set(bool(getattr(settings,"full_sensor",True)))

    def _display_settings_for_camera(self,event=None): pass

    def connect_lights(self):
        if self.busy.intersection({"light_connect"}): return
        try:
            self._refresh_recipe_model(); settle=max(0,int(self.settle_var.get()))
            topology=self.topology_var.get().replace(" (UNVERIFIED)","")
            port_a=self.port_a_var.get().strip() or "SIMULATOR"; port_b=self.port_b_var.get().strip() or "SIMULATOR"
            if topology=="LIGHT_SINGLE_8" and port_a.upper()!="SIMULATOR":
                if not messagebox.askyesno("Unconfirmed protocol","The real 8-channel frame is unconfirmed. Continue only if you have independently verified your controller protocol.",parent=self.root): return
        except Exception as exc: return messagebox.showerror("Lighting",str(exc),parent=self.root)
        def worker():
            try:
                if self.lighting_engine:
                    self.lighting_engine.all_off(); self.lighting_engine.disconnect()
                engine=build_engine(topology,(port_a,port_b),9600,self.log,settle)
                engine.connect(port_a,port_b,9600)
                self.lighting_engine=engine
                self._post_ui(lambda:self.light_status.set(f"Connected: {topology}"+(" — UNCONFIRMED" if topology=="LIGHT_SINGLE_8" else "")))
                self.log("INFO",f"Lighting engine connected: {topology}")
            except Exception as exc: self._post_ui(lambda exc=exc:self._async_error("Light connect",exc))
        threading.Thread(target=worker,daemon=True).start()

    def _ensure_lights(self):
        if not self.lighting_engine or not self.lighting_engine.controller_a.is_open: raise RuntimeError("Connect the lighting controller first (SIMULATOR is available)")
        return self.lighting_engine

    def lights_ready(self):
        def worker():
            try: self._ensure_lights().apply_pair((255,255,255),(255,255,255)); self._post_ui(lambda:self.light_status.set("READY — white applied"))
            except Exception as exc: self._post_ui(lambda exc=exc:self._async_error("Lighting READY",exc))
        threading.Thread(target=worker,daemon=True).start()
    def lights_off(self):
        try:
            if self.lighting_engine: self.lighting_engine.all_off(); self.light_status.set("All lights OFF"); self.log("INFO","Lights switched off")
        except Exception as exc: self.log("ERROR",f"ALL OFF: {exc}")

    def test_recipe(self,index):
        try:
            self._refresh_recipe_model(); engine=self._ensure_lights(); a=self.recipes_a[index]; b=self.recipes_b[index] if index<len(self.recipes_b) else a
        except Exception as exc: return messagebox.showerror("Recipe",str(exc),parent=self.root)
        def worker():
            try: engine.apply_pair(a.rgb(),b.rgb()); self.log("INFO",f"Tested recipe {a.name}")
            except Exception as exc: self._post_ui(lambda exc=exc:self._async_error("Recipe test",exc))
        threading.Thread(target=worker,daemon=True).start()

    def _invalidate_workflow_after_roi_change(self, reason="ROI geometry changed", invalidate_phone=False):
        source=self._workflow_source_image()
        self.workflow_outputs={"Original":source.copy()} if source is not None else {}
        self.workflow_selected_image=None; self.workflow_selected_method=None
        self.workflow_edge_mask=None; self.workflow_backglass_mask=None; self.workflow_segment_overlay=None
        if invalidate_phone:
            self.workflow_phone_mask=None; self.workflow_phone_edges=None
        self.workflow_status_var.set(f"{reason}. Detection will rebuild phone and region masks using the updated geometry.")

    def add_roi_shape(self,role,x1,y1,x2,y2):
        kind=self.shape_var.get().lower()
        if kind=="circle / ellipse": kind="ellipse"
        elif kind=="rounded rectangle": kind="rounded_rectangle"
        elif kind=="capsule / stadium": kind="capsule"
        elif kind=="free shape": kind="free"
        if kind=="free": return
        radius=max(2,min(24,abs(x2-x1)//5,abs(y2-y1)//5))
        shape=ROIShape(kind,bbox=(x1,y1,x2,y2),radius=radius)
        if role=="inspection": self.roi_controller.inspection=self.roi_controller.make_roi("Inspection ROI","inspection",shape)
        elif role=="camera": self.roi_controller.camera=self.roi_controller.make_roi("Camera ROI","camera",shape)
        else: self.roi_controller.rois.append(self.roi_controller.make_roi(f"{role.title()} ROI {len(self.roi_controller.rois)+1}",role,shape))
        self._invalidate_workflow_after_roi_change(f"{role.title()} ROI added", invalidate_phone=(role=="inspection"))
        self._roi_display_cache.clear()
        self._refresh_roi_list(); self._render_preview(); self.log("INFO",f"Drew {role} {kind} in source pixels")

    def _canvas_to_image(self,event):
        if self.current_image is None or self._render_scale<=0: return (0,0)
        x=self.viewer_canvas.canvasx(event.x)/self._render_scale; y=self.viewer_canvas.canvasy(event.y)/self._render_scale
        h,w=self.current_image.shape[:2]
        return (int(np.clip(round(x),0,w-1)),int(np.clip(round(y),0,h-1)))

    def _mouse_down(self,event):
        self._mouse_motion(event)
        tool=self.draw_tool.get()
        if tool=="Navigate": return
        point=self._canvas_to_image(event)
        if tool=="Free Shape":
            self.roi_controller.current_role="mask" if self.role_var.get()=="Mask ROI" else "detect"
            self.roi_controller.current_shape="free"; self.roi_controller.free_points.append(point); self._render_preview(); return
        if tool=="Calibrate Scale":
            self.calibration_points.append(point)
            if len(self.calibration_points)>=2: self._finish_calibration()
            return
        self.draw_start=point; self.draw_current=point

    def _mouse_drag(self,event):
        self._mouse_motion(event)
        if self.draw_start is not None: self.draw_current=self._canvas_to_image(event); self._render_preview()

    def _mouse_up(self,event):
        if self.draw_start is None: return
        end=self._canvas_to_image(event); start=self.draw_start; self.draw_start=None; self.draw_current=None
        x1,y1=start; x2,y2=end
        if abs(x2-x1)<2 or abs(y2-y1)<2: self._render_preview(); return
        tool=self.draw_tool.get()
        role={"Inspection ROI":"inspection","Camera ROI":"camera","Detection ROI":"detect","Mask ROI":"mask"}.get(tool)
        if role: self.add_roi_shape(role,x1,y1,x2,y2)

    def _mouse_motion(self,event):
        if self.loupe_enabled.get() and self.current_image is not None: self._update_loupe(event)

    def _viewer_wheel(self,event):
        if event.delta>0: self.zoom_by(1.1)
        elif event.delta<0: self.zoom_by(.9)
        return "break"

    def _escape(self,event=None):
        self.cancel_tool()
    def _enter(self,event=None):
        if self.draw_tool.get()=="Free Shape": self.finish_free_shape()
    def undo_free_point(self):
        if self.roi_controller.free_points: self.roi_controller.free_points.pop(); self._render_preview()
    def finish_free_shape(self):
        if self.roi_controller.finish_free(): self._refresh_roi_list(); self._render_preview(); self.log("INFO","Finished free-shape ROI")
        else: messagebox.showinfo("Free shape","A free ROI needs at least three vertices.",parent=self.root)
    def cancel_tool(self): self.draw_start=None; self.draw_current=None; self.roi_controller.free_points.clear(); self.calibration_points.clear(); self._render_preview()

    def delete_roi(self,rid):
        target=next((r for r in [self.roi_controller.inspection,self.roi_controller.camera,*self.roi_controller.rois] if r and r.id==rid),None)
        self.roi_controller.delete(rid)
        self._invalidate_workflow_after_roi_change("ROI deleted", invalidate_phone=bool(target and target.role=="inspection"))
        self._roi_display_cache.clear(); self._roi_render_cache.clear(); self._refresh_roi_list(); self._render_preview()
    def clear_rois(self):
        self.roi_controller.clear(); self.segment_result=None; self.segment_vars.clear()
        self._invalidate_workflow_after_roi_change("ROIs cleared", invalidate_phone=True)
        self._roi_display_cache.clear(); self._roi_render_cache.clear(); self._segment_render_cache.clear(); self._refresh_roi_list(); self._refresh_segment_list(); self._render_preview()
    def set_all_rois(self,enabled):
        for r in [self.roi_controller.inspection,self.roi_controller.camera,*self.roi_controller.rois]:
            if r: r.enabled=enabled
        self._invalidate_workflow_after_roi_change("ROI enabled states changed", invalidate_phone=True)
        self._roi_display_cache.clear(); self._roi_render_cache.clear(); self._refresh_roi_list(); self._render_preview()

    def _active_roi(self,role):
        if role=="inspection": return self.roi_controller.inspection
        if role=="camera": return self.roi_controller.camera
        return None

    def _get_preview_image(self, pair=None):
        """Return the selected source frame without copying immutable camera-owned arrays."""
        pair = pair or self.camera_manager.latest(self.stitch_mode.get())
        self.last_pair = pair
        src = self.preview_source.get()
        if src == "Camera 1":
            return pair.camera1.image if pair.camera1 else None
        if src == "Camera 2":
            return pair.camera2.image if pair.camera2 else None
        return pair.stitched(self.stitch_mode.get())

    @staticmethod
    def _frame_signature(pair, source, stitch_mode):
        t1 = pair.camera1.timestamp if pair.camera1 is not None else None
        t2 = pair.camera2.timestamp if pair.camera2 is not None else None
        if source == "Camera 1":
            times = (t1,)
        elif source == "Camera 2":
            times = (t2,)
        else:
            times = (t1, t2)
        return source, stitch_mode, times

    def _tick(self):
        """Lightweight heartbeat; new frames are handed to workers without blocking Tk."""
        if self.closed:
            return
        try:
            if not self.workflow_frozen:
                pair = self.camera_manager.latest(self.stitch_mode.get())
                self.last_pair = pair
                source = self.preview_source.get()
                mode = self.stitch_mode.get()
                signature = self._frame_signature(pair, source, mode)
                if signature != self._last_preview_frame_signature:
                    self._last_preview_frame_signature = signature
                    if source == "Stitched":
                        self._queue_stitch_preview(pair, source, mode, signature)
                    else:
                        image = self._get_preview_image(pair)
                        self._accept_preview_image(image)
        except Exception as exc:
            self.log("WARN", f"Preview update: {exc}")
        self._preview_after_id = self.root.after(30, self._tick)

    def _accept_preview_image(self, image):
        """Update viewer state on the Tk thread after camera selection/stitching."""
        if image is None or self.closed or self.workflow_frozen:
            return
        frame_shape = tuple(image.shape[:2])
        if self.current_source_shape is None:
            self.log("INFO", f"Preview frame received: {frame_shape[1]} x {frame_shape[0]} pixels ({self.preview_source.get()})")
            self._zoom = 1.0
            try:
                self.viewer_canvas.xview_moveto(0); self.viewer_canvas.yview_moveto(0)
            except Exception:
                pass
        elif frame_shape != tuple(self.current_source_shape):
            self.log("WARN", f"Source frame size changed to {frame_shape[1]} x {frame_shape[0]} pixels. Clear/recreate ROIs before using them.")
            self._zoom = 1.0
            try:
                self.viewer_canvas.xview_moveto(0); self.viewer_canvas.yview_moveto(0)
            except Exception:
                pass
        # Camera workers publish fresh arrays. Keep the immutable reference instead of copying megapixel data here.
        self.current_image = image
        self.current_source_shape = image.shape[:2]
        self._render_preview()

    def _queue_stitch_preview(self, pair, source, mode, signature):
        self._stitch_generation += 1
        job = (self._stitch_generation, pair, source, mode, signature)
        with self._stitch_lock:
            self._stitch_latest = job
            if not self._stitch_active:
                self._stitch_active = True
                threading.Thread(target=self._stitch_preview_loop, daemon=True, name="stitch-preview").start()

    def _stitch_preview_loop(self):
        """A single latest-only stitch worker avoids UI freezes and stitch backlogs."""
        while True:
            with self._stitch_lock:
                job = self._stitch_latest
                self._stitch_latest = None
                if job is None:
                    self._stitch_active = False
                    return
            generation, pair, source, mode, signature = job
            try:
                image = pair.stitched(mode)
                self._post_ui(lambda generation=generation, image=image, source=source, mode=mode, signature=signature: self._accept_stitched_preview(generation, image, source, mode, signature))
            except Exception as exc:
                self.log("WARN", f"Stitch preview worker: {exc}")

    def _accept_stitched_preview(self, generation, image, source, mode, signature):
        if self.closed or self.workflow_frozen:
            return
        if source != self.preview_source.get() or mode != self.stitch_mode.get():
            return
        if generation < self._stitch_displayed_generation:
            return
        self._stitch_displayed_generation = generation
        self._accept_preview_image(image)

    @staticmethod
    def _roi_shape_signature(roi, image_shape):
        shape = roi.shape
        bbox = tuple(shape.bbox) if shape.bbox is not None else None
        points = tuple(tuple(p) for p in (shape.points or []))
        bends = tuple(tuple(p) if p is not None else None for p in (shape.bends or []))
        return (tuple(image_shape[:2]), roi.id, roi.role, bbox, points, bends, float(shape.radius), shape.kind)

    def _roi_render_data(self, roi, image_shape):
        key = self._roi_shape_signature(roi, image_shape)
        item = self._roi_render_cache.get(key)
        if item is None:
            mask = rasterize_shape(roi.shape, image_shape)
            contours, _ = cv2.findContours(mask.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            ys, xs = np.where(mask > 0)
            bounds = (int(xs.min()), int(ys.min()), int(xs.max()) + 1, int(ys.max()) + 1) if len(xs) else (0, 0, 0, 0)
            item = (mask, contours, bounds)
            if len(self._roi_render_cache) > 160:
                self._roi_render_cache.clear()
            self._roi_render_cache[key] = item
        return item

    def _overlay_image(self, image, render_state):
        """Compose overlays on a worker thread; Tk variables/widgets are not accessed here."""
        out = image.copy()
        h, w = image.shape[:2]
        for roi in render_state["rois"]:
            if roi is None:
                continue
            try:
                mask, contours, bounds = self._roi_render_data(roi, image.shape)
            except Exception:
                continue
            color = tuple(int(roi.color.lstrip("#")[i:i+2], 16) for i in (4, 2, 0)) if roi.color.startswith("#") else (0, 255, 255)
            if not roi.enabled:
                color = (135, 135, 135)
            cv2.drawContours(out, contours, -1, color, 2, cv2.LINE_AA)
            if roi.role == "mask" and roi.enabled:
                # Limited diagonal hatch only inside the mask bbox, not a full-frame blend.
                x1, y1, x2, y2 = bounds
                x1, y1, x2, y2 = max(0,x1), max(0,y1), min(w,x2), min(h,y2)
                if x2 > x1 and y2 > y1:
                    roi_part = mask[y1:y2, x1:x2] > 0
                    hatch = np.zeros((y2-y1, x2-x1), np.uint8)
                    step = 12
                    for yy in range(-hatch.shape[1], hatch.shape[0] + hatch.shape[1], step):
                        cv2.line(hatch, (0, yy), (hatch.shape[1]-1, yy-hatch.shape[1]), 255, 1)
                    use = roi_part & (hatch > 0)
                    if np.any(use):
                        patch = out[y1:y2, x1:x2]
                        px = patch[use].astype(np.uint16)
                        tint = np.array((0, 0, 220), dtype=np.uint16)
                        patch[use] = ((px * 3 + tint) // 4).astype(np.uint8)

        colors = {1:(50,190,90), 2:(230,100,50), 3:(20,200,235), 4:(160,90,180)}
        for sid, seg_mask in render_state["selected_segments"]:
            cache_key = (id(seg_mask), tuple(seg_mask.shape))
            cnt = self._segment_render_cache.get(cache_key)
            if cnt is None:
                cnt, _ = cv2.findContours(seg_mask.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
                if len(self._segment_render_cache) > 32:
                    self._segment_render_cache.clear()
                self._segment_render_cache[cache_key] = cnt
            cv2.drawContours(out, cnt, -1, colors.get(sid, (100,200,200)), 1)

        if render_state["draw_start"] and render_state["draw_current"]:
            kind = render_state["shape_kind"]
            if "capsule" in kind or "stadium" in kind:
                try:
                    temp = rasterize_shape(ROIShape("capsule", bbox=(*render_state["draw_start"], *render_state["draw_current"])), image.shape)
                    cs, _ = cv2.findContours(temp, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
                    cv2.drawContours(out, cs, -1, (0,255,255), 2)
                except Exception:
                    cv2.rectangle(out, render_state["draw_start"], render_state["draw_current"], (0,255,255), 2)
            else:
                cv2.rectangle(out, render_state["draw_start"], render_state["draw_current"], (0,255,255), 2)

        if render_state["calibration_line"] is not None:
            a, b = render_state["calibration_line"]
            cv2.line(out, a, b, (255,255,0), 2, cv2.LINE_AA)
            cv2.circle(out, a, 4, (255,255,0), -1); cv2.circle(out, b, 4, (255,255,0), -1)
            length = f"{render_state['calibration_distance_px']:.1f}px" if render_state["calibration_distance_px"] is not None else "line"
            if render_state["calibration_distance_mm"] is not None:
                length += f" = {render_state['calibration_distance_mm']:.3f}mm"
            cv2.putText(out, length, (min(a[0],b[0])+5, max(20,min(a[1],b[1])-8)), cv2.FONT_HERSHEY_SIMPLEX, .6, (255,255,0), 2, cv2.LINE_AA)

        if render_state["free_points"]:
            pts = np.array(render_state["free_points"], np.int32).reshape((-1,1,2))
            cv2.polylines(out, [pts], False, (0,255,255), 2)
            for x, y in render_state["free_points"]:
                cv2.circle(out, (int(x),int(y)), 4, (0,255,255), -1)
        if render_state["live_enabled"]:
            for result in render_state["live_results"]:
                for defect in result.defects:
                    cv2.rectangle(out, (defect.x, defect.y), (defect.x+defect.w-1, defect.y+defect.h-1), (0,0,255), 3)
                    label = defect.label or "DEFECT"
                    cv2.putText(out, label, (defect.x, max(18, defect.y-6)), cv2.FONT_HERSHEY_SIMPLEX, .55, (0,0,255), 2, cv2.LINE_AA)
        return out

    def _render_preview(self):
        """Queue a latest-only image render; expensive overlay/resize work never blocks Tk."""
        if not hasattr(self, "viewer_canvas") or self.closed:
            return
        img = self.current_image
        canvas = self.viewer_canvas
        if img is None:
            self._preview_generation += 1
            self._preview_invalidate_before = self._preview_generation
            if self._canvas_img_id is not None:
                canvas.delete(self._canvas_img_id); self._canvas_img_id = None
            if self._empty_canvas_text_id is None:
                self._empty_canvas_text_id = canvas.create_text(180, 80, text="Start Camera 1 / Camera 2 to view a live image", fill="#cbd5e1", font=("Segoe UI", 12), anchor="nw")
            return
        try:
            if self._empty_canvas_text_id is not None:
                canvas.delete(self._empty_canvas_text_id); self._empty_canvas_text_id = None
            cw = max(200, canvas.winfo_width()-4); ch = max(150, canvas.winfo_height()-4)
            fit = min(cw/max(1,img.shape[1]), ch/max(1,img.shape[0]))
            scale = max(.02, fit*self._zoom); self._render_scale = scale
            dw = max(1, int(img.shape[1]*scale)); dh = max(1, int(img.shape[0]*scale))
            # All GUI state is snapshotted on the main thread before worker rendering.
            rois = [copy.deepcopy(r) if r is not None else None for r in (self.roi_controller.inspection, self.roi_controller.camera, *self.roi_controller.rois)]
            selected_segments = []
            if self.segment_result is not None:
                for seg in self.segment_result.segments:
                    var = self.segment_vars.get(seg.id)
                    if var is not None and bool(var.get()):
                        selected_segments.append((seg.id, seg.mask))
            state = {
                "rois": rois,
                "selected_segments": selected_segments,
                "draw_start": tuple(self.draw_start) if self.draw_start else None,
                "draw_current": tuple(self.draw_current) if self.draw_current else None,
                "shape_kind": str(self.shape_var.get()).lower(),
                "free_points": tuple(tuple(p) for p in self.roi_controller.free_points),
                "calibration_line": tuple(tuple(p) for p in self.calibration_line) if self.calibration_line else None,
                "calibration_distance_px": self.calibration_distance_px,
                "calibration_distance_mm": self.calibration_distance_mm,
                "live_enabled": bool(self.live_detection_var.get()),
                "live_results": list(self.last_detection_results),
            }
            self._preview_generation += 1
            generation = self._preview_generation
            job = (generation, img, state, dw, dh, scale)
            with self._preview_render_lock:
                self._preview_render_latest = job
                if not self._preview_render_active:
                    self._preview_render_active = True
                    threading.Thread(target=self._preview_render_loop, daemon=True, name="preview-render").start()
        except Exception as exc:
            self.log("WARN", f"Viewer scheduling: {exc}")

    def _preview_render_loop(self):
        """One worker and one replaceable pending frame prevent a render backlog."""
        while True:
            with self._preview_render_lock:
                job = self._preview_render_latest
                self._preview_render_latest = None
                if job is None:
                    self._preview_render_active = False
                    return
            generation, image, state, dw, dh, scale = job
            try:
                overlay = self._overlay_image(image, state)
                resized = cv2.resize(overlay, (dw, dh), interpolation=cv2.INTER_NEAREST if scale > 1 else cv2.INTER_AREA)
                rgb = cv2.cvtColor(resized, cv2.COLOR_BGR2RGB)
                self._post_ui(lambda generation=generation, rgb=rgb, dw=dw, dh=dh, scale=scale: self._display_preview(generation, rgb, dw, dh, scale))
            except Exception as exc:
                self.log("WARN", f"Viewer render worker: {exc}")

    def _display_preview(self, generation, rgb, dw, dh, scale):
        """Tk-only display. Do not discard every frame just because a newer frame is queued."""
        if self.closed or generation < self._preview_invalidate_before or generation < self._preview_displayed_generation:
            return
        canvas = self.viewer_canvas
        try:
            self._photo = ImageTk.PhotoImage(Image.fromarray(rgb))
            if self._canvas_img_id is None:
                self._canvas_img_id = canvas.create_image(0, 0, image=self._photo, anchor="nw")
            else:
                canvas.itemconfigure(self._canvas_img_id, image=self._photo)
            scrollregion = (0, 0, dw, dh)
            if scrollregion != self._canvas_scrollregion:
                canvas.configure(scrollregion=scrollregion)
                self._canvas_scrollregion = scrollregion
            self._preview_displayed_generation = generation
            self.zoom_label.configure(text=f"{scale*100:.0f}%")
        except Exception as exc:
            self.log("WARN", f"Viewer display: {exc}")

    def _viewer_resized(self, event=None):
        # Coalesce the many Configure events emitted by dragging the window border.
        if self.closed:
            return
        try:
            if self._resize_render_after_id is not None:
                self.root.after_cancel(self._resize_render_after_id)
            self._resize_render_after_id = self.root.after(65, self._render_preview)
        except Exception:
            self._render_preview()

    def fit_view(self): self._zoom=1.0; self.viewer_canvas.xview_moveto(0); self.viewer_canvas.yview_moveto(0); self._render_preview()
    def zoom_by(self,factor): self._zoom=float(np.clip(self._zoom*factor,.1,8)); self._render_preview()
    def zoom_100(self):
        if self.current_image is not None:
            fit=min(max(200,self.viewer_canvas.winfo_width()-4)/self.current_image.shape[1],max(150,self.viewer_canvas.winfo_height()-4)/self.current_image.shape[0]); self._zoom=1/max(fit,.01); self._render_preview()

    def toggle_loupe(self):
        self.loupe_enabled.set(not self.loupe_enabled.get())
        if self.loupe_enabled.get():
            if self.loupe_window is None or not self.loupe_window.winfo_exists():
                self.loupe_window=tk.Toplevel(self.root); self.loupe_window.overrideredirect(True); self.loupe_window.attributes("-topmost",True)
                self.loupe_label=tk.Label(self.loupe_window,bg="black",bd=1,relief="solid"); self.loupe_label.pack()
            self.loupe_window.deiconify()
        elif self.loupe_window is not None:
            try: self.loupe_window.withdraw()
            except tk.TclError: pass

    def _update_loupe(self,event):
        if not self.loupe_window or not self.loupe_window.winfo_exists(): return
        x,y=self._canvas_to_image(event); h,w=self.current_image.shape[:2]; r=int(np.clip(self.loupe_radius.get(),8,40))
        crop=self.current_image[max(0,y-r):min(h,y+r+1),max(0,x-r):min(w,x+r+1)]
        if crop.size==0: return
        crop=cv2.resize(crop,(288,288),interpolation=cv2.INTER_NEAREST)
        cv2.line(crop,(144,0),(144,287),(255,255,255),1); cv2.line(crop,(0,144),(287,144),(255,255,255),1)
        b,g,rr=map(int,self.current_image[y,x]); mm=self.calibration.get_scale(self.preview_source.get())
        txt=f"x={x} y={y} BGR={b},{g},{rr}"+(f" {2*r*mm:.3f} mm width" if mm else "")
        cv2.rectangle(crop,(2,2),(286,26),(0,0,0),-1); cv2.putText(crop,txt[:48],(5,18),cv2.FONT_HERSHEY_SIMPLEX,.35,(255,255,255),1,cv2.LINE_AA)
        self.loupe_photo=ImageTk.PhotoImage(Image.fromarray(cv2.cvtColor(crop,cv2.COLOR_BGR2RGB))); self.loupe_label.configure(image=self.loupe_photo)
        try: self.loupe_window.geometry(f"+{event.x_root+18}+{event.y_root+18}")
        except tk.TclError: pass

    def start_calibration(self):
        if self.workflow_frame is None or not self.workflow_frozen:
            return messagebox.showwarning("Calibrate scale", "Capture and freeze a frame first so both points are measured on the same image.", parent=self.root)
        self.calibration_points=[]; self.draw_tool.set("Calibrate Scale"); self.status_var.set("CALIBRATE: click two points across a known length")
        messagebox.showinfo("Calibrate scale","Click two points across a known distance on the captured frame, then enter its real length in millimetres.",parent=self.root)
    def _finish_calibration(self):
        a,b=self.calibration_points[:2]; self.calibration_points=[]
        px=float(np.linalg.norm(np.array(a,float)-np.array(b)))
        if px<=0: return
        mm=simpledialog.askfloat("Known reference length","Enter the real distance between the two clicked points (mm):",minvalue=.001,parent=self.root)
        self.calibration_line=(tuple(map(int,a)),tuple(map(int,b))); self.calibration_distance_px=px
        self.calibration_distance_mm=float(mm) if mm else None
        if mm:
            scale=self.calibration.set_scale(self.preview_source.get(),px,mm); self.status_var.set(f"Calibrated {scale:.6f} mm/px")
            self.workflow_scale_label.set(f"Measured {px:.2f}px = {float(mm):.3f}mm · {scale:.6f} mm/px")
            self.log("INFO",f"Scale calibration {self.preview_source.get()}: {scale:.6f} mm/px")
        else:
            self.workflow_scale_label.set(f"Reference line: {px:.2f}px · no physical scale saved")
        self.draw_tool.set("Navigate"); self._render_preview()

    def lock_stitch(self):
        # The aligned-side-by-side transform has no geometric registration to lock; keep the source metadata explicit.
        store=self.calibration.data; store["stitch_locked_source"]={"mode":self.stitch_mode.get(),"source_view":self.preview_source.get(),"note":"Coordinate lock stores source selection only; it does not make stitched pixels metrically accurate."}; self.calibration.save()
        self.log("WARN","Stitch source state saved. Auto-feature homography persistence is not yet implemented; aligned join is not metric calibration.")
        messagebox.showinfo("Stitch lock","Source mode recorded. This does not lock an ORB transform or provide metric calibration.",parent=self.root)

    def _effective_inspection_mask(self,image):
        return rasterize_shape(self.roi_controller.inspection.shape,image.shape) if self.roi_controller.inspection and self.roi_controller.inspection.enabled else np.full(image.shape[:2],255,np.uint8)

    def analyze_current(self):
        if self.current_image is None: return messagebox.showwarning("No image","Start a camera first",parent=self.root)
        if "illumination_analysis" in self.busy: return
        image=self.current_image.copy()
        mask=self._workflow_domain_mask(image) if self.workflow_frozen and self.workflow_frame is not None else self._effective_inspection_mask(image)
        strict=bool(self.strict_channel_var.get())
        rows=self.config.illumination_grid_rows; cols=self.config.illumination_grid_cols; limit=self.config.illumination_range_limit
        self.busy.add("illumination_analysis"); self.illumination_status.set("Analyzing illumination in background…")
        def worker():
            try:
                analysis=analyze_illumination(image,mask,rows,cols,limit,strict)
                hist=histogram_image(image,mask)
                self._post_ui(lambda:self._illumination_analysis_done(analysis,hist))
            except Exception as exc: self._post_ui(lambda exc=exc:self._async_error("Illumination analysis",exc))
            finally: self.busy.discard("illumination_analysis")
        threading.Thread(target=worker,daemon=True,name="illumination-analysis").start()

    def _illumination_analysis_done(self, analysis, hist):
        self.inspection_analysis=analysis
        s=analysis["lab_l"]
        self.illumination_status.set(f"{analysis['verdict']} — LAB-L range {s['range_percent']:.1f}%, CV {s['cv_percent']:.1f}%")
        self._set_panel_image(self.heatmap_tab,analysis["heatmap"]); self._set_panel_image(self.histogram_tab,hist)
        self.log("INFO",f"Illumination {analysis['verdict']}; LAB-L mean={s['mean']:.1f} range={s['range_percent']:.1f}%; per-channel stats available in analysis object")
        channels=analysis["channels"]
        self.log("INFO","Per-channel ranges: "+", ".join(f"{k} {v['range_percent']:.1f}%" for k,v in channels.items()))
        self.results_notebook.select(self.heatmap_tab[0])

    def _set_panel_image(self,tab_tuple,image):
        frame,label=tab_tuple
        try:
            w=max(200,frame.winfo_width()-10); h=max(150,frame.winfo_height()-10)
            if image.ndim==2: rgb=cv2.cvtColor(image,cv2.COLOR_GRAY2RGB)
            else: rgb=cv2.cvtColor(image,cv2.COLOR_BGR2RGB)
            scale=min(w/rgb.shape[1],h/rgb.shape[0]); out=cv2.resize(rgb,(max(1,int(rgb.shape[1]*scale)),max(1,int(rgb.shape[0]*scale))),interpolation=cv2.INTER_AREA)
            photo=ImageTk.PhotoImage(Image.fromarray(out)); self._panel_photos[id(label)]=photo; label.configure(image=photo,text="")
        except Exception as exc: self.log("WARN",f"Could not display result tab: {exc}")

    def run_segmentation(self):
        if self.current_image is None: return messagebox.showwarning("No image","Start cameras first",parent=self.root)
        if "segmentation" in self.busy: return
        self.busy.add("segmentation")
        image=self.current_image.copy(); inspection=copy.deepcopy(self.roi_controller.inspection); camera=copy.deepcopy(self.roi_controller.camera)
        backend_name=self.seg_backend_var.get(); segmentation_params=copy.deepcopy(self.config.segmentation_params)
        correction_enabled=bool(self.correct_var.get()); strength=float(self.correction_strength.get()); highlight=bool(self.highlight_var.get())
        inspection_mask=rasterize_shape(inspection.shape,image.shape) if inspection and inspection.enabled else np.full(image.shape[:2],255,np.uint8)
        def worker():
            try:
                work=correct_illumination(image,inspection_mask,strength,highlight) if correction_enabled else image
                result=self._segment_image(work,inspection,camera,backend_name,segmentation_params)
                self._post_ui(lambda:self._segmentation_done(result))
            except Exception as exc: self._post_ui(lambda exc=exc:self._async_error("Segmentation",exc))
            finally: self.busy.discard("segmentation")
        threading.Thread(target=worker,daemon=True).start()

    def _segment_image(self,image,inspection=None,camera=None,backend_name=None,segmentation_params=None):
        roi_mask=rasterize_shape(inspection.shape,image.shape) if inspection and inspection.enabled else np.full(image.shape[:2],255,np.uint8)
        cam_mask=rasterize_shape(camera.shape,image.shape) if camera and camera.enabled else None
        backend=self.segmentation_backends[backend_name or self.seg_backend_var.get()]
        return backend.segment(image,roi_mask,segmentation_params if segmentation_params is not None else self.config.segmentation_params,cam_mask)

    def _segmentation_done(self,result):
        self.segment_result=result
        for seg in result.segments:
            if seg.id not in self.segment_vars: self.segment_vars[seg.id]=tk.BooleanVar(value=(seg.id in (1,3,4)))
        self.segment_status.set(f"{result.backend}: {len(result.segments)} regions. {result.message}")
        self._refresh_segment_list(); self._set_panel_image(self.segments_tab,result.overlay); self._render_preview(); self.log("INFO",self.segment_status.get())

    def _selected_segments(self,result):
        return [s for s in result.segments if self.segment_vars.get(s.id) and self.segment_vars[s.id].get()]

    def _snapshot_detection_settings(self, detector_names=None):
        # Read Tk variables on the UI thread; workers receive only plain values and copied geometry.
        self._read_detector_settings()
        names=detector_names if detector_names is not None else [n for n,v in self.detector_vars.items() if v.get()]
        detectors=[(n,copy.deepcopy(self.detector_params.get(n,self.detection_registry.get(n).create_default()))) for n in names]
        phone_workflow=bool(self.phone_workflow_enabled_var.get())
        workflow_use=phone_workflow and bool(self.workflow_use_selected_var.get())
        return {
            "inspection":copy.deepcopy(self.roi_controller.inspection),
            "camera":copy.deepcopy(self.roi_controller.camera),
            "rois":copy.deepcopy(self.roi_controller.rois),
            "backend":self.seg_backend_var.get(),
            "segmentation_params":copy.deepcopy(self.config.segmentation_params),
            "segmentation_enabled":bool(self.segmentation_enabled.get()) and not phone_workflow,
            "ticked_segment_ids":[sid for sid,var in self.segment_vars.items() if bool(var.get())],
            "existing_segment_result":copy.deepcopy(self.segment_result) if not phone_workflow else None,
            "correction_enabled":bool(self.correct_var.get()) and not phone_workflow,
            "correction_strength":float(self.correction_strength.get()),
            "highlight_compression":bool(self.highlight_var.get()),
            "workflow_use":workflow_use,
            "phone_workflow_enabled":phone_workflow,
            "phone_width_mm":float(self.phone_width_mm_var.get()),
            "phone_height_mm":float(self.phone_height_mm_var.get()),
            "phone_center_x":float(self.phone_center_x_var.get()),
            "phone_center_y":float(self.phone_center_y_var.get()),
            "phone_frame_width_fraction":float(self.phone_frame_width_var.get())/100.0,
            "phone_color_tolerance":float(self.phone_color_tolerance_var.get()),
            "canny_low":int(self.workflow_canny_low_var.get()),
            "canny_high":int(self.workflow_canny_high_var.get()),
            "edge_width_mm":float(self.workflow_edge_width_mm_var.get()),
            "workflow_corrected":workflow_use,
            "workflow_method":self.workflow_method_var.get(),
            "workflow_strength":float(self.workflow_strength_var.get()),
            "workflow_sigma":float(self.workflow_sigma_var.get()),
            "workflow_flat_field":None if self.workflow_flat_field is None else self.workflow_flat_field.copy(),
            "mode":self.mode_var.get(),
            "source_view":self.preview_source.get(),
            "stitch_mode":self.stitch_mode.get(),
            "calibration":self.calibration.get_scale(self.preview_source.get()),
            "detectors":detectors,
        }

    def _process_image_for_detection(self,image,settings,context_images=None,light=None,live=False):
        """CPU-only processing path. All expensive stages run in a worker thread."""
        inspection=settings["inspection"]; camera=settings["camera"]; rois=settings["rois"]
        insp=rasterize_shape(inspection.shape,image.shape) if inspection and inspection.enabled else np.full(image.shape[:2],255,np.uint8)
        selected_regions=[]
        if settings.get("phone_workflow_enabled", False):
            # Stage 1: dimension- and colour-guided phone detection. The ROI is an
            # inclusion/search domain; exclusion mask pixels never enter stats.
            camera_mask = rasterize_shape(camera.shape,image.shape) if camera and camera.enabled else None
            excludes=np.zeros(image.shape[:2],np.uint8)
            mask_rois=[r for r in rois if r.role=="mask" and r.enabled]
            for roi in mask_rois:
                cv2.bitwise_or(excludes,rasterize_shape(roi.shape,image.shape),dst=excludes)
            if camera_mask is not None:
                cv2.bitwise_or(excludes,camera_mask,dst=excludes)
            edges, phone_mask, phone_overlay, phone_message, bbox = detect_phone_region(
                image, insp, settings["phone_width_mm"], settings["phone_height_mm"],
                settings.get("calibration"), settings["phone_center_x"], settings["phone_center_y"],
                settings["phone_frame_width_fraction"], settings["phone_color_tolerance"],
                settings["canny_low"], settings["canny_high"], exclude_mask=excludes)
            edge_width_mm=max(0.1,float(settings["edge_width_mm"]))
            scale=settings.get("calibration")
            if scale and scale>0:
                edge_width=max(2,int(round(edge_width_mm/float(scale))))
            else:
                inferred_mm_per_px=max(1e-5,float(bbox[2])/max(1.0,float(settings["phone_width_mm"])))
                edge_width=max(2,int(round(edge_width_mm*inferred_mm_per_px)))
            edge_mask,backglass_mask,region_overlay=adaptive_edge_backglass(image,phone_mask,edge_width,camera_mask,excludes)
            valid_backglass=(backglass_mask>0)
            phone_area=max(1,cv2.countNonZero(phone_mask))
            back_area=cv2.countNonZero(backglass_mask)
            if back_area < max(20,int(phone_area*0.02)):
                raise ValueError("Backglass ROI is empty or too small. Check phone dimensions, centre, camera ROI and 1.1 mm edge width.")
            # Stage 2: optional correction. The mask is passed into every estimator;
            # masked pixels are not treated as black and are not used in statistics.
            if settings.get("workflow_corrected",False):
                method=settings["workflow_method"]
                flat_field=settings.get("workflow_flat_field")
                working=correct_image(image,method,backglass_mask,settings["workflow_strength"],settings["workflow_sigma"],flat_field)
            else:
                working=image.copy()
            selected_drois=[r for r in rois if r.role=="detect" and r.enabled]
            # The backglass is the default inspection domain. Explicit Detection ROIs
            # further restrict the domain; all Mask ROIs are excluded at the end.
            from mobile_inspection_app.roi.masks import compose_detection_mask
            final=compose_detection_mask(image.shape,insp,selected_drois,[backglass_mask],mask_rois,True)
            selected_regions=[{"id":1,"name":"Back Glass","mask":backglass_mask}]
            settings["_workflow_generated"]={
                "phone_edges":edges,"phone_mask":phone_mask,"phone_overlay":phone_overlay,
                "edge_mask":edge_mask,"backglass_mask":backglass_mask,"region_overlay":region_overlay,
                "exclusion_mask":excludes.copy(),
                "bbox":bbox,"edge_width_px":edge_width,"message":phone_message,
                "corrected_image":working.copy() if settings.get("workflow_corrected",False) else None,
                "method":settings.get("workflow_method") if settings.get("workflow_corrected",False) else None,
            }
            segresult=None
        else:
            working=correct_illumination(image,insp,settings["correction_strength"],settings["highlight_compression"]) if settings["correction_enabled"] else image.copy()
            segresult=None
            if settings["segmentation_enabled"]:
                segresult=self._segment_image(working,inspection,camera,settings["backend"],settings["segmentation_params"])
            elif settings.get("existing_segment_result") is not None:
                segresult=settings["existing_segment_result"]
            selected=[s for s in (segresult.segments if segresult else []) if s.id in settings["ticked_segment_ids"]]
            from mobile_inspection_app.roi.masks import compose_detection_mask
            selected_drois=[r for r in rois if r.role=="detect" and r.enabled]
            selected_mrois=[r for r in rois if r.role=="mask" and r.enabled]
            selected_masks=[s.mask for s in selected]
            final=compose_detection_mask(image.shape,insp,selected_drois,selected_masks,selected_mrois,True)
            selected_regions=[{"id":s.id,"name":s.name,"mask":s.mask} for s in selected]

        results=[]
        detector_image=working
        generated=settings.get("_workflow_generated")
        if generated and generated.get("exclusion_mask") is not None and cv2.countNonZero(generated["exclusion_mask"]):
            # Fill excluded user/camera ROIs only in the analysis copy so filter
            # neighborhoods never consume the excluded surface pixels. The actual
            # display/correction image remains unchanged there and final detection
            # masks also omit those pixels.
            detector_image=cv2.inpaint(working,generated["exclusion_mask"],3,cv2.INPAINT_TELEA)
        for name,params in settings["detectors"]:
            algo=self.detection_registry.get(name)
            ctx={"params":params,"selected_regions":selected_regions,"roi_shapes":rois,"mode":settings["mode"],"live":bool(live),"light":light,"calibration":{"mm_per_px":settings["calibration"]} if settings["calibration"] else None}
            if algo.multi_image: ctx["images"]=context_images or {}
            results.append(algo.process(detector_image,final,ctx))
        return working,final,results,segresult

    @staticmethod
    def _combine_result_images(image,results):
        combined=image.copy(); palette=[(0,0,255),(0,180,255),(255,80,0),(200,0,200)]
        for i,res in enumerate(results):
            color=palette[i%len(palette)]
            for b in res.defects:
                cv2.rectangle(combined,(b.x,b.y),(b.x+b.w-1,b.y+b.h-1),color,3)
                # Algorithm names belong in the Defects table; the image overlay should identify the defect.
                label=b.label if getattr(b,"label","") else "DEFECT"
                cv2.putText(combined,label,(b.x,max(18,b.y-6)),cv2.FONT_HERSHEY_SIMPLEX,.55,color,2,cv2.LINE_AA)
        if not any(r.defects for r in results): cv2.putText(combined,"NO DEFECTS FLAGGED",(18,32),cv2.FONT_HERSHEY_SIMPLEX,.7,(40,180,40),2)
        return combined

    def perform_detection(self):
        if self.current_image is None: return messagebox.showwarning("No image","Start cameras first",parent=self.root)
        if any(name in self.busy for name in ("workflow_canny","workflow_correction","workflow_segments")):
            return messagebox.showinfo("Workflow busy", "Wait for the current image-processing stage to finish before detection.", parent=self.root)
        if "detection" in self.busy: return
        try:
            settings=self._snapshot_detection_settings()
            if not settings["detectors"]: raise ValueError("Select at least one detector plugin")
            # current_image is frozen after manual capture and otherwise tracks live view.
            image=self.current_image.copy()
        except Exception as exc: return messagebox.showerror("Detection",str(exc),parent=self.root)
        self.busy.add("detection"); self.perform_btn.configure(state="disabled",text="DETECTING…"); self.status_var.set("DETECTION RUNNING…")
        self.workflow_status_var.set("Preparing phone/backglass ROI and running the selected detector in a worker thread…")
        def worker():
            try:
                working,mask,results,segresult=self._process_image_for_detection(image,settings)
                combined=self._combine_result_images(working,results)
                details=settings.get("_workflow_generated")
                self._post_ui(lambda:self._detection_done(combined,working,mask,results,segresult,settings["source_view"],workflow_details=details))
            except Exception as exc: self._post_ui(lambda exc=exc:self._async_error("Detection",exc))
            finally:
                self.busy.discard("detection")
                self._post_ui(lambda:self.perform_btn.configure(state="normal",text="PERFORM DETECTION"))
        threading.Thread(target=worker,daemon=True,name="manual-detection-worker").start()

    def _detection_done(self,combined,working,mask,results,segresult,source_view=None,live=False,workflow_details=None):
        had_live_result=self._live_result_initialized
        self.last_detection_results=results; self.last_detection_mask=mask; self.last_corrected=working; self.last_combined_image=combined.copy(); self.segment_result=segresult
        if workflow_details:
            self.workflow_phone_edges=workflow_details.get("phone_edges")
            self.workflow_phone_mask=workflow_details.get("phone_mask")
            self.workflow_edge_mask=workflow_details.get("edge_mask")
            self.workflow_backglass_mask=workflow_details.get("backglass_mask")
            self.workflow_segment_overlay=workflow_details.get("region_overlay")
            phone_overlay=workflow_details.get("phone_overlay")
            region_overlay=workflow_details.get("region_overlay")
            if phone_overlay is not None: self._set_panel_image(self.workflow_canny_tab,phone_overlay)
            if region_overlay is not None: self._set_panel_image(self.workflow_segments_tab,region_overlay)
            corrected=workflow_details.get("corrected_image")
            method=workflow_details.get("method")
            if corrected is not None and method:
                self.workflow_outputs[method]=corrected.copy()
                self.workflow_selected_image=corrected.copy(); self.workflow_selected_method=method
                self._set_panel_image(self.workflow_corrected_tab,corrected)
            note=workflow_details.get("message", "Phone region and backglass ROIs rebuilt")
            self.workflow_status_var.set(f"Detection ROI prepared: {note}; edge≈{workflow_details.get('edge_width_px', 0)}px; backglass={cv2.countNonZero(self.workflow_backglass_mask):,} px")
        self._set_panel_image(self.result_tab,combined); self._set_panel_image(self.mask_tab,mask)
        if not live or not had_live_result: self.results_notebook.select(self.result_tab[0])
        self._live_result_initialized=True
        self.defects_tree.delete(*self.defects_tree.get_children())
        for result in results:
            for b in result.defects:
                scale=self.calibration.get_scale(source_view or self.preview_source.get()); size=f"{max(b.w,b.h)*scale:.3f} mm" if scale else f"{max(b.w,b.h)} px"
                self.defects_tree.insert("","end",values=(result.algorithm,b.label,b.x,b.y,b.w,b.h,b.area_px,size))
            if not live: self.log("INFO",f"{result.algorithm}: {result.message} score={result.score:.6f}")
        count=sum(len(r.defects) for r in results)
        self.status_var.set(("LIVE DETECTION" if live and self.live_detection_var.get() else "DETECTION COMPLETE")+f" — {count} candidate(s)")
        if not results: self.log("WARN","No detector results returned")
        self._render_preview()

    def _async_error(self,title,exc):
        self.log("ERROR",f"{title}: {exc}")
        try: messagebox.showerror(title,str(exc),parent=self.root)
        except tk.TclError: pass

    def capture_selected(self):
        if not self.model_var.get().strip(): return messagebox.showwarning("Model required","Set a model name first.",parent=self.root)
        try:
            self._refresh_recipe_model(); engine=self._ensure_lights()
            inds=[i for i,v in enumerate(self.recipe_selected) if v.get() and i<len(self.recipes_a) and self.recipes_a[i].enabled]
            if not inds: raise ValueError("Tick at least one capture recipe")
            model=self.model_var.get().strip(); recipes_a=copy.deepcopy(self.recipes_a); recipes_b=copy.deepcopy(self.recipes_b); stitch_mode=self.stitch_mode.get()
        except Exception as exc: return messagebox.showerror("Capture",str(exc),parent=self.root)
        if "capture" in self.busy: return
        self.busy.add("capture"); self.capture_status.set("Capturing selected recipes…")
        manager=CaptureManager(self.camera_manager,lambda:engine,ROOT,self.log)
        camera_settings={"camera1":self.config.camera1.__dict__.copy(),"camera2":self.config.camera2.__dict__.copy()}
        scales={k:self.calibration.get_scale(k) for k in ("Camera 1","Camera 2","Stitched")}
        def worker():
            try:
                folder,manifest=manager.capture_selected(model,recipes_a,recipes_b,inds,stitch_mode,camera_settings,scales)
                self._post_ui(lambda:self.capture_status.set(f"Saved {len(manifest['items'])} image set(s): {folder}"))
            except Exception as exc: self._post_ui(lambda exc=exc:self._async_error("Capture",exc))
            finally: self.busy.discard("capture")
        threading.Thread(target=worker,daemon=True).start()

    def capture_one_testing(self):
        if not self.model_var.get().strip(): return messagebox.showwarning("Model required","Set a model name first.",parent=self.root)
        try:
            self._refresh_recipe_model(); engine=self._ensure_lights(); recipe=copy.deepcopy(self.recipes_a[0]); model=self.model_var.get().strip(); view=self.preview_source.get().lower().replace(" ",""); stitch_mode=self.stitch_mode.get()
        except Exception as exc: return messagebox.showerror("Capture",str(exc),parent=self.root)
        def worker():
            try:
                path=CaptureManager(self.camera_manager,lambda:engine,ROOT,self.log).capture_testing(model,recipe,view,stitch_mode)
                self._post_ui(lambda:self.capture_status.set(f"Testing image saved: {path}"))
            except Exception as exc: self._post_ui(lambda exc=exc:self._async_error("Testing capture",exc))
        threading.Thread(target=worker,daemon=True).start()

    def capture_and_inspect(self):
        if self.mode_var.get()!="DETECTION":
            if not messagebox.askyesno("Mode", "Switch to DETECTION mode and capture + inspect?",parent=self.root): return
            self.mode_var.set("DETECTION"); self._mode_changed()
        if not self.model_var.get().strip(): return messagebox.showwarning("Model required","Set a model name first.",parent=self.root)
        if "capture_inspect" in self.busy: return
        try:
            self._refresh_recipe_model(); engine=self._ensure_lights()
            inds=[i for i,v in enumerate(self.recipe_selected) if v.get() and i<len(self.recipes_a) and self.recipes_a[i].enabled]
            if not inds: raise ValueError("Tick at least one capture recipe")
            settings=self._snapshot_detection_settings()
            if not settings["detectors"]: raise ValueError("Select at least one detector plugin")
            model=self.model_var.get().strip(); recipes_a=copy.deepcopy(self.recipes_a); recipes_b=copy.deepcopy(self.recipes_b); stitch_mode=self.stitch_mode.get(); source_view=self.preview_source.get()
        except Exception as exc: return messagebox.showerror("Capture + inspect",str(exc),parent=self.root)
        self.busy.add("capture_inspect"); self.capture_status.set("Capturing and inspecting selected recipes…"); self.status_var.set("CAPTURE + INSPECT RUNNING…")
        manager=CaptureManager(self.camera_manager,lambda:engine,ROOT,self.log)
        camera_settings={"camera1":self.config.camera1.__dict__.copy(),"camera2":self.config.camera2.__dict__.copy()}
        scales={k:self.calibration.get_scale(k) for k in ("Camera 1","Camera 2","Stitched")}
        def worker():
            try:
                folder,manifest=manager.capture_selected(model,recipes_a,recipes_b,inds,stitch_mode,camera_settings,scales)
                file_key={"Stitched":"stitched","Camera 1":"camera1","Camera 2":"camera2"}.get(source_view,"stitched")
                captured={}
                for item in manifest["items"]:
                    filename=item.get("files",{}).get(file_key)
                    if not filename: continue
                    image=cv2.imread(str(folder/filename),cv2.IMREAD_COLOR)
                    if image is not None: captured[item["name"]]=image
                if not captured: raise RuntimeError(f"No usable images were captured for view {source_view}")
                # Multi-image algorithms receive the whole per-light image dictionary; single-image algorithms run once per light.
                all_results=[]; last_combined=None; last_working=None; last_mask=None; last_seg=None; output_root=ROOT/"results"/safe_name(model)/time.strftime("%Y%m%d_%H%M%S")
                multi_specs=[(n,p) for n,p in settings["detectors"] if self.detection_registry.get(n).multi_image]
                single_specs=[(n,p) for n,p in settings["detectors"] if not self.detection_registry.get(n).multi_image]
                for name,image in captured.items():
                    local_settings=dict(settings); local_settings["detectors"]=single_specs
                    if single_specs:
                        working,mask,results,segresult=self._process_image_for_detection(image,local_settings,light={"name":name})
                    else:
                        # Still form the effective mask to provide the multi-image detector with a correctly sized inspection domain.
                        local_settings["detectors"]=[]
                        try: working,mask,_,segresult=self._process_image_for_detection(image,local_settings,light={"name":name})
                        except Exception as exc:
                            if not multi_specs: raise
                            # Defer mask/region setup below if no single-image detector was selected.
                            working=image.copy(); mask=np.full(image.shape[:2],255,np.uint8); segresult=None
                        results=[]
                    if multi_specs and name==next(iter(captured)):
                        local_settings=dict(settings); local_settings["detectors"]=multi_specs
                        _,_,multi_results,multi_seg=self._process_image_for_detection(image,local_settings,context_images=captured,light={"name":name,"multi_image":True})
                        results.extend(multi_results)
                        if multi_seg is not None: segresult=multi_seg
                    combined=self._combine_result_images(working,results)
                    out=output_root/safe_name(name); out.mkdir(parents=True,exist_ok=True)
                    cv2.imwrite(str(out/"annotated.png"),combined); cv2.imwrite(str(out/"mask.png"),mask)
                    (out/"result.json").write_text(json.dumps({"model":model,"light_name":name,"source_view":source_view,"candidate_only":True,"results":[{"algorithm":r.algorithm,"score":r.score,"message":r.message,"defects":[b.__dict__ for b in r.defects]} for r in results]},indent=2),encoding="utf-8")
                    all_results.extend([(name,r) for r in results]); last_combined=combined; last_working=working; last_mask=mask; last_seg=segresult
                if not all_results: raise RuntimeError("No per-image detector results were produced")
                # Display the final captured recipe and aggregate all candidate boxes in the Defects table.
                results_for_display=[r for _,r in all_results]
                aggregated_combined=self._combine_result_images(last_working,results_for_display)
                self._post_ui(lambda:self._detection_done(aggregated_combined,last_working,last_mask,results_for_display,last_seg,source_view))
                self._post_ui(lambda:self.capture_status.set(f"Captured and inspected {len(captured)} recipe(s); results: {output_root}"))
                self.log("INFO",f"Capture + inspect completed for {len(captured)} images. Saved per-light candidate results to {output_root}")
            except Exception as exc: self._post_ui(lambda exc=exc:self._async_error("Capture + inspect",exc))
            finally: self.busy.discard("capture_inspect")
        threading.Thread(target=worker,daemon=True).start()

    def save_current_profile(self):
        model=self.model_var.get().strip()
        if not model: return messagebox.showwarning("Model required","Set a model name first.",parent=self.root)
        try:
            self._refresh_recipe_model(); image=self.current_image
            if image is None: raise ValueError("No active image source")
            active=[n for n,v in self.detector_vars.items() if v.get()]
            dets=[(n,self.detector_params.get(n,{})) for n in active]
            profile=make_profile(model,image.shape,self.preview_source.get(),self.stitch_mode.get(),self.roi_controller.inspection,self.roi_controller.camera,self.roi_controller.rois,self.seg_backend_var.get(),self.config.segmentation_params,[sid for sid,v in self.segment_vars.items() if v.get()],{"enabled":self.correct_var.get(),"strength":self.correction_strength.get(),"highlight_compression":self.highlight_var.get()},dets,[i for i,v in enumerate(self.recipe_selected) if v.get()])
            profile["workflow_options"]={
                "phone_workflow_enabled":bool(self.phone_workflow_enabled_var.get()),
                "phone_width_mm":float(self.phone_width_mm_var.get()),"phone_height_mm":float(self.phone_height_mm_var.get()),
                "phone_center_x":float(self.phone_center_x_var.get()),"phone_center_y":float(self.phone_center_y_var.get()),
                "phone_frame_width_percent":float(self.phone_frame_width_var.get()),"phone_color_tolerance":float(self.phone_color_tolerance_var.get()),
                "mm_per_px":self.calibration.get_scale(self.preview_source.get()),
                "canny_low":int(self.workflow_canny_low_var.get()),"canny_high":int(self.workflow_canny_high_var.get()),
                "edge_width_mm":float(self.workflow_edge_width_mm_var.get()),
                "use_correction_for_detection":bool(self.workflow_use_selected_var.get()),
                "correction_method":self.workflow_method_var.get(),"correction_strength":float(self.workflow_strength_var.get()),
                "correction_sigma":float(self.workflow_sigma_var.get()),"flat_field_path":self.workflow_flat_field_path,
            }
            path=save_profile(model,profile); self.log("INFO",f"Saved profile {path}"); messagebox.showinfo("Profile saved",str(path),parent=self.root)
        except Exception as exc: messagebox.showerror("Save profile",str(exc),parent=self.root)

    def load_current_profile(self):
        model=self.model_var.get().strip()
        if not model: return messagebox.showwarning("Model required","Set a model name first.",parent=self.root)
        try:
            profile=load_profile(model)
            old_view, old_stitch = self.preview_source.get(), self.stitch_mode.get()
            target_view=profile.get("source_view", old_view)
            target_stitch=profile.get("stitch_mode", old_stitch)
            # Resolve the requested camera view before validating saved image geometry.
            # Otherwise a profile for Camera 2/Stitched could be compared against the
            # stale Camera 1 frame currently displayed in the UI.
            self.preview_source.set(target_view); self.stitch_mode.set(target_stitch)
            target_image=self._get_preview_image()
            if target_image is not None and profile.get("image_size") and list(profile["image_size"]) != [target_image.shape[1], target_image.shape[0]]:
                self.preview_source.set(old_view); self.stitch_mode.set(old_stitch)
                self._last_source_signature=(old_view, old_stitch)
                raise ValueError(f"Profile image size {profile['image_size']} differs from the selected source {[target_image.shape[1],target_image.shape[0]]}; start/select the matching camera view before loading its geometry.")
            self._last_source_signature=(target_view,target_stitch)
            self.workflow_frozen=False; self.workflow_frame=None
            self.workflow_outputs={} if target_image is None else {"Original":target_image.copy()}
            self.workflow_selected_image=None; self.workflow_selected_method=None
            if target_image is not None:
                self.current_image=target_image.copy(); self.current_source_shape=target_image.shape[:2]
            elif (old_view, old_stitch) != (target_view, target_stitch):
                self.current_image=None; self.current_source_shape=None
            self.roi_controller.clear()
            if profile.get("inspection_roi"): self.roi_controller.inspection=ROI.from_dict(profile["inspection_roi"])
            if profile.get("camera_roi"): self.roi_controller.camera=ROI.from_dict(profile["camera_roi"])
            self.roi_controller.rois=[ROI.from_dict(r) for r in profile.get("rois",[])]
            self.seg_backend_var.set(profile.get("segmentation_backend",self.seg_backend_var.get()))
            self.config.segmentation_params=profile.get("segmentation_params",{})
            self.segment_vars={int(k):tk.BooleanVar(value=(int(k) in profile.get("ticked_segment_ids",[]))) for k in ("1","2","3","4")}
            opts=profile.get("correction_options",{}); self.correct_var.set(opts.get("enabled",False)); self.correction_strength.set(opts.get("strength",.75)); self.highlight_var.set(opts.get("highlight_compression",True))
            wopts=profile.get("workflow_options",{})
            if wopts:
                self.phone_workflow_enabled_var.set(bool(wopts.get("phone_workflow_enabled",True)))
                self.phone_width_mm_var.set(float(wopts.get("phone_width_mm",84.0))); self.phone_height_mm_var.set(float(wopts.get("phone_height_mm",163.0)))
                self.phone_center_x_var.set(float(wopts.get("phone_center_x",50.0))); self.phone_center_y_var.set(float(wopts.get("phone_center_y",50.0)))
                self.phone_frame_width_var.set(float(wopts.get("phone_frame_width_percent",65.0))); self.phone_color_tolerance_var.set(float(wopts.get("phone_color_tolerance",30.0)))
                self.workflow_canny_low_var.set(int(wopts.get("canny_low",35))); self.workflow_canny_high_var.set(int(wopts.get("canny_high",110)))
                self.workflow_edge_width_mm_var.set(float(wopts.get("edge_width_mm",1.1)))
                self.workflow_use_selected_var.set(bool(wopts.get("use_correction_for_detection",False)))
                saved_scale=wopts.get("mm_per_px")
                if saved_scale is not None and float(saved_scale) > 0:
                    self.calibration.data.setdefault("mm_per_px", {})[self.preview_source.get()] = float(saved_scale)
                    self.calibration.save()
                    self.workflow_scale_label.set(f"Profile scale restored: {float(saved_scale):.6f} mm/px")
                else:
                    self.workflow_scale_label.set("Scale: not calibrated; dimension estimate will use frame proportions")
                self.workflow_method_var.set(wopts.get("correction_method","Gaussian Divide"))
                self.workflow_strength_var.set(float(wopts.get("correction_strength",0.8))); self.workflow_sigma_var.set(float(wopts.get("correction_sigma",0.06)))
                flat_path=wopts.get("flat_field_path")
                self.workflow_flat_field_path=flat_path
                if flat_path and Path(flat_path).exists():
                    self.workflow_flat_field=cv2.imread(flat_path,cv2.IMREAD_COLOR)
                else:
                    self.workflow_flat_field=None
                self.workflow_phone_mask=None; self.workflow_phone_edges=None; self.workflow_edge_mask=None; self.workflow_backglass_mask=None; self.workflow_segment_overlay=None
            for n,v in self.detector_vars.items(): v.set(False)
            for row in profile.get("detectors",[]):
                n=row.get("name")
                if n in self.detector_vars: self.detector_vars[n].set(True); self.detector_params[n].update(row.get("params",{}))
            self.detector_setting_name.set(next((r.get("name") for r in profile.get("detectors",[]) if r.get("name") in self.detector_params),self.detector_setting_name.get())); self._build_detector_settings()
            self._refresh_roi_list(); self._refresh_segment_list(); self._render_preview(); self.log("INFO",f"Loaded profile {model}")
        except Exception as exc: messagebox.showerror("Load profile",str(exc),parent=self.root)

    def refresh_algorithms(self):
        self.detection_registry=discover_algorithms(ROOT/"algorithms",self.log)
        self._refresh_detector_list(); self._build_detector_settings(); self.log("INFO","Refreshed detector plugins")

    def start_auto_regulator(self):
        try:
            engine=self._ensure_lights()
            if not engine.dual:
                messagebox.showinfo("Auto regulator","A single light can only change overall brightness. Independent left/right balancing requires two lights.",parent=self.root); return
            self._refresh_recipe_model(); rgb_a=self.recipes_a[0].rgb(); rgb_b=self.recipes_b[0].rgb(); stitch_mode=self.stitch_mode.get(); inspection=copy.deepcopy(self.roi_controller.inspection)
        except Exception as exc: return messagebox.showerror("Auto regulator",str(exc),parent=self.root)
        threading.Thread(target=self._regulator_worker,args=(12,rgb_a,rgb_b,stitch_mode,inspection,False),daemon=True).start()

    def toggle_continuous_regulator(self):
        if self.regulator_active:
            self.regulator_stop.set(); self.cont_regulator_btn.configure(text="STOPPING…",state="disabled"); return
        try:
            engine=self._ensure_lights()
            if not engine.dual:
                messagebox.showinfo("Auto regulator","A single light can only change overall brightness. Independent left/right balancing requires two lights.",parent=self.root); return
            self._refresh_recipe_model(); rgb_a=self.recipes_a[0].rgb(); rgb_b=self.recipes_b[0].rgb(); stitch_mode=self.stitch_mode.get(); inspection=copy.deepcopy(self.roi_controller.inspection)
        except Exception as exc: return messagebox.showerror("Auto regulator",str(exc),parent=self.root)
        self.regulator_stop.clear(); self.regulator_active=True; self.cont_regulator_btn.configure(text="STOP REGULATOR",state="normal")
        threading.Thread(target=self._regulator_worker,args=(12,rgb_a,rgb_b,stitch_mode,inspection,True),daemon=True).start()

    def _regulator_finished(self):
        self.regulator_active=False
        try: self.cont_regulator_btn.configure(text="START CONTINUOUS",state="normal")
        except tk.TclError: pass

    def _regulator_worker(self,max_steps=12,rgb_a=None,rgb_b=None,stitch_mode="Aligned side-by-side",inspection=None,continuous=False):
        try:
            engine=self._ensure_lights(); rgb_a=list(rgb_a or (255,255,255)); rgb_b=list(rgb_b or (255,255,255))
            if not engine.dual: raise RuntimeError("A single light can change only overall brightness; independent balancing needs two lights.")
            step=0
            while step<max_steps or continuous:
                if self.closed or (continuous and self.regulator_stop.is_set()): break
                pair=self.camera_manager.capture_once(timeout=2); image=pair.stitched(stitch_mode)
                if image is None: raise RuntimeError("No image for illumination regulator")
                h,w=image.shape[:2]; split=w//2; lab=cv2.cvtColor(image,cv2.COLOR_BGR2LAB)[:,:,0].astype(float)
                if inspection is not None and inspection.enabled:
                    try:
                        valid=rasterize_shape(inspection.shape,image.shape)>0
                        ma=float(lab[:,:split][valid[:,:split]].mean()) if valid[:,:split].any() else float(lab[:,:split].mean())
                        mb=float(lab[:,split:][valid[:,split:]].mean()) if valid[:,split:].any() else float(lab[:,split:].mean())
                    except Exception: ma=float(lab[:,:split].mean()); mb=float(lab[:,split:].mean())
                else: ma=float(lab[:,:split].mean()); mb=float(lab[:,split:].mean())
                target=(ma+mb)/2
                if target<=1 or abs(ma-mb)/target<=.02:
                    self.log("INFO",f"Auto regulator {'monitor' if continuous else 'converged'} at step {step}: left={ma:.1f}, right={mb:.1f}")
                    if not continuous: return
                    time.sleep(.5); step+=1; continue
                factor_a=float(np.clip(target/max(ma,1),.92,1.08)); factor_b=float(np.clip(target/max(mb,1),.92,1.08))
                rgb_a=[int(np.clip(v*factor_a,0,255)) for v in rgb_a]; rgb_b=[int(np.clip(v*factor_b,0,255)) for v in rgb_b]
                engine.apply_pair(rgb_a,rgb_b); time.sleep(.18); step+=1
            if continuous: self.log("INFO","Continuous illumination regulation stopped")
            elif step>=max_steps: self.log("WARN","Auto regulator stopped after 12 steps without reaching 2% tolerance")
        except Exception as exc: self._post_ui(lambda exc=exc:self._async_error("Auto regulator",exc))
        finally:
            if continuous: self._post_ui(self._regulator_finished)

    def save_detection_result(self):
        if not self.last_detection_results or self.last_detection_mask is None:
            return messagebox.showinfo("Save result","Run detection first.",parent=self.root)
        model=self.model_var.get().strip()
        if not model: return messagebox.showwarning("Model required","Set a model name first.",parent=self.root)
        out=ROOT/"results"/safe_name(model)/time.strftime("%Y%m%d_%H%M%S")
        try:
            out.mkdir(parents=True,exist_ok=False)
            combined=getattr(self,"last_combined_image",self.last_detection_results[0].output).copy()
            cv2.imwrite(str(out/"annotated.png"),combined); cv2.imwrite(str(out/"mask.png"),self.last_detection_mask)
            payload={"model":model,"timestamp":time.strftime("%Y-%m-%dT%H:%M:%S%z"),"candidate_only":True,"results":[{"algorithm":r.algorithm,"score":r.score,"message":r.message,"params":r.params,"defects":[b.__dict__ for b in r.defects]} for r in self.last_detection_results]}
            (out/"result.json").write_text(json.dumps(payload,indent=2),encoding="utf-8")
            self.log("INFO",f"Saved annotated result to {out}"); messagebox.showinfo("Result saved",str(out),parent=self.root)
        except Exception as exc: messagebox.showerror("Save result",str(exc),parent=self.root)

    def clear_log(self):
        self._log_lines=[]
        if hasattr(self,"log_text"): self.log_text.configure(state="normal"); self.log_text.delete("1.0","end"); self.log_text.configure(state="disabled")

    def close(self):
        if self.closed: return
        self.closed=True
        for attr in ("_live_after_id","_preview_after_id","_log_after_id","_ui_after_id"):
            after_id=getattr(self,attr,None)
            if after_id is not None:
                try: self.root.after_cancel(after_id)
                except tk.TclError: pass
                setattr(self,attr,None)
        self.live_detection_var.set(False)
        self.regulator_stop.set()
        try:
            if self.lighting_engine: self.lighting_engine.all_off(); self.lighting_engine.disconnect()
        except Exception as exc: print(f"WARN shutdown lights: {exc}")
        try: self.camera_manager.stop()
        except Exception as exc: print(f"WARN shutdown camera: {exc}")
        try:
            self.config.preview_source=self.preview_source.get(); self.config.stitch_mode=self.stitch_mode.get(); self.config.topology=self.topology_var.get(); self.config.port_a=self.port_a_var.get(); self.config.port_b=self.port_b_var.get(); self.config.settle_ms=int(float(self.settle_var.get())); self.config.correction_enabled=self.correct_var.get(); self.config.correction_strength=self.correction_strength.get(); self.config.highlight_compression=self.highlight_var.get(); self.config.strict_per_channel=self.strict_channel_var.get(); self.config.recipes_a=self.recipes_a; self.config.recipes_b=self.recipes_b; self.config.detector_params=self.detector_params; self.config.segmentation_backend=self.seg_backend_var.get(); save_config(self.config)
        except Exception as exc: print(f"WARN config save: {exc}")
        try:
            if self.loupe_window and self.loupe_window.winfo_exists(): self.loupe_window.destroy()
        except Exception: pass
        self.root.destroy()

    def run(self): self.root.mainloop()

def main(): MobileInspectionApp().run()
