"""Image-processing helpers for the staged phone-inspection workflow.

The functions here are deliberately stateless so they can safely run in worker
threads. All images use OpenCV BGR ordering; masks are uint8 with 0/255 values.
"""
from __future__ import annotations

import cv2
import numpy as np

METHODS = (
    "Original",
    "Gaussian Divide",
    "Gaussian Subtract",
    "Flat-field",
    "Homomorphic",
    "Retinex (single scale)",
    "CLAHE",
    "Existing LAB correction",
)


def _mask_or_full(mask: np.ndarray | None, shape: tuple[int, ...]) -> np.ndarray:
    h, w = shape[:2]
    if mask is None:
        return np.full((h, w), 255, np.uint8)
    if mask.shape[:2] != (h, w):
        raise ValueError("Processing mask size does not match image size")
    return np.where(mask > 0, 255, 0).astype(np.uint8)


def _sigma(image: np.ndarray, sigma_fraction: float) -> float:
    return max(3.0, float(np.clip(sigma_fraction, 0.005, 0.30)) * min(image.shape[:2]))


def _illumination_field(channel: np.ndarray, mask: np.ndarray, sigma: float) -> np.ndarray:
    valid = (mask > 0).astype(np.float32)
    values = channel.astype(np.float32)
    numerator = cv2.GaussianBlur(values * valid, (0, 0), sigmaX=sigma, sigmaY=sigma)
    denominator = cv2.GaussianBlur(valid, (0, 0), sigmaX=sigma, sigmaY=sigma)
    fallback = float(np.median(values[valid > 0])) if np.any(valid) else 128.0
    return np.where(denominator > 1e-4, numerator / np.maximum(denominator, 1e-4), fallback)


def _replace_lab_l(image: np.ndarray, lightness: np.ndarray, valid_mask: np.ndarray) -> np.ndarray:
    lab = cv2.cvtColor(image, cv2.COLOR_BGR2LAB)
    original_l = lab[:, :, 0]
    lab[:, :, 0] = np.where(valid_mask > 0, np.clip(lightness, 0, 255), original_l).astype(np.uint8)
    result = cv2.cvtColor(lab, cv2.COLOR_LAB2BGR)
    result[valid_mask == 0] = image[valid_mask == 0]
    return result


def correct_image(
    image: np.ndarray,
    method: str,
    mask: np.ndarray | None = None,
    strength: float = 0.8,
    sigma_fraction: float = 0.06,
    flat_field: np.ndarray | None = None,
) -> np.ndarray:
    """Apply one illumination/contrast method while keeping the BGR image format.

    Correction methods modify LAB-L and keep chroma as stable as possible. The
    original is never modified in-place. This is a candidate preprocessing step,
    not a recovery method for saturated or photon-starved pixels.
    """
    if image is None or image.size == 0:
        raise ValueError("No captured image is available")
    if image.ndim != 3 or image.shape[2] != 3:
        raise ValueError("Expected a 3-channel BGR image")
    if method == "Original":
        return image.copy()

    valid_mask = _mask_or_full(mask, image.shape)
    valid = valid_mask > 0
    if not np.any(valid):
        return image.copy()
    strength = float(np.clip(strength, 0.0, 1.0))
    lab = cv2.cvtColor(image, cv2.COLOR_BGR2LAB)
    light = lab[:, :, 0].astype(np.float32)
    median_l = float(np.median(light[valid]))
    sigma = _sigma(image, sigma_fraction)

    if method == "Gaussian Subtract" or method == "Existing LAB correction":
        field = _illumination_field(light, valid_mask, sigma)
        target = light - strength * (field - median_l)

    elif method == "Gaussian Divide":
        field = _illumination_field(light, valid_mask, sigma)
        floor = max(5.0, float(np.percentile(field[valid], 10)) * 0.25)
        corrected = light * median_l / np.maximum(field, floor)
        target = light + strength * (corrected - light)

    elif method == "Flat-field":
        if flat_field is None:
            raise ValueError("Load a flat-field reference image first")
        reference = flat_field
        if reference.shape[:2] != image.shape[:2]:
            reference = cv2.resize(reference, (image.shape[1], image.shape[0]), interpolation=cv2.INTER_AREA)
        ref_l = cv2.cvtColor(reference, cv2.COLOR_BGR2LAB)[:, :, 0].astype(np.float32)
        ref_valid = ref_l[valid]
        ref_median = float(np.median(ref_valid)) if ref_valid.size else float(np.median(ref_l))
        smooth_ref = _illumination_field(ref_l, valid_mask, sigma)
        floor = max(5.0, ref_median * 0.10)
        corrected = light * ref_median / np.maximum(smooth_ref, floor)
        target = light + strength * (corrected - light)

    elif method in ("Homomorphic", "Retinex (single scale)"):
        log_l = np.log(np.maximum(light, 1.0) / 255.0)
        # Normalized convolution is essential here: pixels in excluded mask ROIs
        # must not leak into the illumination estimate as dark/black values.
        low = _illumination_field(log_l, valid_mask, sigma)
        residual = log_l - low
        if method == "Homomorphic":
            # Keep a portion of low-frequency content; aggressive high-pass filtering
            # can suppress broad shallow dents, so the correction is intentionally mild.
            log_target = log_l - strength * (low - float(np.median(low[valid])))
            target = np.exp(log_target) * 255.0
        else:
            retinex = residual + float(np.median(log_l[valid]))
            raw = np.exp(retinex) * 255.0
            # Robustly map the result to the source luminance range without allowing
            # a single hot pixel to set the entire contrast range.
            lo, hi = np.percentile(raw[valid], [1.0, 99.0])
            if hi - lo > 1e-5:
                mapped = np.clip((raw - lo) * (255.0 / (hi - lo)), 0, 255)
                mapped_median = float(np.median(mapped[valid]))
                raw = mapped + (median_l - mapped_median)
            target = light + strength * (raw - light)

    elif method == "CLAHE":
        # Mask-aware CLAHE. OpenCV's built-in CLAHE cannot accept a validity mask,
        # so it would count pixels inside excluded ROIs when building tile histograms.
        # Build per-tile LUTs from valid pixels only and interpolate between them.
        light_u8 = np.clip(light, 0, 255).astype(np.uint8)
        rows = cols = 8
        ys = np.linspace(0, image.shape[0], rows + 1, dtype=int)
        xs = np.linspace(0, image.shape[1], cols + 1, dtype=int)
        luts = np.tile(np.arange(256, dtype=np.uint8), (rows, cols, 1))
        for ty in range(rows):
            for tx in range(cols):
                y0, y1, x0, x1 = ys[ty], ys[ty + 1], xs[tx], xs[tx + 1]
                tile_mask = valid[y0:y1, x0:x1]
                if not np.any(tile_mask):
                    continue
                values = light_u8[y0:y1, x0:x1][tile_mask]
                hist = np.bincount(values, minlength=256).astype(np.int64)
                clip_limit = max(1, int(2.0 * max(1, values.size) / 256))
                excess = int(np.maximum(hist - clip_limit, 0).sum())
                hist = np.minimum(hist, clip_limit)
                if excess:
                    batch = excess // 256
                    remainder = excess % 256
                    hist += batch
                    if remainder:
                        hist[:remainder] += 1
                cdf = np.cumsum(hist, dtype=np.float64)
                total = float(cdf[-1])
                if total > 0:
                    lut = np.clip(np.rint(cdf * (255.0 / total)), 0, 255).astype(np.uint8)
                    luts[ty, tx] = lut
        # Blend neighboring tile LUT outputs using coordinates relative to tile centres.
        yy, xx = np.indices(light.shape, dtype=np.float32)
        fy = yy * (rows / max(1, image.shape[0])) - 0.5
        fx = xx * (cols / max(1, image.shape[1])) - 0.5
        y0 = np.floor(fy).astype(np.int32); x0 = np.floor(fx).astype(np.int32)
        wy = fy - y0; wx = fx - x0
        y0c = np.clip(y0, 0, rows - 1); y1c = np.clip(y0 + 1, 0, rows - 1)
        x0c = np.clip(x0, 0, cols - 1); x1c = np.clip(x0 + 1, 0, cols - 1)
        v = light_u8
        a = luts[y0c, x0c, v].astype(np.float32)
        b = luts[y0c, x1c, v].astype(np.float32)
        c = luts[y1c, x0c, v].astype(np.float32)
        d = luts[y1c, x1c, v].astype(np.float32)
        enhanced = (a * (1-wx) * (1-wy) + b * wx * (1-wy) + c * (1-wx) * wy + d * wx * wy)
        target = light + strength * (enhanced - light)
    else:
        raise ValueError(f"Unknown image-processing method: {method}")

    # Protect features outside the selected inspection domain and limit numerical
    # amplification in poorly illuminated areas.
    result = _replace_lab_l(image, target, valid_mask)
    return result


def detect_phone_region(
    image: np.ndarray,
    search_mask: np.ndarray | None = None,
    phone_width_mm: float = 84.0,
    phone_height_mm: float = 163.0,
    mm_per_px: float | None = None,
    center_x_percent: float = 50.0,
    center_y_percent: float = 50.0,
    uncalibrated_width_fraction: float = 0.34,
    color_tolerance: float = 30.0,
    canny_low: int = 35,
    canny_high: int = 110,
    exclude_mask: np.ndarray | None = None,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, str, tuple[int, int, int, int]]:
    """Locate the phone with a dimension prior and multiple image cues.

    Unlike the previous colour-only component selection, this version combines:
      * Canny edges from intensity and LAB channels,
      * local foreground/background colour contrast,
      * physical dimensions and aspect ratio,
      * a configurable expected centre, and
      * an operator-drawn Inspection ROI as a search constraint.

    Excluded Mask/Camera ROIs are inpainted for neighbourhood operations and are
    never used to estimate colours. The found phone geometry may pass underneath
    an exclusion so its outer contour remains continuous; exclusions are applied
    again to the Edge/Backglass and final detection masks.

    If the image does not contain enough evidence to locate a boundary, the method
    returns an explicit low-confidence dimension prior rather than pretending that
    an uncertain colour component is a reliable phone contour.
    """
    if image is None or image.size == 0:
        raise ValueError("Capture a frame before detecting the phone")
    if image.ndim != 3 or image.shape[2] != 3:
        raise ValueError("Phone detection expects a 3-channel BGR image")
    h, w = image.shape[:2]
    if h < 10 or w < 10:
        raise ValueError("Image is too small to detect a phone")
    if phone_width_mm <= 0 or phone_height_mm <= 0:
        raise ValueError("Phone width and height must be positive millimetres")

    full = np.full((h, w), 255, np.uint8)
    domain = _mask_or_full(search_mask, image.shape)
    excluded = np.zeros((h, w), np.uint8) if exclude_mask is None else _mask_or_full(exclude_mask, image.shape)
    valid = cv2.bitwise_and(domain, cv2.bitwise_not(excluded))
    if cv2.countNonZero(valid) < max(100, int(h * w * 0.002)):
        raise ValueError("Phone search ROI has too few unmasked pixels. Widen the Inspection ROI or remove an overlapping mask.")

    # A hand-drawn Inspection ROI is a search region. Use its centre as a more
    # useful prior than the full-frame centre when it is meaningfully smaller.
    rx, ry, rw, rh = cv2.boundingRect((domain > 0).astype(np.uint8))
    is_custom_search = rw < w * 0.92 or rh < h * 0.92 or cv2.countNonZero(domain) < h * w * 0.92
    if is_custom_search and rw > 10 and rh > 10:
        cx, cy = int(rx + rw / 2), int(ry + rh / 2)
        search_note = "custom Inspection ROI centre"
    else:
        cx = int(round(np.clip(center_x_percent, 0, 100) / 100.0 * (w - 1)))
        cy = int(round(np.clip(center_y_percent, 0, 100) / 100.0 * (h - 1)))
        search_note = "configured frame centre"

    aspect_h_over_w = float(phone_height_mm) / float(phone_width_mm)
    calibrated = mm_per_px is not None and np.isfinite(mm_per_px) and mm_per_px > 0
    if calibrated:
        target_w = int(round(float(phone_width_mm) / float(mm_per_px)))
        target_h = int(round(float(phone_height_mm) / float(mm_per_px)))
        size_note = f"calibrated at {mm_per_px:.5f} mm/px"
    else:
        # Use configured frame fraction for size; a custom ROI only guides the
        # search location and must not silently redefine the phone's dimensions.
        target_w = int(round(w * float(np.clip(uncalibrated_width_fraction, 0.12, 0.85))))
        target_h = int(round(target_w * aspect_h_over_w))
        size_note = "uncalibrated dimension prior"

    # Preserve aspect ratio when an inconsistent calibration cannot fit the frame.
    # The diagnostic explicitly warns the operator instead of silently claiming mm accuracy.
    fit = min(1.0, (w * 0.96) / max(1, target_w), (h * 0.96) / max(1, target_h))
    if fit < 0.999:
        size_note += "; dimensions scaled to fit frame — verify calibration and source view"
        target_w = max(12, int(round(target_w * fit)))
        target_h = max(12, int(round(target_h * fit)))
    target_w = max(12, min(w, target_w)); target_h = max(12, min(h, target_h))

    x1 = int(np.clip(cx - target_w // 2, 0, max(0, w - target_w)))
    y1 = int(np.clip(cy - target_h // 2, 0, max(0, h - target_h)))
    x2, y2 = x1 + target_w, y1 + target_h

    # Dimension prior with rounded corners; used for scoring and as a transparent
    # fallback only, never as the sole evidence when image edges are available.
    from mobile_inspection_app.roi.model import ROIShape
    from mobile_inspection_app.roi.shapes import rasterize_shape
    prior = rasterize_shape(
        ROIShape("rounded_rectangle", bbox=(x1, y1, x2 - 1, y2 - 1), radius=max(5, min(target_w // 12, target_h // 18))),
        image.shape,
    )

    # Replace excluded source pixels only in the analysis copy. A black-filled mask
    # would create artificial edges and contaminate nearby colour / illumination statistics.
    analysis = image.copy()
    if cv2.countNonZero(excluded):
        analysis = cv2.inpaint(analysis, excluded, 3, cv2.INPAINT_TELEA)

    blurred = cv2.GaussianBlur(analysis, (5, 5), 1.0)
    gray = cv2.cvtColor(blurred, cv2.COLOR_BGR2GRAY)
    lab = cv2.cvtColor(blurred, cv2.COLOR_BGR2LAB)

    # Keep the expensive contour search near the expected phone/search ROI. The
    # operator can reposition the prior with Centre X/Y or draw an Inspection ROI.
    # A generous margin tolerates moderate placement variation while avoiding a
    # full-frame edge/contour pass on high-resolution Basler images.
    if is_custom_search and rw > 10 and rh > 10:
        margin_x = max(12, int(target_w * 0.12)); margin_y = max(12, int(target_h * 0.10))
        sx1, sx2 = max(0, rx-margin_x), min(w, rx+rw+margin_x)
        sy1, sy2 = max(0, ry-margin_y), min(h, ry+rh+margin_y)
    else:
        # Without metric calibration, width fraction is only a soft size prior.
        # Use a wider image search so a larger real-world phone is not cropped out.
        margin_x = max(20, int(target_w * (0.42 if calibrated else 0.80)))
        margin_y = max(20, int(target_h * (0.22 if calibrated else 0.50)))
        sx1, sx2 = max(0, x1-margin_x), min(w, x2+margin_x)
        sy1, sy2 = max(0, y1-margin_y), min(h, y2+margin_y)
    if sx2-sx1 < 10 or sy2-sy1 < 10:
        sx1, sy1, sx2, sy2 = 0, 0, w, h

    low = int(np.clip(canny_low, 0, 254))
    high = int(np.clip(canny_high, low + 1, 255))
    edge_union = np.zeros((h, w), np.uint8)
    # Gray already carries most LAB-L edges; a/b add chromatic boundaries without
    # doing redundant Canny passes over both gray and LAB-L at full resolution.
    channels = [gray[sy1:sy2, sx1:sx2], lab[sy1:sy2, sx1:sx2, 1], lab[sy1:sy2, sx1:sx2, 2]]
    crop_edges = np.zeros((sy2-sy1, sx2-sx1), np.uint8)
    for ch in channels:
        crop_edges = cv2.bitwise_or(crop_edges, cv2.Canny(ch, low, high, L2gradient=True))
    edge_union[sy1:sy2, sx1:sx2] = crop_edges

    # Close small gaps at a scale proportional to the expected phone width.
    # Two scales are tried because a real silhouette may contain broken edge sections.
    close_base = int(np.clip(round(min(target_w, target_h) * 0.025), 5, 17))
    if close_base % 2 == 0:
        close_base += 1
    candidate_contours = []
    edge_crop = edge_union[sy1:sy2, sx1:sx2]
    offset = np.array([[[sx1, sy1]]], dtype=np.int32)
    for close_k in sorted(set([5 if close_base > 5 else close_base, close_base, min(21, close_base + 6)])):
        if close_k % 2 == 0:
            close_k += 1
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (close_k, close_k))
        closed = cv2.morphologyEx(edge_crop, cv2.MORPH_CLOSE, kernel, iterations=2)
        contours, _ = cv2.findContours(closed, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
        candidate_contours.extend([c + offset for c in contours])

    expected_area = float(max(1, target_w * target_h))
    expected_ratio = float(target_h) / max(float(target_w), 1.0)
    best_contour = None
    best_score = -1e9
    best_details = {}
    seen = set()
    for contour in candidate_contours:
        if len(contour) < 4:
            continue
        bx, by, bw, bh = cv2.boundingRect(contour)
        # Deduplicate contours repeated across the different closing scales.
        key = (round(bx / 4), round(by / 4), round(bw / 4), round(bh / 4))
        if key in seen:
            continue
        seen.add(key)
        min_size_ratio = 0.42 if calibrated else 0.28
        max_size_ratio = 1.75 if calibrated else 2.50
        if bw < target_w * min_size_ratio or bh < target_h * min_size_ratio:
            continue
        if bw > target_w * max_size_ratio or bh > target_h * max_size_ratio:
            continue
        ratio = bh / max(float(bw), 1.0)
        ratio_error = abs(np.log(max(ratio, 1e-4) / max(expected_ratio, 1e-4)))
        if ratio_error > (0.72 if calibrated else 0.90):
            continue

        # Evaluate contour evidence only in a tight crop. The previous full-frame
        # contour mask + dilation for every candidate was costly on Basler frames.
        k_ring = max(5, int(round(min(bw, bh) * 0.06)))
        px1, py1 = max(0, bx-k_ring-2), max(0, by-k_ring-2)
        px2, py2 = min(w, bx+bw+k_ring+2), min(h, by+bh+k_ring+2)
        candidate = contour.copy()
        candidate[:, 0, 0] -= px1; candidate[:, 0, 1] -= py1
        local_mask = np.zeros((py2-py1, px2-px1), np.uint8)
        cv2.drawContours(local_mask, [candidate], -1, 255, cv2.FILLED)
        local_domain = domain[py1:py2, px1:px2]
        local_valid = valid[py1:py2, px1:px2] > 0
        contour_area = float(cv2.countNonZero(local_mask))
        if contour_area < expected_area * 0.08 or contour_area > expected_area * (2.2 if calibrated else 5.0):
            continue
        overlap = cv2.countNonZero(cv2.bitwise_and(local_mask, local_domain)) / max(1.0, contour_area)
        if overlap < 0.35:
            continue

        ccx, ccy = bx + bw / 2.0, by + bh / 2.0
        center_error = float(np.hypot((ccx - cx) / max(target_w, 1), (ccy - cy) / max(target_h, 1)))
        width_error = abs(float(np.log(max(bw, 1) / max(target_w, 1))))
        height_error = abs(float(np.log(max(bh, 1) / max(target_h, 1))))

        # Compare interior colour with a surrounding ring, excluding masked pixels.
        ring_kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * k_ring + 1, 2 * k_ring + 1))
        dilated_local = cv2.dilate(local_mask, ring_kernel)
        ring = (dilated_local > 0) & (local_mask == 0) & local_valid
        interior = (local_mask > 0) & local_valid
        if np.count_nonzero(interior) > 500:
            eroded = cv2.erode(local_mask, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))) > 0
            if np.count_nonzero(eroded & local_valid) > 200:
                interior = eroded & local_valid
        local_lab = lab[py1:py2, px1:px2]
        if np.count_nonzero(ring) >= 50 and np.count_nonzero(interior) >= 50:
            inside_lab = np.median(local_lab[interior], axis=0).astype(np.float32)
            outside_lab = np.median(local_lab[ring], axis=0).astype(np.float32)
            contrast = float(np.linalg.norm(inside_lab - outside_lab))
        else:
            contrast = 0.0

        area_ratio = contour_area / expected_area
        area_error = abs(np.log(max(area_ratio, 1e-4)))
        # Dimension + ratio dominate, center is a soft prior; image-edge and colour
        # evidence decide between otherwise similar candidates.
        size_weight = 1.6 if calibrated else 0.70
        score = (
            -size_weight * width_error - size_weight * height_error - 1.7 * ratio_error
            -0.55 * min(center_error, 3.0) - (0.45 if calibrated else 0.20) * area_error
            +0.22 * min(contrast / max(float(color_tolerance), 1.0), 3.0)
            +0.12 * min(overlap, 1.0)
        )
        if score > best_score:
            best_score = score
            best_contour = contour
            best_details = {"bbox": (bx, by, bw, bh), "contrast": contrast, "ratio_error": ratio_error,
                            "centre_error": center_error, "score": score}

    # A second candidate family uses local foreground/background colour difference.
    # It works when the silhouette is low-texture but the phone and surroundings differ.
    colour_contour = None
    colour_score = -1e9
    # Estimate background from a ring outside the prior rectangle, never from masked pixels.
    outer_pad_x = max(5, int(target_w * 0.10)); outer_pad_y = max(5, int(target_h * 0.10))
    ox1, ox2 = max(0, x1 - outer_pad_x), min(w, x2 + outer_pad_x)
    oy1, oy2 = max(0, y1 - outer_pad_y), min(h, y2 + outer_pad_y)
    ring_prior = np.zeros((h, w), np.uint8)
    ring_prior[oy1:oy2, ox1:ox2] = 255
    ring_prior = cv2.bitwise_and(ring_prior, cv2.bitwise_not(prior))
    bg_valid = (ring_prior > 0) & (valid > 0)
    if np.count_nonzero(bg_valid) >= 50:
        bg_lab = np.median(lab[bg_valid], axis=0).astype(np.float32)
        # Estimate the background-distance distribution on its valid ring only.
        bg_delta = lab[bg_valid].astype(np.float32) - bg_lab.reshape(1, 3)
        bg_dist = np.sqrt((0.65 * bg_delta[:, 0]) ** 2 + bg_delta[:, 1] ** 2 + bg_delta[:, 2] ** 2)
        bg_med = float(np.median(bg_dist))
        bg_mad = float(np.median(np.abs(bg_dist - bg_med)))
        threshold = max(float(np.clip(color_tolerance, 8.0, 70.0)) * 0.55, bg_med + 3.5 * bg_mad + 5.0)
        # Compute foreground distance only inside the dimension-guided search window.
        margin_x, margin_y = max(6, int(target_w * (0.28 if calibrated else 0.65))), max(6, int(target_h * (0.18 if calibrated else 0.45)))
        qx1, qx2 = max(0, x1-margin_x), min(w, x2+margin_x)
        qy1, qy2 = max(0, y1-margin_y), min(h, y2+margin_y)
        local_lab = lab[qy1:qy2, qx1:qx2].astype(np.float32)
        delta = local_lab - bg_lab.reshape(1, 1, 3)
        dist = np.sqrt((0.65 * delta[:, :, 0]) ** 2 + delta[:, :, 1] ** 2 + delta[:, :, 2] ** 2)
        local_valid = (domain[qy1:qy2, qx1:qx2] > 0) & (valid[qy1:qy2, qx1:qx2] > 0)
        colour_bin = ((dist > threshold) & local_valid).astype(np.uint8) * 255
        close_k = max(5, min(19, close_base))
        if close_k % 2 == 0: close_k += 1
        colour_bin = cv2.morphologyEx(colour_bin, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(close_k,close_k)),iterations=2)
        colour_bin = cv2.morphologyEx(colour_bin, cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(3,3)))
        comps, labels, stats, cents = cv2.connectedComponentsWithStats((colour_bin > 0).astype(np.uint8), 8)
        for idx in range(1, comps):
            lbx, lby, bw, bh, area = [int(v) for v in stats[idx]]
            bx, by = lbx + qx1, lby + qy1
            min_size_ratio = 0.42 if calibrated else 0.28
            max_size_ratio = 1.75 if calibrated else 2.50
            if bw < target_w * min_size_ratio or bh < target_h * min_size_ratio or bw > target_w * max_size_ratio or bh > target_h * max_size_ratio:
                continue
            ratio = bh / max(float(bw), 1.0)
            ratio_error = abs(np.log(max(ratio,1e-4)/max(expected_ratio,1e-4)))
            max_area_ratio = 2.2 if calibrated else 5.0
            if ratio_error > (0.72 if calibrated else 0.90) or area < expected_area * 0.08 or area > expected_area * max_area_ratio:
                continue
            ccx, ccy = cents[idx]
            ccx += qx1; ccy += qy1
            centre_error = float(np.hypot((ccx-cx)/max(target_w,1),(ccy-cy)/max(target_h,1)))
            size_weight = 1.5 if calibrated else 0.65
            score = -size_weight*abs(np.log(max(bw,1)/max(target_w,1))) - size_weight*abs(np.log(max(bh,1)/max(target_h,1))) - 1.6*ratio_error - 0.6*min(centre_error,3) - (0.4 if calibrated else 0.18)*abs(np.log(max(area,1)/expected_area))
            if score > colour_score:
                colour_score=score
                colour_contour=np.zeros((h,w),np.uint8)
                local_component = labels == idx
                colour_contour[qy1:qy2, qx1:qx2][local_component]=255
                best_details_colour={"bbox":(bx,by,bw,bh),"score":score,"contrast":threshold}
    else:
        best_details_colour={}

    phone = np.zeros((h, w), np.uint8)
    quality_note = ""
    selected_bbox = None
    # Choose whichever candidate family provides the more convincing match to the
    # physical-size prior. Prefer an edge contour when it has explicit contour evidence.
    if best_contour is not None and (colour_contour is None or best_score >= colour_score - 0.25):
        cv2.drawContours(phone, [best_contour], -1, 255, cv2.FILLED)
        selected_bbox = best_details.get("bbox")
        contrast = best_details.get("contrast", 0.0)
        quality_note = f"edge contour + dimension prior (contrast={contrast:.1f}, score={best_score:.2f})"
    elif colour_contour is not None:
        phone = colour_contour
        selected_bbox = best_details_colour.get("bbox")
        quality_note = f"local LAB foreground/background contrast (score={colour_score:.2f})"

    # Reject components dominated by edge closure artifacts. Smooth tiny holes and
    # contour gaps without growing outside the selected phone geometry excessively.
    if selected_bbox is not None and cv2.countNonZero(phone):
        bw, bh = selected_bbox[2], selected_bbox[3]
        smooth_k = int(np.clip(round(min(bw, bh) * 0.012), 3, 11))
        if smooth_k % 2 == 0: smooth_k += 1
        phone = cv2.morphologyEx(phone, cv2.MORPH_CLOSE,
                                 cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (smooth_k, smooth_k)), iterations=1)
        # When an operator drew a search ROI tightly around the phone, do not clip
        # the resulting phone silhouette to that ROI; it is a search limit, not a mask.
        phone = np.where(phone > 0, 255, 0).astype(np.uint8)
    else:
        # There is no reliable visible contour. Return a geometric prior with an
        # explicit warning so the operator can adjust centre/size or use an Inspection ROI.
        phone = prior.copy()
        selected_bbox = (x1, y1, target_w, target_h)
        quality_note = "LOW CONFIDENCE: boundary insufficient; dimension-guided rounded ROI returned"

    # Make the silhouette continuous beneath user/camera masks using geometry only.
    # Those mask pixels will still be excluded from edge/backglass and defect detection.
    if cv2.countNonZero(excluded):
        hidden = cv2.bitwise_and(cv2.dilate(phone, cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(3,3))), excluded)
        phone = cv2.bitwise_or(phone, hidden)

    edges = edge_union.copy()
    edges[excluded > 0] = 0
    overlay = image.copy()
    # Thin orange edges show the evidence used; green shows the selected phone silhouette.
    edge_contours, _ = cv2.findContours(edges, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
    if edge_contours:
        # Limit overlays to avoid rendering thousands of tiny texture edges.
        edge_contours = [c for c in edge_contours if cv2.arcLength(c, False) >= max(20.0, min(target_w, target_h)*0.12)]
        if edge_contours:
            cv2.drawContours(overlay, edge_contours, -1, (0, 205, 255), 1)
    phone_contours, _ = cv2.findContours(phone, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if phone_contours:
        cv2.drawContours(overlay, phone_contours, -1, (40, 230, 80), max(2, int(round(min(h, w) / 500))), cv2.LINE_AA)
    cv2.rectangle(overlay, (x1, y1), (x2-1, y2-1), (255, 120, 20), 1)
    cv2.putText(overlay, "PHONE OUTLINE: GREEN | SIZE PRIOR: BLUE", (10, 23), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1, cv2.LINE_AA)
    if phone_contours:
        bx, by, bw, bh = cv2.boundingRect(max(phone_contours, key=cv2.contourArea))
        selected_bbox = (bx, by, bw, bh)
    bbox = tuple(int(v) for v in selected_bbox)
    message = f"{quality_note}; bbox={bbox}; {size_note}; centre={search_note}"
    return edges, phone, overlay, message, bbox

def make_correction_comparison(outputs: dict[str, np.ndarray], thumbnail_size: tuple[int, int] = (320, 220), columns: int = 3) -> np.ndarray:
    """Create a labeled contact sheet for correction outputs (read-only visualization)."""
    if not outputs:
        raise ValueError("No correction outputs available")
    thumb_w, thumb_h = thumbnail_size
    names = list(outputs.keys())
    rows = int(np.ceil(len(names) / max(1, columns)))
    cell_h = thumb_h + 34
    sheet = np.full((rows * cell_h, columns * thumb_w, 3), 38, np.uint8)
    for idx, name in enumerate(names):
        image = outputs[name]
        r, c = divmod(idx, columns)
        h, w = image.shape[:2]
        scale = min(thumb_w / max(1, w), thumb_h / max(1, h))
        resized = cv2.resize(image, (max(1, int(w * scale)), max(1, int(h * scale))), interpolation=cv2.INTER_AREA if scale < 1 else cv2.INTER_LINEAR)
        canvas = np.full((thumb_h, thumb_w, 3), 20, np.uint8)
        y = (thumb_h - resized.shape[0]) // 2; x = (thumb_w - resized.shape[1]) // 2
        canvas[y:y+resized.shape[0], x:x+resized.shape[1]] = resized
        x0, y0 = c * thumb_w, r * cell_h
        sheet[y0:y0+thumb_h, x0:x0+thumb_w] = canvas
        cv2.putText(sheet, name[:36], (x0 + 8, y0 + thumb_h + 23), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (240, 240, 240), 1, cv2.LINE_AA)
    return sheet

def canny_phone_mask(
    image: np.ndarray,
    search_mask: np.ndarray | None = None,
    low_threshold: int = 35,
    high_threshold: int = 110,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, str]:
    """Use Canny edges and contour closure to estimate the phone silhouette.

    A mask is returned separately from the raw edge map so operators can inspect
    both. This is heuristic and should be checked before using for production.
    """
    if image is None or image.size == 0:
        raise ValueError("Capture a frame before running phone/background separation")
    h, w = image.shape[:2]
    valid = _mask_or_full(search_mask, image.shape)
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    # A light denoise reduces surface texture becoming part of the silhouette.
    gray = cv2.GaussianBlur(gray, (5, 5), 1.0)
    low = max(0, int(low_threshold)); high = max(low + 1, int(high_threshold))
    edges = cv2.Canny(gray, low, high, L2gradient=True)
    edges[valid == 0] = 0

    base = max(5, int(round(min(h, w) * 0.012)))
    if base % 2 == 0:
        base += 1
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (base, base))
    closed = cv2.morphologyEx(edges, cv2.MORPH_CLOSE, kernel, iterations=2)
    closed = cv2.dilate(closed, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3)), iterations=1)
    contours, _ = cv2.findContours(closed, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    best = None
    best_score = -1.0
    image_area = float(h * w)
    for contour in contours:
        area = float(cv2.contourArea(contour))
        x, y, bw, bh = cv2.boundingRect(contour)
        bbox_area = float(bw * bh)
        if area < image_area * 0.015 or bbox_area > image_area * 0.96:
            continue
        aspect = max(bw, bh) / max(1.0, min(bw, bh))
        if aspect < 1.12:
            continue
        # Reward a large, phone-like elongated component near the field centre;
        # do not depend on the phone's actual color.
        cx, cy = x + bw / 2.0, y + bh / 2.0
        centre_penalty = 1.0 / (1.0 + 0.45 * (abs(cx - w / 2) / max(1, w / 2) + abs(cy - h / 2) / max(1, h / 2)))
        elongation_bonus = min(2.0, aspect / 2.0)
        score = area * centre_penalty * elongation_bonus
        if score > best_score:
            best, best_score = contour, score

    phone = np.zeros((h, w), np.uint8)
    if best is not None:
        cv2.drawContours(phone, [best], -1, 255, thickness=cv2.FILLED)
        close_k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (max(3, base), max(3, base)))
        phone = cv2.morphologyEx(phone, cv2.MORPH_CLOSE, close_k, iterations=2)
        phone = cv2.bitwise_and(phone, valid)
        # Retain the larger filled silhouette, not inner camera/lens contours.
        cs, _ = cv2.findContours(phone, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if cs:
            filled = np.zeros_like(phone)
            cv2.drawContours(filled, [max(cs, key=cv2.contourArea)], -1, 255, cv2.FILLED)
            phone = cv2.bitwise_and(filled, valid)
        message = f"Phone contour estimated from Canny; bbox={cv2.boundingRect(best)}"
    else:
        message = "No convincing closed phone contour found. Adjust Canny thresholds, improve contrast, or draw an inspection/search ROI."

    overlay = image.copy()
    overlay[edges > 0] = (0, 220, 255)
    if cv2.countNonZero(phone):
        contours2, _ = cv2.findContours(phone, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        cv2.drawContours(overlay, contours2, -1, (50, 230, 80), max(2, int(round(min(h, w) / 500))))
    return edges, phone, overlay, message


def adaptive_edge_backglass(
    image: np.ndarray,
    phone_mask: np.ndarray,
    edge_width_px: int = 12,
    camera_mask: np.ndarray | None = None,
    exclude_mask: np.ndarray | None = None,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Split a phone silhouette into a distance-transform edge band and back glass."""
    if image is None or phone_mask is None or not np.any(phone_mask):
        raise ValueError("Run Canny phone/background separation successfully first")
    h, w = image.shape[:2]
    phone = _mask_or_full(phone_mask, image.shape)
    contours, _ = cv2.findContours(phone, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        raise ValueError("Phone mask has no external contour")
    cleaned = np.zeros((h, w), np.uint8)
    cv2.drawContours(cleaned, [max(contours, key=cv2.contourArea)], -1, 255, cv2.FILLED)
    # Width is operator controlled but scales up gently for large stitched images.
    nominal = max(2, int(edge_width_px))
    adaptive_min = max(2, int(round(min(h, w) * 0.0025)))
    width = max(nominal, adaptive_min)
    distance = cv2.distanceTransform((cleaned > 0).astype(np.uint8), cv2.DIST_L2, 5)
    edge = np.where((cleaned > 0) & (distance <= width), 255, 0).astype(np.uint8)
    backglass = cv2.bitwise_and(cleaned, cv2.bitwise_not(edge))

    cam = np.zeros((h, w), np.uint8) if camera_mask is None else _mask_or_full(camera_mask, image.shape)
    excludes = np.zeros((h, w), np.uint8) if exclude_mask is None else _mask_or_full(exclude_mask, image.shape)
    edge = cv2.bitwise_and(edge, cv2.bitwise_not(cam))
    backglass = cv2.bitwise_and(backglass, cv2.bitwise_not(cam))
    edge = cv2.bitwise_and(edge, cv2.bitwise_not(excludes))
    backglass = cv2.bitwise_and(backglass, cv2.bitwise_not(excludes))

    overlay = image.copy()
    # Blend the regions only for visualization; source pixels remain unchanged.
    tint = overlay.copy()
    tint[backglass > 0] = (35, 160, 75)
    tint[edge > 0] = (0, 185, 245)
    tint[cam > 0] = (200, 90, 30)
    active = (backglass > 0) | (edge > 0) | (cam > 0)
    overlay[active] = cv2.addWeighted(image, 0.48, tint, 0.52, 0)[active]
    for mask, color in ((backglass, (50, 230, 90)), (edge, (0, 220, 255)), (cam, (255, 100, 40))):
        cs, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        cv2.drawContours(overlay, cs, -1, color, max(2, int(round(min(h, w) / 500))) if color != (50, 230, 90) else 1)
    cv2.putText(overlay, f"Edge band: {width}px", (14, 26), cv2.FONT_HERSHEY_SIMPLEX, 0.65, (0, 220, 255), 2, cv2.LINE_AA)
    return edge, backglass, overlay
