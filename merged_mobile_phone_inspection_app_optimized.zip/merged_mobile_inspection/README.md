# Merged Mobile Phone Inspection App

This merges the **Clean Live View** camera subsystem with the detection workflow from `main6.py`. There are intentionally **no light-controller controls** in this application.

## Features
- Camera 1, Camera 2, or Stitched live view.
- Stitch options: Auto feature stitch, Aligned side-by-side, Vertical aligned join.
- Basler backend (requires optional `pypylon`) and simulator backend for UI/testing without hardware.
- Full-frame Basler setup resets sensor offsets and requests maximum sensor Width/Height.
- Capture current full-resolution image to `captures/`.
- Draw one Inspection ROI and multiple Mask ROIs. Mask shapes: rectangle, ellipse, and polygon (polygon currently creates a four-corner polygon from the drag box).
- Live Laplacian detection with sliders for sensitivity, minimum response, minimum area, kernel, and local window.
- Detection, per-frame image preparation, resize and color conversion run in a background worker; Tk widgets are only updated on the UI thread.
- Latest-frame-only scheduling drops stale queued preview jobs instead of building a backlog when processing is slower than the camera.
- Persistent canvas image items and ROI overlays avoid deleting/recreating the entire canvas on every frame.
- Simulator scene frames are pre-rendered and paced to configured FPS rather than regenerated in an unbounded loop.
- Morphology is re-masked after closing so excluded Mask ROI pixels cannot become defect candidates.
- Capture and detection-result file writes run in background threads.
- Detection boxes labelled `DEFECT 1`, `DEFECT 2`, etc.
- Save ROI profiles, annotated result, binary mask, and defect metadata.
- No lighting/serial control code is exposed in the UI.

## Run on Windows
1. Extract this folder.
2. Run `setup_windows.bat`.
3. Run `run_windows.bat`.
4. Select `Simulator` to verify the workflow without hardware, or `Basler` for two connected Basler cameras.

## Workflow
1. Select backend and Camera 1, Camera 2, or Stitched view.
2. Start cameras and capture a reference image if desired.
3. Select `Inspection ROI` and draw once.
4. Select `Mask ROI` and draw as many exclusion masks as needed. Delete a selected mask individually.
5. Enable live detection or press Run Detection Now.
6. Save results or save the ROI profile.

## Important notes
- ROI coordinates are tied to the selected view and image dimensions. When switching views, the app prompts about clearing them; do not reuse a stitched ROI on a single camera view.
- `Auto feature stitch` requires sufficient overlap/texture and can fall back to aligned side-by-side.
- Aligned side-by-side stitching preserves each camera image's raw intensity values; it does not perform automatic exposure scaling on the inspection pixels.
- The detector flags candidate regions; it is not a certified pass/fail judgement. Validate thresholds on real phone images.
- Simulator GUI, background detection, output rendering, camera stop, and mask exclusion were smoke-tested. Real Basler cameras were not available for hardware verification here.
