from __future__ import annotations
import os, time, json, threading, copy, queue
from pathlib import Path
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import cv2
import numpy as np
from PIL import Image, ImageTk
from collections import deque

# Limit OpenCV's internal pool to avoid CPU oversubscription beside camera and UI workers.
try: cv2.setNumThreads(max(1, min(4, os.cpu_count() or 2)))
except Exception: pass
from mobile_inspection_app.camera.camera_manager import CameraManager
from mobile_inspection_app.camera.basler_camera import BaslerCamera
from mobile_inspection_app.camera.simulated_camera import SimulatedCamera

ROOT_DIR = Path(__file__).resolve().parent
CAPTURE_DIR = ROOT_DIR / 'captures'

class LiveLaplacian:
    def __init__(self):
        self.buffer = deque(maxlen=3)
        self.last_shape = None
    def detect(self, image, allowed_mask, k=2.8, min_strength=18, ksize=3, window=31, min_area=20, persistence=True):
        gray=cv2.cvtColor(image,cv2.COLOR_BGR2GRAY) if image.ndim==3 else image
        ksize=int(ksize); window=max(3,int(window)); window += (window%2==0)
        lap=np.abs(cv2.Laplacian(gray,cv2.CV_32F,ksize=ksize))
        valid=(allowed_mask>0).astype(np.float32)
        count=cv2.boxFilter(valid,-1,(window,window),normalize=False,borderType=cv2.BORDER_REFLECT)
        sum1=cv2.boxFilter(lap*valid,-1,(window,window),normalize=False,borderType=cv2.BORDER_REFLECT)
        sum2=cv2.boxFilter(lap*lap*valid,-1,(window,window),normalize=False,borderType=cv2.BORDER_REFLECT)
        mean=sum1/np.maximum(count,1); var=np.maximum(sum2/np.maximum(count,1)-mean*mean,0)
        raw=((lap>=np.maximum(mean+float(k)*np.sqrt(var),float(min_strength))) & (valid>0)).astype(np.uint8)
        if self.last_shape != raw.shape:
            self.buffer.clear(); self.last_shape=raw.shape
        self.buffer.append(raw)
        if persistence and len(self.buffer)>=2:
            mask=(np.sum(self.buffer,axis=0)>=2).astype(np.uint8)*255
        else:
            mask=raw*255
        # Keep excluded pixels excluded through persistence and morphology. Closing can
        # otherwise bridge across mask boundaries and create candidates inside masks.
        valid_pixels = allowed_mask > 0
        mask[~valid_pixels] = 0
        kernel=cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(3,3))
        mask=cv2.morphologyEx(mask,cv2.MORPH_CLOSE,kernel)
        mask[~valid_pixels] = 0
        contours,_=cv2.findContours(mask,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
        output=image.copy(); defects=[]
        for c in contours:
            area=cv2.contourArea(c)
            if area < float(min_area): continue
            x,y,w,h=cv2.boundingRect(c)
            if w<2 and h<2: continue
            defects.append((x,y,w,h,float(area)))
        for i,(x,y,w,h,area) in enumerate(defects,1):
            cv2.rectangle(output,(x,y),(x+w,y+h),(0,0,255),max(2,round(min(image.shape[:2])/400)))
            cv2.putText(output,f'DEFECT {i}',(x,max(18,y-7)),cv2.FONT_HERSHEY_SIMPLEX,max(.45,min(image.shape[:2])/1500),(0,0,255),2,cv2.LINE_AA)
        if not defects: cv2.putText(output,'NO DEFECTS FLAGGED',(18,32),cv2.FONT_HERSHEY_SIMPLEX,.7,(80,220,80),2,cv2.LINE_AA)
        return output,mask,defects

class MergedInspectionApp:
    def __init__(self, root):
        self.root=root; self.root.title('Mobile Phone Inspection — Camera + main6 Workflow')
        self.root.geometry('1450x900'); self.root.minsize(1050,700); self.root.configure(bg='#111418')
        self.style=ttk.Style(); self.style.theme_use('clam')
        self.style.configure('.',background='#191d22',foreground='#e6e6e6',font=('Segoe UI',10))
        self.style.configure('TFrame',background='#191d22'); self.style.configure('TLabel',background='#191d22',foreground='#e6e6e6')
        self.style.configure('TLabelframe',background='#191d22',foreground='#00a8ff'); self.style.configure('TLabelframe.Label',background='#191d22',foreground='#00a8ff')
        self.style.configure('TButton',padding=5,background='#252c34',foreground='#f2f4f8')
        self.backend_mode=tk.StringVar(value='Basler')
        self.view_var=tk.StringVar(value='Stitched')
        self.stitch_var=tk.StringVar(value='Aligned side-by-side')
        self.roi_tool=tk.StringVar(value='Inspection ROI')
        self.shape_var=tk.StringVar(value='Rectangle')
        self.live_var=tk.BooleanVar(value=True)
        self.k_var=tk.DoubleVar(value=2.8); self.min_strength_var=tk.DoubleVar(value=18); self.min_area_var=tk.DoubleVar(value=20)
        self.ksize_var=tk.StringVar(value='3'); self.window_var=tk.StringVar(value='31')
        self.cameras=None; self.running=False; self.current_frame=None; self.display_frame=None; self.tk_image=None
        self.inspection_roi=None; self.masks=[]; self.mask_counter=0; self.drawing=False; self.draw_start=None; self.preview_shape=None
        self.scale=1.0; self.offset_x=0; self.offset_y=0; self.detector=LiveLaplacian(); self.latest_result=None; self.last_render_size=(1,1)
        self._closing=False; self._frame_signature=None; self._manual_detection_active=False
        self._camera_transition=False; self._restart_after_stop=False
        self._render_lock=threading.Lock(); self._render_job_latest=None; self._render_worker_active=False
        self._render_state_signature=None; self._render_state_generation=0; self._render_job_counter=0
        self._result_lock=threading.Lock(); self._pending_render_result=None; self._display_image_item=None; self._placeholder_item=None
        self._overlay_item_ids=[]; self._preview_shape_item_id=None; self._drain_after_id=None
        self._build_ui(); self.root.protocol('WM_DELETE_WINDOW',self.close); self._tick(); self._drain_after_id=self.root.after(15,self._drain_render_results)

    def _build_ui(self):
        header=ttk.Frame(self.root,padding=(10,8)); header.pack(fill='x')
        ttk.Label(header,text='MOBILE PHONE INSPECTION',font=('Segoe UI',15,'bold')).pack(side='left')
        ttk.Label(header,text='Camera capture + main6 detection | no light control',foreground='#9ca3af').pack(side='left',padx=18)
        body=ttk.Panedwindow(self.root,orient='horizontal'); body.pack(fill='both',expand=True,padx=8,pady=(0,8))
        left=ttk.Frame(body); right_outer=ttk.Frame(body); body.add(left,weight=7); body.add(right_outer,weight=3)
        camrow=ttk.Frame(left,padding=5); camrow.pack(fill='x')
        ttk.Label(camrow,text='Backend').pack(side='left')
        ttk.Combobox(camrow,textvariable=self.backend_mode,values=['Basler','Simulator'],state='readonly',width=10).pack(side='left',padx=5)
        ttk.Label(camrow,text='View').pack(side='left',padx=(8,0))
        view=ttk.Combobox(camrow,textvariable=self.view_var,values=['Camera 1','Camera 2','Stitched'],state='readonly',width=14); view.pack(side='left',padx=5); view.bind('<<ComboboxSelected>>',self._view_changed)
        ttk.Label(camrow,text='Stitch').pack(side='left',padx=(8,0))
        ttk.Combobox(camrow,textvariable=self.stitch_var,values=['Auto feature stitch','Aligned side-by-side','Vertical aligned join'],state='readonly',width=22).pack(side='left',padx=5)
        self.start_btn=ttk.Button(camrow,text='START CAMERAS',command=self.toggle_cameras); self.start_btn.pack(side='left',padx=5)
        ttk.Button(camrow,text='CAPTURE IMAGE',command=self.capture).pack(side='left',padx=5)
        ttk.Button(camrow,text='FIT VIEW',command=self.render_current).pack(side='left',padx=5)
        self.canvas=tk.Canvas(left,bg='#080a0c',highlightthickness=0,cursor='crosshair'); self.canvas.pack(fill='both',expand=True,padx=5,pady=5)
        self.canvas.bind('<Configure>',lambda e:self.render_current())
        self.canvas.bind('<ButtonPress-1>',self._draw_start); self.canvas.bind('<B1-Motion>',self._draw_drag); self.canvas.bind('<ButtonRelease-1>',self._draw_end)
        self.canvas.bind('<MouseWheel>',self._wheel_zoom)
        self.status=ttk.Label(left,text='Choose Basler or Simulator, then START CAMERAS.',padding=5); self.status.pack(fill='x')
        # Scrollable settings panel
        right_canvas=tk.Canvas(right_outer,bg='#191d22',highlightthickness=0); sb=ttk.Scrollbar(right_outer,orient='vertical',command=right_canvas.yview); right_canvas.configure(yscrollcommand=sb.set)
        sb.pack(side='right',fill='y'); right_canvas.pack(side='left',fill='both',expand=True)
        panel=ttk.Frame(right_canvas,padding=8); win=right_canvas.create_window((0,0),window=panel,anchor='nw')
        panel.bind('<Configure>',lambda e:right_canvas.configure(scrollregion=right_canvas.bbox('all'))); right_canvas.bind('<Configure>',lambda e:right_canvas.itemconfigure(win,width=e.width))
        right_canvas.bind_all('<MouseWheel>',lambda e:right_canvas.yview_scroll(int(-e.delta/120),'units'))
        roi=ttk.LabelFrame(panel,text='Inspection / Mask ROIs',padding=8); roi.pack(fill='x',pady=5)
        ttk.Label(roi,text='Draw tool').grid(row=0,column=0,sticky='w')
        ttk.Combobox(roi,textvariable=self.roi_tool,values=['Inspection ROI','Mask ROI'],state='readonly',width=17).grid(row=0,column=1,sticky='ew',padx=4,pady=3)
        ttk.Label(roi,text='Shape').grid(row=1,column=0,sticky='w')
        ttk.Combobox(roi,textvariable=self.shape_var,values=['Rectangle','Ellipse','Polygon'],state='readonly',width=17).grid(row=1,column=1,sticky='ew',padx=4,pady=3)
        ttk.Label(roi,text='Inspection ROI: one region. Masks: multiple exclusions.').grid(row=2,column=0,columnspan=2,sticky='w',pady=3)
        self.mask_list=tk.Listbox(roi,height=5,selectmode='browse',bg='#20252b',fg='#e6e6e6',selectbackground='#006ca8',borderwidth=0); self.mask_list.grid(row=3,column=0,columnspan=2,sticky='ew',pady=4)
        btns=ttk.Frame(roi); btns.grid(row=4,column=0,columnspan=2,sticky='ew')
        ttk.Button(btns,text='Delete selected mask',command=self.delete_mask).pack(side='left',fill='x',expand=True,padx=2)
        ttk.Button(btns,text='Clear all ROIs',command=self.clear_rois).pack(side='left',fill='x',expand=True,padx=2)
        ttk.Button(roi,text='Save ROI profile',command=self.save_rois).grid(row=5,column=0,columnspan=2,sticky='ew',pady=3)
        roi.columnconfigure(1,weight=1)
        det=ttk.LabelFrame(panel,text='Detection — main6 Laplacian',padding=8); det.pack(fill='x',pady=5)
        ttk.Checkbutton(det,text='Live detection',variable=self.live_var,command=self.render_current).pack(anchor='w')
        self._slider(det,'Sensitivity (k)',self.k_var,.5,8,1)
        self._slider(det,'Minimum Laplacian strength',self.min_strength_var,0,100,1)
        self._slider(det,'Minimum defect area (px)',self.min_area_var,1,2000,0)
        row=ttk.Frame(det); row.pack(fill='x',pady=4); ttk.Label(row,text='Laplacian kernel').pack(side='left'); ttk.Combobox(row,textvariable=self.ksize_var,values=['1','3','5','7'],state='readonly',width=6).pack(side='right')
        row=ttk.Frame(det); row.pack(fill='x',pady=4); ttk.Label(row,text='Local window').pack(side='left'); ttk.Combobox(row,textvariable=self.window_var,values=['9','15','21','31','51','75','101'],state='readonly',width=6).pack(side='right')
        ttk.Button(det,text='RUN DETECTION NOW',command=self.run_detection).pack(fill='x',pady=(5,2))
        ttk.Button(det,text='Save annotated result',command=self.save_result).pack(fill='x',pady=2)
        self.result_label=ttk.Label(det,text='No detection run yet.',wraplength=280); self.result_label.pack(fill='x',pady=5)
        helpf=ttk.LabelFrame(panel,text='Workflow',padding=8); helpf.pack(fill='x',pady=5)
        ttk.Label(helpf,text='1. Start cameras\n2. Choose Camera 1, Camera 2 or Stitched\n3. Draw Inspection ROI\n4. Draw any number of Mask ROIs\n5. Enable live detection or Run Detection\n6. Capture/save results',justify='left').pack(anchor='w')

    def _slider(self,parent,label,var,lo,hi,digits=1):
        frame=ttk.Frame(parent); frame.pack(fill='x',pady=4)
        top=ttk.Frame(frame); top.pack(fill='x'); ttk.Label(top,text=label).pack(side='left')
        value=ttk.Label(top,text=f'{var.get():.{digits}f}'); value.pack(side='right')
        def changed(v): value.config(text=f'{float(v):.{digits}f}');
        ttk.Scale(frame,from_=lo,to=hi,variable=var,command=changed).pack(fill='x')

    def _new_manager(self):
        if self.backend_mode.get()=='Simulator': return CameraManager(SimulatedCamera(0),SimulatedCamera(1),on_log=self._log)
        return CameraManager(BaslerCamera(0,on_log=self._log),BaslerCamera(1,on_log=self._log),on_log=self._log)
    def _log(self,level,msg):
        try: self.root.after(0,lambda:self.status.config(text=f'{level}: {msg}'))
        except Exception: pass
    def toggle_cameras(self):
        if self._closing or self._camera_transition:
            return
        if self.running:
            manager = self.cameras
            self.running = False
            self._camera_transition = True
            self.start_btn.configure(state='disabled')
            self.status.config(text='Stopping camera streams…')
            def stop_worker():
                try:
                    if manager:
                        manager.stop()
                except Exception as exc:
                    self._log('WARN', f'Camera shutdown: {exc}')
                try:
                    self.root.after(0, self._camera_stopped)
                except Exception:
                    pass
            threading.Thread(target=stop_worker, daemon=True, name='camera-stop').start()
            return

        self._camera_transition = True
        self.start_btn.configure(state='disabled')
        manager = self._new_manager()
        self.cameras = manager
        view = self.view_var.get()
        active = (view in ('Camera 1','Stitched'), view in ('Camera 2','Stitched'))
        self.status.config(text='Starting camera streams…')
        def start_worker():
            ok = False
            error = None
            try:
                manager.start(active=active)
                ok = True
            except Exception as exc:
                error = exc
            try:
                self.root.after(0, lambda ok=ok,error=error,manager=manager: self._camera_started(manager,ok,error))
            except Exception:
                try: manager.stop()
                except Exception: pass
        threading.Thread(target=start_worker, daemon=True, name='camera-start').start()

    def _camera_stopped(self):
        if self._closing:
            return
        self._camera_transition = False
        self.start_btn.configure(state='normal', text='START CAMERAS')
        self.status.config(text='Cameras stopped.')
        self._frame_signature = None
        if self._restart_after_stop:
            self._restart_after_stop = False
            self.toggle_cameras()

    def _camera_started(self, manager, ok, error=None):
        if self._closing:
            try: threading.Thread(target=manager.stop, daemon=True, name='camera-cleanup').start()
            except Exception: pass
            return
        self._camera_transition = False
        self.running = bool(ok)
        self.start_btn.configure(state='normal', text='STOP CAMERAS' if ok else 'START CAMERAS')
        self._frame_signature = None
        if ok:
            self.status.config(text='Camera stream started.')
            self._log('INFO','Camera stream started.')
        else:
            self.status.config(text=f'Camera start failed: {error}')
            self._log('ERROR', str(error))

    def _view_changed(self,event=None):
        if self.inspection_roi or self.masks:
            if not messagebox.askyesno('ROI coordinates','Changing view changes image coordinates. Clear all ROIs and redraw for this view?'):
                return
            self.clear_rois()
        self._frame_signature = None
        if self.running:
            self._restart_after_stop = True
            self.toggle_cameras()
        else:
            self.render_current()
    def _get_frame(self, pair=None):
        if not self.running or self.cameras is None:
            return None
        try:
            pair = pair or self.cameras.latest(self.stitch_var.get())
            view = self.view_var.get()
            if view == 'Camera 1':
                return pair.camera1.image if pair.camera1 else None
            if view == 'Camera 2':
                return pair.camera2.image if pair.camera2 else None
            return pair.stitched(self.stitch_var.get())
        except Exception as exc:
            self._log('WARN', f'Frame acquisition: {exc}')
            return None

    def _fit_params(self, frame):
        h,w=frame.shape[:2]; cw=max(1,self.canvas.winfo_width()); ch=max(1,self.canvas.winfo_height())
        s=min(cw/w,ch/h); return s,(cw-w*s)/2,(ch-h*s)/2

    def _snapshot_detection_params(self):
        # Tk variables are read only from the main thread.
        return {
            'k': float(self.k_var.get()),
            'min_strength': float(self.min_strength_var.get()),
            'ksize': int(self.ksize_var.get()),
            'window': int(self.window_var.get()),
            'min_area': float(self.min_area_var.get()),
        }

    def render_current(self):
        """Schedule a render; expensive CV, masks, resize and color conversion run off the Tk thread."""
        if self._closing:
            return
        frame = self._get_frame() if self.running else None
        if frame is not None:
            if self.current_frame is None or frame.shape[:2] != self.current_frame.shape[:2]:
                if self.current_frame is not None and (self.inspection_roi or self.masks):
                    self.inspection_roi=None; self.masks=[]; self._refresh_mask_list()
                    self.status.config(text='Frame size changed: ROIs cleared; redraw them for the new image size.')
            self.current_frame = frame
        if self.current_frame is None:
            self._show_no_frame()
            return
        if self._manual_detection_active:
            return
        self._queue_render(detect=bool(self.live_var.get()))

    def _show_no_frame(self):
        if self._display_image_item is not None:
            self.canvas.delete(self._display_image_item); self._display_image_item=None
        if self._placeholder_item is None:
            self._placeholder_item=self.canvas.create_text(max(100,self.canvas.winfo_width()//2),max(80,self.canvas.winfo_height()//2),text='Camera stopped / no frame',fill='#d1d5db',font=('Segoe UI',16))

    def _queue_render(self, detect=False, manual=False, frame=None):
        if self._closing:
            return
        image = frame if frame is not None else self.current_frame
        if image is None:
            return
        # Capture immutable worker inputs on the UI thread; workers never read Tk variables.
        inspection = copy.deepcopy(self.inspection_roi)
        masks = copy.deepcopy(self.masks)
        params = self._snapshot_detection_params()
        s, ox, oy = self._fit_params(image)
        h, w = image.shape[:2]
        dw, dh = max(1, int(w*s)), max(1, int(h*s))
        signature = (repr(inspection), repr(masks), params['k'], params['min_strength'], params['ksize'], params['window'], params['min_area'],
                     bool(detect), bool(manual), self.view_var.get(), self.stitch_var.get(), round(s,6), round(ox,3), round(oy,3), dw, dh)
        if signature != self._render_state_signature:
            self._render_state_generation += 1
            self._render_state_signature = signature
        self._render_job_counter += 1
        job = {
            'state_generation': self._render_state_generation,
            'job_id': self._render_job_counter,
            'frame': image,
            'inspection': inspection,
            'masks': masks,
            'params': params,
            'detect': bool(detect),
            'manual': bool(manual),
            'scale': s, 'ox': ox, 'oy': oy, 'dw': dw, 'dh': dh,
        }
        with self._render_lock:
            self._render_job_latest = job
            if not self._render_worker_active:
                self._render_worker_active = True
                threading.Thread(target=self._render_worker_loop, daemon=True, name='main6-render-detection').start()

    def _raster_snapshot(self, mask, kind, coords, value):
        if kind == 'Rectangle':
            x1,y1,x2,y2=map(int,coords); cv2.rectangle(mask,(x1,y1),(x2,y2),value,-1)
        elif kind == 'Ellipse':
            x1,y1,x2,y2=map(int,coords); cv2.ellipse(mask,((x1+x2)//2,(y1+y2)//2),(max(1,abs(x2-x1)//2),max(1,abs(y2-y1)//2)),0,0,360,value,-1)
        elif kind == 'Polygon':
            cv2.fillPoly(mask,[np.array(coords,np.int32)],value)

    def _effective_mask_snapshot(self, shape, inspection_roi, masks):
        h,w=shape[:2]
        allowed=np.zeros((h,w),np.uint8)
        if inspection_roi:
            kind,coords=inspection_roi; self._raster_snapshot(allowed,kind,coords,255)
        else:
            allowed[:]=255
        for item in masks:
            if item.get('enabled',True):
                self._raster_snapshot(allowed,item['shape'],item['coords'],0)
        return allowed

    def _detect_frame(self, frame, allowed_mask, params):
        return self.detector.detect(frame, allowed_mask, k=params['k'], min_strength=params['min_strength'],
                                    ksize=params['ksize'], window=params['window'], min_area=params['min_area'], persistence=True)

    def _render_worker_loop(self):
        """One worker and a latest-only job slot prevent unbounded queue growth."""
        while True:
            with self._render_lock:
                job = self._render_job_latest
                self._render_job_latest = None
                if job is None:
                    self._render_worker_active = False
                    return
            try:
                frame = job['frame']
                if job['detect']:
                    allowed = self._effective_mask_snapshot(frame.shape, job['inspection'], job['masks'])
                    out, mask, defects = self._detect_frame(frame, allowed, job['params'])
                else:
                    out, mask, defects = frame.copy(), None, []
                shown = cv2.resize(out, (job['dw'], job['dh']), interpolation=cv2.INTER_AREA if job['scale'] < 1 else cv2.INTER_LINEAR)
                rgb = cv2.cvtColor(shown, cv2.COLOR_BGR2RGB)
                result = (job, rgb, out, mask, defects)
                if not self._closing:
                    with self._result_lock:
                        self._pending_render_result = result
            except Exception as exc:
                self._log('ERROR', f'Background processing: {exc}')

    def _drain_render_results(self):
        if self._closing:
            return
        with self._result_lock:
            result = self._pending_render_result
            self._pending_render_result = None
        if result is not None:
            try:
                self._finish_render(*result)
            except Exception as exc:
                self._log('ERROR', f'Preview display: {exc}')
        self._drain_after_id = self.root.after(15, self._drain_render_results)

    def _finish_render(self, job, rgb, out, mask, defects):
        if self._closing or job['state_generation'] != self._render_state_generation:
            return
        self.scale, self.offset_x, self.offset_y = job['scale'], job['ox'], job['oy']
        self.display_frame = out
        self.tk_image = ImageTk.PhotoImage(Image.fromarray(rgb))
        if self._placeholder_item is not None:
            self.canvas.delete(self._placeholder_item); self._placeholder_item=None
        if self._display_image_item is None:
            self._display_image_item = self.canvas.create_image(self.offset_x,self.offset_y,anchor='nw',image=self.tk_image)
        else:
            self.canvas.itemconfigure(self._display_image_item,image=self.tk_image)
            self.canvas.coords(self._display_image_item,self.offset_x,self.offset_y)
        if job['detect']:
            self.latest_result = (out, mask, defects)
            if job['manual']:
                self.result_label.config(text=f'{len(defects)} candidate defect(s) | ROI-limited Laplacian')
                self.status.config(text='Detection complete. Candidate boxes require human review.')
                self._manual_detection_active = False
        self._draw_roi_overlays()
        # A manual run pauses live submissions so its selected frame cannot be overwritten.
        if job['manual'] and self.live_var.get() and self.current_frame is not None:
            self._queue_render(detect=True, frame=self.current_frame)

    def run_detection(self):
        if self.current_frame is None:
            messagebox.showwarning('Detection','Start a camera first.')
            return
        if self._manual_detection_active:
            return
        self._manual_detection_active = True
        self.status.config(text='Detection running in background…')
        self._queue_render(detect=True, manual=True, frame=self.current_frame)

    def _render_given(self, frame):
        # Compatibility hook: renders asynchronously, without blocking the UI.
        self.current_frame = frame
        self._queue_render(detect=False, frame=frame)

    def _draw_roi_overlays(self):
        if self.current_frame is None:
            return
        for item_id in self._overlay_item_ids:
            try: self.canvas.delete(item_id)
            except Exception: pass
        self._overlay_item_ids = []
        def xy(p): return self.offset_x+p[0]*self.scale,self.offset_y+p[1]*self.scale
        if self.inspection_roi:
            kind,c=self.inspection_roi
            if kind in ('Rectangle','Ellipse'):
                x1,y1=xy((c[0],c[1])); x2,y2=xy((c[2],c[3]))
                self._overlay_item_ids.append(self.canvas.create_rectangle(x1,y1,x2,y2,outline='#00ff88',width=2,dash=(6,3)))
            elif kind=='Polygon':
                pts=[xy(p) for p in c]; flat=[v for p in pts for v in p]
                self._overlay_item_ids.append(self.canvas.create_polygon(*flat,outline='#00ff88',fill='',width=2,dash=(6,3)))
        for m in self.masks:
            if not m['enabled']:
                continue
            c=m['coords']; kind=m['shape']
            if kind=='Polygon':
                pts=[xy(p) for p in c]; flat=[v for p in pts for v in p]
                self._overlay_item_ids.append(self.canvas.create_polygon(*flat,outline='#ff4444',fill='',width=2,dash=(5,3)))
            else:
                x1,y1=xy((c[0],c[1])); x2,y2=xy((c[2],c[3]))
                fn=self.canvas.create_oval if kind=='Ellipse' else self.canvas.create_rectangle
                self._overlay_item_ids.append(fn(x1,y1,x2,y2,outline='#ff4444',width=2,dash=(5,3)))

    def _canvas_to_image(self,x,y):
        return int((x-self.offset_x)/max(self.scale,1e-6)),int((y-self.offset_y)/max(self.scale,1e-6))
    def _draw_start(self,event):
        if self.current_frame is None:return
        self.drawing=True; self.draw_start=self._canvas_to_image(event.x,event.y); self.preview_shape=None
        if self._preview_shape_item_id is not None:
            self.canvas.delete(self._preview_shape_item_id); self._preview_shape_item_id=None
    def _draw_drag(self,event):
        if not self.drawing or not self.draw_start:return
        # Pointer motion updates only the temporary vector; no detector/resize is launched.
        if self._preview_shape_item_id is not None:
            self.canvas.delete(self._preview_shape_item_id); self._preview_shape_item_id=None
        x1,y1=self.offset_x+self.draw_start[0]*self.scale,self.offset_y+self.draw_start[1]*self.scale
        x2,y2=event.x,event.y; kind=self.shape_var.get(); fn=self.canvas.create_oval if kind=='Ellipse' else self.canvas.create_rectangle
        if kind=='Polygon': self._preview_shape_item_id=self.canvas.create_text(x2,y2,text='Polygon drawing: drag creates bounding polygon',fill='#ff6666')
        else: self._preview_shape_item_id=fn(x1,y1,x2,y2,outline='#ffff00',width=2,dash=(4,3))
    def _draw_end(self,event):
        if not self.drawing or not self.draw_start:return
        self.drawing=False
        if self._preview_shape_item_id is not None:
            self.canvas.delete(self._preview_shape_item_id); self._preview_shape_item_id=None
        p1=self.draw_start; p2=self._canvas_to_image(event.x,event.y); h,w=self.current_frame.shape[:2]
        x1=max(0,min(w-1,p1[0])); x2=max(0,min(w-1,p2[0])); y1=max(0,min(h-1,p1[1])); y2=max(0,min(h-1,p2[1]))
        if abs(x2-x1)<3 or abs(y2-y1)<3:return
        coords=(min(x1,x2),min(y1,y2),max(x1,x2),max(y1,y2)); kind=self.shape_var.get()
        if kind=='Polygon': kind='Polygon'; coords=[(coords[0],coords[1]),(coords[2],coords[1]),(coords[2],coords[3]),(coords[0],coords[3])]
        if self.roi_tool.get()=='Inspection ROI': self.inspection_roi=(kind,coords)
        else:
            self.mask_counter+=1; self.masks.append({'name':f'Mask {self.mask_counter}','shape':kind,'coords':coords,'enabled':True}); self._refresh_mask_list()
        self.render_current()
    def _refresh_mask_list(self):
        self.mask_list.delete(0,'end')
        for m in self.masks:self.mask_list.insert('end',f"☑ {m['name']} — {m['shape']}")
    def delete_mask(self):
        sel=self.mask_list.curselection()
        if sel:self.masks.pop(sel[0]); self._refresh_mask_list(); self.render_current()
    def clear_rois(self): self.inspection_roi=None; self.masks=[]; self._refresh_mask_list(); self.render_current()
    def save_rois(self):
        if self.current_frame is None: return
        path=filedialog.asksaveasfilename(defaultextension='.json',initialdir=str(ROOT_DIR/'profiles'),filetypes=[('JSON','*.json')])
        if not path:return
        Path(path).parent.mkdir(parents=True,exist_ok=True)
        data={'view':self.view_var.get(),'stitch_mode':self.stitch_var.get(),'image_size':list(self.current_frame.shape[:2][::-1]),'inspection_roi':self.inspection_roi,'masks':self.masks}
        with open(path,'w',encoding='utf-8') as f:json.dump(data,f,indent=2)
        self.status.config(text=f'ROI profile saved: {path}')
    def capture(self):
        frame=self._get_frame()
        if frame is None:
            messagebox.showwarning('Capture','No fresh camera frame available.')
            return
        self.current_frame=frame
        CAPTURE_DIR.mkdir(exist_ok=True)
        path=CAPTURE_DIR/f"phone_{time.strftime('%Y%m%d_%H%M%S')}_{self.view_var.get().lower().replace(' ','_')}.png"
        self.status.config(text='Saving captured frame in background…')
        self.render_current()
        def worker():
            try:
                if not cv2.imwrite(str(path), frame):
                    raise IOError(f'Could not save capture: {path}')
                self._log('INFO',f'Captured full frame: {path.name}')
            except Exception as exc:
                self._log('ERROR',f'Capture save failed: {exc}')
        threading.Thread(target=worker,daemon=True,name='capture-save').start()

    def save_result(self):
        if not self.latest_result:
            messagebox.showinfo('Save result','Run detection first.')
            return
        path=filedialog.asksaveasfilename(defaultextension='.png',filetypes=[('PNG','*.png')])
        if not path:
            return
        out,mask,defects=self.latest_result
        # Keep references to these completed arrays while the worker writes the files.
        result_path=Path(path)
        self.status.config(text='Saving detection result in background…')
        def worker():
            try:
                if not cv2.imwrite(str(result_path),out):
                    raise IOError(f'Could not save result: {result_path}')
                if mask is not None:
                    if not cv2.imwrite(str(result_path.with_name(result_path.stem+'_mask.png')),mask):
                        raise IOError('Could not save detection mask')
                payload={'defects':[{'x':x,'y':y,'w':w,'h':h,'area_px':a} for x,y,w,h,a in defects]}
                result_path.with_suffix('.json').write_text(json.dumps(payload,indent=2),encoding='utf-8')
                self._log('INFO',f'Detection result saved: {result_path}')
            except Exception as exc:
                self._log('ERROR',f'Result save failed: {exc}')
        threading.Thread(target=worker,daemon=True,name='result-save').start()
    def _wheel_zoom(self,event):
        # Fit-to-window is intentional; zooming is not allowed to crop the live feed unexpectedly.
        return
    def _tick(self):
        if self._closing:
            return
        if self.running and self.cameras is not None:
            try:
                pair = self.cameras.latest(self.stitch_var.get())
                t1 = pair.camera1.timestamp if pair.camera1 else None
                t2 = pair.camera2.timestamp if pair.camera2 else None
                view = self.view_var.get()
                times = (t1,) if view == 'Camera 1' else ((t2,) if view == 'Camera 2' else (t1,t2))
                signature = (view, self.stitch_var.get(), times)
                if signature != self._frame_signature:
                    self._frame_signature = signature
                    frame = self._get_frame(pair)
                    if frame is not None:
                        if self.current_frame is None or frame.shape[:2] != self.current_frame.shape[:2]:
                            if self.current_frame is not None and (self.inspection_roi or self.masks):
                                self.inspection_roi=None; self.masks=[]; self._refresh_mask_list()
                                self.status.config(text='Frame size changed: ROIs cleared; redraw them for the new image size.')
                        self.current_frame = frame
                        if not self._manual_detection_active:
                            self._queue_render(detect=bool(self.live_var.get()), frame=frame)
            except Exception as exc:
                self._log('WARN', f'Live preview: {exc}')
        if not self._closing:
            self.root.after(30, self._tick)

    def close(self):
        if self._closing:
            return
        self._closing = True
        try:
            if self._drain_after_id is not None:
                self.root.after_cancel(self._drain_after_id)
        except Exception:
            pass
        manager = self.cameras
        if manager is not None:
            threading.Thread(target=manager.stop, daemon=True, name='camera-shutdown').start()
        self.root.destroy()


def main():
    root=tk.Tk(); MergedInspectionApp(root); root.mainloop()
if __name__=='__main__':main()
