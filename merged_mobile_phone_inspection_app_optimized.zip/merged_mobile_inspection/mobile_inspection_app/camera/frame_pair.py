from __future__ import annotations
from dataclasses import dataclass
from typing import Callable
import cv2
import numpy as np

@dataclass
class TimedFrame:
    image: np.ndarray
    timestamp: float
    camera_index: int

@dataclass
class FramePair:
    camera1: TimedFrame | None
    camera2: TimedFrame | None
    stitch_mode: str = "Aligned side-by-side"
    stitch_message: str = ""
    _homography: np.ndarray | None = None
    _locked: bool = False
    _on_homography: Callable[[np.ndarray], None] | None = None

    def stitched(self, mode: str | None = None) -> np.ndarray | None:
        mode = mode or self.stitch_mode
        a = self.camera1.image if self.camera1 else None
        b = self.camera2.image if self.camera2 else None
        if a is None: return b.copy() if b is not None else None
        if b is None: return a.copy()
        if mode == "Vertical aligned join":
            target_w = max(a.shape[1], b.shape[1])
            aa = cv2.resize(a, (target_w, int(a.shape[0]*target_w/a.shape[1])))
            bb = cv2.resize(b, (target_w, int(b.shape[0]*target_w/b.shape[1])))
            return np.vstack([aa, bb])
        if mode == "Auto feature stitch":
            try:
                if self._homography is None:
                    gray_a, gray_b = cv2.cvtColor(a, cv2.COLOR_BGR2GRAY), cv2.cvtColor(b, cv2.COLOR_BGR2GRAY)
                    orb = cv2.ORB_create(1200)
                    k1,d1 = orb.detectAndCompute(gray_a,None); k2,d2 = orb.detectAndCompute(gray_b,None)
                    if d1 is None or d2 is None: raise ValueError("insufficient feature descriptors")
                    matches = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True).match(d1,d2)
                    matches = sorted(matches,key=lambda m:m.distance)[:300]
                    if len(matches)<12: raise ValueError("insufficient overlap texture")
                    src=np.float32([k2[m.trainIdx].pt for m in matches]).reshape(-1,1,2)
                    dst=np.float32([k1[m.queryIdx].pt for m in matches]).reshape(-1,1,2)
                    H, inliers=cv2.findHomography(src,dst,cv2.RANSAC,4.0)
                    if H is None or int(inliers.sum())<8: raise ValueError("homography estimation failed")
                    self._homography=H
                    if self._on_homography is not None: self._on_homography(H.copy())
                # Warp B into A's coordinate system, then translate the union into positive canvas coords.
                h1,w1=a.shape[:2]; h2,w2=b.shape[:2]
                corners_b=np.float32([[0,0],[w2,0],[w2,h2],[0,h2]]).reshape(-1,1,2)
                projected=cv2.perspectiveTransform(corners_b,self._homography).reshape(-1,2)
                corners_a=np.float32([[0,0],[w1,0],[w1,h1],[0,h1]])
                all_corners=np.vstack([corners_a,projected])
                min_xy=np.floor(all_corners.min(axis=0)).astype(int); max_xy=np.ceil(all_corners.max(axis=0)).astype(int)
                out_w=max(1,int(max_xy[0]-min_xy[0])); out_h=max(1,int(max_xy[1]-min_xy[1]))
                T=np.array([[1,0,-min_xy[0]],[0,1,-min_xy[1]],[0,0,1]],dtype=np.float64)
                warped_b=cv2.warpPerspective(b,T@self._homography,(out_w,out_h))
                warped_a=cv2.warpPerspective(a,T,(out_w,out_h))
                mask_a=cv2.warpPerspective(np.ones((h1,w1),np.uint8)*255,T,(out_w,out_h))>0
                mask_b=cv2.warpPerspective(np.ones((h2,w2),np.uint8)*255,T@self._homography,(out_w,out_h))>0
                canvas=np.zeros((out_h,out_w,3),np.uint8)
                canvas[mask_a]=warped_a[mask_a]; canvas[mask_b]=warped_b[mask_b]
                overlap=mask_a&mask_b
                if overlap.any():
                    blend=((warped_a.astype(np.float32)+warped_b.astype(np.float32))/2).astype(np.uint8)
                    canvas[overlap]=blend[overlap]
                self.stitch_message=f"ORB/RANSAC stitch; {int(inliers.sum())} inliers"
                return canvas
            except Exception as exc:
                self.stitch_message=f"Auto stitch fallback: {exc}; aligned join used"
        # Aligned side-by-side: resize only to common height, preserving aspect ratio.
        h=max(a.shape[0],b.shape[0])
        aa=cv2.resize(a,(int(a.shape[1]*h/a.shape[0]),h)) if a.shape[0]!=h else a
        bb=cv2.resize(b,(int(b.shape[1]*h/b.shape[0]),h)) if b.shape[0]!=h else b
        # Preserve raw pixel values. Automatic exposure matching here modified the
        # right image on every preview frame, cost two Lab conversions plus a full
        # float-frame pass, and could hide real illumination defects. Any seam
        # matching should be an explicit preview-only option, never part of the
        # inspection image by default.
        self.stitch_message = "Aligned side-by-side; raw intensities preserved; no metric calibration implied"
        return np.hstack([aa,bb])
