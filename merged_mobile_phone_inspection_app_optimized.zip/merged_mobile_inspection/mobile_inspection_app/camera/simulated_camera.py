from __future__ import annotations

import time
import cv2
import numpy as np
from mobile_inspection_app.interfaces import CameraBackend


class SimulatedCamera(CameraBackend):
    """FPS-paced synthetic phone view used for UI and pipeline testing.

    The original simulator regenerated coordinate grids, illumination and all static
    drawing primitives on every read, and returned as fast as the CPU allowed. Two
    simulator streams could consequently saturate the CPU and make the Tk UI lag.
    Static scene variants are now rendered once per settings change and read() is
    paced to the configured frame rate, like a physical camera.
    """

    def __init__(self, camera_index: int = 0, width: int = 960, height: int = 720):
        self.camera_index = camera_index
        self.width, self.height = int(width), int(height)
        self.exposure_us, self.gain, self.fps = 10000.0, 0.0, 20.0
        self._open = False
        self._running = False
        self._started = time.monotonic()
        self._frame_no = 0
        self._next_frame_time = 0.0
        self._scene_frames: tuple[np.ndarray, np.ndarray] | None = None
        self._scene_shape: tuple[int, int] | None = None

    def open(self) -> None:
        self._open = True

    def apply_settings(self, exposure_us: float, gain: float, fps: float, width: int, height: int, full_sensor: bool = True) -> None:
        self.exposure_us, self.gain, self.fps = float(exposure_us), float(gain), max(1.0, float(fps))
        self.width, self.height = max(160, int(width)), max(120, int(height))
        self._prepare_scene()

    def start(self) -> None:
        if not self._open:
            self.open()
        if self._scene_frames is None or self._scene_shape != (self.height, self.width):
            self._prepare_scene()
        self._running = True
        self._started = time.monotonic()
        self._next_frame_time = self._started

    def _prepare_scene(self) -> None:
        self._scene_frames = (self._render_scene(0), self._render_scene(1))
        self._scene_shape = (self.height, self.width)

    def _render_scene(self, phase: int) -> np.ndarray:
        h, w = self.height, self.width
        # Static broad illumination gradient is computed only when scene/settings change.
        y = np.arange(h, dtype=np.float32)[:, None]
        x = np.arange(w, dtype=np.float32)[None, :]
        light = 0.78 + 0.20 * (x / max(w - 1, 1)) + 0.04 * np.sin(y / max(h, 1) * np.pi)
        base_color = (37, 42, 47) if self.camera_index == 0 else (42, 39, 36)
        img = np.empty((h, w, 3), np.uint8)
        for channel, value in enumerate(base_color):
            img[:, :, channel] = np.clip(value * light, 0, 255).astype(np.uint8)

        # The simulated phone body and features stay fixed between frames.
        cx, cy = int(w * (0.51 if self.camera_index == 0 else 0.47)), int(h * .52)
        pw, ph = int(w * .38), int(h * .82)
        outer = (cx - pw // 2, cy - ph // 2, cx + pw // 2, cy + ph // 2)
        cv2.rectangle(img, (outer[0] + 20, outer[1]), (outer[2] - 20, outer[3]), (78, 82, 87), -1)
        cv2.ellipse(img, (cx, outer[1] + 20), (pw // 2 - 20, 23), 0, 180, 360, (78, 82, 87), -1)
        cv2.ellipse(img, (cx, outer[3] - 20), (pw // 2 - 20, 23), 0, 0, 180, (78, 82, 87), -1)
        margin = max(5, int(w * .012))
        inner = (outer[0] + margin * 2, outer[1] + margin * 2, outer[2] - margin * 2, outer[3] - margin * 2)
        cv2.rectangle(img, (inner[0] + 16, inner[1]), (inner[2] - 16, inner[3]), (111, 116, 120), -1)
        cv2.ellipse(img, (cx, inner[1] + 16), (max(1, (inner[2] - inner[0]) // 2 - 16), 15), 0, 180, 360, (111, 116, 120), -1)
        cv2.ellipse(img, (cx, inner[3] - 16), (max(1, (inner[2] - inner[0]) // 2 - 16), 15), 0, 0, 180, (111, 116, 120), -1)
        cv2.rectangle(img, (inner[0] + 16, inner[1] + 20), (inner[2] - 16, inner[3] - 20), (127, 130, 132), -1)
        cv2.rectangle(img, (inner[0] + 16, inner[1] + 20), (inner[0] + 26, inner[3] - 20), (91, 96, 100), -1)
        cv2.rectangle(img, (inner[2] - 27, inner[1] + 20), (inner[2] - 16, inner[3] - 20), (151, 154, 155), -1)

        bump_x, bump_y = outer[0] + int(pw * .27), outer[1] + int(ph * .15)
        cv2.rectangle(img, (bump_x - 5, bump_y - 5), (bump_x + int(pw * .34), bump_y + int(pw * .30)), (54, 58, 62), -1)
        rr = max(5, int(w * .013))
        for dx, dy in [(0, 0), (rr * 2, 0), (0, rr * 2)]:
            cv2.circle(img, (bump_x + dx + rr, bump_y + dy + rr), rr, (24, 27, 30), -1, cv2.LINE_AA)
            cv2.circle(img, (bump_x + dx + rr - 2, bump_y + dy + rr - 2), max(2, rr // 3), (87, 104, 119), -1, cv2.LINE_AA)
        cv2.circle(img, (bump_x + rr * 4, bump_y + rr * 4), max(3, rr // 2), (185, 175, 143), -1)

        if self.camera_index == 0:
            cv2.line(img, (cx - int(pw * .28), cy + int(ph * .13)), (cx - int(pw * .20), cy + int(ph * .18)), (48, 49, 50), 2, cv2.LINE_AA)
            if phase == 0:
                cv2.circle(img, (cx + int(pw * .16), cy - int(ph * .14)), 5, (55, 56, 58), -1)
        else:
            cv2.line(img, (cx + int(pw * .09), cy + int(ph * .22)), (cx + int(pw * .24), cy + int(ph * .25)), (63, 65, 67), 2, cv2.LINE_AA)
        return img

    def read(self, timeout_ms: int = 1000) -> np.ndarray | None:
        if not self._running:
            return None
        period = 1.0 / max(1.0, float(self.fps))
        now = time.monotonic()
        delay = self._next_frame_time - now
        if delay > 0:
            # Pacing is essential: do not let the simulator spin at 100% CPU.
            time.sleep(delay)
        now = time.monotonic()
        if now - self._next_frame_time > period * 3:
            self._next_frame_time = now
        self._next_frame_time += period
        phase = self._frame_no % 2
        self._frame_no += 1
        frames = self._scene_frames
        if frames is None:
            self._prepare_scene()
            frames = self._scene_frames
        return frames[phase].copy()

    def stop(self) -> None:
        self._running = False

    def close(self) -> None:
        self.stop()
        self._open = False
