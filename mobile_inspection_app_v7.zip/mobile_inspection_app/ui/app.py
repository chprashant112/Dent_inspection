from __future__ import annotations

import json
import threading
from pathlib import Path
import tkinter as tk
from tkinter import ttk, messagebox

import cv2
import numpy as np
from PIL import Image, ImageTk

from ..config import AppConfig, TestingProfile, save_profile, load_profile
from ..camera import CameraManager
from ..capture import CaptureManager
from ..detection import discover_algorithms
from ..pipeline import TestingService
from ..dataset import save_approved_defects
from ..segmentation import SegmentationRegistry
from .theme import BG, configure_style
from .widgets import ScrollableFrame, ImageViewer
from .panels.camera_panel import CameraPanel
from .panels.lighting_panel import LightingPanel
from .panels.capture_panel import CapturePanel
from .panels.testing_panel import TestingPanel
from .panels.detection_mode_panel import DetectionModePanel
from .panels.log_panel import LogPanel


class Application(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Mobile Vision Inspection · V7")
        self.minsize(1180, 760)
        self.configure(bg=BG)
        self.protocol("WM_DELETE_WINDOW", self._close)
        configure_style(self)

        self.config_data = AppConfig()
        self.camera_manager = CameraManager()
        self.registry = discover_algorithms(Path("algorithms"), logger=self._plugin_log)
        self.testing_service = TestingService(self.config_data.analysis)
        self.seg_registry = SegmentationRegistry()
        self._last_frame = None
        self._running = False
        self._capture_busy = False
        self._mode = tk.StringVar(value="Testing Mode")
        self._live_segmentation_token = 0
        self._live_detection_token = 0

        self._build_ui()
        self.profile = load_profile()
        self.profile_path = Path("profiles/last_testing_profile.json") if self.profile else None
        self.detection_mode_panel.set_profile(self.profile)

    @property
    def is_camera_running(self):
        return bool(self._running)

    def _plugin_log(self, line):
        if hasattr(self, "log_panel"):
            self.after(0, lambda l=line: self.log_panel.log(l))

    def _build_ui(self):
        root = ttk.Frame(self, style="App.TFrame")
        root.pack(fill="both", expand=True)

        header = ttk.Frame(root, style="Header.TFrame", padding=(18, 12))
        header.pack(fill="x")
        header.columnconfigure(1, weight=1)
        ttk.Label(header, text="MOBILE VISION INSPECTION", style="Title.TLabel").grid(row=0, column=0, sticky="w")
        ttk.Label(header, text="Camera · Lighting · Capture · Testing / Detection", style="Sub.TLabel").grid(row=1, column=0, sticky="w")
        ttk.Label(header, text="MODEL", style="Mini.TLabel").grid(row=0, column=2, sticky="e")
        self.model_var = tk.StringVar(value=self.config_data.model_name)
        ttk.Entry(header, textvariable=self.model_var, width=15).grid(row=1, column=2, sticky="e")
        ttk.Button(header, text="SAVE", style="Neutral.TButton", command=self.save_model).grid(row=1, column=3, padx=7)
        ttk.Label(header, text="MODE", style="Mini.TLabel").grid(row=0, column=4, sticky="e")
        ttk.Combobox(header, textvariable=self._mode, values=("Testing Mode", "Detection Mode"), state="readonly", width=17).grid(row=1, column=4, sticky="e")
        self._mode_widget = header.grid_slaves(row=1, column=4)[0]
        self._mode_widget.bind("<<ComboboxSelected>>", lambda _e: self.switch_mode())

        body = ttk.Frame(root, style="App.TFrame", padding=10)
        body.pack(fill="both", expand=True)
        body.columnconfigure(0, weight=7)
        body.columnconfigure(1, weight=3)
        body.rowconfigure(0, weight=1)

        left = ttk.Frame(body, style="App.TFrame")
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 10))
        left.columnconfigure(0, weight=1)
        left.rowconfigure(0, weight=7)
        left.rowconfigure(1, weight=3)

        pf = ttk.LabelFrame(left, text="LIVE VIEW")
        pf.grid(row=0, column=0, sticky="nsew")
        self.preview = ImageViewer(pf, text="Start camera(s)")
        self.preview.pack(fill="both", expand=True, padx=5, pady=5)

        rf = ttk.LabelFrame(left, text="ANALYSIS / INSPECTION")
        rf.grid(row=1, column=0, sticky="nsew", pady=(10, 0))
        self.viewer_nb = ttk.Notebook(rf)
        self.viewer_nb.pack(fill="both", expand=True, padx=4, pady=4)
        self.viewers = {}
        for name in ("Result", "Heatmap", "Histogram", "Segments", "Inspection Mask"):
            frame = ttk.Frame(self.viewer_nb)
            frame.pack(fill="both", expand=True)
            lab = ImageViewer(frame, text=name)
            lab.pack(fill="both", expand=True)
            self.viewers[name] = lab
            self.viewer_nb.add(frame, text=name)

        right = ScrollableFrame(body)
        right.grid(row=0, column=1, sticky="nsew")
        right.inner.columnconfigure(0, weight=1)

        self.log_panel = LogPanel(right.inner)
        self.camera_panel = CameraPanel(
            right.inner, self.camera_manager, self.config_data.camera1, self.config_data.camera2,
            self.log_panel.log, self._camera_started, self._camera_stopped,
        )
        self.camera_panel.pack(fill="x", pady=(0, 8))
        self.lighting_panel = LightingPanel(
            right.inner, self.config_data.lighting_topology, self.config_data.lighting_baudrate,
            self.config_data.capture.settle_ms, self.log_panel.log, self._light_changed,
        )
        self.lighting_panel.pack(fill="x", pady=(0, 8))
        self.capture_panel = CapturePanel(right.inner, self.capture_set)
        self.capture_panel.pack(fill="x", pady=(0, 8))
        self.testing_panel = TestingPanel(right.inner, self, self.log_panel.log)
        self.testing_panel.pack(fill="x", pady=(0, 8))
        self.testing_panel.set_algorithms(self.registry.names())
        self.detection_mode_panel = DetectionModePanel(right.inner, self, self.log_panel.log)
        self.detection_mode_panel.pack_forget()
        self.switch_mode()

    def _light_changed(self, engine):
        if hasattr(self, "capture_manager"):
            self.capture_manager.light_engine = engine

    def _camera_started(self):
        self._running = True
        self._tick_preview()

    def _camera_stopped(self):
        self._running = False
        self.preview.configure(image="", text="Camera stopped")
        if self.testing_panel.live_segmentation_var.get():
            self.testing_panel.live_segmentation_var.set(False)
            self.stop_live_segmentation(self.testing_panel)
        if self.testing_panel.live_detection_var.get():
            self.testing_panel.live_detection_var.set(False)
            self.stop_live_detection(self.testing_panel)

    def _tick_preview(self):
        if not self._running:
            return
        pair = self.camera_manager.latest()
        frame = pair.stitched()
        view = self.camera_panel.selected_view
        if view == "Camera 1":
            frame = pair.camera1
        elif view == "Camera 2":
            frame = pair.camera2
        if frame is not None:
            self._last_frame = frame.copy()
            self._show(self.preview, frame, 1600, 900)
        self.after(40, self._tick_preview)

    def _show(self, label, frame, max_w=1000, max_h=420):
        if frame is None:
            label.configure(image="", text="No image")
            return
        h, w = frame.shape[:2]
        s = min(max_w / w, max_h / h, 1.0)
        img = cv2.resize(frame, (max(1, int(w * s)), max(1, int(h * s))), interpolation=cv2.INTER_AREA) if s < 1 else frame
        img = Image.fromarray(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
        photo = ImageTk.PhotoImage(img)
        label.configure(image=photo, text="")
        label._photo = photo

    def show_result_image(self, img): self._show(self.viewers["Result"], img)
    def show_heatmap(self, img): self._show(self.viewers["Heatmap"], img)
    def show_histogram(self, img): self._show(self.viewers["Histogram"], img)
    def show_segments(self, img): self._show(self.viewers["Segments"], img)
    def show_inspection_mask(self, img): self._show(self.viewers["Inspection Mask"], img)

    def select_result_view(self): self.viewer_nb.select(0)
    def select_segments_view(self): self.viewer_nb.select(3)
    def select_mask_view(self): self.viewer_nb.select(4)

    def switch_mode(self):
        if self._mode.get() == "Testing Mode":
            self.detection_mode_panel.pack_forget()
            self.testing_panel.pack(fill="x", pady=(0, 8))
        else:
            self.testing_panel.pack_forget()
            self.detection_mode_panel.pack(fill="x", pady=(0, 8))

    def refresh_algorithms(self):
        self.registry = discover_algorithms(Path("algorithms"), logger=self._plugin_log)
        self.testing_panel.set_algorithms(
            self.registry.names(),
            self.testing_panel.alg_name.get() if self.testing_panel.alg_name.get() in self.registry.names() else None,
        )
        self.detection_mode_panel.set_profile(self.profile)
        self.log_panel.log(f"INFO: algorithms refreshed: {self.registry.names()}")

    def save_model(self):
        self.config_data.model_name = self.model_var.get().strip()
        self.log_panel.log(f"INFO: model = {self.config_data.model_name}")

    def capture_set(self):
        if self._capture_busy:
            return
        if not self._running:
            messagebox.showwarning("Capture", "Start camera(s) first.")
            return
        self._capture_busy = True
        self.capture_panel.status.set("Capturing selected set…")

        def work():
            try:
                a = self.lighting_panel.recipes('a')
                b = self.lighting_panel.recipes('b') if self.lighting_panel.is_dual() else a
                selected = [i for i, r in enumerate(a) if r.enabled and (not self.lighting_panel.is_dual() or b[i].enabled)]
                self.capture_manager = CaptureManager(self.camera_manager, self.lighting_panel.engine, self.config_data.capture, self.log_panel.log)
                out, _ = self.capture_manager.capture_selected(self.model_var.get(), a, b, selected)
                self.after(0, lambda: self.capture_panel.status.set(f"Saved set → {out}"))
            except Exception as exc:
                self.after(0, lambda e=exc: messagebox.showerror("Capture", str(e)))
            finally:
                self._capture_busy = False

        threading.Thread(target=work, daemon=True).start()

    def capture_test_image(self, idx, source, callback):
        if not self._running:
            messagebox.showwarning("Testing", "Start camera(s) first.")
            return

        def work():
            try:
                a = self.lighting_panel.recipes('a')
                b = self.lighting_panel.recipes('b') if self.lighting_panel.is_dual() else a
                i = max(1, min(4, int(idx))) - 1
                cm = CaptureManager(self.camera_manager, self.lighting_panel.engine, self.config_data.capture, self.log_panel.log)
                path, img = cm.capture_single(self.model_var.get(), a[i], b[i] if self.lighting_panel.is_dual() else None, source)
                self.after(0, lambda p=path, im=img, ln=a[i].name: callback(p, im, ln))
            except Exception as exc:
                self.after(0, lambda e=exc: messagebox.showerror("Test capture", str(e)))

        threading.Thread(target=work, daemon=True).start()

    # ---------------------------- single-image testing ----------------------------
    def _build_selected_mask(self, effective, seg_result, ids):
        selected = np.zeros_like(effective, np.uint8)
        for seg in seg_result.segments:
            if seg.id in ids:
                selected[seg.mask > 0] = 255
        selected = cv2.bitwise_and(selected, effective)
        return selected

    def analyze_testing(self, panel):
        if panel.image is None or panel.roi is None:
            messagebox.showwarning("Testing", "Capture/load an image and draw ROI first.")
            return

        image = panel.image.copy()
        roi, mask_roi, camera_rect = panel.roi, panel.mask_roi, panel.camera_rect
        seg_name = panel.seg_name.get()
        sam_path = panel.sam_path.get()

        def work():
            try:
                analysis = self.testing_service.analyze(image, roi, mask_roi)
                backend = self.seg_registry.create(seg_name, checkpoint_path=sam_path, camera_rect=camera_rect)
                seg_result = backend.segment(image, analysis.effective_mask)
                self.after(0, lambda: self._finish_testing_analysis(panel, analysis, seg_result))
            except Exception as exc:
                self.after(0, lambda e=exc: messagebox.showerror("Analysis / segmentation", str(e)))

        threading.Thread(target=work, daemon=True).start()

    def _finish_testing_analysis(self, panel, analysis, seg_result):
        panel.analysis = analysis
        panel.segment_result = seg_result
        panel.populate_segments(preserve=False)
        self.show_heatmap(analysis.illumination.heatmap)
        self.show_histogram(analysis.histogram_image)
        self.show_segments(seg_result.overlay)
        self.update_selected_mask(panel)
        self.select_segments_view()
        self.log_panel.log(f"INFO: segmentation = {seg_result.backend}: {seg_result.message}")
        panel.metrics.set(
            f"Illumination: {analysis.illumination.message}\n"
            f"Histogram L*: mean={analysis.histogram_metrics['mean']:.1f}, std={analysis.histogram_metrics['std']:.1f}\n"
            f"Segmentation: {seg_result.backend}"
        )

    def update_selected_mask(self, panel):
        if panel.segment_result is None:
            return
        ids = panel.selected_ids()
        if not ids:
            self.show_inspection_mask(panel.image)
            return
        if panel.analysis is not None:
            eff = panel.analysis.effective_mask
        else:
            # Live segmentation can be displayed before a fresh static analysis exists.
            eff = np.zeros(panel.segment_result.segments[0].mask.shape, np.uint8)
            for s in panel.segment_result.segments:
                eff = cv2.bitwise_or(eff, s.mask)
        mask = self._build_selected_mask(eff, panel.segment_result, ids)
        base = panel.image if panel.image is not None else self._last_frame
        if base is None:
            return
        visual = base.copy()
        idx = mask > 0
        if np.any(idx):
            layer = np.zeros_like(visual); layer[:] = (40, 220, 80)
            visual[idx] = (visual[idx].astype(np.float32) * 0.55 + layer[idx].astype(np.float32) * 0.45).astype(np.uint8)
            contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            cv2.drawContours(visual, contours, -1, (40, 255, 80), 2)
        self.show_inspection_mask(visual)

    def run_testing_detection(self, panel, image, effective, seg_result, ids, alg_name):
        if alg_name not in self.registry.names():
            messagebox.showerror("Detection", "No external algorithm selected.")
            return
        final = self._build_selected_mask(effective, seg_result, ids)
        self.show_inspection_mask(self._mask_overlay(image, final))
        self.select_mask_view()

        def work():
            try:
                detector = self.registry.create(alg_name)
                result = detector.process(image, final, context={"mode": "testing", "selected_segments": ids})
                self.after(0, lambda r=result: panel.show_detection_result(r, live=False))
                self.after(0, lambda: self.log_panel.log(f"INFO: {result.algorithm}: {result.message}"))
            except Exception as exc:
                self.after(0, lambda e=exc: messagebox.showerror("Detection", str(e)))

        threading.Thread(target=work, daemon=True).start()

    def _mask_overlay(self, image, mask):
        visual = image.copy()
        idx = mask > 0
        if np.any(idx):
            layer = np.zeros_like(visual); layer[:] = (40, 220, 80)
            visual[idx] = (visual[idx].astype(np.float32) * 0.58 + layer[idx].astype(np.float32) * 0.42).astype(np.uint8)
        cv2.putText(visual, "DETECTION AREA", (18, 32), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (40, 255, 80), 2, cv2.LINE_AA)
        return visual

    # ---------------------------- live segmentation -----------------------------
    def start_live_segmentation(self, panel):
        self._live_segmentation_token += 1
        token = self._live_segmentation_token
        self.log_panel.log("INFO: live segmentation started")
        self._schedule_live_segmentation(panel, token, immediate=True)

    def stop_live_segmentation(self, panel):
        self._live_segmentation_token += 1
        panel._live_seg_busy = False
        if panel.live_detection_var.get():
            panel.live_detection_var.set(False)
            self.stop_live_detection(panel)
        self.log_panel.log("INFO: live segmentation stopped")

    def _schedule_live_segmentation(self, panel, token, immediate=False):
        if not panel.live_segmentation_var.get() or token != self._live_segmentation_token or not self._running:
            return
        delay = 50 if immediate else 550
        if panel._live_seg_busy:
            self.after(delay, lambda: self._schedule_live_segmentation(panel, token))
            return
        frame = None if self._last_frame is None else self._last_frame.copy()
        if frame is None or panel.roi is None:
            self.after(delay, lambda: self._schedule_live_segmentation(panel, token))
            return
        panel._live_seg_busy = True
        roi, mask_roi = panel.roi, panel.mask_roi
        camera_rect = panel.camera_rect
        seg_name, sam_path = panel.seg_name.get(), panel.sam_path.get()

        def work():
            try:
                analysis = self.testing_service.analyze(frame, roi, mask_roi)
                backend = self.seg_registry.create(seg_name, checkpoint_path=sam_path, camera_rect=camera_rect)
                seg_result = backend.segment(frame, analysis.effective_mask)
                self.after(0, lambda: self._finish_live_segmentation(panel, analysis, seg_result, token, frame))
            except Exception as exc:
                self.after(0, lambda e=exc: self._live_seg_error(panel, e, token))

        threading.Thread(target=work, daemon=True).start()

    def _finish_live_segmentation(self, panel, analysis, seg_result, token, frame):
        panel._live_seg_busy = False
        if not panel.live_segmentation_var.get() or token != self._live_segmentation_token:
            return
        panel.analysis = analysis
        panel.segment_result = seg_result
        panel.live_frame = frame
        panel.populate_segments(preserve=True)
        self.show_heatmap(analysis.illumination.heatmap)
        self.show_histogram(analysis.histogram_image)
        self.show_segments(seg_result.overlay)
        self.update_selected_mask(panel)
        panel.image = frame.copy()
        panel.img_status.set(f"LIVE frame | {frame.shape[1]}×{frame.shape[0]} | segmentation running")
        if panel.live_detection_var.get():
            self._run_live_detection_from_result(panel, frame, analysis, seg_result, token)
        self._schedule_live_segmentation(panel, token)

    def _live_seg_error(self, panel, exc, token):
        panel._live_seg_busy = False
        if panel.live_segmentation_var.get() and token == self._live_segmentation_token:
            self.log_panel.log(f"LIVE SEGMENT ERROR: {exc}")
            self._schedule_live_segmentation(panel, token)

    def start_live_detection(self, panel):
        if not panel.live_segmentation_var.get():
            panel.live_segmentation_var.set(True)
            self.start_live_segmentation(panel)
        self._live_detection_token += 1
        self.log_panel.log("INFO: live detection started")

    def stop_live_detection(self, panel):
        self._live_detection_token += 1
        panel._live_detect_busy = False
        self.log_panel.log("INFO: live detection stopped")

    def run_live_detection_once(self, panel):
        if not self._running or self._last_frame is None:
            messagebox.showwarning("Live detection", "Start the camera feed first.")
            return
        if panel.segment_result is None or panel.analysis is None:
            messagebox.showwarning("Live detection", "Run/enable live segmentation first.")
            return
        self._run_live_detection_from_result(panel, self._last_frame.copy(), panel.analysis, panel.segment_result, None)

    def _run_live_detection_from_result(self, panel, frame, analysis, seg_result, token):
        ids = panel.selected_ids()
        if not ids:
            return
        alg_name = panel.alg_name.get()
        if alg_name not in self.registry.names():
            return
        final = self._build_selected_mask(analysis.effective_mask, seg_result, ids)
        if panel._live_detect_busy:
            return
        panel._live_detect_busy = True
        detector = self.registry.create(alg_name)

        def work():
            try:
                result = detector.process(frame, final, context={"mode": "live", "selected_segments": ids})
                self.after(0, lambda r=result: panel.show_detection_result(r, live=True))
            except Exception as exc:
                self.after(0, lambda e=exc: self.log_panel.log(f"LIVE DETECTION ERROR: {e}"))
            finally:
                self.after(0, lambda: setattr(panel, "_live_detect_busy", False))

        threading.Thread(target=work, daemon=True).start()

    # ------------------------------ dataset/profile -----------------------------
    def save_testing_dataset(self, panel):
        if not getattr(panel, "_result", None):
            messagebox.showwarning("Dataset", "Run detection first.")
            return
        approved = [i for i, (label, v) in enumerate(panel.defect_vars.items(), 1) if v.get()]
        r = panel._result
        meta = {
            "image_path": str(panel.image_path) if panel.image_path else "",
            "roi": list(panel.roi),
            "mask_roi": None if panel.mask_roi is None else list(panel.mask_roi),
            "camera_rect": None if panel.camera_rect is None else list(panel.camera_rect),
            "effective_area_px": int((panel.analysis.effective_mask > 0).sum()) if panel.analysis else None,
            "segmentation_backend": panel.seg_name.get(),
            "selected_segments": panel.selected_ids(),
            "algorithm": r.algorithm,
            "algorithm_params": r.params,
            "approved_ids": approved,
            "model_name": self.model_var.get(),
            "light_name": panel.light_name,
        }
        try:
            base, _ = save_approved_defects("dataset", self.model_var.get(), panel.image, r.output, r.binary_mask, r.defects, meta)
            messagebox.showinfo("Dataset saved", f"Saved approved dataset unit to:\n{base}")
        except Exception as exc:
            messagebox.showerror("Dataset", str(exc))

    def save_testing_profile(self, panel):
        if panel.image is None or panel.roi is None or panel.segment_result is None:
            messagebox.showwarning("Profile", "Complete image + ROI + segmentation first.")
            return
        profile = TestingProfile(
            self.model_var.get(), panel.image.shape[1], panel.image.shape[0], tuple(panel.roi), panel.mask_roi,
            panel.seg_name.get(), panel.selected_ids(), panel.alg_name.get(), panel.source_view.get(), panel.light_name,
            panel.sam_path.get(), None, None, panel.camera_rect,
        )
        self.profile = profile
        self.profile_path = save_profile(profile)
        self.detection_mode_panel.set_profile(profile)
        messagebox.showinfo("Profile saved", f"Saved to:\n{self.profile_path}")

    # ---------------------------- detection mode -------------------------------
    def capture_and_inspect(self, panel):
        if not self.profile:
            messagebox.showwarning("Detection Mode", "Save a Testing Profile first.")
            return
        if not self._running:
            messagebox.showwarning("Detection Mode", "Start camera(s) first.")
            return
        try:
            recipes = self.lighting_panel.recipes('a')
            idx = 0
            for i, r in enumerate(recipes):
                if r.name == self.profile.light_name:
                    idx = i; break
            b = self.lighting_panel.recipes('b') if self.lighting_panel.is_dual() else recipes
            cm = CaptureManager(self.camera_manager, self.lighting_panel.engine, self.config_data.capture, self.log_panel.log)
            _p, img = cm.capture_single(self.model_var.get(), recipes[idx], b[idx] if self.lighting_panel.is_dual() else None, self.profile.source_view)
            self._inspect_with_profile(panel, img, self.profile)
        except Exception as exc:
            messagebox.showerror("Detection Mode", str(exc))

    def inspect_live(self, panel):
        if not self.profile:
            messagebox.showwarning("Detection Mode", "Save a Testing Profile first.")
            return
        if self._last_frame is None:
            messagebox.showwarning("Detection Mode", "No live frame available.")
            return
        self._inspect_with_profile(panel, self._last_frame.copy(), self.profile)

    def _inspect_with_profile(self, panel, image, profile):
        if (image.shape[1], image.shape[0]) != (profile.image_width, profile.image_height):
            messagebox.showwarning("Detection Mode", "Current image size does not match the Testing Profile.")
            return

        def work():
            try:
                analysis = self.testing_service.analyze(image, profile.roi, profile.mask_roi)
                backend = self.seg_registry.create(profile.segmentation_backend, checkpoint_path=profile.sam_checkpoint_path, camera_rect=profile.camera_rect)
                seg_res = backend.segment(image, analysis.effective_mask)
                final = self._build_selected_mask(analysis.effective_mask, seg_res, profile.selected_segments)
                detector = self.registry.create(self.detection_mode_panel.alg.get() or profile.algorithm_name)
                result = detector.process(image, final, context={"mode": "detection", "selected_segments": profile.selected_segments})
                self.after(0, lambda r=result: panel.show_result(r))
            except Exception as exc:
                self.after(0, lambda e=exc: messagebox.showerror("Detection Mode", str(e)))

        threading.Thread(target=work, daemon=True).start()

    def _close(self):
        try:
            self.testing_panel.stop_live_modes()
            self.lighting_panel.all_off()
            self.lighting_panel.disconnect()
        except Exception:
            pass
        self.camera_manager.close()
        self.destroy()
