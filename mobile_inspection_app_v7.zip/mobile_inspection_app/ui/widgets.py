from __future__ import annotations
import tkinter as tk
from tkinter import ttk
from .theme import BG

class CollapsibleCard(ttk.Frame):
    def __init__(self,master,title,open_by_default=False,**kwargs):
        super().__init__(master,style="Card.TFrame",**kwargs); self.columnconfigure(0,weight=1); self._open=tk.BooleanVar(value=open_by_default); self._title=title
        self.header=ttk.Frame(self,style="Card.TFrame"); self.header.grid(row=0,column=0,sticky="ew"); self.header.columnconfigure(0,weight=1); self.button=ttk.Button(self.header,text="",style="CardHeader.TButton",command=self.toggle); self.button.grid(row=0,column=0,sticky="ew")
        self.body=ttk.Frame(self,padding=(14,10,14,14),style="Card.TFrame");
        if open_by_default: self.body.grid(row=1,column=0,sticky="ew")
        self._refresh()
    def toggle(self):
        self._open.set(not self._open.get()); self.body.grid(row=1,column=0,sticky="ew") if self._open.get() else self.body.grid_remove(); self._refresh()
    def _refresh(self): self.button.configure(text=f"  {'▾' if self._open.get() else '▸'}   {self._title}")

class ScrollableFrame(ttk.Frame):
    def __init__(self,master,**kwargs):
        super().__init__(master,**kwargs); self.canvas=tk.Canvas(self,highlightthickness=0,borderwidth=0,bg=BG); self.scrollbar=ttk.Scrollbar(self,orient="vertical",command=self.canvas.yview); self.inner=ttk.Frame(self.canvas,style="App.TFrame"); self.window_id=self.canvas.create_window((0,0),window=self.inner,anchor="nw"); self.canvas.configure(yscrollcommand=self.scrollbar.set); self.canvas.pack(side="left",fill="both",expand=True); self.scrollbar.pack(side="right",fill="y"); self.inner.bind("<Configure>",lambda e:self.canvas.configure(scrollregion=self.canvas.bbox("all"))); self.canvas.bind("<Configure>",lambda e:self.canvas.itemconfigure(self.window_id,width=e.width)); self.canvas.bind_all("<MouseWheel>",lambda e:self.canvas.yview_scroll(int(-e.delta/120),"units"))

class ImageViewer(tk.Label):
    def __init__(self,master,**kwargs): super().__init__(master,bg="#0f1115",fg="#d7dde3",**kwargs); self._photo=None
