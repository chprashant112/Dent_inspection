from __future__ import annotations
import json, re
from datetime import datetime
from pathlib import Path
import cv2
import numpy as np

def _safe(text): return re.sub(r"[^A-Za-z0-9._-]+","_",str(text).strip()) or "unnamed"

def save_approved_defects(root, model_name, original, annotated, detection_mask, defects, metadata):
    base=Path(root)/_safe(model_name)/f"test_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')[:-3]}"; (base/'defects').mkdir(parents=True,exist_ok=False)
    cv2.imwrite(str(base/'original.png'),original); cv2.imwrite(str(base/'annotated.png'),annotated); cv2.imwrite(str(base/'detection_mask.png'),detection_mask)
    saved=[]; approved={int(x) for x in metadata.get('approved_ids',[])}
    for idx,d in enumerate(defects,1):
        ok=idx in approved
        item={"id":idx,"label":d.label,"approved":ok,"bbox":[d.x,d.y,d.w,d.h],"raw_bbox":[d.raw_x,d.raw_y,d.raw_w,d.raw_h],"area_px":d.area_px}
        if ok:
            h,w=original.shape[:2]; x0=max(0,d.x); y0=max(0,d.y); x1=min(w,d.x+d.w); y1=min(h,d.y+d.h)
            crop=original[y0:y1,x0:x1].copy(); path=base/'defects'/f"defect_{idx:03d}.png"; cv2.imwrite(str(path),crop); item["crop_file"]=str(path.relative_to(base)); saved.append(item)
        saved.append(item) if not ok else None
    full={**metadata,"saved_at":datetime.now().isoformat(),"defects":saved}
    (base/'metadata.json').write_text(json.dumps(full,indent=2),encoding='utf-8')
    return base, full
