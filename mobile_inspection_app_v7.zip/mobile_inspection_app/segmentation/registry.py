from .traditional import KMeansSegmenter, MeanShiftSegmenter
from .sam_optional import SAMSegmenter
from .adaptive_regions import AdaptivePhoneRegionSegmenter


class SegmentationRegistry:
    def names(self):
        return [
            "Adaptive Phone Regions (Bulged Edge)",
            "K-Means",
            "Mean Shift",
            "SAM (offline, optional)",
        ]

    def create(self, name, **kwargs):
        if name == "Adaptive Phone Regions (Bulged Edge)":
            return AdaptivePhoneRegionSegmenter(
                camera_rect=kwargs.get("camera_rect"),
                max_offset=kwargs.get("max_offset", 24),
            )
        if name == "K-Means":
            return KMeansSegmenter()
        if name == "Mean Shift":
            return MeanShiftSegmenter()
        if name.startswith("SAM"):
            return SAMSegmenter(
                checkpoint_path=kwargs.get("checkpoint_path", ""),
                model_type=kwargs.get("model_type", "vit_b"),
                device=kwargs.get("device", "cpu"),
            )
        raise KeyError(name)
