@echo off
cd /d "%~dp0"
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
echo.
echo For physical Basler cameras, install pypylon separately if required.
pause
