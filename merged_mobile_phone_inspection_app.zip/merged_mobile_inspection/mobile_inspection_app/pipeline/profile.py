from __future__ import annotations
from mobile_inspection_app.config import save_profile, load_profile

def make_profile(model, image_shape, source_view, stitch_mode, inspection_roi, camera_roi, roi_shapes, segmentation_backend, segmentation_params, ticked_segment_ids, correction_options, detectors, selected_recipe_indices):
    return {"version":1,"model":model,"image_size":[int(image_shape[1]),int(image_shape[0])],"source_view":source_view,"stitch_mode":stitch_mode,"inspection_roi":inspection_roi.to_dict() if inspection_roi else None,"camera_roi":camera_roi.to_dict() if camera_roi else None,"rois":[r.to_dict() for r in roi_shapes],"segmentation_backend":segmentation_backend,"segmentation_params":segmentation_params,"ticked_segment_ids":list(ticked_segment_ids),"correction_options":correction_options,"detectors":[{"name":n,"params":p} for n,p in detectors],"selected_recipe_indices":list(selected_recipe_indices)}
__all__=["make_profile","save_profile","load_profile"]
