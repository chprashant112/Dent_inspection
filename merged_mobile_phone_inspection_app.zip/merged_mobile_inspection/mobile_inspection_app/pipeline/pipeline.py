from __future__ import annotations
import cv2
import numpy as np
from mobile_inspection_app.analysis.correction import correct_illumination
from mobile_inspection_app.roi.masks import compose_detection_mask
from mobile_inspection_app.roi.model import ROI

class InspectionPipeline:
    def __init__(self, segmentation_backends: dict, detector_registry, on_log=None):
        self.segmentation_backends=segmentation_backends; self.detector_registry=detector_registry; self.on_log=on_log or (lambda level,msg:None)
    @staticmethod
    def make_roi_mask(shape, roi: ROI | None):
        if roi is None: return np.full(shape[:2],255,np.uint8)
        from mobile_inspection_app.roi.shapes import rasterize_shape
        return rasterize_shape(roi.shape,shape)
    def segment(self,image,inspection_roi=None,camera_roi=None,backend_name=None,params=None):
        roi_mask=self.make_roi_mask(image.shape,inspection_roi); cam=self.make_roi_mask(image.shape,camera_roi) if camera_roi else None
        backend=self.segmentation_backends[backend_name or next(iter(self.segmentation_backends))]
        return backend.segment(image,roi_mask,params or {},cam)
    def detect(self,image,inspection_roi,roi_shapes,segment_result,ticked_segment_ids,detectors,correction_options=None,light=None,calibration=None,mode="TESTING"):
        correction_options=correction_options or {}; working=image.copy()
        inspection_mask=self.make_roi_mask(image.shape,inspection_roi)
        if correction_options.get("enabled"):
            working=correct_illumination(working,inspection_mask,correction_options.get("strength",.75),correction_options.get("highlight_compression",True),correction_options.get("knee",225))
        selected_segments=[]; segment_masks=[]
        if segment_result is not None:
            for s in segment_result.segments:
                if s.id in ticked_segment_ids:
                    selected_segments.append({"id":s.id,"name":s.name,"mask":s.mask}); segment_masks.append(s.mask)
        detect_rois=[r for r in roi_shapes if r.role=="detect" and r.enabled]
        mask_rois=[r for r in roi_shapes if r.role=="mask" and r.enabled]
        final=compose_detection_mask(image.shape,inspection_mask,detect_rois,segment_masks,mask_rois,require_region=True)
        results=[]
        for name,params in detectors:
            algo=self.detector_registry.get(name)
            ctx={"params":params,"selected_regions":selected_segments,"roi_shapes":roi_shapes,"mode":mode,"light":light,"calibration":calibration}
            res=algo.process(working,final,ctx); results.append(res)
        return working,final,results
