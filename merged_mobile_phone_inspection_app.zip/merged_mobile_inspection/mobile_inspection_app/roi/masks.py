from __future__ import annotations
import cv2
import numpy as np
from mobile_inspection_app.roi.model import ROI
from mobile_inspection_app.roi.shapes import rasterize_shape

class MaskCompositionError(ValueError): pass

def roi_mask(roi: ROI, shape: tuple[int,...]) -> np.ndarray:
    return rasterize_shape(roi.shape,shape)

def compose_detection_mask(image_shape: tuple[int,...], inspection: np.ndarray | None = None,
                           detection_rois: list[ROI] | None = None, segment_masks: list[np.ndarray] | None = None,
                           mask_rois: list[ROI] | None = None, require_region: bool = True) -> np.ndarray:
    h,w=image_shape[:2]
    full=np.full((h,w),255,np.uint8)
    def norm(m):
        if m is None: return None
        if m.shape[:2]!=(h,w): raise MaskCompositionError(f"Mask size {m.shape[:2]} does not match image {(h,w)}")
        return np.where(m>0,255,0).astype(np.uint8)
    ins=norm(inspection) if inspection is not None else full.copy()
    detects=[r for r in (detection_rois or []) if r.enabled and r.role=="detect"]
    segs=segment_masks or []
    inc=None
    if detects:
        inc=np.zeros((h,w),np.uint8)
        for r in detects: cv2.bitwise_or(inc,roi_mask(r,(h,w)),dst=inc)
    seg=None
    if segs:
        seg=np.zeros((h,w),np.uint8)
        for m in segs: cv2.bitwise_or(seg,norm(m),dst=seg)
    if inc is not None and seg is not None: region=cv2.bitwise_and(inc,seg)
    elif inc is not None: region=inc
    elif seg is not None: region=seg
    elif require_region: raise MaskCompositionError("Select at least one active Detection ROI or one segmentation region before detection.")
    else: region=full
    final=cv2.bitwise_and(ins,region)
    excludes=[r for r in (mask_rois or []) if r.enabled and r.role=="mask"]
    for r in excludes: final=cv2.bitwise_and(final,cv2.bitwise_not(roi_mask(r,(h,w))))
    if not np.any(final): raise MaskCompositionError("The effective detection mask is empty. Review Inspection, Detection, segment and Mask ROIs.")
    return final
