from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Literal
Point=tuple[float,float]
ROIRole=Literal["inspection","camera","detect","mask"]

@dataclass
class ROIShape:
    kind: str = "rectangle"  # rectangle, ellipse, rounded_rectangle, free
    bbox: tuple[float,float,float,float] | None = None
    points: list[Point] = field(default_factory=list)
    bends: list[Point | None] = field(default_factory=list)
    radius: float = 12.0

@dataclass
class ROI:
    id: str
    name: str
    role: ROIRole
    shape: ROIShape
    enabled: bool = True
    color: str = "#00c7d9"

    def to_dict(self): return asdict(self)

    @classmethod
    def from_dict(cls,data):
        s=dict(data.get("shape",{}))
        if s.get("bbox") is not None: s["bbox"]=tuple(s["bbox"])
        s["points"]=[tuple(p) for p in s.get("points",[])]
        s["bends"]=[tuple(p) if p is not None else None for p in s.get("bends",[])]
        return cls(data["id"],data.get("name",data["id"]),data.get("role","detect"),ROIShape(**{k:v for k,v in s.items() if k in ROIShape.__dataclass_fields__}),data.get("enabled",True),data.get("color","#00c7d9"))
