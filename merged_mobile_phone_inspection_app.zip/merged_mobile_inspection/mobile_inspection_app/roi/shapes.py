from __future__ import annotations
import math
import cv2
import numpy as np
from mobile_inspection_app.roi.model import ROIShape

def _bbox(shape: ROIShape):
    if shape.bbox is not None:
        x1,y1,x2,y2=shape.bbox
    elif shape.points:
        xs=[p[0] for p in shape.points]; ys=[p[1] for p in shape.points]
        x1,y1,x2,y2=min(xs),min(ys),max(xs),max(ys)
    else: return 0,0,0,0
    return min(x1,x2),min(y1,y2),max(x1,x2),max(y1,y2)

def _arc_points(start, handle, end, max_chord_error=0.25):
    """Circular arc through start, handle and end; the handle is retained exactly."""
    p1=np.array(start,float); p2=np.array(handle,float); p3=np.array(end,float)
    ax,ay=p1; bx,by=p2; cx,cy=p3
    d=2*(ax*(by-cy)+bx*(cy-ay)+cx*(ay-by))
    if abs(d)<1e-5: return [tuple(p1),tuple(p3)]
    a2=ax*ax+ay*ay; b2=bx*bx+by*by; c2=cx*cx+cy*cy
    ux=(a2*(by-cy)+b2*(cy-ay)+c2*(ay-by))/d
    uy=(a2*(cx-bx)+b2*(ax-cx)+c2*(bx-ax))/d
    center=np.array([ux,uy]); radius=float(np.linalg.norm(p1-center))
    if not np.isfinite(radius) or radius>1e7: return [tuple(p1),tuple(p3)]
    angle1=math.atan2(ay-uy,ax-ux); angle2=math.atan2(by-uy,bx-ux); angle3=math.atan2(cy-uy,cx-ux)
    norm=lambda a: a%(2*math.pi)
    ccw_total=norm(angle3-angle1); ccw_handle=norm(angle2-angle1)
    if ccw_handle<=ccw_total+1e-8:
        angle_handle=angle1+ccw_handle; angle_end=angle1+ccw_total
    else:
        angle_handle=angle1+(ccw_handle-2*math.pi); angle_end=angle1+(ccw_total-2*math.pi)
    def sample(a0,a1):
        sweep=a1-a0
        if radius<=max_chord_error: n=1
        else:
            max_angle=2*math.acos(max(-1.0,min(1.0,1-max_chord_error/radius)))
            n=max(1,int(math.ceil(abs(sweep)/max(max_angle,1e-3))))
        pts=[(ux+radius*math.cos(a0+sweep*i/n),uy+radius*math.sin(a0+sweep*i/n)) for i in range(n+1)]
        return pts
    first=sample(angle1,angle_handle)
    second=sample(angle_handle,angle_end)
    # Use the selected pixel itself as the shared point; do not leave its location to interpolation.
    first[-1]=(float(p2[0]),float(p2[1])); second[0]=(float(p2[0]),float(p2[1]))
    return first[:-1]+second

def free_shape_outline(shape: ROIShape, chord_error: float=0.25) -> list[tuple[float,float]]:
    pts=shape.points
    if len(pts)<2: return pts[:]
    bends=shape.bends or [None]*len(pts)
    if len(bends)<len(pts): bends=bends+[None]*(len(pts)-len(bends))
    out=[]
    for i,p0 in enumerate(pts):
        p1=pts[(i+1)%len(pts)]
        bend=bends[i]
        edge=_arc_points(p0,bend,p1,chord_error) if bend is not None else [p0,p1]
        out.extend(edge[:-1])
    return out

def rasterize_shape(shape: ROIShape, image_shape: tuple[int,...]) -> np.ndarray:
    h,w=image_shape[:2]; mask=np.zeros((h,w),np.uint8)
    kind=shape.kind.lower()
    if kind in ("rectangle","rect"):
        x1,y1,x2,y2=_bbox(shape)
        cv2.rectangle(mask,(int(round(x1)),int(round(y1))),(int(round(x2)),int(round(y2))),255,-1)
    elif kind in ("ellipse","circle"):
        x1,y1,x2,y2=_bbox(shape)
        center=(int(round((x1+x2)/2)),int(round((y1+y2)/2)))
        axes=(max(1,int(round(abs(x2-x1)/2))),max(1,int(round(abs(y2-y1)/2))))
        cv2.ellipse(mask,center,axes,0,0,360,255,-1,cv2.LINE_AA)
    elif kind in ("rounded_rectangle","rounded rectangle","rounded"):
        x1,y1,x2,y2=_bbox(shape); x1,y1,x2,y2=map(lambda n:int(round(n)),(x1,y1,x2,y2))
        r=max(0,min(int(round(shape.radius)),max(0,(x2-x1)//2),max(0,(y2-y1)//2)))
        if r==0: cv2.rectangle(mask,(x1,y1),(x2,y2),255,-1)
        else:
            cv2.rectangle(mask,(x1+r,y1),(x2-r,y2),255,-1)
            cv2.rectangle(mask,(x1,y1+r),(x2,y2-r),255,-1)
            for c in ((x1+r,y1+r),(x2-r,y1+r),(x1+r,y2-r),(x2-r,y2-r)):
                cv2.circle(mask,c,r,255,-1,cv2.LINE_AA)
    elif kind in ("free","polygon","free_shape"):
        if len(shape.points)>=3:
            outline=free_shape_outline(shape)
            # shift=4 gives 1/16 pixel coordinates to fillPoly.
            poly=np.round(np.asarray(outline,dtype=np.float32)*16).astype(np.int32).reshape((-1,1,2))
            cv2.fillPoly(mask,[poly],255,shift=4,lineType=cv2.LINE_AA)
    else: raise ValueError(f"Unsupported ROI shape: {shape.kind}")
    mask[:]=np.where(mask>0,255,0).astype(np.uint8)
    return mask
