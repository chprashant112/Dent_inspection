from __future__ import annotations
import tkinter as tk
from tkinter import ttk
from mobile_inspection_app.ui.theme import COLORS

class ScrollableFrame(ttk.Frame):
    """A vertical scrolling frame whose wheel works over every nested child widget."""
    def __init__(self, master, **kwargs):
        super().__init__(master,**kwargs)
        self.canvas=tk.Canvas(self,highlightthickness=0,bg=COLORS["background"])
        self.vbar=ttk.Scrollbar(self,orient="vertical",command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=self.vbar.set)
        self.inner=ttk.Frame(self.canvas)
        self.window=self.canvas.create_window((0,0),window=self.inner,anchor="nw")
        self._wheel_bound_paths=set()
        self.canvas.pack(side="left",fill="both",expand=True); self.vbar.pack(side="right",fill="y")
        self.inner.bind("<Configure>",self._configure); self.canvas.bind("<Configure>",self._resize)
        self.canvas.bind("<MouseWheel>",self._wheel_local,add="+")
        self.canvas.bind("<Button-4>",self._wheel_up_local,add="+")
        self.canvas.bind("<Button-5>",self._wheel_down_local,add="+")
        # Global wheel bindings are filtered by widget ancestry. This matters because ttk
        # labels, comboboxes, spinboxes, text boxes and buttons do not propagate wheel events
        # to the canvas when the pointer is over a child widget.
        self.bind_all("<MouseWheel>",self._wheel_anywhere,add="+")
        self.bind_all("<Button-4>",self._wheel_up_linux,add="+")
        self.bind_all("<Button-5>",self._wheel_down_linux,add="+")

    def _configure(self,event=None):
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))
        # Bind directly to descendants as well as using bind_all, so widgets with their own
        # class-level wheel behaviour (notably read-only comboboxes) still scroll the panel.
        self._bind_descendants(self.inner)

    def _bind_descendants(self,parent):
        for child in parent.winfo_children():
            path=str(child)
            if path not in self._wheel_bound_paths:
                self._wheel_bound_paths.add(path)
                child.bind("<MouseWheel>",self._wheel_local,add="+")
                child.bind("<Button-4>",self._wheel_up_local,add="+")
                child.bind("<Button-5>",self._wheel_down_local,add="+")
            self._bind_descendants(child)

    def _resize(self,event):
        self.canvas.itemconfigure(self.window,width=event.width)

    def _is_inside(self,widget):
        current=widget
        while current is not None:
            if current is self.inner or current is self.canvas or current is self:
                return True
            current=getattr(current,"master",None)
        return False

    def _wheel_anywhere(self,event):
        if not self._is_inside(event.widget): return
        delta=event.delta
        if not delta: return "break"
        # Windows sends multiples of 120; macOS commonly sends smaller values.
        units=int(-delta/120) if abs(delta)>=120 else (-1 if delta>0 else 1)
        if units==0: units=-1 if delta>0 else 1
        self.canvas.yview_scroll(units,"units")
        return "break"

    def _wheel_local(self,event):
        delta=event.delta
        if not delta: return "break"
        units=int(-delta/120) if abs(delta)>=120 else (-1 if delta>0 else 1)
        if units==0: units=-1 if delta>0 else 1
        self.canvas.yview_scroll(units,"units")
        return "break"

    def _wheel_up_local(self,event):
        self.canvas.yview_scroll(-1,"units")
        return "break"

    def _wheel_down_local(self,event):
        self.canvas.yview_scroll(1,"units")
        return "break"

    def _wheel_up_linux(self,event):
        if self._is_inside(event.widget):
            self.canvas.yview_scroll(-1,"units")
            return "break"

    def _wheel_down_linux(self,event):
        if self._is_inside(event.widget):
            self.canvas.yview_scroll(1,"units")
            return "break"

class CollapsibleCard(ttk.Frame):
    def __init__(self, master, title: str, open_by_default: bool=False):
        super().__init__(master,style="Card.TFrame",padding=0)
        self.title=title; self.open=tk.BooleanVar(value=open_by_default)
        self.header=ttk.Button(self,text=("▾ " if open_by_default else "▸ ")+title,command=self.toggle,style="Mini.TButton")
        self.header.pack(fill="x",padx=5,pady=(5,2))
        self.body=ttk.Frame(self,style="Card.TFrame",padding=8)
        if open_by_default: self.body.pack(fill="x",expand=True,padx=2,pady=(0,6))
    def toggle(self):
        self.open.set(not self.open.get())
        if self.open.get(): self.body.pack(fill="x",expand=True,padx=2,pady=(0,6)); self.header.configure(text="▾ "+self.title)
        else: self.body.pack_forget(); self.header.configure(text="▸ "+self.title)
