from __future__ import annotations
import uuid
import tkinter as tk
from mobile_inspection_app.roi.model import ROI, ROIShape

class ROIToolController:
    """Image-coordinate ROI state used by the Tk viewer."""
    def __init__(self):
        self.inspection: ROI | None=None
        self.camera: ROI | None=None
        self.rois: list[ROI]=[]
        self.current_role="detect"; self.current_shape="rectangle"; self.free_points=[]
        self._counter=0
    def make_roi(self,name,role,shape,enabled=True):
        self._counter+=1
        colors={"inspection":"#22c55e","camera":"#3b82f6","detect":"#06b6d4","mask":"#ef4444"}
        return ROI(f"roi-{uuid.uuid4().hex[:8]}",name or f"{role.title()} {self._counter}",role,shape,enabled,colors.get(role,"#06b6d4"))
    def set_box(self,role,x1,y1,x2,y2):
        shape=ROIShape("rectangle",bbox=(x1,y1,x2,y2))
        if role=="inspection": self.inspection=self.make_roi("Inspection ROI","inspection",shape)
        elif role=="camera": self.camera=self.make_roi("Camera ROI","camera",shape)
        else: self.rois.append(self.make_roi(f"{role.title()} ROI {len(self.rois)+1}",role,shape))
    def finish_free(self):
        if len(self.free_points)<3: return False
        self.rois.append(self.make_roi(f"{self.current_role.title()} Free {len(self.rois)+1}",self.current_role,ROIShape("free",points=list(self.free_points),bends=[None]*len(self.free_points))))
        self.free_points=[]; return True
    def delete(self,roi_id): self.rois=[r for r in self.rois if r.id!=roi_id]
    def clear(self): self.inspection=None; self.camera=None; self.rois.clear(); self.free_points.clear()
