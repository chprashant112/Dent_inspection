from __future__ import annotations
import tkinter as tk
from tkinter import ttk
COLORS={"background":"#f3f4f8","card":"#ffffff","border":"#e3e5ec","text":"#12131a","subtext":"#6b7280","accent":"#4f46e5","hover":"#4338ca","success":"#15803d","danger":"#dc2626","warning":"#b45309","viewer":"#0b0d0f"}
def apply_theme(root: tk.Misc):
    root.configure(bg=COLORS["background"])
    style=ttk.Style(root)
    try: style.theme_use("clam")
    except tk.TclError: pass
    style.configure("TFrame",background=COLORS["background"])
    style.configure("Card.TFrame",background=COLORS["card"],relief="flat")
    style.configure("TLabel",background=COLORS["background"],foreground=COLORS["text"],font=("Segoe UI",9))
    style.configure("Card.TLabel",background=COLORS["card"],foreground=COLORS["text"],font=("Segoe UI",9))
    style.configure("Sub.TLabel",background=COLORS["card"],foreground=COLORS["subtext"],font=("Segoe UI",8))
    style.configure("TButton",font=("Segoe UI",9),padding=(8,5))
    style.configure("Accent.TButton",background=COLORS["accent"],foreground="white",font=("Segoe UI",9,"bold"))
    style.map("Accent.TButton",background=[("active",COLORS["hover"])])
    style.configure("Success.TButton",background=COLORS["success"],foreground="white")
    style.configure("Danger.TButton",background=COLORS["danger"],foreground="white")
    style.configure("Mini.TButton",padding=(4,2),font=("Segoe UI",8))
    style.configure("TEntry",padding=4)
    style.configure("TCombobox",padding=3)
    style.configure("TCheckbutton",background=COLORS["card"],foreground=COLORS["text"])
    style.configure("TRadiobutton",background=COLORS["card"],foreground=COLORS["text"])
    style.configure("TNotebook",background=COLORS["background"],borderwidth=0)
    style.configure("TNotebook.Tab",padding=(10,5),font=("Segoe UI",9))
    return style
