from __future__ import annotations
import cv2
import numpy as np
from mobile_inspection_app.segmentation.base import Segment, SegmentResult
from mobile_inspection_app.roi.shapes import rasterize_shape
from mobile_inspection_app.roi.model import ROIShape

class AdaptivePhoneRegions:
    name="Adaptive Phone Regions (Bulged Edge)"
    def segment(self, image: np.ndarray, roi_mask: np.ndarray, params: dict | None=None, camera_roi: np.ndarray | None=None) -> SegmentResult:
        params=params or {}; h,w=image.shape[:2]; roi=roi_mask>0
        if roi.sum()<50: raise ValueError("Inspection ROI is too small for segmentation")
        gray=cv2.cvtColor(image,cv2.COLOR_BGR2GRAY)
        blurred=cv2.GaussianBlur(gray,(0,0),1.2)
        # Locate the largest connected foreground object within the inspection ROI using robust local contrast.
        pixels=blurred[roi]; median=float(np.median(pixels)); lo=float(np.percentile(pixels,8)); hi=float(np.percentile(pixels,92))
        # Otsu is constrained to ROI; choose threshold polarity that yields plausible central component.
        local=np.zeros((h,w),np.uint8); local[roi]=blurred[roi]
        vals=np.where(roi,blurred,0).astype(np.uint8)
        otsu,_=cv2.threshold(vals[roi].reshape(-1,1),0,255,cv2.THRESH_BINARY+cv2.THRESH_OTSU)
        candidate=((blurred>otsu)&roi)|((blurred<=otsu)&roi)
        # Prefer boundaries from edge response, avoiding reliance on phone colour.
        edges=cv2.Canny(blurred, max(8,int(np.percentile(cv2.Sobel(blurred,cv2.CV_32F,1,0,ksize=3)[roi]**2,65)**.5)) if roi.any() else 30, 100)
        edges=np.where(roi,edges,0).astype(np.uint8)
        close=cv2.morphologyEx(edges,cv2.MORPH_CLOSE,cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(9,9)))
        contours,_=cv2.findContours(close,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
        phone=np.zeros((h,w),np.uint8)
        # Choose an elongated contour within the ROI; otherwise use a robust foreground/gradient estimate.
        chosen=None; score_best=0
        for c in contours:
            x,y,bw,bh=cv2.boundingRect(c); area=cv2.contourArea(c)
            if area<roi.sum()*.03: continue
            aspect=max(bw,bh)/max(1,min(bw,bh))
            score=area*(1.25 if aspect>1.2 else 1.0)
            if score>score_best: chosen=c; score_best=score
        if chosen is not None:
            cv2.drawContours(phone,[chosen],-1,255,-1)
            phone=cv2.morphologyEx(phone,cv2.MORPH_CLOSE,cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(17,17)))
        else:
            # Fall back to the central component, not colour-specific thresholds.
            contours2,_=cv2.findContours((edges>0).astype(np.uint8),cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
            if contours2:
                c=max(contours2,key=cv2.contourArea); cv2.drawContours(phone,[c],-1,255,-1)
            else:
                ys,xs=np.where(roi)
                phone[ys.min():ys.max()+1,xs.min():xs.max()+1]=255
        phone=cv2.bitwise_and(phone,roi_mask)
        # If edges do not close, approximate rounded body from its extent; this remains an adaptive heuristic.
        contours,_=cv2.findContours(phone,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
        if contours:
            c=max(contours,key=cv2.contourArea); x,y,bw,bh=cv2.boundingRect(c)
            if bw>8 and bh>8:
                approx=np.zeros_like(phone); r=max(6,min(28,bw//12,bh//20))
                shape=ROIShape("rounded_rectangle",bbox=(x,y,x+bw-1,y+bh-1),radius=r)
                approx=rasterize_shape(shape,image.shape)
                # Keep edge-defined irregularity only when there is enough contour coverage.
                if cv2.countNonZero(phone)>0.12*cv2.countNonZero(approx): phone=cv2.bitwise_and(cv2.bitwise_or(phone,approx),roi_mask)
        # Camera module is optional and should be excluded only when a Camera ROI exists.
        camera=np.zeros((h,w),np.uint8)
        if camera_roi is not None: camera=cv2.bitwise_and(camera_roi,phone)
        # Curved edge approximation from signed distance; band width can be configured in pixels.
        edge_width=max(3,min(32,int(params.get("edge_width_px",max(4,round(min(h,w)*.008))))))
        inside=(phone>0).astype(np.uint8)
        dist=cv2.distanceTransform(inside,cv2.DIST_L2,5)
        edge=np.where((phone>0)&(dist<=edge_width),255,0).astype(np.uint8)
        edge=cv2.bitwise_and(edge,cv2.bitwise_not(camera))
        back=cv2.bitwise_and(phone,cv2.bitwise_not(edge)); back=cv2.bitwise_and(back,cv2.bitwise_not(camera))
        surrounding=cv2.bitwise_and(roi_mask,cv2.bitwise_not(phone))
        masks=[back,camera,edge,surrounding]
        names=["Back Glass","Camera Module","Bulged Edge","Surrounding"]
        ids=[1,2,3,4]; segments=[]
        # Make disjoint masks: Camera first, then edge, then back; surrounding last.
        assigned=np.zeros((h,w),np.uint8)
        for sid,name,m in zip(ids,names,masks):
            if sid==2 and camera_roi is None: continue
            m=cv2.bitwise_and(m,cv2.bitwise_not(assigned)); m=cv2.bitwise_and(m,roi_mask)
            assigned=cv2.bitwise_or(assigned,m)
            segments.append(Segment(sid,name,m,int(cv2.countNonZero(m))))
        overlay=image.copy(); colors={1:(70,200,90),2:(230,100,50),3:(20,190,230),4:(90,90,170)}
        for s in segments:
            edgecontours,_=cv2.findContours(s.mask,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
            cv2.drawContours(overlay,edgecontours,-1,colors[s.id],2)
        return SegmentResult(self.name,segments,overlay,"Adaptive geometry + distance-band estimate; inspect and tune on real images.")
