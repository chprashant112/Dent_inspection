from mobile_inspection_app.segmentation.adaptive_regions import AdaptivePhoneRegions
from mobile_inspection_app.segmentation.traditional import KMeansLAB, MeanShiftRegions

def create_segmentation_backends():
    items=[AdaptivePhoneRegions(),KMeansLAB(),MeanShiftRegions()]
    return {item.name:item for item in items}
