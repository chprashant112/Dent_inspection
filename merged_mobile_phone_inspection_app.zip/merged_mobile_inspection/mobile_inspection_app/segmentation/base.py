from __future__ import annotations
from dataclasses import dataclass
import numpy as np
@dataclass
class Segment:
    id: int
    name: str
    mask: np.ndarray
    area_px: int
@dataclass
class SegmentResult:
    backend: str
    segments: list[Segment]
    overlay: np.ndarray
    message: str = ""
