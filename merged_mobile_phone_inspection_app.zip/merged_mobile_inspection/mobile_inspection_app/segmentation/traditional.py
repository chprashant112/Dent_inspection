from __future__ import annotations
import cv2
import numpy as np
from mobile_inspection_app.segmentation.base import Segment, SegmentResult

class KMeansLAB:
    name="K-Means (LAB colour)"
    def segment(self,image,roi_mask,params=None,camera_roi=None):
        params=params or {}; h,w=image.shape[:2]; valid=roi_mask>0; lab=cv2.cvtColor(image,cv2.COLOR_BGR2LAB)
        data=lab[valid].astype(np.float32)
        if len(data)<3: raise ValueError("Inspection ROI too small for k-means")
        k=max(2,min(3,int(params.get("k",3)),len(data)))
        _,labels,centers=cv2.kmeans(data,k,None,(cv2.TERM_CRITERIA_EPS+cv2.TERM_CRITERIA_MAX_ITER,30,.5),3,cv2.KMEANS_PP_CENTERS)
        label_img=np.full((h,w),-1,np.int32); label_img[valid]=labels.flatten()
        gray=cv2.cvtColor(image,cv2.COLOR_BGR2GRAY); edges=cv2.Canny(gray,30,80); phone=np.zeros((h,w),np.uint8)
        cc,_=cv2.findContours(cv2.morphologyEx(edges,cv2.MORPH_CLOSE,np.ones((7,7),np.uint8)),cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
        if cc: cv2.drawContours(phone,[max(cc,key=cv2.contourArea)],-1,255,-1)
        segs=[]; overlay=image.copy()
        for i in range(k):
            m=np.where((label_img==i)&valid,255,0).astype(np.uint8); area=int(cv2.countNonZero(m))
            segs.append(Segment(i+1,f"LAB Cluster {i+1}",m,area)); cnt,_=cv2.findContours(m,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE); cv2.drawContours(overlay,cnt,-1,(40+70*i,210-50*i,90+45*i),1)
        return SegmentResult(self.name,segs,overlay,"K-means clusters LAB pixels; clusters are not semantic phone regions.")

class MeanShiftRegions:
    name="Mean Shift (connected regions)"
    def segment(self,image,roi_mask,params=None,camera_roi=None):
        h,w=image.shape[:2]; filtered=cv2.pyrMeanShiftFiltering(image,sp=12,sr=18); gray=cv2.cvtColor(filtered,cv2.COLOR_BGR2GRAY)
        edges=cv2.Canny(gray,25,65); barriers=cv2.dilate(edges,np.ones((3,3),np.uint8)); open_area=(barriers==0)&(roi_mask>0)
        count,labels=cv2.connectedComponents(open_area.astype(np.uint8)); comps=[]
        for i in range(1,count):
            m=np.where(labels==i,255,0).astype(np.uint8); area=cv2.countNonZero(m)
            if area>max(100,int(roi_mask.sum()/255*.01)): comps.append((area,m))
        comps=sorted(comps,reverse=True,key=lambda x:x[0])[:6]; segs=[]; overlay=image.copy()
        for i,(area,m) in enumerate(comps):
            segs.append(Segment(i+1,f"Region {i+1}",m,area)); cnt,_=cv2.findContours(m,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE); cv2.drawContours(overlay,cnt,-1,(255,100+i*15,50+i*25),1)
        return SegmentResult(self.name,segs,overlay,"Mean-shift connected regions; regions are not semantic labels.")
