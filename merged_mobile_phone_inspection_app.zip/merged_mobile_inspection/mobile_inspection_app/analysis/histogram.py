from __future__ import annotations
import cv2
import numpy as np

def histogram_image(image: np.ndarray, mask: np.ndarray | None = None, width: int=520, height: int=220) -> np.ndarray:
    canvas=np.full((height,width,3),255,np.uint8)
    colors=(("B",0),("G",1),("R",2))
    for _,idx in colors:
        hist=cv2.calcHist([image],[idx],mask,[256],[0,256]).flatten()
        if hist.max()>0: hist=hist/hist.max()*(height-24)
        pts=np.array([[int(i*(width-1)/255),height-12-int(v)] for i,v in enumerate(hist)],np.int32)
        col=[0,0,0]; col[idx]=220
        cv2.polylines(canvas,[pts],False,col,1,cv2.LINE_AA)
    cv2.putText(canvas,"BGR intensity",(8,15),cv2.FONT_HERSHEY_SIMPLEX,.45,(50,50,50),1,cv2.LINE_AA)
    return canvas
