from __future__ import annotations
import cv2
import numpy as np

def _valid_mask(mask, shape):
    if mask is None: return np.ones(shape[:2],bool)
    if mask.shape[:2]!=shape[:2]: raise ValueError("Illumination mask shape differs from image")
    return mask>0

def _metrics(values: np.ndarray) -> dict:
    if values.size==0: return {"mean":0.0,"std":0.0,"min":0.0,"max":0.0,"range_percent":0.0,"cv_percent":0.0}
    values=values.astype(np.float64); mean=float(values.mean()); std=float(values.std()); lo=float(values.min()); hi=float(values.max())
    return {"mean":mean,"std":std,"min":lo,"max":hi,"range_percent":(100*(hi-lo)/mean if mean else 0.0),"cv_percent":(100*std/mean if mean else 0.0)}

def analyze_illumination(image: np.ndarray, mask: np.ndarray | None = None, rows: int=8, cols: int=10, range_limit: float=15.0, strict_per_channel: bool=False) -> dict:
    if image is None or image.ndim!=3 or image.shape[2]!=3: raise ValueError("Expected a BGR color image")
    valid=_valid_mask(mask,image.shape); h,w=image.shape[:2]
    lab=cv2.cvtColor(image,cv2.COLOR_BGR2LAB); l=lab[:,:,0]
    rows=max(1,int(rows)); cols=max(1,int(cols))
    grid=np.full((rows,cols),np.nan,dtype=np.float32)
    for ri in range(rows):
        y1=round(ri*h/rows); y2=round((ri+1)*h/rows)
        for ci in range(cols):
            x1=round(ci*w/cols); x2=round((ci+1)*w/cols)
            gm=valid[y1:y2,x1:x2]
            if gm.any(): grid[ri,ci]=float(l[y1:y2,x1:x2][gm].mean())
    grid_values=grid[np.isfinite(grid)]
    lab_stats=_metrics(grid_values if grid_values.size else l[valid])
    channels={}
    for name,idx in (("B",0),("G",1),("R",2)):
        cgrid=[]
        for ri in range(rows):
            y1=round(ri*h/rows); y2=round((ri+1)*h/rows)
            for ci in range(cols):
                x1=round(ci*w/cols); x2=round((ci+1)*w/cols); gm=valid[y1:y2,x1:x2]
                if gm.any(): cgrid.append(float(image[y1:y2,x1:x2,idx][gm].mean()))
        channels[name]=_metrics(np.asarray(cgrid))
    channel_bad=any(v["range_percent"]>range_limit for v in channels.values())
    verdict="NON-UNIFORM" if (channel_bad if strict_per_channel else lab_stats["range_percent"]>range_limit) else "EVEN"
    scaled=np.nan_to_num(grid,nan=0.0)
    heat=cv2.resize(scaled,(w,h),interpolation=cv2.INTER_CUBIC)
    heat_norm=np.clip((heat-heat.min())/(max(float(heat.max()-heat.min()),1e-6))*255,0,255).astype(np.uint8)
    heatmap=cv2.applyColorMap(heat_norm,cv2.COLORMAP_JET); heatmap[~valid]=0
    hist=np.histogram(l[valid],bins=64,range=(0,256)) if valid.any() else (np.zeros(64,dtype=int),np.linspace(0,256,65))
    return {"grid":grid.tolist(),"lab_l":lab_stats,"channels":channels,"verdict":verdict,"heatmap":heatmap,"histogram":{"counts":hist[0].tolist(),"edges":hist[1].tolist()},"rows":rows,"cols":cols,"range_limit":range_limit}
