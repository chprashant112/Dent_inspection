from __future__ import annotations
import cv2
import numpy as np

def correct_illumination(image: np.ndarray, mask: np.ndarray | None = None, strength: float=0.75, highlight_compression: bool=True, knee: int=225) -> np.ndarray:
    """Correct slow LAB-L illumination field only; preserve original pixels outside mask."""
    if image is None: raise ValueError("Image is empty")
    strength=float(np.clip(strength,0,1)); h,w=image.shape[:2]
    valid=np.ones((h,w),bool) if mask is None else mask>0
    if not valid.any(): return image.copy()
    lab=cv2.cvtColor(image,cv2.COLOR_BGR2LAB); L=lab[:,:,0].astype(np.float32)
    sigma=max(4.0,.06*min(h,w))
    weights=valid.astype(np.float32)
    numerator=cv2.GaussianBlur(L*weights,(0,0),sigmaX=sigma,sigmaY=sigma)
    denominator=cv2.GaussianBlur(weights,(0,0),sigmaX=sigma,sigmaY=sigma)
    low=numerator/np.maximum(denominator,1e-4)
    median=float(np.median(low[valid]))
    corrected=L-strength*(low-median)
    outL=np.clip(corrected,0,255)
    if highlight_compression:
        hsv=cv2.cvtColor(image,cv2.COLOR_BGR2HSV)
        highlight=(hsv[:,:,2]>=int(np.clip(knee,160,250)))&(hsv[:,:,1]<=115)&valid
        outL[highlight]=knee+(outL[highlight]-knee)*.32
    lab[:,:,0]=np.where(valid,np.clip(outL,0,255),L).astype(np.uint8)
    out=cv2.cvtColor(lab,cv2.COLOR_LAB2BGR)
    out[~valid]=image[~valid]
    return out
