"""Application configuration and profile persistence."""
from __future__ import annotations
from dataclasses import asdict, dataclass, field
import json, os, re
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent.parent
CONFIG_DIR = ROOT / "config"
PROFILES_DIR = ROOT / "profiles"

def safe_name(value: str, fallback: str = "model") -> str:
    value = re.sub(r"[^A-Za-z0-9_.-]+", "_", (value or "").strip()).strip("._")
    return (value or fallback)[:80]

@dataclass
class CameraSettings:
    exposure_us: float = 10000.0
    gain: float = 0.0
    fps: float = 20.0
    width: int = 960
    height: int = 720
    # On Basler cameras, true means reset offsets and use the maximum sensor ROI.
    # This avoids accidentally showing only a top-left crop when a small width/height
    # was saved by an earlier configuration. Simulated cameras keep their preview size.
    full_sensor: bool = True

@dataclass
class Recipe:
    enabled: bool = True
    name: str = "WARM"
    r: int = 255
    g: int = 140
    b: int = 60
    def rgb(self) -> tuple[int, int, int]:
        return tuple(max(0, min(255, int(v))) for v in (self.r, self.g, self.b))

DEFAULT_RECIPES = [
    Recipe(True, "WARM", 255, 140, 60),
    Recipe(True, "BLUE", 40, 90, 255),
    Recipe(True, "SKY_GREEN", 50, 220, 130),
    Recipe(True, "NEUTRAL", 255, 255, 255),
]

@dataclass
class AppConfig:
    camera1: CameraSettings = field(default_factory=CameraSettings)
    camera2: CameraSettings = field(default_factory=CameraSettings)
    topology: str = "LIGHT_SINGLE_4"
    port_a: str = "SIMULATOR"
    port_b: str = "SIMULATOR"
    baud: int = 9600
    settle_ms: int = 350
    recipes_a: list[Recipe] = field(default_factory=lambda: [Recipe(**asdict(r)) for r in DEFAULT_RECIPES])
    recipes_b: list[Recipe] = field(default_factory=lambda: [Recipe(**asdict(r)) for r in DEFAULT_RECIPES])
    illumination_grid_rows: int = 8
    illumination_grid_cols: int = 10
    illumination_range_limit: float = 15.0
    correction_strength: float = 0.75
    correction_enabled: bool = False
    strict_per_channel: bool = False
    highlight_compression: bool = True
    highlight_knee: int = 225
    segmentation_backend: str = "Adaptive Phone Regions (Bulged Edge)"
    segmentation_params: dict[str, Any] = field(default_factory=dict)
    detector_params: dict[str, dict[str, Any]] = field(default_factory=dict)
    stitch_mode: str = "Aligned side-by-side"
    preview_source: str = "Stitched"

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "AppConfig":
        defaults = cls()
        def cam(key: str, default: CameraSettings) -> CameraSettings:
            val = data.get(key, {})
            known = {k: val[k] for k in CameraSettings.__dataclass_fields__ if k in val}
            return CameraSettings(**{**asdict(default), **known})
        def recipes(key: str, fallback: list[Recipe]) -> list[Recipe]:
            raw = data.get(key)
            if not isinstance(raw, list): return [Recipe(**asdict(r)) for r in fallback]
            out = []
            for item in raw[:8]:
                if isinstance(item, dict):
                    allowed = Recipe.__dataclass_fields__.keys()
                    out.append(Recipe(**{k: item[k] for k in allowed if k in item}))
            return out or [Recipe(**asdict(r)) for r in fallback]
        values = {}
        known_simple = ["topology", "port_a", "port_b", "baud", "settle_ms", "illumination_grid_rows", "illumination_grid_cols", "illumination_range_limit", "correction_strength", "correction_enabled", "strict_per_channel", "highlight_compression", "highlight_knee", "segmentation_backend", "segmentation_params", "detector_params", "stitch_mode", "preview_source"]
        for key in known_simple:
            if key in data: values[key] = data[key]
        return cls(camera1=cam("camera1", defaults.camera1), camera2=cam("camera2", defaults.camera2), recipes_a=recipes("recipes_a", defaults.recipes_a), recipes_b=recipes("recipes_b", defaults.recipes_b), **values)

def config_path() -> Path:
    return CONFIG_DIR / "app_config.json"

def load_config(path: str | Path | None = None) -> AppConfig:
    target = Path(path) if path else config_path()
    if not target.exists(): return AppConfig()
    try:
        with target.open("r", encoding="utf-8") as f: return AppConfig.from_dict(json.load(f))
    except (OSError, ValueError, TypeError): return AppConfig()

def save_config(config: AppConfig, path: str | Path | None = None) -> None:
    target = Path(path) if path else config_path()
    target.parent.mkdir(parents=True, exist_ok=True)
    payload = asdict(config)
    target.write_text(json.dumps(payload, indent=2), encoding="utf-8")

def save_profile(model: str, profile: dict[str, Any]) -> Path:
    PROFILES_DIR.mkdir(parents=True, exist_ok=True)
    path = PROFILES_DIR / f"{safe_name(model)}.json"
    payload = dict(profile)
    payload.setdefault("version", 1)
    payload.setdefault("model", model)
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return path

def load_profile(model: str) -> dict[str, Any]:
    path = PROFILES_DIR / f"{safe_name(model)}.json"
    return json.loads(path.read_text(encoding="utf-8"))
