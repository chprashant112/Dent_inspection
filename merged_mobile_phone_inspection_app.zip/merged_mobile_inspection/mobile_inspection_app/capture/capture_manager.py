from __future__ import annotations
import json, time, re
from pathlib import Path
import cv2
from mobile_inspection_app.config import safe_name

class CaptureManager:
    def __init__(self, camera_manager, light_engine_getter, root: str | Path, on_log=None):
        self.camera_manager=camera_manager; self.light_engine_getter=light_engine_getter; self.root=Path(root); self.on_log=on_log or (lambda level,msg:None)
    @staticmethod
    def _save(path: Path,image):
        path.parent.mkdir(parents=True,exist_ok=True)
        if not cv2.imwrite(str(path),image): raise IOError(f"Could not save image: {path}")
    def _next_set(self, model_path: Path) -> int:
        nums=[]
        if model_path.exists():
            for p in model_path.glob("set*"):
                m=re.fullmatch(r"set(\d+)",p.name)
                if m: nums.append(int(m.group(1)))
        return max(nums,default=0)+1
    def capture_selected(self, model: str, recipes_a, recipes_b, selected_indices, stitch_mode: str="Aligned side-by-side", camera_settings=None, calibration=None):
        if not model or not model.strip(): raise ValueError("Set a model name before capturing")
        model_dir=self.root/"captures"/safe_name(model); set_no=self._next_set(model_dir); folder=model_dir/f"set{set_no}"; folder.mkdir(parents=True,exist_ok=False)
        engine=self.light_engine_getter(); items=[]
        active_indices=sorted(set(int(i) for i in selected_indices))
        if not active_indices: raise ValueError("Select at least one recipe")
        try:
            for idx in active_indices:
                if idx<0 or idx>=len(recipes_a): continue
                ra=recipes_a[idx]; rb=recipes_b[idx] if idx<len(recipes_b) else ra
                if not ra.enabled or not rb.enabled: continue
                rgb_a=ra.rgb(); rgb_b=rb.rgb()
                t0=time.monotonic(); engine.apply_pair(rgb_a,rgb_b); settled=time.monotonic()
                pair=self.camera_manager.capture_once(timeout=3.0,after_timestamp=settled)
                engine.all_off()
                img1=pair.camera1.image if pair.camera1 else None; img2=pair.camera2.image if pair.camera2 else None; stitched=pair.stitched(stitch_mode)
                left=safe_name(ra.name,f"Light{idx+1}"); right=safe_name(rb.name,f"Light{idx+1}")
                name=left if left==right else f"{left}__{right}"
                base=name; suffix=2
                while any((folder/f"{name}_{v}.png").exists() for v in ("stitched","camera1","camera2")):
                    name=f"{base}_{suffix}"; suffix+=1
                files={}
                if stitched is not None:
                    p=folder/f"{name}_stitched.png"; self._save(p,stitched); files["stitched"]=p.name
                if img1 is not None:
                    p=folder/f"{name}_camera1.png"; self._save(p,img1); files["camera1"]=p.name
                if img2 is not None:
                    p=folder/f"{name}_camera2.png"; self._save(p,img2); files["camera2"]=p.name
                items.append({"light_index":idx,"name":name,"rgb_a":list(rgb_a),"rgb_b":list(rgb_b),"files":files,"capture_timestamp":time.time(),"elapsed_s":round(time.monotonic()-t0,3),"stitch_message":pair.stitch_message})
        finally:
            try: engine.all_off()
            except Exception as exc: self.on_log("ERROR",f"Lighting ALL OFF during capture cleanup failed: {exc}")
        manifest={"capture_time":time.strftime("%Y-%m-%dT%H:%M:%S%z"),"model":model,"set":set_no,"stitch_mode":stitch_mode,"camera_settings":camera_settings or {},"mm_per_px":calibration or {},"items":items}
        (folder/"manifest.json").write_text(json.dumps(manifest,indent=2),encoding="utf-8")
        self.on_log("INFO",f"Saved {len(items)} capture(s) to {folder}")
        return folder,manifest
    def capture_testing(self,model,recipe,view="stitched",stitch_mode="Aligned side-by-side"):
        engine=self.light_engine_getter(); folder=self.root/"captures"/safe_name(model)/"testing"; folder.mkdir(parents=True,exist_ok=True)
        engine.apply(recipe.rgb()); settled=time.monotonic()
        try: pair=self.camera_manager.capture_once(timeout=3,after_timestamp=settled)
        finally: engine.all_off()
        image=pair.stitched(stitch_mode) if view=="stitched" else (pair.camera1.image if view=="camera1" and pair.camera1 else pair.camera2.image if pair.camera2 else None)
        if image is None: raise RuntimeError("Selected camera view has no image")
        path=folder/f"{time.strftime('%Y%m%d_%H%M%S')}_{safe_name(recipe.name,'Light')}_{safe_name(view)}.png"; self._save(path,image); return path
