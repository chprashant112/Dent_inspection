from __future__ import annotations
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any
import numpy as np

@dataclass
class DefectBox:
    x: int; y: int; w: int; h: int; label: str
    area_px: int = 0
    raw_x: int = 0; raw_y: int = 0; raw_w: int = 0; raw_h: int = 0
    accepted: bool = True

@dataclass
class DetectionResult:
    algorithm: str
    output: np.ndarray
    binary_mask: np.ndarray
    score: float
    message: str
    defects: list[DefectBox] = field(default_factory=list)
    params: dict[str,Any] = field(default_factory=dict)

class DetectionAlgorithm(ABC):
    name="Unnamed detector"
    version="1.0"
    multi_image=False
    DEFAULTS: dict[str,Any]={}
    SETTINGS_SCHEMA: list[dict[str,Any]]=[]
    def create_default(self): return dict(self.DEFAULTS)
    def settings(self): return list(self.SETTINGS_SCHEMA)
    @abstractmethod
    def process(self,image,inspection_mask=None,context=None)->DetectionResult: ...
