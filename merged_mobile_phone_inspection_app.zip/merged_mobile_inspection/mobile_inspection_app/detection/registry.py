from __future__ import annotations
from typing import Any
from mobile_inspection_app.detection.base import DetectionAlgorithm
class DetectionRegistry:
    def __init__(self): self._algorithms: dict[str,DetectionAlgorithm]={}
    def register(self,algorithm: DetectionAlgorithm): self._algorithms[algorithm.name]=algorithm
    def get(self,name: str): return self._algorithms[name]
    def names(self): return sorted(self._algorithms)
    def items(self): return dict(self._algorithms)
