from __future__ import annotations
import importlib.util, inspect, sys
from pathlib import Path
from mobile_inspection_app.detection.base import DetectionAlgorithm
from mobile_inspection_app.detection.registry import DetectionRegistry

def discover_algorithms(directory: str | Path, on_log=None) -> DetectionRegistry:
    log=on_log or (lambda level,msg:None); root=Path(directory); root.mkdir(parents=True,exist_ok=True); registry=DetectionRegistry()
    # Built-in plug-ins are loaded from files, keeping drop-in discovery independent from GUI code.
    for file in sorted(root.glob("*.py")):
        if file.name.startswith("_"): continue
        try:
            module_name=f"_inspection_plugin_{file.stem}"
            spec=importlib.util.spec_from_file_location(module_name,file)
            if spec is None or spec.loader is None: raise ImportError("Could not create module spec")
            module=importlib.util.module_from_spec(spec); sys.modules[module_name]=module; spec.loader.exec_module(module)
            for _,cls in inspect.getmembers(module,inspect.isclass):
                if issubclass(cls,DetectionAlgorithm) and cls is not DetectionAlgorithm and cls.__module__==module.__name__:
                    registry.register(cls()); log("INFO",f"Loaded detector plugin: {cls.name}")
        except Exception as exc: log("ERROR",f"Detector plugin {file.name} skipped: {exc}")
    return registry
