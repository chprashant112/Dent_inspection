from __future__ import annotations
import threading
from mobile_inspection_app.interfaces import ChannelController
from mobile_inspection_app.lighting.protocol import build_4ch_frame, build_8ch_frame_unconfirmed, hex_frame

class SimulatorController:
    def __init__(self, on_log=None):
        self._open=False; self.port="SIMULATOR"; self.frames=[]; self.on_log=on_log or (lambda level,msg: None); self._lock=threading.Lock()
    @property
    def is_open(self): return self._open
    def connect(self, port: str="SIMULATOR", baud: int=9600): self.port=port; self._open=True; self.on_log("INFO",f"Light simulator connected ({port}, {baud} baud)")
    def disconnect(self): self.all_off(); self._open=False
    def set_channels(self, levels: list[int], unconfirmed_8ch: bool=False):
        if not self._open: raise RuntimeError("Light controller is not connected")
        frame=build_8ch_frame_unconfirmed(levels) if unconfirmed_8ch else build_4ch_frame(levels)
        with self._lock: self.frames.append(frame)
        self.on_log("INFO",f"TX {self.port}: {hex_frame(frame)}" + (" [8-channel UNCONFIRMED]" if unconfirmed_8ch else ""))
    def all_off(self):
        if not self._open: return
        try: self.set_channels([0]*8 if getattr(self,"_eight",False) else [0]*4, unconfirmed_8ch=getattr(self,"_eight",False))
        except Exception as exc: self.on_log("WARN",f"Could not send simulator ALL OFF: {exc}")

class SerialController:
    def __init__(self, on_log=None):
        self._serial=None; self.on_log=on_log or (lambda level,msg: None); self._lock=threading.Lock(); self._eight=False
    @property
    def is_open(self): return self._serial is not None and self._serial.is_open
    def connect(self, port: str, baud: int=9600):
        try: import serial
        except ImportError as exc: raise RuntimeError("Real serial lighting requires optional package pyserial") from exc
        self._serial=serial.Serial(port=port,baudrate=baud,bytesize=8,parity="N",stopbits=1,timeout=1,write_timeout=2)
        self.on_log("INFO",f"Serial light controller connected at {port}, {baud} baud, 8N1")
    def disconnect(self):
        try: self.all_off()
        finally:
            if self._serial:
                self._serial.close(); self._serial=None
    def set_channels(self, levels: list[int], unconfirmed_8ch: bool=False):
        frame=build_8ch_frame_unconfirmed(levels) if unconfirmed_8ch else build_4ch_frame(levels)
        if not self.is_open: raise RuntimeError("Serial light controller is not connected")
        with self._lock: self._serial.write(frame); self._serial.flush()
        self.on_log("INFO",f"TX serial: {hex_frame(frame)}" + (" [8-channel UNCONFIRMED]" if unconfirmed_8ch else ""))
    def all_off(self):
        if self.is_open:
            try: self.set_channels([0]*8 if self._eight else [0]*4,unconfirmed_8ch=self._eight)
            except Exception as exc: self.on_log("ERROR",f"ALL OFF failed: {exc}")
