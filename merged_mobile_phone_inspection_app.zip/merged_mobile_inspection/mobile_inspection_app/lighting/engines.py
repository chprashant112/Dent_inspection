from __future__ import annotations
import time
from mobile_inspection_app.lighting.protocol import _clamp

class LightEngine:
    dual=False; topology=""
    def __init__(self, controller_a, controller_b=None, settle_ms=350, on_log=None):
        self.controller_a=controller_a; self.controller_b=controller_b; self.settle_ms=max(0,int(settle_ms)); self.on_log=on_log or (lambda level,msg:None)
    def connect(self, port_a="SIMULATOR", port_b="SIMULATOR", baud=9600):
        try:
            self.controller_a.connect(port_a,baud)
            if self.controller_b: self.controller_b.connect(port_b,baud)
        except Exception:
            self.all_off(); self.disconnect(); raise
    def apply(self, rgb): self.apply_pair(rgb,(0,0,0))
    def apply_pair(self,rgb_a,rgb_b=(0,0,0)):
        raise NotImplementedError
    def _settle(self):
        if self.settle_ms: time.sleep(self.settle_ms/1000)
    def all_off(self):
        errs=[]
        for c in (self.controller_a,self.controller_b):
            if c:
                try: c.all_off()
                except Exception as exc: errs.append(str(exc))
        if errs: self.on_log("ERROR","Light all_off failures: "+"; ".join(errs))
    def disconnect(self):
        for c in (self.controller_a,self.controller_b):
            if c:
                try: c.disconnect()
                except Exception as exc: self.on_log("WARN",f"Light disconnect: {exc}")

class Single4Engine(LightEngine):
    topology="LIGHT_SINGLE_4"; dual=False
    def apply_pair(self,rgb_a,rgb_b=(0,0,0)):
        vals=[_clamp(v) for v in rgb_a]+[0]
        try: self.controller_a.set_channels(vals); self._settle()
        except Exception: self.all_off(); raise

class Dual4Engine(LightEngine):
    topology="LIGHT_DUAL_4"; dual=True
    def apply_pair(self,rgb_a,rgb_b=(0,0,0)):
        try:
            self.controller_a.set_channels([_clamp(v) for v in rgb_a]+[0])
            if not self.controller_b: raise RuntimeError("Dual4 requires two controllers")
            self.controller_b.set_channels([_clamp(v) for v in rgb_b]+[0])
            self._settle()
        except Exception: self.all_off(); raise

class Single8Engine(LightEngine):
    topology="LIGHT_SINGLE_8"; dual=True; unconfirmed=True
    def apply_pair(self,rgb_a,rgb_b=(0,0,0)):
        levels=[_clamp(v) for v in rgb_a]+[_clamp(v) for v in rgb_b]+[0,0]
        try: self.controller_a.set_channels(levels,unconfirmed_8ch=True); self._settle()
        except Exception: self.all_off(); raise
