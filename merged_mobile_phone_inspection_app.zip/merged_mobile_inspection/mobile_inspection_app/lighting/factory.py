from __future__ import annotations
from mobile_inspection_app.lighting.controllers import SimulatorController, SerialController
from mobile_inspection_app.lighting.engines import Single4Engine, Dual4Engine, Single8Engine

def build_engine(topology: str, ports: tuple[str,str] = ("SIMULATOR","SIMULATOR"), baud: int=9600, on_log=None, settle_ms: int=350):
    log=on_log or (lambda level,msg:None)
    def controller(port): return SimulatorController(log) if str(port).upper()=="SIMULATOR" else SerialController(log)
    a=controller(ports[0]); b=controller(ports[1]) if topology=="LIGHT_DUAL_4" else None
    if topology=="LIGHT_SINGLE_4": engine=Single4Engine(a,None,settle_ms,log)
    elif topology=="LIGHT_DUAL_4": engine=Dual4Engine(a,b,settle_ms,log)
    elif topology=="LIGHT_SINGLE_8": engine=Single8Engine(a,None,settle_ms,log); a._eight=True
    else: raise ValueError(f"Unknown lighting topology: {topology}")
    return engine
