"""ALT-E4RS protocol helpers. The 4-channel frame is confirmed; 8-channel is not."""
from __future__ import annotations

def _clamp(level: int) -> int: return max(0,min(255,int(level)))

def build_4ch_frame(levels: list[int] | tuple[int,...]) -> bytes:
    if len(levels)!=4: raise ValueError("4-channel controller requires exactly four channel values")
    vals=[_clamp(x) for x in levels]
    checksum=0x15
    for value in vals: checksum ^= value
    return bytes([0x4C,0x15,*vals,checksum,0x0D,0x0A])

def build_8ch_frame_unconfirmed(levels: list[int] | tuple[int,...]) -> bytes:
    """Placeholder extrapolation only. Do not treat as validated hardware protocol."""
    if len(levels)!=8: raise ValueError("8-channel placeholder requires exactly eight channel values")
    vals=[_clamp(x) for x in levels]
    checksum=0x15
    for value in vals: checksum ^= value
    return bytes([0x4C,0x15,*vals,checksum,0x0D,0x0A])

def hex_frame(frame: bytes) -> str: return " ".join(f"{b:02X}" for b in frame)
