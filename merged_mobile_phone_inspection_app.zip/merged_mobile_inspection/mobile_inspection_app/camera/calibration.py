from __future__ import annotations
import json
from pathlib import Path

class CalibrationStore:
    def __init__(self, path: str | Path):
        self.path=Path(path); self.data={"mm_per_px":{},"stitch_transform":None}
        if self.path.exists():
            try: self.data=json.loads(self.path.read_text(encoding="utf-8"))
            except Exception: pass
    def set_scale(self, source: str, pixel_length: float, known_mm: float) -> float:
        if pixel_length<=0 or known_mm<=0: raise ValueError("Pixel and reference lengths must be positive")
        scale=float(known_mm)/float(pixel_length); self.data.setdefault("mm_per_px",{})[source]=scale; self.save(); return scale
    def get_scale(self, source: str): return self.data.get("mm_per_px",{}).get(source)
    def lock_stitch(self, transform): self.data["stitch_transform"]=transform; self.save()
    def save(self):
        self.path.parent.mkdir(parents=True,exist_ok=True); self.path.write_text(json.dumps(self.data,indent=2),encoding="utf-8")
