"""Basler backend with explicit sensor-ROI handling.

By default the camera is reset to offset (0, 0) and maximum Width/Height, so a
small saved ROI cannot silently restrict the field of view to the sensor's top-left.
"""
from __future__ import annotations
import numpy as np
from mobile_inspection_app.interfaces import CameraBackend


class BaslerCamera(CameraBackend):
    def __init__(self, device_index: int = 0, on_log=None):
        self.device_index = device_index
        self.camera = None
        self.converter = None
        self.on_log = on_log or (lambda level, message: print(f"{level}: {message}"))
        self._actual_width: int | None = None
        self._actual_height: int | None = None

    def _log(self, level: str, message: str) -> None:
        try: self.on_log(level, message)
        except Exception: pass

    @staticmethod
    def _node_value(node, method: str, fallback=None):
        try:
            fn = getattr(node, method, None)
            if callable(fn): return fn()
        except Exception: pass
        try:
            return getattr(node, method.replace("Get", ""))
        except Exception:
            return fallback

    def _set_node(self, name: str, value, clamp: bool = False) -> bool:
        """Write a GenICam node defensively; node ranges vary across camera models."""
        if self.camera is None: return False
        try:
            node = getattr(self.camera, name)
            if hasattr(node, "IsWritable") and not node.IsWritable():
                self._log("WARN", f"Camera {self.device_index+1}: {name} is not writable")
                return False
            target = value
            if clamp:
                try:
                    lo = node.GetMin() if hasattr(node, "GetMin") else node.Min
                    hi = node.GetMax() if hasattr(node, "GetMax") else node.Max
                    target = max(lo, min(hi, target))
                    inc = node.GetInc() if hasattr(node, "GetInc") else 1
                    if inc and inc > 1: target = lo + ((target - lo) // inc) * inc
                except Exception:
                    pass
            node.SetValue(target)
            return True
        except Exception as exc:
            self._log("WARN", f"Camera {self.device_index+1}: cannot set {name}={value}: {exc}")
            return False

    def _get_node_value(self, name: str):
        try:
            node = getattr(self.camera, name)
            return node.GetValue() if hasattr(node, "GetValue") else int(node)
        except Exception:
            return None

    def open(self) -> None:
        try:
            from pypylon import pylon
        except ImportError as exc:
            raise RuntimeError("Basler support requires optional package 'pypylon'.") from exc
        factory = pylon.TlFactory.GetInstance()
        devices = factory.EnumerateDevices()
        if self.device_index >= len(devices):
            raise RuntimeError(f"Basler camera index {self.device_index} not found; {len(devices)} device(s) discovered.")
        self.camera = pylon.InstantCamera(factory.CreateDevice(devices[self.device_index]))
        self.camera.Open()
        self.converter = pylon.ImageFormatConverter()
        self.converter.OutputPixelFormat = pylon.PixelType_BGR8packed
        self.converter.OutputBitAlignment = pylon.OutputBitAlignment_MsbAligned

    def apply_settings(self, exposure_us: float, gain: float, fps: float, width: int, height: int, full_sensor: bool = True) -> None:
        if self.camera is None: raise RuntimeError("Camera is not open")

        # Normal exposure/gain/frame-rate settings.
        for node, value in (("ExposureTime", exposure_us), ("Gain", gain), ("AcquisitionFrameRate", fps)):
            self._set_node(node, value, clamp=True)

        # IMPORTANT: Basler Width/Height describe a sensor ROI, not a resize of the
        # full image. First clear old offsets, otherwise even a max Width/Height may
        # still select a region displaced from the origin.
        for offset in ("OffsetX", "OffsetY"):
            try:
                node = getattr(self.camera, offset)
                min_value = node.GetMin() if hasattr(node, "GetMin") else 0
                self._set_node(offset, min_value, clamp=True)
            except Exception:
                # Some camera models do not expose an offset node.
                pass

        if full_sensor:
            # Use the maximum legal dimensions on the current camera model.
            # Width/Height are read only after offsets have been reset.
            for name in ("Width", "Height"):
                try:
                    node = getattr(self.camera, name)
                    maximum = node.GetMax() if hasattr(node, "GetMax") else node.Max
                    if not self._set_node(name, maximum, clamp=True):
                        raise RuntimeError(f"could not set {name} to sensor maximum {maximum}")
                except Exception as exc:
                    self._log("ERROR", f"Camera {self.device_index+1}: full-sensor setup for {name} failed: {exc}")
                    raise RuntimeError(f"Unable to configure full sensor {name}: {exc}") from exc
        else:
            # Explicit dimensions are a crop unless the camera supports sensor
            # decimation/binning. Labelled as fixed ROI in the UI for this reason.
            for name, value in (("Width", width), ("Height", height)):
                try:
                    if not self._set_node(name, int(value), clamp=True):
                        raise RuntimeError(f"could not set {name}={value}")
                except Exception as exc:
                    raise RuntimeError(f"Unable to set camera {name}={value}: {exc}") from exc

        self._actual_width = self._get_node_value("Width")
        self._actual_height = self._get_node_value("Height")
        mode = "full sensor FOV" if full_sensor else "fixed sensor ROI"
        self._log("INFO", f"Camera {self.device_index+1}: {mode}; output frame {self._actual_width} x {self._actual_height}")

    def frame_dimensions(self) -> tuple[int, int] | None:
        width = self._get_node_value("Width") if self.camera is not None else self._actual_width
        height = self._get_node_value("Height") if self.camera is not None else self._actual_height
        if width and height: return int(width), int(height)
        return None

    def start(self) -> None:
        if self.camera is None: self.open()
        from pypylon import pylon
        self.camera.StartGrabbing(pylon.GrabStrategy_LatestImageOnly)

    def read(self, timeout_ms: int = 1000) -> np.ndarray | None:
        if self.camera is None or not self.camera.IsGrabbing(): return None
        from pypylon import pylon
        result = self.camera.RetrieveResult(timeout_ms, pylon.TimeoutHandling_Return)
        if result is None: return None
        try:
            if not result.GrabSucceeded(): return None
            frame = self.converter.Convert(result).GetArray().copy()
            # Some cameras expose dynamic format changes; trust the delivered frame dimensions.
            self._actual_height, self._actual_width = frame.shape[:2]
            return frame
        finally:
            result.Release()

    def stop(self) -> None:
        try:
            if self.camera is not None and self.camera.IsGrabbing(): self.camera.StopGrabbing()
        except Exception: pass

    def close(self) -> None:
        self.stop()
        try:
            if self.camera is not None and self.camera.IsOpen(): self.camera.Close()
        finally: self.camera = None
