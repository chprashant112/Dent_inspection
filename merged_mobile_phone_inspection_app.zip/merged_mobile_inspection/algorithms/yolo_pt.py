from __future__ import annotations
import cv2
import numpy as np
from mobile_inspection_app.detection.base import DetectionAlgorithm, DetectionResult, DefectBox

class YOLOPtAdapter(DetectionAlgorithm):
    name="YOLO .pt"
    version="1.0"
    DEFAULTS={"weights_path":"","conf":.25,"iou":.45,"imgsz":640}
    SETTINGS_SCHEMA=[{"key":"weights_path","label":"Weights (.pt)","kind":"file"},{"key":"conf","label":"Confidence","kind":"float","from":0,"to":1,"step":.01},{"key":"iou","label":"IoU","kind":"float","from":0,"to":1,"step":.01},{"key":"imgsz","label":"Image size","kind":"choice","values":[320,416,512,640,960,1280]}]
    def process(self,image,inspection_mask=None,context=None):
        context=context or {}; p={**self.DEFAULTS,**context.get("params",{})}
        try: from ultralytics import YOLO
        except Exception as exc:
            raise RuntimeError(f"YOLO adapter is installed but Ultralytics/PyTorch is unavailable: {exc}") from exc
        weights=str(p.get("weights_path","")).strip()
        if not weights: raise RuntimeError("Choose a .pt weights file in the YOLO settings first")
        work=image.copy(); h,w=image.shape[:2]
        mask=np.full((h,w),255,np.uint8) if inspection_mask is None else np.where(inspection_mask>0,255,0).astype(np.uint8)
        work[mask==0]=0
        model=YOLO(weights); pred=model.predict(work,conf=float(p["conf"]),iou=float(p["iou"]),imgsz=int(p["imgsz"]),verbose=False)[0]
        out=image.copy(); binary=np.zeros((h,w),np.uint8); boxes=[]
        if pred.boxes is not None:
            for i,box in enumerate(pred.boxes):
                x1,y1,x2,y2=map(int,box.xyxy[0].tolist()); x1=max(0,x1); y1=max(0,y1); x2=min(w,x2); y2=min(h,y2)
                if x2<=x1 or y2<=y1 or not np.any(mask[y1:y2,x1:x2]): continue
                binary[y1:y2,x1:x2]=mask[y1:y2,x1:x2]
                conf=float(box.conf[0]); cls=int(box.cls[0]); label=model.names.get(cls,str(cls))
                boxes.append(DefectBox(x1,y1,x2-x1,y2-y1,f"{label} {conf:.2f}",(x2-x1)*(y2-y1),x1,y1,x2-x1,y2-y1,True))
                cv2.rectangle(out,(x1,y1),(x2,y2),(0,0,255),3); cv2.putText(out,f"{label} {conf:.2f}",(x1,max(18,y1-5)),cv2.FONT_HERSHEY_SIMPLEX,.55,(0,0,255),2)
        if not boxes: cv2.putText(out,"NO DEFECTS FLAGGED",(18,32),cv2.FONT_HERSHEY_SIMPLEX,.7,(40,180,40),2)
        return DetectionResult(self.name,out,binary,float(np.count_nonzero(binary)/max(h*w,1)),f"{len(boxes)} YOLO proposal(s); model-specific performance not validated.",boxes,p)
