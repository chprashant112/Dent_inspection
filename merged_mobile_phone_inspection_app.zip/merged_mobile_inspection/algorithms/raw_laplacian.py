from __future__ import annotations
import cv2
import numpy as np
from mobile_inspection_app.detection.base import DetectionAlgorithm, DetectionResult, DefectBox

class RawLaplacianV1(DetectionAlgorithm):
    name="RAW Laplacian V1"
    version="1.0"
    DEFAULTS={"k":2.8,"min_magnitude":18.0,"lap_ksize":3,"morph_kernel":3,"min_area_px":20,"max_area_px":2000000,"min_box_size_px":70,"box_expand_ratio":0.75,"blob_max_aspect":12.0,"blob_min_solidity":0.08,"edge_auto_orientation":True,"temporal_enabled":False,"persistence_frames":3,"persistence_hits":2,"window_backglass":21,"window_camera":15,"window_surrounding":21,"window_edge_long":31,"window_edge_short":5}
    SETTINGS_SCHEMA=[
      {"key":"k","label":"Std multiplier k","kind":"float","from":0.1,"to":10,"step":0.1},
      {"key":"min_magnitude","label":"Minimum Laplacian magnitude","kind":"float","from":0,"to":255,"step":1},
      {"key":"lap_ksize","label":"Laplacian kernel","kind":"choice","values":[1,3,5,7]},
      {"key":"morph_kernel","label":"Morphology kernel","kind":"int","from":1,"to":15,"step":2},
      {"key":"min_area_px","label":"Minimum blob area (px)","kind":"int","from":1,"to":100000,"step":1},
      {"key":"max_area_px","label":"Maximum blob area (px)","kind":"int","from":100,"to":5000000,"step":100},
      {"key":"min_box_size_px","label":"Minimum proposal box (px)","kind":"int","from":1,"to":2000,"step":1},
      {"key":"box_expand_ratio","label":"Proposal box expansion","kind":"float","from":0,"to":3,"step":0.05},
      {"key":"blob_max_aspect","label":"Maximum blob aspect ratio","kind":"float","from":1,"to":50,"step":0.5},
      {"key":"blob_min_solidity","label":"Minimum solidity","kind":"float","from":0,"to":1,"step":0.01},
      {"key":"edge_auto_orientation","label":"Directional windows on Bulged Edge","kind":"bool"},
      {"key":"temporal_enabled","label":"Temporal persistence","kind":"bool"},
    ]

    @staticmethod
    def _local_stats(lap: np.ndarray, valid: np.ndarray, ksize: tuple[int,int]):
        weight=valid.astype(np.float32); lapf=lap.astype(np.float32)
        count=cv2.boxFilter(weight,-1,ksize,normalize=False,borderType=cv2.BORDER_REFLECT)
        total=cv2.boxFilter(lapf*weight,-1,ksize,normalize=False,borderType=cv2.BORDER_REFLECT)
        total2=cv2.boxFilter(lapf*lapf*weight,-1,ksize,normalize=False,borderType=cv2.BORDER_REFLECT)
        mean=total/np.maximum(count,1.0)
        variance=np.maximum(total2/np.maximum(count,1.0)-mean*mean,0)
        return mean,np.sqrt(variance)

    @staticmethod
    def _components(binary, params, mask):
        kernel=max(1,int(params.get("morph_kernel",3))); kernel += (kernel%2==0)
        ellipse=cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(kernel,kernel))
        m=cv2.morphologyEx(binary,cv2.MORPH_CLOSE,ellipse); m=cv2.dilate(m,ellipse); m=cv2.morphologyEx(m,cv2.MORPH_OPEN,ellipse)
        m=cv2.bitwise_and(m,mask)
        contours,_=cv2.findContours(m,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
        h,w=m.shape; boxes=[]; clean=np.zeros_like(m)
        mn=max(1,int(params.get("min_area_px",20))); mx=max(mn,int(params.get("max_area_px",2_000_000)))
        max_aspect=float(params.get("blob_max_aspect",12)); min_sol=float(params.get("blob_min_solidity",.08))
        for cnt in contours:
            area=float(cv2.contourArea(cnt)); x,y,bw,bh=cv2.boundingRect(cnt)
            if area<mn or area>mx: continue
            aspect=max(bw,bh)/max(1,min(bw,bh))
            hull=cv2.convexHull(cnt); hull_area=max(float(cv2.contourArea(hull)),1.0); solidity=area/hull_area
            if aspect>max_aspect or solidity<min_sol: continue
            cv2.drawContours(clean,[cnt],-1,255,-1)
            minside=max(1,int(params.get("min_box_size_px",70))); side=max(minside,int(max(bw,bh)*(1+float(params.get("box_expand_ratio",.75)))))
            cx=x+bw//2; cy=y+bh//2; bx=max(0,cx-side//2); by=max(0,cy-side//2); ex=min(w,bx+side); ey=min(h,by+side); bx=max(0,ex-side); by=max(0,ey-side)
            if not np.any(mask[by:ey,bx:ex]): continue
            boxes.append(DefectBox(bx,by,ex-bx,ey-by,f"DEFECT {len(boxes)+1}",int(area),x,y,bw,bh,True))
        return clean,boxes

    def process(self,image,inspection_mask=None,context=None)->DetectionResult:
        if image is None: raise ValueError("No image supplied to RAW Laplacian")
        context=context or {}; params={**self.DEFAULTS,**context.get("params",{})}
        h,w=image.shape[:2]
        mask=np.full((h,w),255,np.uint8) if inspection_mask is None else np.where(inspection_mask>0,255,0).astype(np.uint8)
        gray=cv2.cvtColor(image,cv2.COLOR_BGR2GRAY)
        ks=int(params.get("lap_ksize",3)); ks=ks if ks in (1,3,5,7) else 3
        lap=np.abs(cv2.Laplacian(gray,cv2.CV_32F,ksize=ks))
        valid=mask>0; combined=np.zeros((h,w),np.uint8)
        selected_regions=context.get("selected_regions") or []
        regions=[r for r in selected_regions if r.get("mask") is not None] if selected_regions else [{"name":"All","mask":mask}]
        for region in regions:
            rmask=(region["mask"]>0)&valid
            if not rmask.any(): continue
            name=str(region.get("name","" )).lower()
            if "edge" in name and params.get("edge_auto_orientation",True):
                windows=[(int(params.get("window_edge_short",5)),int(params.get("window_edge_long",31))),(int(params.get("window_edge_long",31)),int(params.get("window_edge_short",5)))]
            elif "camera" in name: windows=[(int(params.get("window_camera",15)),int(params.get("window_camera",15)))]
            elif "back" in name: windows=[(int(params.get("window_backglass",21)),int(params.get("window_backglass",21)))]
            elif "surround" in name: windows=[(int(params.get("window_surrounding",21)),int(params.get("window_surrounding",21)))]
            else: windows=[(21,21)]
            candidate=np.zeros((h,w),bool)
            for kw,kh in windows:
                kw=max(3,kw); kh=max(3,kh)
                if kw%2==0: kw+=1
                if kh%2==0: kh+=1
                mean,std=self._local_stats(lap,rmask,(kw,kh))
                threshold=np.maximum(mean+float(params.get("k",2.8))*std,float(params.get("min_magnitude",18)))
                candidate |= (lap>=threshold)&rmask
            combined[candidate]=255
        clean,boxes=self._components(combined,params,mask)
        annotated=image.copy()
        for i,b in enumerate(boxes,1):
            cv2.rectangle(annotated,(b.x,b.y),(b.x+b.w-1,b.y+b.h-1),(0,0,255),4)
            cv2.rectangle(annotated,(b.raw_x,b.raw_y),(b.raw_x+b.raw_w-1,b.raw_y+b.raw_h-1),(0,70,255),1)
            cv2.putText(annotated,f"DEFECT {i}",(b.x,max(20,b.y-7)),cv2.FONT_HERSHEY_SIMPLEX,.6,(0,0,255),2,cv2.LINE_AA)
        if not boxes: cv2.putText(annotated,"NO DEFECTS FLAGGED",(18,32),cv2.FONT_HERSHEY_SIMPLEX,.75,(40,210,80),2,cv2.LINE_AA)
        score=float(np.count_nonzero(clean)/max(h*w,1))
        return DetectionResult(self.name,annotated,clean,score,f"{len(boxes)} candidate defect(s); proposals require human review.",boxes,params)
