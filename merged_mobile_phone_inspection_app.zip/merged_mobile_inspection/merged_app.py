from __future__ import annotations
import os, time, json, threading
from pathlib import Path
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import cv2
import numpy as np
from PIL import Image, ImageTk
from collections import deque
from mobile_inspection_app.camera.camera_manager import CameraManager
from mobile_inspection_app.camera.basler_camera import BaslerCamera
from mobile_inspection_app.camera.simulated_camera import SimulatedCamera

ROOT_DIR = Path(__file__).resolve().parent
CAPTURE_DIR = ROOT_DIR / 'captures'

class LiveLaplacian:
    def __init__(self):
        self.buffer = deque(maxlen=3)
        self.last_shape = None
    def detect(self, image, allowed_mask, k=2.8, min_strength=18, ksize=3, window=31, min_area=20, persistence=True):
        gray=cv2.cvtColor(image,cv2.COLOR_BGR2GRAY) if image.ndim==3 else image
        ksize=int(ksize); window=max(3,int(window)); window += (window%2==0)
        lap=np.abs(cv2.Laplacian(gray,cv2.CV_32F,ksize=ksize))
        valid=(allowed_mask>0).astype(np.float32)
        count=cv2.boxFilter(valid,-1,(window,window),normalize=False,borderType=cv2.BORDER_REFLECT)
        sum1=cv2.boxFilter(lap*valid,-1,(window,window),normalize=False,borderType=cv2.BORDER_REFLECT)
        sum2=cv2.boxFilter(lap*lap*valid,-1,(window,window),normalize=False,borderType=cv2.BORDER_REFLECT)
        mean=sum1/np.maximum(count,1); var=np.maximum(sum2/np.maximum(count,1)-mean*mean,0)
        raw=((lap>=np.maximum(mean+float(k)*np.sqrt(var),float(min_strength))) & (valid>0)).astype(np.uint8)
        if self.last_shape != raw.shape:
            self.buffer.clear(); self.last_shape=raw.shape
        self.buffer.append(raw)
        if persistence and len(self.buffer)>=2:
            mask=(np.sum(self.buffer,axis=0)>=2).astype(np.uint8)*255
        else: mask=raw*255
        kernel=cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(3,3))
        mask=cv2.morphologyEx(mask,cv2.MORPH_CLOSE,kernel)
        contours,_=cv2.findContours(mask,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
        output=image.copy(); defects=[]
        for c in contours:
            area=cv2.contourArea(c)
            if area < float(min_area): continue
            x,y,w,h=cv2.boundingRect(c)
            if w<2 and h<2: continue
            defects.append((x,y,w,h,float(area)))
        for i,(x,y,w,h,area) in enumerate(defects,1):
            cv2.rectangle(output,(x,y),(x+w,y+h),(0,0,255),max(2,round(min(image.shape[:2])/400)))
            cv2.putText(output,f'DEFECT {i}',(x,max(18,y-7)),cv2.FONT_HERSHEY_SIMPLEX,max(.45,min(image.shape[:2])/1500),(0,0,255),2,cv2.LINE_AA)
        if not defects: cv2.putText(output,'NO DEFECTS FLAGGED',(18,32),cv2.FONT_HERSHEY_SIMPLEX,.7,(80,220,80),2,cv2.LINE_AA)
        return output,mask,defects

class MergedInspectionApp:
    def __init__(self, root):
        self.root=root; self.root.title('Mobile Phone Inspection — Camera + main6 Workflow')
        self.root.geometry('1450x900'); self.root.minsize(1050,700); self.root.configure(bg='#111418')
        self.style=ttk.Style(); self.style.theme_use('clam')
        self.style.configure('.',background='#191d22',foreground='#e6e6e6',font=('Segoe UI',10))
        self.style.configure('TFrame',background='#191d22'); self.style.configure('TLabel',background='#191d22',foreground='#e6e6e6')
        self.style.configure('TLabelframe',background='#191d22',foreground='#00a8ff'); self.style.configure('TLabelframe.Label',background='#191d22',foreground='#00a8ff')
        self.style.configure('TButton',padding=5,background='#252c34',foreground='#f2f4f8')
        self.backend_mode=tk.StringVar(value='Basler')
        self.view_var=tk.StringVar(value='Stitched')
        self.stitch_var=tk.StringVar(value='Aligned side-by-side')
        self.roi_tool=tk.StringVar(value='Inspection ROI')
        self.shape_var=tk.StringVar(value='Rectangle')
        self.live_var=tk.BooleanVar(value=True)
        self.k_var=tk.DoubleVar(value=2.8); self.min_strength_var=tk.DoubleVar(value=18); self.min_area_var=tk.DoubleVar(value=20)
        self.ksize_var=tk.StringVar(value='3'); self.window_var=tk.StringVar(value='31')
        self.cameras=None; self.running=False; self.current_frame=None; self.display_frame=None; self.tk_image=None
        self.inspection_roi=None; self.masks=[]; self.mask_counter=0; self.drawing=False; self.draw_start=None; self.preview_shape=None
        self.scale=1.0; self.offset_x=0; self.offset_y=0; self.detector=LiveLaplacian(); self.latest_result=None; self.last_render_size=(1,1)
        self._build_ui(); self.root.protocol('WM_DELETE_WINDOW',self.close); self._tick()

    def _build_ui(self):
        header=ttk.Frame(self.root,padding=(10,8)); header.pack(fill='x')
        ttk.Label(header,text='MOBILE PHONE INSPECTION',font=('Segoe UI',15,'bold')).pack(side='left')
        ttk.Label(header,text='Camera capture + main6 detection | no light control',foreground='#9ca3af').pack(side='left',padx=18)
        body=ttk.Panedwindow(self.root,orient='horizontal'); body.pack(fill='both',expand=True,padx=8,pady=(0,8))
        left=ttk.Frame(body); right_outer=ttk.Frame(body); body.add(left,weight=7); body.add(right_outer,weight=3)
        camrow=ttk.Frame(left,padding=5); camrow.pack(fill='x')
        ttk.Label(camrow,text='Backend').pack(side='left')
        ttk.Combobox(camrow,textvariable=self.backend_mode,values=['Basler','Simulator'],state='readonly',width=10).pack(side='left',padx=5)
        ttk.Label(camrow,text='View').pack(side='left',padx=(8,0))
        view=ttk.Combobox(camrow,textvariable=self.view_var,values=['Camera 1','Camera 2','Stitched'],state='readonly',width=14); view.pack(side='left',padx=5); view.bind('<<ComboboxSelected>>',self._view_changed)
        ttk.Label(camrow,text='Stitch').pack(side='left',padx=(8,0))
        ttk.Combobox(camrow,textvariable=self.stitch_var,values=['Auto feature stitch','Aligned side-by-side','Vertical aligned join'],state='readonly',width=22).pack(side='left',padx=5)
        self.start_btn=ttk.Button(camrow,text='START CAMERAS',command=self.toggle_cameras); self.start_btn.pack(side='left',padx=5)
        ttk.Button(camrow,text='CAPTURE IMAGE',command=self.capture).pack(side='left',padx=5)
        ttk.Button(camrow,text='FIT VIEW',command=self.render_current).pack(side='left',padx=5)
        self.canvas=tk.Canvas(left,bg='#080a0c',highlightthickness=0,cursor='crosshair'); self.canvas.pack(fill='both',expand=True,padx=5,pady=5)
        self.canvas.bind('<Configure>',lambda e:self.render_current())
        self.canvas.bind('<ButtonPress-1>',self._draw_start); self.canvas.bind('<B1-Motion>',self._draw_drag); self.canvas.bind('<ButtonRelease-1>',self._draw_end)
        self.canvas.bind('<MouseWheel>',self._wheel_zoom)
        self.status=ttk.Label(left,text='Choose Basler or Simulator, then START CAMERAS.',padding=5); self.status.pack(fill='x')
        # Scrollable settings panel
        right_canvas=tk.Canvas(right_outer,bg='#191d22',highlightthickness=0); sb=ttk.Scrollbar(right_outer,orient='vertical',command=right_canvas.yview); right_canvas.configure(yscrollcommand=sb.set)
        sb.pack(side='right',fill='y'); right_canvas.pack(side='left',fill='both',expand=True)
        panel=ttk.Frame(right_canvas,padding=8); win=right_canvas.create_window((0,0),window=panel,anchor='nw')
        panel.bind('<Configure>',lambda e:right_canvas.configure(scrollregion=right_canvas.bbox('all'))); right_canvas.bind('<Configure>',lambda e:right_canvas.itemconfigure(win,width=e.width))
        right_canvas.bind_all('<MouseWheel>',lambda e:right_canvas.yview_scroll(int(-e.delta/120),'units'))
        roi=ttk.LabelFrame(panel,text='Inspection / Mask ROIs',padding=8); roi.pack(fill='x',pady=5)
        ttk.Label(roi,text='Draw tool').grid(row=0,column=0,sticky='w')
        ttk.Combobox(roi,textvariable=self.roi_tool,values=['Inspection ROI','Mask ROI'],state='readonly',width=17).grid(row=0,column=1,sticky='ew',padx=4,pady=3)
        ttk.Label(roi,text='Shape').grid(row=1,column=0,sticky='w')
        ttk.Combobox(roi,textvariable=self.shape_var,values=['Rectangle','Ellipse','Polygon'],state='readonly',width=17).grid(row=1,column=1,sticky='ew',padx=4,pady=3)
        ttk.Label(roi,text='Inspection ROI: one region. Masks: multiple exclusions.').grid(row=2,column=0,columnspan=2,sticky='w',pady=3)
        self.mask_list=tk.Listbox(roi,height=5,selectmode='browse',bg='#20252b',fg='#e6e6e6',selectbackground='#006ca8',borderwidth=0); self.mask_list.grid(row=3,column=0,columnspan=2,sticky='ew',pady=4)
        btns=ttk.Frame(roi); btns.grid(row=4,column=0,columnspan=2,sticky='ew')
        ttk.Button(btns,text='Delete selected mask',command=self.delete_mask).pack(side='left',fill='x',expand=True,padx=2)
        ttk.Button(btns,text='Clear all ROIs',command=self.clear_rois).pack(side='left',fill='x',expand=True,padx=2)
        ttk.Button(roi,text='Save ROI profile',command=self.save_rois).grid(row=5,column=0,columnspan=2,sticky='ew',pady=3)
        roi.columnconfigure(1,weight=1)
        det=ttk.LabelFrame(panel,text='Detection — main6 Laplacian',padding=8); det.pack(fill='x',pady=5)
        ttk.Checkbutton(det,text='Live detection',variable=self.live_var,command=self.render_current).pack(anchor='w')
        self._slider(det,'Sensitivity (k)',self.k_var,.5,8,1)
        self._slider(det,'Minimum Laplacian strength',self.min_strength_var,0,100,1)
        self._slider(det,'Minimum defect area (px)',self.min_area_var,1,2000,0)
        row=ttk.Frame(det); row.pack(fill='x',pady=4); ttk.Label(row,text='Laplacian kernel').pack(side='left'); ttk.Combobox(row,textvariable=self.ksize_var,values=['1','3','5','7'],state='readonly',width=6).pack(side='right')
        row=ttk.Frame(det); row.pack(fill='x',pady=4); ttk.Label(row,text='Local window').pack(side='left'); ttk.Combobox(row,textvariable=self.window_var,values=['9','15','21','31','51','75','101'],state='readonly',width=6).pack(side='right')
        ttk.Button(det,text='RUN DETECTION NOW',command=self.run_detection).pack(fill='x',pady=(5,2))
        ttk.Button(det,text='Save annotated result',command=self.save_result).pack(fill='x',pady=2)
        self.result_label=ttk.Label(det,text='No detection run yet.',wraplength=280); self.result_label.pack(fill='x',pady=5)
        helpf=ttk.LabelFrame(panel,text='Workflow',padding=8); helpf.pack(fill='x',pady=5)
        ttk.Label(helpf,text='1. Start cameras\n2. Choose Camera 1, Camera 2 or Stitched\n3. Draw Inspection ROI\n4. Draw any number of Mask ROIs\n5. Enable live detection or Run Detection\n6. Capture/save results',justify='left').pack(anchor='w')

    def _slider(self,parent,label,var,lo,hi,digits=1):
        frame=ttk.Frame(parent); frame.pack(fill='x',pady=4)
        top=ttk.Frame(frame); top.pack(fill='x'); ttk.Label(top,text=label).pack(side='left')
        value=ttk.Label(top,text=f'{var.get():.{digits}f}'); value.pack(side='right')
        def changed(v): value.config(text=f'{float(v):.{digits}f}');
        ttk.Scale(frame,from_=lo,to=hi,variable=var,command=changed).pack(fill='x')

    def _new_manager(self):
        if self.backend_mode.get()=='Simulator': return CameraManager(SimulatedCamera(0),SimulatedCamera(1),on_log=self._log)
        return CameraManager(BaslerCamera(0,on_log=self._log),BaslerCamera(1,on_log=self._log),on_log=self._log)
    def _log(self,level,msg):
        try: self.root.after(0,lambda:self.status.config(text=f'{level}: {msg}'))
        except Exception: pass
    def toggle_cameras(self):
        if self.running:
            try: self.cameras.stop()
            except Exception: pass
            self.running=False; self.start_btn.config(text='START CAMERAS'); self.status.config(text='Cameras stopped.'); return
        self.cameras=self._new_manager(); view=self.view_var.get(); active=(view in ('Camera 1','Stitched'),view in ('Camera 2','Stitched'))
        def worker():
            try:
                self.cameras.start(active=active); self.running=True
                self.root.after(0,lambda:self.start_btn.config(text='STOP CAMERAS'))
                self._log('INFO','Camera stream started.')
            except Exception as e: self._log('ERROR',str(e))
        threading.Thread(target=worker,daemon=True).start()
    def _view_changed(self,event=None):
        if self.inspection_roi or self.masks:
            if not messagebox.askyesno('ROI coordinates','Changing view changes image coordinates. Clear all ROIs and redraw for this view?'):
                return
            self.clear_rois()
        if self.running:
            self.toggle_cameras(); self.root.after(250,self.toggle_cameras)
        self.render_current()
    def _get_frame(self):
        if not self.running or self.cameras is None: return None
        try:
            pair=self.cameras.latest(self.stitch_var.get())
            if self.view_var.get()=='Camera 1': return pair.camera1.image.copy() if pair.camera1 else None
            if self.view_var.get()=='Camera 2': return pair.camera2.image.copy() if pair.camera2 else None
            return pair.stitched(self.stitch_var.get())
        except Exception: return None
    def _fit_params(self,frame):
        h,w=frame.shape[:2]; cw=max(1,self.canvas.winfo_width()); ch=max(1,self.canvas.winfo_height())
        s=min(cw/w,ch/h); return s,(cw-w*s)/2,(ch-h*s)/2
    def render_current(self):
        frame=self._get_frame()
        if frame is not None: self.current_frame=frame
        if self.current_frame is None:
            self.canvas.delete('all'); self.canvas.create_text(max(100,self.canvas.winfo_width()//2),max(80,self.canvas.winfo_height()//2),text='Camera stopped / no frame',fill='#d1d5db',font=('Segoe UI',16)); return
        frame=self.current_frame.copy()
        if self.live_var.get(): frame,mask,defects=self._detect_frame(frame,draw=True); self.latest_result=(frame,mask,defects)
        self.display_frame=frame; s,ox,oy=self._fit_params(frame); self.scale=s; self.offset_x=ox; self.offset_y=oy
        h,w=frame.shape[:2]; shown=cv2.resize(frame,(max(1,int(w*s)),max(1,int(h*s))),interpolation=cv2.INTER_AREA if s<1 else cv2.INTER_LINEAR)
        self.tk_image=ImageTk.PhotoImage(Image.fromarray(cv2.cvtColor(shown,cv2.COLOR_BGR2RGB)))
        self.canvas.delete('all'); self.canvas.create_image(ox,oy,anchor='nw',image=self.tk_image)
        self._draw_roi_overlays()
    def _effective_mask(self,shape):
        h,w=shape[:2]; allowed=np.zeros((h,w),np.uint8)
        if self.inspection_roi:
            kind,coords=self.inspection_roi; self._raster(allowed,kind,coords,255)
        else: allowed[:]=255
        for item in self.masks:
            if item['enabled']: self._raster(allowed,item['shape'],item['coords'],0)
        return allowed
    def _raster(self,mask,kind,coords,value):
        if kind=='Rectangle':
            x1,y1,x2,y2=map(int,coords); cv2.rectangle(mask,(x1,y1),(x2,y2),value,-1)
        elif kind=='Ellipse':
            x1,y1,x2,y2=map(int,coords); cv2.ellipse(mask,((x1+x2)//2,(y1+y2)//2),(max(1,abs(x2-x1)//2),max(1,abs(y2-y1)//2)),0,0,360,value,-1)
        elif kind=='Polygon': cv2.fillPoly(mask,[np.array(coords,np.int32)],value)
    def _detect_frame(self,frame,draw=True):
        allowed=self._effective_mask(frame.shape)
        out,mask,defects=self.detector.detect(frame,allowed,k=self.k_var.get(),min_strength=self.min_strength_var.get(),ksize=int(self.ksize_var.get()),window=int(self.window_var.get()),min_area=self.min_area_var.get(),persistence=True)
        return (out if draw else frame),mask,defects
    def run_detection(self):
        if self.current_frame is None: messagebox.showwarning('Detection','Start a camera first.'); return
        frame=self.current_frame.copy(); out,mask,defects=self._detect_frame(frame,True); self.latest_result=(out,mask,defects); self.display_frame=out
        self.result_label.config(text=f'{len(defects)} candidate defect(s) | ROI-limited Laplacian')
        self._render_given(out)
    def _render_given(self,frame):
        self.display_frame=frame; s,ox,oy=self._fit_params(frame); self.scale=s; self.offset_x=ox; self.offset_y=oy
        h,w=frame.shape[:2]; shown=cv2.resize(frame,(max(1,int(w*s)),max(1,int(h*s))),interpolation=cv2.INTER_AREA if s<1 else cv2.INTER_LINEAR)
        self.tk_image=ImageTk.PhotoImage(Image.fromarray(cv2.cvtColor(shown,cv2.COLOR_BGR2RGB))); self.canvas.delete('all'); self.canvas.create_image(ox,oy,anchor='nw',image=self.tk_image); self._draw_roi_overlays()
    def _draw_roi_overlays(self):
        if self.current_frame is None:return
        def xy(p): return self.offset_x+p[0]*self.scale,self.offset_y+p[1]*self.scale
        if self.inspection_roi:
            kind,c=self.inspection_roi
            if kind in ('Rectangle','Ellipse'):
                x1,y1=xy((c[0],c[1])); x2,y2=xy((c[2],c[3])); self.canvas.create_rectangle(x1,y1,x2,y2,outline='#00ff88',width=2,dash=(6,3))
        for i,m in enumerate(self.masks):
            if not m['enabled']: continue
            c=m['coords']; kind=m['shape']
            if kind=='Polygon':
                pts=[xy(p) for p in c]; flat=[v for p in pts for v in p]; self.canvas.create_polygon(*flat,outline='#ff4444',fill='',width=2,dash=(5,3))
            else:
                x1,y1=xy((c[0],c[1])); x2,y2=xy((c[2],c[3])); fn=self.canvas.create_oval if kind=='Ellipse' else self.canvas.create_rectangle; fn(x1,y1,x2,y2,outline='#ff4444',width=2,dash=(5,3))
    def _canvas_to_image(self,x,y):
        return int((x-self.offset_x)/max(self.scale,1e-6)),int((y-self.offset_y)/max(self.scale,1e-6))
    def _draw_start(self,event):
        if self.current_frame is None:return
        self.drawing=True; self.draw_start=self._canvas_to_image(event.x,event.y); self.preview_shape=None
    def _draw_drag(self,event):
        if not self.drawing or not self.draw_start:return
        self.render_current(); x1,y1=self.offset_x+self.draw_start[0]*self.scale,self.offset_y+self.draw_start[1]*self.scale
        x2,y2=event.x,event.y; kind=self.shape_var.get(); fn=self.canvas.create_oval if kind=='Ellipse' else self.canvas.create_rectangle
        if kind=='Polygon': self.canvas.create_text(x2,y2,text='Polygon drawing: drag creates bounding polygon',fill='#ff6666')
        else: fn(x1,y1,x2,y2,outline='#ffff00',width=2,dash=(4,3))
    def _draw_end(self,event):
        if not self.drawing or not self.draw_start:return
        self.drawing=False; p1=self.draw_start; p2=self._canvas_to_image(event.x,event.y); h,w=self.current_frame.shape[:2]
        x1=max(0,min(w-1,p1[0])); x2=max(0,min(w-1,p2[0])); y1=max(0,min(h-1,p1[1])); y2=max(0,min(h-1,p2[1]))
        if abs(x2-x1)<3 or abs(y2-y1)<3:return
        coords=(min(x1,x2),min(y1,y2),max(x1,x2),max(y1,y2)); kind=self.shape_var.get()
        if kind=='Polygon': kind='Polygon'; coords=[(coords[0],coords[1]),(coords[2],coords[1]),(coords[2],coords[3]),(coords[0],coords[3])]
        if self.roi_tool.get()=='Inspection ROI': self.inspection_roi=(kind,coords)
        else:
            self.mask_counter+=1; self.masks.append({'name':f'Mask {self.mask_counter}','shape':kind,'coords':coords,'enabled':True}); self._refresh_mask_list()
        self.render_current()
    def _refresh_mask_list(self):
        self.mask_list.delete(0,'end')
        for m in self.masks:self.mask_list.insert('end',f"☑ {m['name']} — {m['shape']}")
    def delete_mask(self):
        sel=self.mask_list.curselection()
        if sel:self.masks.pop(sel[0]); self._refresh_mask_list(); self.render_current()
    def clear_rois(self): self.inspection_roi=None; self.masks=[]; self._refresh_mask_list(); self.render_current()
    def save_rois(self):
        if self.current_frame is None: return
        path=filedialog.asksaveasfilename(defaultextension='.json',initialdir=str(ROOT_DIR/'profiles'),filetypes=[('JSON','*.json')])
        if not path:return
        Path(path).parent.mkdir(parents=True,exist_ok=True)
        data={'view':self.view_var.get(),'stitch_mode':self.stitch_var.get(),'image_size':list(self.current_frame.shape[:2][::-1]),'inspection_roi':self.inspection_roi,'masks':self.masks}
        with open(path,'w',encoding='utf-8') as f:json.dump(data,f,indent=2)
        self.status.config(text=f'ROI profile saved: {path}')
    def capture(self):
        frame=self._get_frame()
        if frame is None: messagebox.showwarning('Capture','No fresh camera frame available.'); return
        self.current_frame=frame.copy(); CAPTURE_DIR.mkdir(exist_ok=True)
        path=CAPTURE_DIR/f"phone_{time.strftime('%Y%m%d_%H%M%S')}_{self.view_var.get().lower().replace(' ','_')}.png"
        cv2.imwrite(str(path),frame); self.status.config(text=f'Captured full frame: {path.name}'); self.render_current()
    def save_result(self):
        if not self.latest_result: messagebox.showinfo('Save result','Run detection first.'); return
        path=filedialog.asksaveasfilename(defaultextension='.png',filetypes=[('PNG','*.png')])
        if path:
            out,mask,defects=self.latest_result; cv2.imwrite(path,out); cv2.imwrite(str(Path(path).with_name(Path(path).stem+'_mask.png')),mask)
            with open(str(Path(path).with_suffix('.json')),'w',encoding='utf-8') as f:json.dump({'defects':[{'x':x,'y':y,'w':w,'h':h,'area_px':a} for x,y,w,h,a in defects]},f,indent=2)
    def _wheel_zoom(self,event):
        # Fit-to-window is intentional; zooming is not allowed to crop the live feed unexpectedly.
        return
    def _tick(self):
        if self.running:
            frame=self._get_frame()
            if frame is not None:
                if self.current_frame is None or frame.shape[:2]!=self.current_frame.shape[:2]:
                    # Avoid silently applying ROI coordinates to a differently-sized image.
                    if self.inspection_roi or self.masks:
                        self.inspection_roi=None; self.masks=[]; self._refresh_mask_list(); self.status.config(text='Frame size changed: ROIs cleared; redraw them for the new image size.')
                self.current_frame=frame
                self.render_current()
        self.root.after(80,self._tick)
    def close(self):
        try:
            if self.cameras:self.cameras.stop()
        except Exception:pass
        self.root.destroy()

def main():
    root=tk.Tk(); MergedInspectionApp(root); root.mainloop()
if __name__=='__main__':main()
