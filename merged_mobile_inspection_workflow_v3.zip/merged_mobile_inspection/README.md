# Industrial Mobile Phone Inspection App

A modular Tkinter/OpenCV application for dual-camera phone inspection. It supports Camera 1, Camera 2, and stitched views, has no light-controller controls in this app, and runs image processing in background workers so the main UI stays responsive.

## Intended workflow

1. **Camera → Capture Frame.** Start the selected camera view and capture/freeze a full-resolution frame. Resume Live returns to live preview.
2. **Calibrate scale (recommended).** Draw a line between two points and enter the known distance in millimetres. The calculated mm/px scale is stored in the profile. Without calibration, phone detection uses the entered phone dimensions and an adjustable expected width as a percentage of the frame.
3. **Set the phone search area and dimensions.** Defaults are 84 × 163 mm, with an adjustable center and color tolerance. Find Phone Region uses the size/centre prior plus Lab colour similarity and Canny support; when colour/background contrast is inadequate, it can use a dimension-guided fallback. Inspect the Phone Mask output rather than assuming the automatically found contour is correct.
4. **Draw exclusions.** Inspection ROI limits the search domain. Add as many Mask ROIs as needed using rectangle, circle/ellipse, rounded rectangle, capsule/stadium, and free-shape drawing tools. Camera ROI excludes the camera module. Mask and Camera ROI pixels are excluded from illumination statistics and the final detection mask; they are not converted to black to represent missing data.
5. **Build the two phone regions.** Build Edge + Backglass ROIs. The phone silhouette is divided into a consistent distance-transform border band (default 1.1 mm; converted to pixels using calibration or an estimated phone-width scale) and the inner backglass. Mask and camera ROIs are subtracted from both regions.
6. **Optional illumination correction.** Generate and compare Original, Gaussian Divide, Gaussian Subtract, Flat-field, Homomorphic, single-scale Retinex, CLAHE, and the existing LAB correction. Outputs appear in the Correction Preview and Correction Grid tabs. Flat-field requires a suitable reference image. Correction is **not** used by detection unless “Use selected correction for detection” is enabled. By default, detectors run on the original image restricted to the backglass ROI.
7. **Perform Detection.** Select the existing detector plugin(s) and click **PERFORM DETECTION**. The app recomputes phone, edge and backglass masks for the current frame, applies any enabled correction, excludes masked pixels, and runs the current detector logic. This also supports a loaded profile on a new same-resolution image of the same setup.
8. **Save profile and outputs.** Save the profile after calibration, ROI setup and detector selection. It stores phone dimensions, center, edge width, masks/ROIs, camera/source choice, detector settings, optional correction settings and mm/px calibration. Stage outputs can be exported separately for validation.

## Important operating notes

- The phone region is an operator-assisted estimate based on geometry and colour similarity, not a universal semantic detector. Verify its outline on each product/lighting setup. Adjust phone center, dimensions, inspection ROI, expected width, and colour tolerance where needed.
- Use a calibrated scale for a physically meaningful 1.1 mm edge band. If calibration is absent, the app estimates the pixel width from the detected phone width and entered physical width; this estimate is less precise.
- The flat-field reference should match the optical setup and relevant material/lighting condition. A white reference helps characterize the lighting field but does not automatically model every colored reflective surface.
- Software correction cannot restore saturated highlights or detail hidden by sensor noise. Compare correction outputs using known defects and keep Original as the default until tests show that a correction improves defect detection.
- Canny, colour similarity, and distance-transform region construction are heuristics. Confirm repeatability, defect detection rate and false-positive rate before production release.

## Run on Windows

1. Extract the folder.
2. Run `setup_windows.bat`.
3. Run `run_windows.bat`.
4. Select **Simulator** to test without hardware, or **Basler** with supported connected cameras and `pypylon` installed.

## Responsiveness

Camera acquisition and computational stages use separate worker threads. The image viewer supports zooming, fit-to-window, scrolling and resizing. UI variables and image snapshots are read on the main thread before worker jobs begin; output rendering is posted back to Tk's event loop.
