"""Launch the modular industrial phone inspection application."""
from mobile_inspection_app.ui.app import MobileInspectionApp

if __name__ == "__main__":
    MobileInspectionApp().run()
