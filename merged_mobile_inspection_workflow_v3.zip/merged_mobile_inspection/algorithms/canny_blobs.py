from __future__ import annotations
import cv2
import numpy as np
from mobile_inspection_app.detection.base import DetectionAlgorithm, DetectionResult
from algorithms.raw_laplacian import RawLaplacianV1

class CannyBlobs(DetectionAlgorithm):
    name="Canny Blobs"
    version="1.0"
    DEFAULTS={"low_threshold":45,"high_threshold":120,"morph_kernel":3,"min_area_px":20,"max_area_px":2000000,"min_box_size_px":70,"box_expand_ratio":.75,"blob_max_aspect":12,"blob_min_solidity":.08}
    SETTINGS_SCHEMA=[{"key":"low_threshold","label":"Canny low threshold","kind":"int","from":0,"to":255,"step":1},{"key":"high_threshold","label":"Canny high threshold","kind":"int","from":1,"to":255,"step":1},{"key":"morph_kernel","label":"Morphology kernel","kind":"int","from":1,"to":15,"step":2}]
    def process(self,image,inspection_mask=None,context=None):
        context=context or {}; p={**self.DEFAULTS,**context.get("params",{})}; h,w=image.shape[:2]
        mask=np.full((h,w),255,np.uint8) if inspection_mask is None else np.where(inspection_mask>0,255,0).astype(np.uint8)
        gray=cv2.cvtColor(image,cv2.COLOR_BGR2GRAY)
        low=int(p["low_threshold"]); high=max(low+1,int(p["high_threshold"]))
        # Detect on the unblackened image, then apply the valid-region mask. Setting
        # excluded ROI pixels to (0,0,0) before Canny creates artificial borders.
        edges=cv2.Canny(gray,low,high); edges=cv2.bitwise_and(edges,mask)
        clean,boxes=RawLaplacianV1._components(edges,p,mask); out=image.copy()
        for i,b in enumerate(boxes,1):
            cv2.rectangle(out,(b.x,b.y),(b.x+b.w-1,b.y+b.h-1),(0,0,255),3); cv2.putText(out,f"CANNY {i}",(b.x,max(18,b.y-5)),cv2.FONT_HERSHEY_SIMPLEX,.55,(0,0,255),2)
        if not boxes: cv2.putText(out,"NO DEFECTS FLAGGED",(18,32),cv2.FONT_HERSHEY_SIMPLEX,.7,(40,180,40),2)
        return DetectionResult(self.name,out,clean,float(np.count_nonzero(clean)/max(h*w,1)),f"{len(boxes)} candidate blob(s); heuristic edge detector.",boxes,p)
