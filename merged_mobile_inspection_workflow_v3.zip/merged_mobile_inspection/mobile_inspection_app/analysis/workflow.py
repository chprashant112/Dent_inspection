"""Image-processing helpers for the staged phone-inspection workflow.

The functions here are deliberately stateless so they can safely run in worker
threads. All images use OpenCV BGR ordering; masks are uint8 with 0/255 values.
"""
from __future__ import annotations

import cv2
import numpy as np

METHODS = (
    "Original",
    "Gaussian Divide",
    "Gaussian Subtract",
    "Flat-field",
    "Homomorphic",
    "Retinex (single scale)",
    "CLAHE",
    "Existing LAB correction",
)


def _mask_or_full(mask: np.ndarray | None, shape: tuple[int, ...]) -> np.ndarray:
    h, w = shape[:2]
    if mask is None:
        return np.full((h, w), 255, np.uint8)
    if mask.shape[:2] != (h, w):
        raise ValueError("Processing mask size does not match image size")
    return np.where(mask > 0, 255, 0).astype(np.uint8)


def _sigma(image: np.ndarray, sigma_fraction: float) -> float:
    return max(3.0, float(np.clip(sigma_fraction, 0.005, 0.30)) * min(image.shape[:2]))


def _illumination_field(channel: np.ndarray, mask: np.ndarray, sigma: float) -> np.ndarray:
    valid = (mask > 0).astype(np.float32)
    values = channel.astype(np.float32)
    numerator = cv2.GaussianBlur(values * valid, (0, 0), sigmaX=sigma, sigmaY=sigma)
    denominator = cv2.GaussianBlur(valid, (0, 0), sigmaX=sigma, sigmaY=sigma)
    fallback = float(np.median(values[valid > 0])) if np.any(valid) else 128.0
    return np.where(denominator > 1e-4, numerator / np.maximum(denominator, 1e-4), fallback)


def _replace_lab_l(image: np.ndarray, lightness: np.ndarray, valid_mask: np.ndarray) -> np.ndarray:
    lab = cv2.cvtColor(image, cv2.COLOR_BGR2LAB)
    original_l = lab[:, :, 0]
    lab[:, :, 0] = np.where(valid_mask > 0, np.clip(lightness, 0, 255), original_l).astype(np.uint8)
    result = cv2.cvtColor(lab, cv2.COLOR_LAB2BGR)
    result[valid_mask == 0] = image[valid_mask == 0]
    return result


def correct_image(
    image: np.ndarray,
    method: str,
    mask: np.ndarray | None = None,
    strength: float = 0.8,
    sigma_fraction: float = 0.06,
    flat_field: np.ndarray | None = None,
) -> np.ndarray:
    """Apply one illumination/contrast method while keeping the BGR image format.

    Correction methods modify LAB-L and keep chroma as stable as possible. The
    original is never modified in-place. This is a candidate preprocessing step,
    not a recovery method for saturated or photon-starved pixels.
    """
    if image is None or image.size == 0:
        raise ValueError("No captured image is available")
    if image.ndim != 3 or image.shape[2] != 3:
        raise ValueError("Expected a 3-channel BGR image")
    if method == "Original":
        return image.copy()

    valid_mask = _mask_or_full(mask, image.shape)
    valid = valid_mask > 0
    if not np.any(valid):
        return image.copy()
    strength = float(np.clip(strength, 0.0, 1.0))
    lab = cv2.cvtColor(image, cv2.COLOR_BGR2LAB)
    light = lab[:, :, 0].astype(np.float32)
    median_l = float(np.median(light[valid]))
    sigma = _sigma(image, sigma_fraction)

    if method == "Gaussian Subtract" or method == "Existing LAB correction":
        field = _illumination_field(light, valid_mask, sigma)
        target = light - strength * (field - median_l)

    elif method == "Gaussian Divide":
        field = _illumination_field(light, valid_mask, sigma)
        floor = max(5.0, float(np.percentile(field[valid], 10)) * 0.25)
        corrected = light * median_l / np.maximum(field, floor)
        target = light + strength * (corrected - light)

    elif method == "Flat-field":
        if flat_field is None:
            raise ValueError("Load a flat-field reference image first")
        reference = flat_field
        if reference.shape[:2] != image.shape[:2]:
            reference = cv2.resize(reference, (image.shape[1], image.shape[0]), interpolation=cv2.INTER_AREA)
        ref_l = cv2.cvtColor(reference, cv2.COLOR_BGR2LAB)[:, :, 0].astype(np.float32)
        ref_valid = ref_l[valid]
        ref_median = float(np.median(ref_valid)) if ref_valid.size else float(np.median(ref_l))
        smooth_ref = _illumination_field(ref_l, valid_mask, sigma)
        floor = max(5.0, ref_median * 0.10)
        corrected = light * ref_median / np.maximum(smooth_ref, floor)
        target = light + strength * (corrected - light)

    elif method in ("Homomorphic", "Retinex (single scale)"):
        log_l = np.log(np.maximum(light, 1.0) / 255.0)
        # Normalized convolution is essential here: pixels in excluded mask ROIs
        # must not leak into the illumination estimate as dark/black values.
        low = _illumination_field(log_l, valid_mask, sigma)
        residual = log_l - low
        if method == "Homomorphic":
            # Keep a portion of low-frequency content; aggressive high-pass filtering
            # can suppress broad shallow dents, so the correction is intentionally mild.
            log_target = log_l - strength * (low - float(np.median(low[valid])))
            target = np.exp(log_target) * 255.0
        else:
            retinex = residual + float(np.median(log_l[valid]))
            raw = np.exp(retinex) * 255.0
            # Robustly map the result to the source luminance range without allowing
            # a single hot pixel to set the entire contrast range.
            lo, hi = np.percentile(raw[valid], [1.0, 99.0])
            if hi - lo > 1e-5:
                mapped = np.clip((raw - lo) * (255.0 / (hi - lo)), 0, 255)
                mapped_median = float(np.median(mapped[valid]))
                raw = mapped + (median_l - mapped_median)
            target = light + strength * (raw - light)

    elif method == "CLAHE":
        # Mask-aware CLAHE. OpenCV's built-in CLAHE cannot accept a validity mask,
        # so it would count pixels inside excluded ROIs when building tile histograms.
        # Build per-tile LUTs from valid pixels only and interpolate between them.
        light_u8 = np.clip(light, 0, 255).astype(np.uint8)
        rows = cols = 8
        ys = np.linspace(0, image.shape[0], rows + 1, dtype=int)
        xs = np.linspace(0, image.shape[1], cols + 1, dtype=int)
        luts = np.tile(np.arange(256, dtype=np.uint8), (rows, cols, 1))
        for ty in range(rows):
            for tx in range(cols):
                y0, y1, x0, x1 = ys[ty], ys[ty + 1], xs[tx], xs[tx + 1]
                tile_mask = valid[y0:y1, x0:x1]
                if not np.any(tile_mask):
                    continue
                values = light_u8[y0:y1, x0:x1][tile_mask]
                hist = np.bincount(values, minlength=256).astype(np.int64)
                clip_limit = max(1, int(2.0 * max(1, values.size) / 256))
                excess = int(np.maximum(hist - clip_limit, 0).sum())
                hist = np.minimum(hist, clip_limit)
                if excess:
                    batch = excess // 256
                    remainder = excess % 256
                    hist += batch
                    if remainder:
                        hist[:remainder] += 1
                cdf = np.cumsum(hist, dtype=np.float64)
                total = float(cdf[-1])
                if total > 0:
                    lut = np.clip(np.rint(cdf * (255.0 / total)), 0, 255).astype(np.uint8)
                    luts[ty, tx] = lut
        # Blend neighboring tile LUT outputs using coordinates relative to tile centres.
        yy, xx = np.indices(light.shape, dtype=np.float32)
        fy = yy * (rows / max(1, image.shape[0])) - 0.5
        fx = xx * (cols / max(1, image.shape[1])) - 0.5
        y0 = np.floor(fy).astype(np.int32); x0 = np.floor(fx).astype(np.int32)
        wy = fy - y0; wx = fx - x0
        y0c = np.clip(y0, 0, rows - 1); y1c = np.clip(y0 + 1, 0, rows - 1)
        x0c = np.clip(x0, 0, cols - 1); x1c = np.clip(x0 + 1, 0, cols - 1)
        v = light_u8
        a = luts[y0c, x0c, v].astype(np.float32)
        b = luts[y0c, x1c, v].astype(np.float32)
        c = luts[y1c, x0c, v].astype(np.float32)
        d = luts[y1c, x1c, v].astype(np.float32)
        enhanced = (a * (1-wx) * (1-wy) + b * wx * (1-wy) + c * (1-wx) * wy + d * wx * wy)
        target = light + strength * (enhanced - light)
    else:
        raise ValueError(f"Unknown image-processing method: {method}")

    # Protect features outside the selected inspection domain and limit numerical
    # amplification in poorly illuminated areas.
    result = _replace_lab_l(image, target, valid_mask)
    return result


def detect_phone_region(
    image: np.ndarray,
    search_mask: np.ndarray | None = None,
    phone_width_mm: float = 84.0,
    phone_height_mm: float = 163.0,
    mm_per_px: float | None = None,
    center_x_percent: float = 50.0,
    center_y_percent: float = 50.0,
    uncalibrated_width_fraction: float = 0.34,
    color_tolerance: float = 30.0,
    canny_low: int = 35,
    canny_high: int = 110,
    exclude_mask: np.ndarray | None = None,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, str, tuple[int, int, int, int]]:
    """Estimate a centrally located phone region using dimension + colour cues.

    The physical dimensions and optional mm/px calibration provide a strong shape
    prior. A Lab colour-similarity mask attempts to refine the silhouette. When
    surface and background are too similar, a rounded dimension-guided region is
    returned instead of failing with an empty phone mask; the status explicitly
    warns that the contour should be verified.
    """
    if image is None or image.size == 0:
        raise ValueError("Capture a frame before detecting the phone")
    h, w = image.shape[:2]
    if h < 10 or w < 10:
        raise ValueError("Image is too small to detect a phone")
    if phone_width_mm <= 0 or phone_height_mm <= 0:
        raise ValueError("Phone width and height must be positive millimetres")

    domain = _mask_or_full(search_mask, image.shape)
    excluded = np.zeros((h, w), np.uint8) if exclude_mask is None else _mask_or_full(exclude_mask, image.shape)
    # Excluded user ROIs and camera-module ROIs are not used for colour statistics.
    # They do not deform the geometric size prior that defines the phone silhouette.
    valid = cv2.bitwise_and(domain, cv2.bitwise_not(excluded))
    aspect_h_over_w = float(phone_height_mm) / float(phone_width_mm)
    cx = int(round(np.clip(center_x_percent, 0, 100) / 100.0 * (w - 1)))
    cy = int(round(np.clip(center_y_percent, 0, 100) / 100.0 * (h - 1)))

    if mm_per_px is not None and np.isfinite(mm_per_px) and mm_per_px > 0:
        target_w = int(round(float(phone_width_mm) / float(mm_per_px)))
        target_h = int(round(float(phone_height_mm) / float(mm_per_px)))
        size_note = f"calibrated scale {mm_per_px:.5f} mm/px"
    else:
        target_w = int(round(w * float(np.clip(uncalibrated_width_fraction, 0.12, 0.85))))
        target_h = int(round(target_w * aspect_h_over_w))
        size_note = "uncalibrated size estimate from frame-width fraction"

    fit = min(1.0, (w * 0.94) / max(1, target_w), (h * 0.94) / max(1, target_h))
    if fit < 0.999:
        size_note += "; dimensions scaled down to fit image, verify calibration/source view"
    target_w = max(12, int(round(target_w * fit)))
    target_h = max(12, int(round(target_h * fit)))
    x1 = max(0, min(w - 1, cx - target_w // 2))
    y1 = max(0, min(h - 1, cy - target_h // 2))
    x2 = max(x1 + 1, min(w, x1 + target_w))
    y2 = max(y1 + 1, min(h, y1 + target_h))
    # If the ROI/search mask does not overlap the predicted region enough, report
    # that fact; the visual dimension prior remains available for operator review.
    expected = np.zeros((h, w), np.uint8)
    radius = max(4, min((x2 - x1) // 12, (y2 - y1) // 12))
    from mobile_inspection_app.roi.model import ROIShape
    from mobile_inspection_app.roi.shapes import rasterize_shape
    expected_shape = ROIShape("rounded_rectangle", bbox=(x1, y1, x2 - 1, y2 - 1), radius=radius)
    expected[:] = rasterize_shape(expected_shape, image.shape)
    expected = cv2.bitwise_and(expected, domain)

    # For analysis filters, replace excluded pixels using only their valid
    # neighbours. The original exclusion pixels are never used by blur/Canny.
    analysis_image = image
    if cv2.countNonZero(excluded):
        analysis_image = cv2.inpaint(image, excluded, 3, cv2.INPAINT_TELEA)
    lab = cv2.cvtColor(analysis_image, cv2.COLOR_BGR2LAB).astype(np.float32)
    gray = cv2.cvtColor(analysis_image, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(lab, (5, 5), 1.0)
    # Seed from an interior patch, away from the perimeter where the edge band lives.
    seed_pad_x = max(2, int((x2 - x1) * 0.10))
    seed_pad_y = max(2, int((y2 - y1) * 0.10))
    sx1, sx2 = max(x1, cx - seed_pad_x), min(x2, cx + seed_pad_x + 1)
    sy1, sy2 = max(y1, cy - seed_pad_y), min(y2, cy + seed_pad_y + 1)
    seed_mask = valid[sy1:sy2, sx1:sx2] > 0
    seed_patch = blurred[sy1:sy2, sx1:sx2][seed_mask]
    if seed_patch.size == 0:
        # Never sample a masked pixel to create a colour seed. The geometry prior
        # remains usable and will be returned with a low-confidence status instead.
        edges = cv2.Canny(cv2.GaussianBlur(gray, (5, 5), 1.0), max(0, int(canny_low)), max(int(canny_low) + 1, int(canny_high)), L2gradient=True)
        edges[valid == 0] = 0
        phone = expected.copy()
        overlay = image.copy()
        contours, _ = cv2.findContours(phone, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if contours:
            cv2.drawContours(overlay, contours, -1, (40, 230, 80), max(2, int(round(min(h, w) / 500))), cv2.LINE_AA)
        bbox = cv2.boundingRect(max(contours, key=cv2.contourArea)) if contours else (x1, y1, x2-x1, y2-y1)
        return edges, phone, overlay, f"No unmasked central seed pixels; used dimension-guided phone region; bbox={bbox}; {size_note}", bbox
    seed = np.median(seed_patch, axis=0)
    # Reduce luminance weight slightly to tolerate gradual falloff, while retaining
    # chromatic similarity as a useful cue for coloured backs against a neutral field.
    delta = blurred - seed.reshape(1, 1, 3)
    distance = np.sqrt((0.45 * delta[:, :, 0]) ** 2 + delta[:, :, 1] ** 2 + delta[:, :, 2] ** 2)
    seed_dist = distance[sy1:sy2, sx1:sx2][seed_mask] if seed_mask.any() else distance[sy1:sy2, sx1:sx2].ravel()
    spread = float(np.median(np.abs(seed_dist - np.median(seed_dist)))) if seed_dist.size else 0.0
    threshold = float(np.clip(max(float(color_tolerance), np.median(seed_dist) + 4.0 * spread + 8.0), 12.0, 70.0))

    # Restrict colour search to a slightly expanded size-prior box so a uniform
    # background cannot swallow the entire frame.
    margin_x = max(4, int((x2 - x1) * 0.24)); margin_y = max(4, int((y2 - y1) * 0.24))
    rx1, rx2 = max(0, x1 - margin_x), min(w, x2 + margin_x)
    ry1, ry2 = max(0, y1 - margin_y), min(h, y2 + margin_y)
    search = np.zeros((h, w), np.uint8)
    search[ry1:ry2, rx1:rx2] = 255
    search = cv2.bitwise_and(search, valid)
    candidate = ((distance <= threshold) & (search > 0)).astype(np.uint8) * 255
    k = max(3, int(round(min(target_w, target_h) * 0.018)))
    if k % 2 == 0:
        k += 1
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k))
    candidate = cv2.morphologyEx(candidate, cv2.MORPH_CLOSE, kernel, iterations=2)
    candidate = cv2.morphologyEx(candidate, cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3)))

    # Score components using dimension and centre priors. Reject background-sized
    # components and very small patches that only match the central seed.
    n, labels, stats, centroids = cv2.connectedComponentsWithStats((candidate > 0).astype(np.uint8), 8)
    expected_area = float(max(1, cv2.countNonZero(expected)))
    best = None
    best_score = -1e9
    for idx in range(1, n):
        area = float(stats[idx, cv2.CC_STAT_AREA])
        bx, by, bw, bh = [int(v) for v in stats[idx, :4]]
        if area < expected_area * 0.12 or area > expected_area * 1.9:
            continue
        if bw < target_w * 0.45 or bh < target_h * 0.45:
            continue
        if bw > target_w * 1.45 or bh > target_h * 1.45:
            continue
        ratio = max(bw / max(1.0, bh), bh / max(1.0, bw))
        expected_ratio = max(phone_width_mm, phone_height_mm) / min(phone_width_mm, phone_height_mm)
        ratio_error = abs(np.log(max(1e-4, ratio) / expected_ratio))
        ccx, ccy = centroids[idx]
        centre_error = np.hypot((ccx - cx) / max(1.0, target_w), (ccy - cy) / max(1.0, target_h))
        size_error = abs(np.log(max(1.0, bw * bh) / expected_area))
        score = -2.0 * ratio_error - 1.5 * centre_error - 0.35 * size_error + 0.05 * np.log1p(area)
        if score > best_score:
            best_score, best = score, idx

    used_colour = False
    phone = np.zeros((h, w), np.uint8)
    if best is not None:
        component = np.where(labels == best, 255, 0).astype(np.uint8)
        contours, _ = cv2.findContours(component, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if contours:
            cv2.drawContours(phone, [max(contours, key=cv2.contourArea)], -1, 255, cv2.FILLED)
            # Fill small holes and smooth pixel-level boundary noise without expanding
            # arbitrarily beyond the size-guided search.
            phone = cv2.morphologyEx(phone, cv2.MORPH_CLOSE, kernel, iterations=1)
            phone = cv2.bitwise_and(phone, search)
            used_colour = True

    # If colour contrast is insufficient to distinguish phone/background reliably,
    # use the configured dimension-prior shape. This is a deliberate, inspectable
    # fallback (not a claim of high-confidence segmentation).
    if not used_colour or cv2.countNonZero(phone) < expected_area * 0.18:
        phone = expected.copy()
        quality_note = "colour boundary was ambiguous; using dimension-guided rounded phone region (verify outline)"
    else:
        quality_note = "colour-similarity component selected with phone dimension/centre priors"

    phone = cv2.bitwise_and(phone, domain)
    # Excluded ROI pixels must not contribute colour/edge statistics. However,
    # a user mask can cover part of the physical phone outline or cross the body.
    # Reconstitute only the dimension-guided portion underneath exclusions so the
    # silhouette remains geometrically continuous; excluded source intensities are
    # never sampled for this fill. The exclusions are removed from edge/backglass
    # and final detection masks later in the workflow.
    hidden_geometry = cv2.bitwise_and(expected, excluded)
    phone = cv2.bitwise_or(phone, hidden_geometry)
    edges = cv2.Canny(cv2.GaussianBlur(gray, (5, 5), 1.0), max(0, int(canny_low)), max(int(canny_low) + 1, int(canny_high)), L2gradient=True)
    edges[valid == 0] = 0
    overlay = image.copy()
    edge_contours, _ = cv2.findContours(edges, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
    # Display just a thin sample of raw Canny edges; the chosen phone contour is green.
    if edge_contours:
        cv2.drawContours(overlay, edge_contours, -1, (0, 205, 255), 1)
    phone_contours, _ = cv2.findContours(phone, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if phone_contours:
        cv2.drawContours(overlay, phone_contours, -1, (40, 230, 80), max(2, int(round(min(h, w) / 500))), cv2.LINE_AA)
    overlay[:34, :] = (overlay[:34, :].astype(np.float32) * 0.25).astype(np.uint8)
    cv2.putText(overlay, "PHONE REGION / CANNY SUPPORT", (10, 23), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 255, 255), 1, cv2.LINE_AA)
    bbox = cv2.boundingRect(max(phone_contours, key=cv2.contourArea)) if phone_contours else (x1, y1, x2 - x1, y2 - y1)
    message = f"Phone region: {quality_note}; bbox={bbox}; {size_note}; colour threshold={threshold:.1f}"
    return edges, phone, overlay, message, bbox


def make_correction_comparison(outputs: dict[str, np.ndarray], thumbnail_size: tuple[int, int] = (320, 220), columns: int = 3) -> np.ndarray:
    """Create a labeled contact sheet for correction outputs (read-only visualization)."""
    if not outputs:
        raise ValueError("No correction outputs available")
    thumb_w, thumb_h = thumbnail_size
    names = list(outputs.keys())
    rows = int(np.ceil(len(names) / max(1, columns)))
    cell_h = thumb_h + 34
    sheet = np.full((rows * cell_h, columns * thumb_w, 3), 38, np.uint8)
    for idx, name in enumerate(names):
        image = outputs[name]
        r, c = divmod(idx, columns)
        h, w = image.shape[:2]
        scale = min(thumb_w / max(1, w), thumb_h / max(1, h))
        resized = cv2.resize(image, (max(1, int(w * scale)), max(1, int(h * scale))), interpolation=cv2.INTER_AREA if scale < 1 else cv2.INTER_LINEAR)
        canvas = np.full((thumb_h, thumb_w, 3), 20, np.uint8)
        y = (thumb_h - resized.shape[0]) // 2; x = (thumb_w - resized.shape[1]) // 2
        canvas[y:y+resized.shape[0], x:x+resized.shape[1]] = resized
        x0, y0 = c * thumb_w, r * cell_h
        sheet[y0:y0+thumb_h, x0:x0+thumb_w] = canvas
        cv2.putText(sheet, name[:36], (x0 + 8, y0 + thumb_h + 23), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (240, 240, 240), 1, cv2.LINE_AA)
    return sheet

def canny_phone_mask(
    image: np.ndarray,
    search_mask: np.ndarray | None = None,
    low_threshold: int = 35,
    high_threshold: int = 110,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, str]:
    """Use Canny edges and contour closure to estimate the phone silhouette.

    A mask is returned separately from the raw edge map so operators can inspect
    both. This is heuristic and should be checked before using for production.
    """
    if image is None or image.size == 0:
        raise ValueError("Capture a frame before running phone/background separation")
    h, w = image.shape[:2]
    valid = _mask_or_full(search_mask, image.shape)
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    # A light denoise reduces surface texture becoming part of the silhouette.
    gray = cv2.GaussianBlur(gray, (5, 5), 1.0)
    low = max(0, int(low_threshold)); high = max(low + 1, int(high_threshold))
    edges = cv2.Canny(gray, low, high, L2gradient=True)
    edges[valid == 0] = 0

    base = max(5, int(round(min(h, w) * 0.012)))
    if base % 2 == 0:
        base += 1
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (base, base))
    closed = cv2.morphologyEx(edges, cv2.MORPH_CLOSE, kernel, iterations=2)
    closed = cv2.dilate(closed, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3)), iterations=1)
    contours, _ = cv2.findContours(closed, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    best = None
    best_score = -1.0
    image_area = float(h * w)
    for contour in contours:
        area = float(cv2.contourArea(contour))
        x, y, bw, bh = cv2.boundingRect(contour)
        bbox_area = float(bw * bh)
        if area < image_area * 0.015 or bbox_area > image_area * 0.96:
            continue
        aspect = max(bw, bh) / max(1.0, min(bw, bh))
        if aspect < 1.12:
            continue
        # Reward a large, phone-like elongated component near the field centre;
        # do not depend on the phone's actual color.
        cx, cy = x + bw / 2.0, y + bh / 2.0
        centre_penalty = 1.0 / (1.0 + 0.45 * (abs(cx - w / 2) / max(1, w / 2) + abs(cy - h / 2) / max(1, h / 2)))
        elongation_bonus = min(2.0, aspect / 2.0)
        score = area * centre_penalty * elongation_bonus
        if score > best_score:
            best, best_score = contour, score

    phone = np.zeros((h, w), np.uint8)
    if best is not None:
        cv2.drawContours(phone, [best], -1, 255, thickness=cv2.FILLED)
        close_k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (max(3, base), max(3, base)))
        phone = cv2.morphologyEx(phone, cv2.MORPH_CLOSE, close_k, iterations=2)
        phone = cv2.bitwise_and(phone, valid)
        # Retain the larger filled silhouette, not inner camera/lens contours.
        cs, _ = cv2.findContours(phone, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if cs:
            filled = np.zeros_like(phone)
            cv2.drawContours(filled, [max(cs, key=cv2.contourArea)], -1, 255, cv2.FILLED)
            phone = cv2.bitwise_and(filled, valid)
        message = f"Phone contour estimated from Canny; bbox={cv2.boundingRect(best)}"
    else:
        message = "No convincing closed phone contour found. Adjust Canny thresholds, improve contrast, or draw an inspection/search ROI."

    overlay = image.copy()
    overlay[edges > 0] = (0, 220, 255)
    if cv2.countNonZero(phone):
        contours2, _ = cv2.findContours(phone, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        cv2.drawContours(overlay, contours2, -1, (50, 230, 80), max(2, int(round(min(h, w) / 500))))
    return edges, phone, overlay, message


def adaptive_edge_backglass(
    image: np.ndarray,
    phone_mask: np.ndarray,
    edge_width_px: int = 12,
    camera_mask: np.ndarray | None = None,
    exclude_mask: np.ndarray | None = None,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Split a phone silhouette into a distance-transform edge band and back glass."""
    if image is None or phone_mask is None or not np.any(phone_mask):
        raise ValueError("Run Canny phone/background separation successfully first")
    h, w = image.shape[:2]
    phone = _mask_or_full(phone_mask, image.shape)
    contours, _ = cv2.findContours(phone, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        raise ValueError("Phone mask has no external contour")
    cleaned = np.zeros((h, w), np.uint8)
    cv2.drawContours(cleaned, [max(contours, key=cv2.contourArea)], -1, 255, cv2.FILLED)
    # Width is operator controlled but scales up gently for large stitched images.
    nominal = max(2, int(edge_width_px))
    adaptive_min = max(2, int(round(min(h, w) * 0.0025)))
    width = max(nominal, adaptive_min)
    distance = cv2.distanceTransform((cleaned > 0).astype(np.uint8), cv2.DIST_L2, 5)
    edge = np.where((cleaned > 0) & (distance <= width), 255, 0).astype(np.uint8)
    backglass = cv2.bitwise_and(cleaned, cv2.bitwise_not(edge))

    cam = np.zeros((h, w), np.uint8) if camera_mask is None else _mask_or_full(camera_mask, image.shape)
    excludes = np.zeros((h, w), np.uint8) if exclude_mask is None else _mask_or_full(exclude_mask, image.shape)
    edge = cv2.bitwise_and(edge, cv2.bitwise_not(cam))
    backglass = cv2.bitwise_and(backglass, cv2.bitwise_not(cam))
    edge = cv2.bitwise_and(edge, cv2.bitwise_not(excludes))
    backglass = cv2.bitwise_and(backglass, cv2.bitwise_not(excludes))

    overlay = image.copy()
    # Blend the regions only for visualization; source pixels remain unchanged.
    tint = overlay.copy()
    tint[backglass > 0] = (35, 160, 75)
    tint[edge > 0] = (0, 185, 245)
    tint[cam > 0] = (200, 90, 30)
    active = (backglass > 0) | (edge > 0) | (cam > 0)
    overlay[active] = cv2.addWeighted(image, 0.48, tint, 0.52, 0)[active]
    for mask, color in ((backglass, (50, 230, 90)), (edge, (0, 220, 255)), (cam, (255, 100, 40))):
        cs, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        cv2.drawContours(overlay, cs, -1, color, max(2, int(round(min(h, w) / 500))) if color != (50, 230, 90) else 1)
    cv2.putText(overlay, f"Edge band: {width}px", (14, 26), cv2.FONT_HERSHEY_SIMPLEX, 0.65, (0, 220, 255), 2, cv2.LINE_AA)
    return edge, backglass, overlay
