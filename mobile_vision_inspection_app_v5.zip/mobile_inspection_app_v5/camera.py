from __future__ import annotations

import threading
import time
from dataclasses import dataclass
from typing import Optional, Tuple

import cv2
import numpy as np

try:
    from pypylon import pylon
except ImportError:  # Optional until Basler SDK is installed.
    pylon = None


@dataclass
class FramePair:
    camera1: Optional[np.ndarray] = None
    camera2: Optional[np.ndarray] = None

    def stitched(self) -> Optional[np.ndarray]:
        if self.camera1 is None and self.camera2 is None:
            return None
        if self.camera1 is None:
            return self.camera2.copy()
        if self.camera2 is None:
            return self.camera1.copy()
        h = min(self.camera1.shape[0], self.camera2.shape[0])
        c1 = _resize_height(self.camera1, h)
        c2 = _resize_height(self.camera2, h)
        return cv2.hconcat([c1, c2])


def _resize_height(image: np.ndarray, target_h: int) -> np.ndarray:
    if image.shape[0] == target_h:
        return image
    scale = target_h / image.shape[0]
    return cv2.resize(image, (int(image.shape[1] * scale), target_h))


class BaslerCamera:
    """Small adapter around Basler pypylon. Camera-specific settings stay here."""

    def __init__(self, device_index: int, name: str):
        if pylon is None:
            raise RuntimeError("pypylon is not installed. Install Basler pypylon before using Basler cameras.")
        self.device_index = device_index
        self.name = name
        self.camera = None
        self.converter = None

    def open(self) -> None:
        tl_factory = pylon.TlFactory.GetInstance()
        devices = tl_factory.EnumerateDevices()
        if self.device_index >= len(devices):
            raise RuntimeError(f"{self.name}: Basler device index {self.device_index} not found. Found {len(devices)} device(s).")
        self.camera = pylon.InstantCamera(tl_factory.CreateDevice(devices[self.device_index]))
        self.camera.Open()
        self.converter = pylon.ImageFormatConverter()
        self.converter.OutputPixelFormat = pylon.PixelType_BGR8packed
        self.converter.OutputBitAlignment = pylon.OutputBitAlignment_MsbAligned

    def apply_settings(self, exposure_us=None, gain=None, fps=None, width=None, height=None) -> None:
        if self.camera is None:
            return
        node_map = self.camera.GetNodeMap()
        for key, value in (("ExposureTime", exposure_us), ("Gain", gain), ("AcquisitionFrameRate", fps)):
            if value is None:
                continue
            try:
                node = node_map.GetNode(key)
                if node is not None and node.IsWritable():
                    node.SetValue(float(value))
            except Exception:
                pass
        for key, value in (("Width", width), ("Height", height)):
            if value is None:
                continue
            try:
                node = node_map.GetNode(key)
                if node is not None and node.IsWritable():
                    node.SetValue(int(value))
            except Exception:
                pass

    def start(self) -> None:
        if self.camera is None:
            self.open()
        if not self.camera.IsGrabbing():
            self.camera.StartGrabbing(pylon.GrabStrategy_LatestImageOnly)

    def read(self, timeout_ms: int = 500) -> np.ndarray:
        if self.camera is None or not self.camera.IsGrabbing():
            raise RuntimeError(f"{self.name} is not running")
        result = self.camera.RetrieveResult(timeout_ms, pylon.TimeoutHandling_ThrowException)
        try:
            if not result.GrabSucceeded():
                raise RuntimeError(f"{self.name}: grab failed")
            image = self.converter.Convert(result)
            return image.GetArray().copy()
        finally:
            result.Release()

    def stop(self) -> None:
        if self.camera is not None:
            try:
                if self.camera.IsGrabbing():
                    self.camera.StopGrabbing()
            except Exception:
                pass

    def close(self) -> None:
        self.stop()
        if self.camera is not None:
            try:
                if self.camera.IsOpen():
                    self.camera.Close()
            except Exception:
                pass
        self.camera = None


class CameraManager:
    """Owns camera selection and a background latest-frame loop."""

    def __init__(self):
        self.cam1: Optional[BaslerCamera] = None
        self.cam2: Optional[BaslerCamera] = None
        self.use_cam1 = True
        self.use_cam2 = True
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._lock = threading.Lock()
        self._latest = FramePair()

    def configure(self, cam1_cfg, cam2_cfg, use_cam1=True, use_cam2=True):
        self.close()
        self.use_cam1 = use_cam1
        self.use_cam2 = use_cam2
        if use_cam1:
            self.cam1 = BaslerCamera(cam1_cfg.device_index, cam1_cfg.name)
            self.cam1.open()
            self.cam1.apply_settings(cam1_cfg.exposure_us, cam1_cfg.gain, cam1_cfg.fps, cam1_cfg.width, cam1_cfg.height)
            self.cam1.start()
        if use_cam2:
            self.cam2 = BaslerCamera(cam2_cfg.device_index, cam2_cfg.name)
            self.cam2.open()
            self.cam2.apply_settings(cam2_cfg.exposure_us, cam2_cfg.gain, cam2_cfg.fps, cam2_cfg.width, cam2_cfg.height)
            self.cam2.start()

    def start(self):
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(target=self._loop, name="camera-loop", daemon=True)
        self._thread.start()

    def _loop(self):
        while self._running:
            pair = FramePair()
            try:
                if self.use_cam1 and self.cam1:
                    pair.camera1 = self.cam1.read(300)
            except Exception:
                pass
            try:
                if self.use_cam2 and self.cam2:
                    pair.camera2 = self.cam2.read(300)
            except Exception:
                pass
            with self._lock:
                self._latest = pair
            time.sleep(0.001)

    def latest(self) -> FramePair:
        with self._lock:
            return FramePair(
                None if self._latest.camera1 is None else self._latest.camera1.copy(),
                None if self._latest.camera2 is None else self._latest.camera2.copy(),
            )

    def capture_once(self, timeout_s=2.0) -> FramePair:
        deadline = time.time() + timeout_s
        while time.time() < deadline:
            pair = self.latest()
            if pair.camera1 is not None or pair.camera2 is not None:
                return pair
            time.sleep(0.02)
        raise RuntimeError("No camera frame available for capture")

    def stop(self):
        self._running = False
        if self._thread is not None:
            self._thread.join(timeout=1.0)
            self._thread = None

    def close(self):
        self.stop()
        if self.cam1:
            self.cam1.close()
        if self.cam2:
            self.cam2.close()
        self.cam1 = None
        self.cam2 = None

