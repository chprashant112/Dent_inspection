from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Tuple


@dataclass
class CameraConfig:
    name: str
    device_index: int = 0
    exposure_us: float | None = None
    gain: float | None = None
    fps: float | None = None
    width: int | None = None
    height: int | None = None


@dataclass
class LightRecipe:
    name: str
    rgb: Tuple[int, int, int]
    enabled: bool = True

    def validate(self) -> None:
        if len(self.rgb) != 3:
            raise ValueError("RGB must contain exactly 3 values")
        if any(not 0 <= int(v) <= 255 for v in self.rgb):
            raise ValueError("RGB values must be between 0 and 255")


@dataclass
class CaptureConfig:
    output_root: Path = Path("captures")
    settle_ms: int = 150
    camera_timeout_ms: int = 1500
    save_individual_cameras: bool = True
    save_stitched: bool = True


@dataclass
class AppConfig:
    model_name: str = "S24"
    # LIGHT_DUAL_4 = two 4-channel controllers; LIGHT_SINGLE_8 = one 8-channel controller.
    lighting_topology: str = "LIGHT_DUAL_4"
    lighting_baudrate: int = 9600
    camera1: CameraConfig = field(default_factory=lambda: CameraConfig("Camera 1", 0))
    camera2: CameraConfig = field(default_factory=lambda: CameraConfig("Camera 2", 1))
    capture: CaptureConfig = field(default_factory=CaptureConfig)
    light_count: int = 4
