from __future__ import annotations

import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

import cv2
from PIL import Image, ImageTk
import serial.tools.list_ports

from alt_ers_protocol import AltErs4Controller, AltErs8Controller
from camera import CameraManager
from capture_manager import CaptureManager
from config import AppConfig, CaptureConfig, CameraConfig, LightRecipe
from detection import DetectionRegistry, RawLaplacian, OpenCVCanny, UltralyticsPT
from lighting import Dual4LightEngine, Single8LightEngine, SimulatedController, FourChannelControllerAdapter


class CollapsibleCard(ttk.Frame):
    def __init__(self, master, title: str, open_by_default=False, **kwargs):
        super().__init__(master, **kwargs)
        self.columnconfigure(0, weight=1)
        self._open = tk.BooleanVar(value=open_by_default)
        self.header = ttk.Frame(self)
        self.header.grid(row=0, column=0, sticky="ew")
        self.header.columnconfigure(0, weight=1)
        self.button = ttk.Button(self.header, text="", style="Card.TButton", command=self.toggle)
        self.button.grid(row=0, column=0, sticky="ew")
        self.body = ttk.Frame(self, padding=(10, 8, 10, 10))
        if open_by_default:
            self.body.grid(row=1, column=0, sticky="ew")
        self._refresh()

    def toggle(self):
        self._open.set(not self._open.get())
        if self._open.get():
            self.body.grid(row=1, column=0, sticky="ew")
        else:
            self.body.grid_remove()
        self._refresh()

    def _refresh(self):
        mark = "▾" if self._open.get() else "▸"
        self.button.configure(text=f"{mark}  {self.button_text}")

    @property
    def button_text(self):
        return getattr(self, "_title", "Section")

    @button_text.setter
    def button_text(self, value):
        self._title = value
        self._refresh()


class ScrollableFrame(ttk.Frame):
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)
        self.canvas = tk.Canvas(self, highlightthickness=0, borderwidth=0)
        self.scrollbar = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.inner = ttk.Frame(self.canvas)
        self.window_id = self.canvas.create_window((0, 0), window=self.inner, anchor="nw")
        self.canvas.configure(yscrollcommand=self.scrollbar.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        self.scrollbar.pack(side="right", fill="y")
        self.inner.bind("<Configure>", self._on_configure)
        self.canvas.bind("<Configure>", self._on_canvas_configure)
        self.canvas.bind_all("<MouseWheel>", self._on_mousewheel)

    def _on_configure(self, _event=None):
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def _on_canvas_configure(self, event):
        self.canvas.itemconfigure(self.window_id, width=event.width)

    def _on_mousewheel(self, event):
        if self.winfo_exists():
            self.canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")


class Application(tk.Tk):
    """Inspection-station shell. Hardware and detection logic stay outside the UI."""

    def __init__(self):
        super().__init__()
        self.title("Mobile Vision Inspection")
        try:
            self.state("zoomed")
        except tk.TclError:
            # Some window managers (for example Linux/Xvfb) do not expose
            # the Windows-style ``zoomed`` state. Fall back gracefully.
            try:
                self.attributes("-zoomed", True)
            except tk.TclError:
                pass
        self.minsize(1100, 700)
        self.configure(bg="#eef1f4")
        self.protocol("WM_DELETE_WINDOW", self._close)

        self._configure_style()
        self.config_data = AppConfig()
        self.camera_manager = CameraManager()
        self.left_light_controller = None
        self.right_light_controller = None
        self.eight_light_controller = None
        self.light_engine = None
        self._init_lighting_engine()
        self.capture_manager = CaptureManager(
            self.camera_manager, self.light_engine, self.config_data.capture, logger=self._log
        )
        self.detectors = DetectionRegistry()
        self.detectors.register(RawLaplacian())
        self.detectors.register(OpenCVCanny())

        self._last_frame = None
        self._running_feed = False
        self._capture_busy = False
        self._photo = None
        self._build_ui()

    def _configure_style(self):
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("App.TFrame", background="#eef1f4")
        style.configure("Header.TFrame", background="#ffffff")
        style.configure("Title.TLabel", background="#ffffff", foreground="#16202a", font=("Segoe UI", 18, "bold"))
        style.configure("Sub.TLabel", background="#ffffff", foreground="#6b7480", font=("Segoe UI", 9))
        style.configure("Card.TButton", anchor="w", padding=(10, 8), font=("Segoe UI", 10, "bold"))
        style.configure("Section.TLabelframe", padding=2)
        style.configure("Accent.TButton", font=("Segoe UI", 10, "bold"), padding=(12, 9))
        style.configure("BigAccent.TButton", font=("Segoe UI", 12, "bold"), padding=(14, 12))
        style.configure("Status.TLabel", font=("Segoe UI", 10, "bold"))
        style.configure("Mini.TLabel", foreground="#6b7480", font=("Segoe UI", 8))

    def _init_lighting_engine(self):
        """Build the selected lighting topology without changing capture code."""
        topology = self.config_data.lighting_topology
        if topology == "LIGHT_DUAL_4":
            self.left_light_controller = FourChannelControllerAdapter(AltErs4Controller(on_log=self._log_from_worker))
            self.right_light_controller = FourChannelControllerAdapter(AltErs4Controller(on_log=self._log_from_worker))
            self.light_engine = Dual4LightEngine(
                self.left_light_controller, self.right_light_controller,
                settle_ms=self.config_data.capture.settle_ms,
            )
        else:
            self.eight_light_controller = AltErs8Controller(on_log=self._log_from_worker)
            self.light_engine = Single8LightEngine(
                self.eight_light_controller,
                settle_ms=self.config_data.capture.settle_ms,
            )

    # ---------------------------------------------------------------- UI
    def _build_ui(self):
        root = ttk.Frame(self, style="App.TFrame")
        root.pack(fill="both", expand=True)

        header = ttk.Frame(root, style="Header.TFrame", padding=(16, 12))
        header.pack(fill="x")
        header.columnconfigure(1, weight=1)
        ttk.Label(header, text="MOBILE VISION INSPECTION", style="Title.TLabel").grid(row=0, column=0, sticky="w")
        ttk.Label(header, text="Camera • Lighting • Capture • Detection", style="Sub.TLabel").grid(row=1, column=0, sticky="w", pady=(2, 0))
        ttk.Label(header, text="MODEL", style="Mini.TLabel").grid(row=0, column=2, sticky="e", padx=(10, 6))
        self.model_var = tk.StringVar(value=self.config_data.model_name)
        model_entry = ttk.Entry(header, textvariable=self.model_var, width=18, font=("Segoe UI", 11))
        model_entry.grid(row=1, column=2, sticky="e")
        ttk.Button(header, text="Save", command=self._save_model_name).grid(row=1, column=3, padx=(6, 0))

        # 70 / 30 main split
        body = ttk.Frame(root, style="App.TFrame", padding=(10, 8, 10, 10))
        body.pack(fill="both", expand=True)
        body.columnconfigure(0, weight=7)
        body.columnconfigure(1, weight=3)
        body.rowconfigure(0, weight=1)

        left = ttk.Frame(body, style="App.TFrame")
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 8))
        left.columnconfigure(0, weight=1)
        left.rowconfigure(0, weight=7)
        left.rowconfigure(1, weight=3)

        self.preview_frame = ttk.LabelFrame(left, text="LIVE VIEW")
        self.preview_frame.grid(row=0, column=0, sticky="nsew")
        self.preview_label = tk.Label(self.preview_frame, text="Start cameras", bg="#101418", fg="#d7dde3")
        self.preview_label.pack(fill="both", expand=True, padx=5, pady=5)

        self.result_frame = ttk.LabelFrame(left, text="DETECTION / CAPTURE RESULT")
        self.result_frame.grid(row=1, column=0, sticky="nsew", pady=(8, 0))
        self.result_label = tk.Label(self.result_frame, text="No result", bg="#171c21", fg="#d7dde3")
        self.result_label.pack(fill="both", expand=True, padx=5, pady=5)

        right = ScrollableFrame(body)
        right.grid(row=0, column=1, sticky="nsew")
        right.inner.columnconfigure(0, weight=1)

        self._camera_card(right.inner)
        self._lighting_card(right.inner)
        self._capture_card(right.inner)
        self._detection_card(right.inner)
        self._log_card(right.inner)

    def _card(self, parent, title, open_by_default=False):
        card = CollapsibleCard(parent, title, open_by_default=open_by_default)
        card.button_text = title
        card.pack(fill="x", pady=(0, 8))
        return card

    def _camera_card(self, parent):
        card = self._card(parent, "CAMERA", open_by_default=True)
        b = card.body
        b.columnconfigure(1, weight=1)
        self.cam1_var = tk.BooleanVar(value=True)
        self.cam2_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(b, text="Camera 1 • Basler", variable=self.cam1_var).grid(row=0, column=0, sticky="w")
        ttk.Checkbutton(b, text="Camera 2 • Basler", variable=self.cam2_var).grid(row=1, column=0, sticky="w", pady=(5, 0))
        ttk.Label(b, text="View").grid(row=2, column=0, sticky="w", pady=(10, 3))
        self.view_var = tk.StringVar(value="Stitched")
        ttk.Combobox(b, textvariable=self.view_var, values=["Stitched", "Camera 1", "Camera 2"], state="readonly").grid(row=3, column=0, sticky="ew")
        actions = ttk.Frame(b)
        actions.grid(row=4, column=0, sticky="ew", pady=(10, 0))
        actions.columnconfigure(0, weight=1)
        actions.columnconfigure(1, weight=1)
        ttk.Button(actions, text="Start", command=self._start_cameras, style="Accent.TButton").grid(row=0, column=0, sticky="ew", padx=(0, 4))
        ttk.Button(actions, text="Stop", command=self._stop_cameras).grid(row=0, column=1, sticky="ew", padx=(4, 0))

    def _lighting_card(self, parent):
        card = self._card(parent, "LIGHTING", open_by_default=False)
        b = card.body
        b.columnconfigure(0, weight=1)

        ttk.Label(b, text="CONTROLLER TOPOLOGY", style="Mini.TLabel").grid(row=0, column=0, sticky="w")
        self.topology_var = tk.StringVar(value=self.config_data.lighting_topology)
        topology_combo = ttk.Combobox(
            b, textvariable=self.topology_var, state="readonly",
            values=["LIGHT_DUAL_4", "LIGHT_SINGLE_8"]
        )
        topology_combo.grid(row=1, column=0, sticky="ew", pady=(4, 8))
        topology_combo.bind("<<ComboboxSelected>>", self._on_topology_change)

        self.mapping_label = ttk.Label(b, style="Sub.TLabel", justify="left", wraplength=310)
        self.mapping_label.grid(row=2, column=0, sticky="w", pady=(0, 8))

        self.port_area = ttk.Frame(b)
        self.port_area.grid(row=3, column=0, sticky="ew")
        self.port_area.columnconfigure(1, weight=1)
        self._build_light_ports()

        action_row = ttk.Frame(b)
        action_row.grid(row=4, column=0, sticky="ew", pady=(10, 10))
        for c in range(3):
            action_row.columnconfigure(c, weight=1)
        ttk.Button(action_row, text="Connect", command=self._connect_lights, style="Accent.TButton").grid(row=0, column=0, sticky="ew", padx=(0, 4))
        ttk.Button(action_row, text="READY", command=self._all_on_ready).grid(row=0, column=1, sticky="ew", padx=4)
        ttk.Button(action_row, text="ALL OFF", command=self._all_off).grid(row=0, column=2, sticky="ew", padx=(4, 0))

        self.left_rows = self._recipe_editor(b, "LIGHT 1 — 4 • LEFT RGB", 5)
        self.right_rows = self._recipe_editor(b, "LIGHT 1 — 4 • RIGHT RGB", 6)
        self._update_mapping_label()

    def _build_light_ports(self):
        for child in self.port_area.winfo_children():
            child.destroy()

        self._refreshing_ports = True
        ports = [p.device for p in serial.tools.list_ports.comports()]
        ports.append("SIMULATOR")
        self._refreshing_ports = False

        topology = self.topology_var.get()
        if topology == "LIGHT_DUAL_4":
            ttk.Label(self.port_area, text="Left controller").grid(row=0, column=0, sticky="w")
            self.left_port_var = getattr(self, "left_port_var", tk.StringVar())
            self.left_port_combo = ttk.Combobox(self.port_area, textvariable=self.left_port_var, values=ports, state="readonly")
            self.left_port_combo.grid(row=0, column=1, sticky="ew", padx=(8, 0))
            ttk.Label(self.port_area, text="Right controller").grid(row=1, column=0, sticky="w", pady=(7, 0))
            self.right_port_var = getattr(self, "right_port_var", tk.StringVar())
            self.right_port_combo = ttk.Combobox(self.port_area, textvariable=self.right_port_var, values=ports, state="readonly")
            self.right_port_combo.grid(row=1, column=1, sticky="ew", padx=(8, 0), pady=(7, 0))
            for var, combo in ((self.left_port_var, self.left_port_combo), (self.right_port_var, self.right_port_combo)):
                if var.get() not in ports:
                    var.set(ports[0] if ports else "SIMULATOR")
            ttk.Button(self.port_area, text="↻", width=3, command=self._refresh_light_ports).grid(row=0, column=2, padx=(6, 0))
        else:
            ttk.Label(self.port_area, text="8-channel controller").grid(row=0, column=0, sticky="w")
            self.eight_port_var = getattr(self, "eight_port_var", tk.StringVar())
            self.eight_port_combo = ttk.Combobox(self.port_area, textvariable=self.eight_port_var, values=ports, state="readonly")
            self.eight_port_combo.grid(row=0, column=1, sticky="ew", padx=(8, 0))
            if self.eight_port_var.get() not in ports:
                self.eight_port_var.set(ports[0] if ports else "SIMULATOR")
            ttk.Button(self.port_area, text="↻", width=3, command=self._refresh_light_ports).grid(row=0, column=2, padx=(6, 0))

    def _refresh_light_ports(self):
        self._build_light_ports()

    def _update_mapping_label(self):
        if self.topology_var.get() == "LIGHT_DUAL_4":
            text = ("2 × 4-channel controllers\n"
                    "LEFT controller: CH1=R1 • CH2=G1 • CH3=B1 • CH4=unused\n"
                    "RIGHT controller: CH1=R2 • CH2=G2 • CH3=B2 • CH4=unused")
        else:
            text = ("1 × 8-channel controller\n"
                    "CH1=R1 • CH2=G1 • CH3=B1 • CH4=R2 • CH5=G2 • CH6=B2\n"
                    "CH7 / CH8=reserved")
        self.mapping_label.configure(text=text)

    def _on_topology_change(self, _event=None):
        topology = self.topology_var.get()
        if self.light_engine is not None:
            try:
                self.light_engine.all_off()
            except Exception:
                pass
            try:
                self.light_engine.disconnect()
            except Exception:
                pass
        self.config_data.lighting_topology = topology
        self._init_lighting_engine()
        self._build_light_ports()
        self._update_mapping_label()
        self._log(f"INFO: lighting topology = {topology}")

    def _recipe_editor(self, parent, title, row):
        lf = ttk.LabelFrame(parent, text=title)
        lf.grid(row=row, column=0, sticky="ew", pady=(0, 8))
        lf.columnconfigure(0, weight=1)
        rows = []
        for i in range(4):
            outer = ttk.Frame(lf)
            outer.grid(row=i, column=0, sticky="ew", pady=3, padx=5)
            outer.columnconfigure(1, weight=1)
            use = tk.BooleanVar(value=True)
            name = tk.StringVar(value=["WARM", "BLUE", "SKY_GREEN", "NEUTRAL"][i])
            rgb_defaults = [(255, 140, 60), (40, 90, 255), (50, 220, 130), (255, 255, 255)]
            rgb = [tk.IntVar(value=v) for v in rgb_defaults[i]]

            ttk.Checkbutton(outer, variable=use).grid(row=0, column=0, padx=(0, 5))
            ttk.Label(outer, text=f"L{i+1}", width=3).grid(row=0, column=1, sticky="w")
            ttk.Entry(outer, textvariable=name, width=12).grid(row=0, column=2, padx=3)
            for j, (label, var) in enumerate(zip(("R", "G", "B"), rgb), start=3):
                ttk.Spinbox(outer, from_=0, to=255, textvariable=var, width=5).grid(row=0, column=j, padx=2)
            rows.append((use, name, rgb))
        return rows

    def _capture_card(self, parent):
        card = self._card(parent, "CAPTURE", open_by_default=False)
        b = card.body
        b.columnconfigure(0, weight=1)
        self.capture_info = tk.StringVar(value="Select lighting states, then capture a new set")
        ttk.Label(b, textvariable=self.capture_info, style="Sub.TLabel", wraplength=300).grid(row=0, column=0, sticky="w")
        ttk.Button(b, text="CAPTURE SELECTED SET", command=self._capture_async, style="BigAccent.TButton").grid(row=1, column=0, sticky="ew", pady=(10, 5))
        ttk.Label(b, text="Sequence: ON → settle → capture → OFF → next selected light", style="Mini.TLabel").grid(row=2, column=0, sticky="w")

    def _detection_card(self, parent):
        card = self._card(parent, "DETECTION PIPELINE", open_by_default=False)
        b = card.body
        b.columnconfigure(0, weight=1)
        ttk.Label(b, text="Current default: RAW Laplacian", style="Sub.TLabel").grid(row=0, column=0, sticky="w")
        self.detector_var = tk.StringVar(value="RAW Laplacian")
        self.detector_combo = ttk.Combobox(b, textvariable=self.detector_var, values=self.detectors.names(), state="readonly")
        self.detector_combo.grid(row=1, column=0, sticky="ew", pady=(7, 6))
        ttk.Button(b, text="Run Detection on Live Frame", command=self._run_detection).grid(row=2, column=0, sticky="ew", pady=2)
        ttk.Button(b, text="Load .pt Model", command=self._load_pt_model).grid(row=3, column=0, sticky="ew", pady=2)
        ttk.Label(b, text="Planned extension: multi-light image preprocessing + comparison + defect decision.", style="Mini.TLabel", wraplength=300).grid(row=4, column=0, sticky="w", pady=(8, 0))

    def _log_card(self, parent):
        card = self._card(parent, "SYSTEM LOG", open_by_default=False)
        b = card.body
        b.columnconfigure(0, weight=1)
        b.rowconfigure(0, weight=1)
        self.log_text = tk.Text(b, height=8, bg="#101418", fg="#cfe8d2", insertbackground="white", relief="flat", font=("Consolas", 9))
        self.log_text.grid(row=0, column=0, sticky="nsew")

    # ---------------------------------------------------------------- cameras
    def _start_cameras(self):
        if not self.cam1_var.get() and not self.cam2_var.get():
            messagebox.showwarning("Camera", "Select at least one camera.")
            return
        try:
            self.camera_manager.configure(
                CameraConfig("Camera 1", 0), CameraConfig("Camera 2", 1),
                self.cam1_var.get(), self.cam2_var.get()
            )
            self.camera_manager.start()
            self._running_feed = True
            self._log("INFO: cameras started")
            self.after(30, self._update_preview)
        except Exception as ex:
            messagebox.showerror("Camera", str(ex))

    def _stop_cameras(self):
        self._running_feed = False
        self.camera_manager.close()
        self.preview_label.config(image="", text="Camera stopped")

    def _update_preview(self):
        if not self._running_feed:
            return
        pair = self.camera_manager.latest()
        frame = pair.stitched()
        if self.view_var.get() == "Camera 1":
            frame = pair.camera1
        elif self.view_var.get() == "Camera 2":
            frame = pair.camera2
        if frame is not None:
            self._last_frame = frame
            self._show_image(self.preview_label, frame, 1600, 1000)
        self.after(30, self._update_preview)

    # ---------------------------------------------------------------- lighting
    def _connect_lights(self):
        baud = self.config_data.lighting_baudrate
        try:
            if self.topology_var.get() == "LIGHT_DUAL_4":
                lp, rp = self.left_port_var.get(), self.right_port_var.get()
                if not lp or not rp:
                    raise RuntimeError("Select both controller ports.")
                if lp == "SIMULATOR":
                    self.left_light_controller = SimulatedController(4, self._log, "LEFT-4CH")
                elif not isinstance(self.left_light_controller, FourChannelControllerAdapter):
                    self.left_light_controller = FourChannelControllerAdapter(AltErs4Controller(on_log=self._log_from_worker))
                if rp == "SIMULATOR":
                    self.right_light_controller = SimulatedController(4, self._log, "RIGHT-4CH")
                elif not isinstance(self.right_light_controller, FourChannelControllerAdapter):
                    self.right_light_controller = FourChannelControllerAdapter(AltErs4Controller(on_log=self._log_from_worker))
                self.light_engine = Dual4LightEngine(self.left_light_controller, self.right_light_controller, self.config_data.capture.settle_ms)
                self.left_light_controller.connect(lp, baud)
                self.right_light_controller.connect(rp, baud)
                self._log(f"INFO: dual 4-channel controllers connected: LEFT={lp}, RIGHT={rp}")
            else:
                port = self.eight_port_var.get()
                if not port:
                    raise RuntimeError("Select the 8-channel controller port.")
                if port == "SIMULATOR":
                    self.eight_light_controller = SimulatedController(8, self._log, "8CH")
                elif not isinstance(self.eight_light_controller, AltErs8Controller):
                    self.eight_light_controller = AltErs8Controller(on_log=self._log_from_worker)
                self.light_engine = Single8LightEngine(self.eight_light_controller, self.config_data.capture.settle_ms)
                self.eight_light_controller.connect(port, baud)
                self._log(f"INFO: single 8-channel controller connected: {port}")
        except Exception as ex:
            messagebox.showerror("Lighting connection", str(ex))

    def _all_on_ready(self):
        try:
            self.light_engine.apply_pair((255, 255, 255), (255, 255, 255))
            self._log("INFO: both RGB lights ON / ready")
        except Exception as ex:
            messagebox.showerror("Lighting", str(ex))

    def _all_off(self):
        try:
            self.light_engine.all_off()
            self._log("INFO: all lighting channels OFF")
        except Exception as ex:
            self._log(f"ERROR: {ex}")

    # ---------------------------------------------------------------- capture / detection
    def _get_recipes(self, rows):
        out = []
        for use, name, rgb in rows:
            out.append(LightRecipe(name.get().strip(), tuple(v.get() for v in rgb), use.get()))
        return out

    def _capture_async(self):
        if self._capture_busy:
            return
        if not self._running_feed:
            messagebox.showwarning("Capture", "Start the camera(s) before capture.")
            return
        self._capture_busy = True
        self.capture_info.set("Capturing selected lighting states…")
        threading.Thread(target=self._capture_worker, daemon=True).start()

    def _capture_worker(self):
        try:
            left = self._get_recipes(self.left_rows)
            right = self._get_recipes(self.right_rows)
            selected = [i for i in range(4) if left[i].enabled and right[i].enabled]
            set_dir, manifest = self.capture_manager.capture_selected(self.model_var.get().strip(), left, right, selected)
            self.after(0, lambda: self.capture_info.set(f"Saved {len(manifest)} lighting images → {set_dir}"))
            self.after(0, lambda: messagebox.showinfo("Capture Complete", f"Saved to:\n{set_dir}"))
        except Exception as ex:
            self.after(0, lambda: messagebox.showerror("Capture", str(ex)))
            self.after(0, lambda: self.capture_info.set("Capture failed — check System Log"))
        finally:
            self._capture_busy = False

    def _run_detection(self):
        if self._last_frame is None:
            messagebox.showwarning("Detection", "Start cameras first.")
            return
        try:
            result = self.detectors.get(self.detector_var.get()).process(self._last_frame)
            self._show_image(self.result_label, result.output, 1000, 350)
            self._log(f"DETECTION [{result.algorithm}] {result.message}")
        except Exception as ex:
            messagebox.showerror("Detection", str(ex))

    def _load_pt_model(self):
        path = filedialog.askopenfilename(title="Select .pt model", filetypes=[("PyTorch / YOLO model", "*.pt"), ("All files", "*.*")])
        if not path:
            return
        try:
            detector = UltralyticsPT(path)
            self.detectors.register(detector)
            self.detector_combo["values"] = self.detectors.names()
            self.detector_var.set(detector.name)
            self._log(f"INFO: loaded .pt model: {path}")
        except Exception as ex:
            messagebox.showerror("Model", f"Could not load .pt model:\n{ex}")

    # ---------------------------------------------------------------- helpers
    def _save_model_name(self):
        model = self.model_var.get().strip()
        if not model:
            messagebox.showwarning("Model", "Enter a model name.")
            return
        self.config_data.model_name = model
        self._log(f"INFO: model = {model}")

    def _show_image(self, label, frame, max_w, max_h):
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        image = Image.fromarray(rgb)
        image.thumbnail((max_w, max_h), Image.Resampling.LANCZOS)
        photo = ImageTk.PhotoImage(image=image)
        label.configure(image=photo, text="")
        label.image = photo

    def _log(self, line):
        if hasattr(self, "log_text"):
            self.log_text.insert("end", str(line) + "\n")
            self.log_text.see("end")

    def _log_from_worker(self, line):
        self.after(0, lambda: self._log(line))

    def _close(self):
        try:
            self.light_engine.all_off()
        except Exception:
            pass
        self.camera_manager.close()
        try:
            if self.light_engine is not None:
                self.light_engine.disconnect()
        except Exception:
            pass
        self.destroy()


if __name__ == "__main__":
    Application().mainloop()
