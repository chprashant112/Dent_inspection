"""ALT-E4RS serial protocol implementations.

The 4-channel frame is the supplied/confirmed implementation.
The 8-channel frame remains isolated as a separate implementation because its
exact wire format should be verified against the 8-channel hardware before
production use.
"""

from __future__ import annotations

import threading
import time
import serial


def _clamp(v):
    return max(0, min(255, int(v)))


def build_frame(levels):
    """Confirmed 4-channel frame: 4C 15 CH1 CH2 CH3 CH4 XOR CR LF."""
    if len(levels) != 4:
        raise ValueError("4-channel frame requires exactly 4 values")
    msg = bytearray(9)
    msg[0] = 0x4C
    msg[1] = 0x15
    for i in range(4):
        msg[2 + i] = _clamp(levels[i])
    msg[6] = msg[1] ^ msg[2] ^ msg[3] ^ msg[4] ^ msg[5]
    msg[7] = 0x0D
    msg[8] = 0x0A
    return bytes(msg)


def build_8channel_frame(levels):
    """Inferred 8-channel extension; verify before production hardware use."""
    if len(levels) != 8:
        raise ValueError("8-channel frame requires exactly 8 values")
    msg = bytearray(13)
    msg[0] = 0x4C
    msg[1] = 0x15
    for i in range(8):
        msg[2 + i] = _clamp(levels[i])
    checksum = msg[1]
    for i in range(2, 10):
        checksum ^= msg[i]
    msg[10] = checksum
    msg[11] = 0x0D
    msg[12] = 0x0A
    return bytes(msg)


class _SerialBase:
    frame_builder = None
    channel_count = 0

    def __init__(self, on_log=None):
        self._port = None
        self._lock = threading.Lock()
        self._on_log = on_log or (lambda line: None)

    @property
    def is_open(self):
        return self._port is not None and self._port.is_open

    def connect(self, port_name, baudrate=9600):
        self.disconnect()
        self._port = serial.Serial(
            port=port_name,
            baudrate=baudrate,
            bytesize=serial.EIGHTBITS,
            parity=serial.PARITY_NONE,
            stopbits=serial.STOPBITS_ONE,
            timeout=0.3,
            write_timeout=2,
        )
        self._log(f"INFO: opened {port_name} @ {baudrate} baud")

    def disconnect(self):
        if self._port is not None:
            try:
                if self._port.is_open:
                    self._port.close()
            except Exception:
                pass
            self._port = None

    def _send(self, levels):
        if not self.is_open:
            raise RuntimeError("Light controller is not connected")
        if len(levels) != self.channel_count:
            raise ValueError(f"Expected {self.channel_count} channel values")
        frame = self.frame_builder(levels)
        with self._lock:
            self._log("TX: " + frame.hex(" ").upper())
            self._port.write(frame)
            time.sleep(0.02)

    def _log(self, line):
        try:
            self._on_log(line)
        except Exception:
            pass


class AltErs4Controller(_SerialBase):
    channel_count = 4
    frame_builder = staticmethod(build_frame)

    def set_all(self, levels):
        self._send(levels)

    def set_channels(self, levels):
        self.set_all(levels)

    def all_off(self):
        self.set_all([0] * 4)


class AltErs8Controller(_SerialBase):
    channel_count = 8
    frame_builder = staticmethod(build_8channel_frame)

    def set_channels(self, levels):
        self._send(levels)

    def all_off(self):
        self.set_channels([0] * 8)


# Existing name kept for compatibility with earlier versions.
AltErsController = AltErs8Controller
