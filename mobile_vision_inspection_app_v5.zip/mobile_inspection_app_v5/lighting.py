from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Protocol, Sequence


class ChannelController(Protocol):
    def connect(self, port_name: str, baudrate: int = 9600): ...
    def disconnect(self): ...
    def set_channels(self, levels: Sequence[int]): ...
    def all_off(self): ...


@dataclass
class RgbMapping:
    """Physical RGB channel mapping for the selected controller topology.

    Single 8-channel controller:
        CH1=R1, CH2=G1, CH3=B1,
        CH4=R2, CH5=G2, CH6=B2,
        CH7/CH8 reserved.

    Dual 4-channel controllers:
        Controller A CH1..CH3 = left RGB; CH4 unused.
        Controller B CH1..CH3 = right RGB; CH4 unused.
    """

    left_channels: tuple[int, int, int]
    right_channels: tuple[int, int, int]


class SimulatedController:
    def __init__(self, channel_count: int, logger=print, label="SIM"):
        self.channel_count = channel_count
        self.logger = logger
        self.label = label
        self.levels = [0] * channel_count
        self.connected = False

    def connect(self, port_name="SIMULATOR", baudrate=9600):
        self.connected = True
        self.logger(f"SIM CONNECT {self.label}: {port_name} @ {baudrate}")

    def disconnect(self):
        if self.connected:
            self.logger(f"SIM DISCONNECT {self.label}")
        self.connected = False

    def set_channels(self, levels):
        if len(levels) != self.channel_count:
            raise ValueError(f"Exactly {self.channel_count} channel values are required")
        self.levels = [max(0, min(255, int(v))) for v in levels]
        self.logger(f"SIM {self.label} CH1..CH{self.channel_count}: " + ", ".join(map(str, self.levels)))

    def all_off(self):
        self.set_channels([0] * self.channel_count)


class FourChannelControllerAdapter:
    """Adapter around the confirmed 4-channel ALT protocol."""

    def __init__(self, controller):
        self.controller = controller

    def connect(self, port_name: str, baudrate: int = 9600):
        self.controller.connect(port_name, baudrate)

    def disconnect(self):
        self.controller.disconnect()

    def set_channels(self, levels: Sequence[int]):
        if len(levels) != 4:
            raise ValueError("Exactly 4 channel values are required")
        self.controller.set_all(levels)

    def all_off(self):
        self.controller.all_off()


class Single8LightEngine:
    """Two RGB lights controlled by one 8-channel controller."""

    channel_count = 8
    topology_name = "1 × 8-channel controller"

    def __init__(self, controller: ChannelController, settle_ms: int = 150):
        self.controller = controller
        self.mapping = RgbMapping((0, 1, 2), (3, 4, 5))
        self.settle_ms = settle_ms

    def apply_pair(self, left_rgb, right_rgb):
        left_rgb = _clip_rgb(left_rgb)
        right_rgb = _clip_rgb(right_rgb)
        levels = [0] * 8
        for idx, value in zip(self.mapping.left_channels, left_rgb):
            levels[idx] = value
        for idx, value in zip(self.mapping.right_channels, right_rgb):
            levels[idx] = value
        self.controller.set_channels(levels)
        time.sleep(self.settle_ms / 1000.0)

    def all_off(self):
        self.controller.all_off()

    def disconnect(self):
        self.controller.disconnect()


class Dual4LightEngine:
    """Two independent 4-channel controllers: one dedicated to each RGB light."""

    channel_count = 4
    topology_name = "2 × 4-channel controllers"

    def __init__(self, left_controller: ChannelController, right_controller: ChannelController, settle_ms: int = 150):
        self.left_controller = left_controller
        self.right_controller = right_controller
        self.settle_ms = settle_ms

    def apply_pair(self, left_rgb, right_rgb):
        left_rgb = _clip_rgb(left_rgb)
        right_rgb = _clip_rgb(right_rgb)

        # CH1=R, CH2=G, CH3=B, CH4 is intentionally left OFF/reserved.
        self.left_controller.set_channels([left_rgb[0], left_rgb[1], left_rgb[2], 0])
        self.right_controller.set_channels([right_rgb[0], right_rgb[1], right_rgb[2], 0])
        time.sleep(self.settle_ms / 1000.0)

    def all_off(self):
        errors = []
        for controller in (self.left_controller, self.right_controller):
            try:
                controller.all_off()
            except Exception as exc:
                errors.append(exc)
        if errors:
            raise errors[0]

    def disconnect(self):
        for controller in (self.left_controller, self.right_controller):
            try:
                controller.disconnect()
            except Exception:
                pass


def _clip_rgb(rgb):
    if len(rgb) != 3:
        raise ValueError("RGB must contain exactly 3 values")
    return tuple(max(0, min(255, int(v))) for v in rgb)


# Backward-compatible name used by earlier code.
LightEngine = Single8LightEngine
RgbPair = RgbMapping
SimulatedEightChannelController = lambda logger=print: SimulatedController(8, logger, "8CH")
