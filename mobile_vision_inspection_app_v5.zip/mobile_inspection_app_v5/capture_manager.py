from __future__ import annotations

import re
from datetime import datetime
from pathlib import Path

import cv2

from config import CaptureConfig, LightRecipe


def safe_name(text: str) -> str:
    text = re.sub(r"[^A-Za-z0-9._-]+", "_", text.strip())
    return text or "unnamed"


class CaptureManager:
    def __init__(self, camera_manager, light_engine, config: CaptureConfig, logger=print):
        self.camera_manager = camera_manager
        self.light_engine = light_engine
        self.config = config
        self.logger = logger
        self.capture_count = 0

    def _next_set_dir(self, model_name: str) -> Path:
        root = Path(self.config.output_root) / safe_name(model_name)
        root.mkdir(parents=True, exist_ok=True)
        numbers = [
            int(m.group(1))
            for p in root.glob("set*")
            if (m := re.fullmatch(r"set(\d+)", p.name, flags=re.I))
        ]
        next_number = max(numbers, default=0) + 1
        self.capture_count = next_number
        path = root / f"set{next_number}"
        path.mkdir(parents=True, exist_ok=False)
        return path

    def capture_selected(self, model_name: str, left_recipes: list[LightRecipe], right_recipes: list[LightRecipe], selected_indices: list[int]):
        if not selected_indices:
            raise ValueError("Select at least one lighting state before Capture.")

        set_dir = self._next_set_dir(model_name)
        manifest = []

        for idx in selected_indices:
            left = left_recipes[idx]
            right = right_recipes[idx]
            left.validate()
            right.validate()

            lighting_name = safe_name(left.name.strip() or right.name.strip() or f"Light_{idx + 1}")
            self.logger(f"CAPTURE {idx + 1}: {lighting_name} | L={left.rgb} R={right.rgb}")
            self.light_engine.apply_pair(left.rgb, right.rgb)
            try:
                pair = self.camera_manager.capture_once(self.config.camera_timeout_ms / 1000.0)
            finally:
                self.light_engine.all_off()

            saved = []
            if self.config.save_stitched:
                stitched = pair.stitched()
                if stitched is not None:
                    out = set_dir / f"{lighting_name}_stitched.png"
                    cv2.imwrite(str(out), stitched)
                    saved.append(out.name)

            if self.config.save_individual_cameras:
                if pair.camera1 is not None:
                    out = set_dir / f"{lighting_name}_camera1.png"
                    cv2.imwrite(str(out), pair.camera1)
                    saved.append(out.name)
                if pair.camera2 is not None:
                    out = set_dir / f"{lighting_name}_camera2.png"
                    cv2.imwrite(str(out), pair.camera2)
                    saved.append(out.name)

            manifest.append({
                "light_index": idx + 1,
                "name": lighting_name,
                "left_rgb": left.rgb,
                "right_rgb": right.rgb,
                "files": saved,
            })

        (set_dir / "manifest.txt").write_text(
            "Capture time: " + datetime.now().isoformat() + "\n" + repr(manifest),
            encoding="utf-8",
        )
        self.logger(f"CAPTURE COMPLETE: {set_dir}")
        return set_dir, manifest
