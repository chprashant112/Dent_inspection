# Mobile Vision Inspection — v4

Modular inspection-station GUI for Basler cameras and configurable RGB lighting.

## Lighting controller modes

The GUI supports two hardware topologies and can be switched from **LIGHTING → Controller Topology**:

### `LIGHT_DUAL_4`
Two independent 4-channel controllers / two serial ports.

- Left controller: CH1=R1, CH2=G1, CH3=B1, CH4 unused
- Right controller: CH1=R2, CH2=G2, CH3=B2, CH4 unused

This mode uses the supplied confirmed 4-channel frame implementation.

### `LIGHT_SINGLE_8`
One 8-channel controller / one serial port.

- CH1=R1
- CH2=G1
- CH3=B1
- CH4=R2
- CH5=G2
- CH6=B2
- CH7/CH8 reserved

The 8-channel wire frame remains isolated in `alt_ers_protocol.py`. Its exact format should be verified against the actual 8-channel controller before production use.

## Capture

The capture manager is topology-independent. It turns the selected left/right RGB recipes on sequentially, captures the configured camera view, turns the lights off, and saves files under:

`captures/<MODEL>/setN/`

Images are named from the lighting recipe names, e.g. `WARM_stitched.png`.

## Architecture

- `app.py` — GUI and orchestration only
- `camera.py` — camera abstraction
- `lighting.py` — topology-neutral lighting engine
- `alt_ers_protocol.py` — 4/8 channel serial protocols
- `capture_manager.py` — sequential light/capture workflow
- `detection.py` — pluggable detection algorithms
- `config.py` — application configuration

Run:

```bash
pip install -r requirements.txt
python app.py
```
